"""Check the built bundle and relocated DMG; never install or touch user settings."""
import hashlib, json, os, plistlib, shutil, subprocess, tarfile
from pathlib import Path
R=Path.cwd(); OUT=R/'build/updater-llvm/artifact-checks';OUT.mkdir(parents=True,exist_ok=False)
APP=R/'dist/MLXL3 Desktop.app';RT=APP/'Contents/Resources/runtime'
TAR=R/'dist/MLXL3-Engine-v1.4.6-arm64.tar.gz';DMG=R/'dist/MLXL3-Desktop-v1.4.6-b28-Apple-Silicon.dmg'
report={'status':'running','checks':[],'installed_app_replaced':False,'signing':'ad-hoc; not notarized'}
def save():
 p=OUT/'report.tmp';p.write_text(json.dumps(report,indent=2));p.replace(OUT/'report.json')
def check(name,condition):
 assert condition,name
 report['checks'].append(name);save()
def digest(data):return hashlib.sha256(data).hexdigest()
def run(name,args):
 p=subprocess.run(args,capture_output=True,timeout=90,check=False,env={k:v for k,v in os.environ.items() if not k.startswith(('MLXL3_','DYLD_'))})
 (OUT/f'{name}.stdout').write_bytes(p.stdout);(OUT/f'{name}.stderr').write_bytes(p.stderr)
 check(name,p.returncode==0);return p.stdout
mounted=False;mount=OUT/'mount';mount.mkdir()
try:
 save();head=run('source-head',['git','rev-parse','HEAD']).decode().strip()
 info=json.loads((APP/'Contents/Resources/build-info.json').read_text())
 check('clean-source-metadata',info['commit']==head and info['tracked_changes'] is False)
 check('desktop-version',info['version']=='1.4.6' and str(info['build'])=='28')
 runtime=json.loads(run('runtime-info',[str(RT/'mlxl3'),'runtime-info']))
 check('release-runtime-identity',runtime['version']=='1.4.6' and runtime['profile']=='release' and runtime['mlx_enabled'] is True and runtime['chat_enabled'] is True and head.startswith(runtime['commit']))
 engine=json.loads((RT/'engine.json').read_text());names={'mlxl3','libmlx.dylib','libjaccl.dylib','mlx.metallib'}
 check('engine-manifest-contract',engine['version']=='1.4.6' and engine['minimum_macos']=='26.2.0' and set(engine['files'])==names)
 for name in sorted(names):
  data=(RT/name).read_bytes();record=engine['files'][name]
  check('runtime-sha-'+name,record['size']==len(data) and record['sha256']==digest(data))
 with tarfile.open(TAR) as archive:
  members=archive.getmembers();check('engine-archive-members',len(members)==5 and {m.name for m in members}==names|{'engine.json'} and all(m.isfile() for m in members))
  for member in members:check('archive-identical-'+member.name,archive.extractfile(member).read()==(RT/member.name).read_bytes())
 manifest=R/'dist/MLXL3-Engine-v1.4.6-arm64.json';shutil.copyfile(RT/'engine.json',manifest)
 for name,path in [('app',APP),('runtime',RT/'mlxl3'),('libmlx',RT/'libmlx.dylib'),('libjaccl',RT/'libjaccl.dylib')]:
  run('signature-'+name,['codesign','--verify','--deep','--strict',str(path)])
 for name,path in [('desktop',APP/'Contents/MacOS/MLXL3Studio'),('runtime',RT/'mlxl3'),('libmlx',RT/'libmlx.dylib'),('libjaccl',RT/'libjaccl.dylib')]:
  check('arm64-'+name,run('architecture-'+name,['lipo','-archs',str(path)]).strip()==b'arm64')
 check('runtime-min-os',b'minos 26.2' in run('runtime-load-commands',['otool','-l',str(RT/'mlxl3')]))
 check('math-fonts-present',any((APP/'Contents/Resources/mathFonts.bundle').rglob('*.otf')))
 for name,flag in [('chat-timeline','--check-chat-timeline'),('mcp-preferences','--check-mcp-preferences')]:run(name,[str(APP/'Contents/MacOS/MLXL3Studio'),flag])
 check('settings-footer-removed',b'Powered by MTPLX' not in (APP/'Contents/MacOS/MLXL3Studio').read_bytes())
 run('dmg-checksum',['hdiutil','verify',str(DMG)])
 run('dmg-attach',['hdiutil','attach','-readonly','-nobrowse','-mountpoint',str(mount),str(DMG)]);mounted=True
 relocated=mount/'MLXL3 Desktop.app'
 original={str(p.relative_to(APP)):digest(p.read_bytes()) for p in APP.rglob('*') if p.is_file()}
 actual={str(p.relative_to(relocated)):digest(p.read_bytes()) for p in relocated.rglob('*') if p.is_file()}
 check('dmg-app-bytes-identical',original==actual and len(original)>10)
 run('dmg-signature',['codesign','--verify','--deep','--strict',str(relocated)])
 check('relocated-runtime',json.loads(run('relocated-runtime-info',[str(relocated/'Contents/Resources/runtime/mlxl3'),'runtime-info']))==runtime)
 report['assets']=[{'name':p.name,'size':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in (DMG,TAR,manifest)]
 report.update(status='complete',source_commit=head,build_info=info,runtime_info=runtime)
except BaseException as error:
 report.update(status='failed',error={'type':type(error).__name__,'message':str(error)});raise
finally:
 if mounted or mount.is_mount():
  try:run('dmg-detach',['hdiutil','detach',str(mount)]);report['dmg_detached']=True
  except BaseException as error:report.update(status='failed',dmg_detached=False,cleanup_error=str(error));save();raise
 save()
print(json.dumps({'status':report['status'],'checks':len(report['checks']),'source_commit':report['source_commit'],'assets':report['assets']}))
