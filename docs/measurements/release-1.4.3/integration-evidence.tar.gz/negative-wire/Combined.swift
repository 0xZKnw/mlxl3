import AppKit
import CryptoKit
import Darwin
import Foundation

struct AppUpdateRelease: Sendable, Equatable {
    let version: String
    let tag: String
    let title: String
    let notes: String
    let pageURL: URL
    let asset: AppUpdateAsset
    var build: Int {
        guard let range = asset.name.range(of: "-b[0-9]+-", options: .regularExpression) else { return 0 }
        return Int(asset.name[range].dropFirst(2).dropLast()) ?? 0
    }
}

struct AppUpdateAsset: Sendable, Equatable {
    let name: String
    let downloadURL: URL
    let size: Int64
    let digest: String?
}

enum AppUpdateState: Equatable {
    case idle
    case checking
    case upToDate(checkedAt: Date)
    case downloading(AppUpdateRelease)
    case ready(release: AppUpdateRelease, diskImage: URL)
    case installing(AppUpdateRelease)
    case failed(String)

    var isBusy: Bool {
        switch self {
        case .checking, .downloading, .installing: true
        default: false
        }
    }

    var readyRelease: AppUpdateRelease? {
        guard case let .ready(release, _) = self else { return nil }
        return release
    }
}

struct SemanticVersion: Comparable, Sendable {
    let components: [Int]

    init?(_ rawValue: String) {
        var version = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
        if version.hasPrefix("v") || version.hasPrefix("V") { version.removeFirst() }
        let pieces = version.split(separator: ".", omittingEmptySubsequences: false)
        guard (1...3).contains(pieces.count) else { return nil }
        var parsed: [Int] = []
        for piece in pieces {
            guard !piece.isEmpty, piece.utf8.allSatisfy({ (48...57).contains($0) }),
                  piece.count == 1 || !piece.hasPrefix("0"),
                  let number = Int(piece), number >= 0 else { return nil }
            parsed.append(number)
        }
        while parsed.count > 1 && parsed.last == 0 { parsed.removeLast() }
        components = parsed
    }

    static func < (lhs: SemanticVersion, rhs: SemanticVersion) -> Bool {
        let count = max(lhs.components.count, rhs.components.count)
        for index in 0..<count {
            let left = index < lhs.components.count ? lhs.components[index] : 0
            let right = index < rhs.components.count ? rhs.components[index] : 0
            if left != right { return left < right }
        }
        return false
    }
}

@MainActor
final class UpdateManager: ObservableObject {
    nonisolated static let repository = "0xZKnw/mlxl3"

    @Published private(set) var state: AppUpdateState = .idle
    @Published private(set) var latestRelease: AppUpdateRelease?
    @Published private(set) var engineState: AppUpdateState = .idle
    @Published private(set) var engineRelease: AppUpdateRelease?
    @Published private(set) var currentEngineVersion: String

    let currentVersion: String
    let currentBuild: Int
    private let releasesURL: URL
    private var updateTask: Task<Void, Never>?
    private var didRunAutomaticCheck = false

    init(
        currentVersion: String = Bundle.main.object(
            forInfoDictionaryKey: "CFBundleShortVersionString"
        ) as? String ?? "0.0.0",
        releasesURL: URL = URL(
            string: "https://api.github.com/repos/0xZKnw/mlxl3/releases?per_page=100"
        )!
    ) {
        self.currentVersion = currentVersion
        self.currentBuild = Int(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0") ?? 0
        self.releasesURL = releasesURL
        self.currentEngineVersion = EngineRuntimeStore.installedVersion()
    }

    deinit {
        updateTask?.cancel()
    }

    var hasAppUpdate: Bool {
        switch state {
        case .downloading, .ready, .installing:
            return true
        default:
            guard let latestRelease,
                  let current = SemanticVersion(currentVersion),
                  let latest = SemanticVersion(latestRelease.version)
            else { return false }
            return latest > current || (latest == current && latestRelease.build > currentBuild)
        }
    }

    var hasAvailableUpdate: Bool { hasAppUpdate || hasEngineUpdate }
    var hasEngineUpdate: Bool {
        switch engineState {
        case .downloading, .ready, .installing: true
        default:
            if let release = engineRelease, let current = SemanticVersion(currentEngineVersion),
               let latest = SemanticVersion(release.version) { latest > current } else { false }
        }
    }
    var hasReadyUpdate: Bool { state.readyRelease != nil || engineState.readyRelease != nil }
    var isBusy: Bool { state.isBusy || engineState.isBusy }
    var isInstalling: Bool {
        if case .installing = state { return true }
        if case .installing = engineState { return true }
        return false
    }

    func startAutomaticCheck() {
        guard !didRunAutomaticCheck else { return }
        didRunAutomaticCheck = true
        checkForUpdates()
    }

    func checkForUpdates() {
        guard !isBusy else { return }
        updateTask?.cancel()
        state = .checking
        engineState = .checking
        updateTask = Task { [weak self] in
            guard let self else { return }
            do {
                let data = try await Self.fetchReleases(from: releasesURL, currentVersion: currentVersion)
                try Task.checkCancellation()
                let release = try Self.selectRelease(data, channel: .app)
                latestRelease = release
                if let release, let current = SemanticVersion(currentVersion),
                   let latest = SemanticVersion(release.version),
                   latest > current || (latest == current && release.build > currentBuild) {
                    state = .downloading(release)
                    do {
                        let diskImage = try await Self.downloadAndVerify(release: release)
                        try Task.checkCancellation()
                        state = .ready(release: release, diskImage: diskImage)
                    } catch { state = .failed(error.localizedDescription) }
                } else {
                    state = .upToDate(checkedAt: Date())
                }
                let engine = try Self.selectRelease(data, channel: .engine)
                engineRelease = engine
                if let engine, let current = SemanticVersion(currentEngineVersion),
                   let latest = SemanticVersion(engine.version), latest > current {
                    engineState = .downloading(engine)
                    do {
                        let archive = try await Self.downloadAndVerify(release: engine)
                        try Task.checkCancellation()
                        engineState = .ready(release: engine, diskImage: archive)
                    } catch { engineState = .failed(error.localizedDescription) }
                } else { engineState = .upToDate(checkedAt: Date()) }
                try Task.checkCancellation()
            } catch is CancellationError {
                state = .idle
                engineState = .idle
            } catch {
                if state == .checking { state = .failed(error.localizedDescription) }
                engineState = .failed(error.localizedDescription)
            }
        }
    }

    enum Installation { case restartApp, reloadEngine }

    func beginInstallation() async -> Installation? {
        guard !isBusy, hasReadyUpdate else { return nil }
        var engineInstalled = false
        if case let .ready(release, archive) = engineState {
            engineState = .installing(release)
            let version = state.readyRelease?.version ?? currentVersion
            do {
                try await Task.detached(priority: .userInitiated) {
                    try EngineRuntimeStore.install(archive: archive, release: release, appVersion: version)
                }.value
                currentEngineVersion = release.version
                engineState = .upToDate(checkedAt: Date())
                engineInstalled = true
            } catch {
                engineState = .failed(error.localizedDescription)
            }
        }
        guard case let .ready(release, diskImage) = state else {
            return engineInstalled ? .reloadEngine : nil
        }
        state = .installing(release)
        let currentApp = Bundle.main.bundleURL
        let currentVersion = currentVersion
        let currentBuild = currentBuild
        do {
            try await Task.detached(priority: .userInitiated) {
                try Self.stageInstaller(diskImage: diskImage, currentApp: currentApp,
                                        currentVersion: currentVersion, currentBuild: currentBuild, release: release)
            }.value
            return .restartApp
        } catch {
            state = .failed(error.localizedDescription)
            return engineInstalled ? .reloadEngine : nil
        }
    }

    func openReleasePage() {
        guard let pageURL = latestRelease?.pageURL else { return }
        NSWorkspace.shared.open(pageURL)
    }

    private static func fetchReleases(
        from url: URL,
        currentVersion: String
    ) async throws -> Data {
        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        request.setValue("MLXL3-Desktop/\(currentVersion)", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw UpdateError.releaseLookupFailed
        }
        guard data.count <= 16 * 1_024 * 1_024 else { throw UpdateError.invalidRelease }
        // Frequent engine releases must never push the latest app out of the
        // first GitHub page. Engine tags are published with latest=false.
        if url.host == "api.github.com", url.path == "/repos/\(repository)/releases" {
            request.url = URL(string: "https://api.github.com/repos/\(repository)/releases/latest")!
            let (latestData, latestResponse) = try await URLSession.shared.data(for: request)
            guard let latestHTTP = latestResponse as? HTTPURLResponse, latestHTTP.statusCode == 200,
                  latestData.count <= 16 * 1_024 * 1_024,
                  var releases = try JSONSerialization.jsonObject(with: data) as? [[String: Any]],
                  let latest = try JSONSerialization.jsonObject(with: latestData) as? [String: Any] else {
                throw UpdateError.releaseLookupFailed
            }
            releases.append(latest)
            return try JSONSerialization.data(withJSONObject: releases)
        }
        return data
    }

    enum ReleaseChannel { case app, engine }

    nonisolated static func selectRelease(_ data: Data, channel: ReleaseChannel) throws -> AppUpdateRelease? {
        let payloads: [GitHubRelease]
        if let list = try? JSONDecoder().decode([GitHubRelease].self, from: data) { payloads = list }
        else { payloads = [try JSONDecoder().decode(GitHubRelease.self, from: data)] }
        let prefix = channel == .app ? "v" : "engine-v"
        let releases = payloads.compactMap { payload -> AppUpdateRelease? in
            guard !payload.draft, !payload.prerelease, payload.tagName.hasPrefix(prefix) else { return nil }
            let version = String(payload.tagName.dropFirst(prefix.count))
            guard version.split(separator: ".", omittingEmptySubsequences: false).count == 3,
                  version.utf8.allSatisfy({ (48...57).contains($0) || $0 == 46 }),
                  SemanticVersion(version) != nil,
                  let page = URL(string: payload.htmlURL),
                  trustedURL(page, path: "/\(repository)/releases/tag/\(payload.tagName)") else { return nil }
            let pattern = channel == .app
                ? "^MLXL3-Desktop-v\(NSRegularExpression.escapedPattern(for: version))-b[0-9]+-Apple-Silicon\\.dmg$"
                : "^MLXL3-Engine-v\(NSRegularExpression.escapedPattern(for: version))-arm64\\.tar\\.gz$"
            let assets = payload.assets.compactMap { asset -> AppUpdateAsset? in
                guard asset.name.range(of: pattern, options: .regularExpression) != nil,
                      asset.size > 0, asset.size <= 1_500_000_000,
                      let digest = asset.digest, validDigest(digest),
                      let url = URL(string: asset.browserDownloadURL),
                      trustedURL(url, path: "/\(repository)/releases/download/\(payload.tagName)/\(asset.name)") else { return nil }
                return AppUpdateAsset(name: asset.name, downloadURL: url, size: asset.size, digest: digest)
            }
            guard let asset = assets.max(by: { $0.name.localizedStandardCompare($1.name) == .orderedAscending }) else { return nil }
            return AppUpdateRelease(version: version, tag: payload.tagName, title: payload.name ?? payload.tagName,
                                    notes: payload.body ?? "", pageURL: page, asset: asset)
        }
        return releases.max {
            let left = SemanticVersion($0.version)!, right = SemanticVersion($1.version)!
            return left == right ? $0.build < $1.build : left < right
        }
    }

    nonisolated static func trustedURL(_ url: URL, path: String) -> Bool {
        url.scheme == "https" && url.host == "github.com" && url.port == nil
            && url.user == nil && url.password == nil && url.query == nil && url.fragment == nil && url.path == path
    }

    nonisolated static func validDigest(_ digest: String) -> Bool {
        digest.hasPrefix("sha256:") && digest.count == 71 && digest.dropFirst(7).utf8.allSatisfy {
            (48...57).contains($0) || (65...70).contains($0) || (97...102).contains($0)
        }
    }

    private static func downloadAndVerify(release: AppUpdateRelease) async throws -> URL {
        let cacheRoot = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appending(path: "io.mlxl3.desktop/Updates", directoryHint: .isDirectory)
        try FileManager.default.createDirectory(at: cacheRoot, withIntermediateDirectories: true)
        let destination = cacheRoot.appending(path: release.asset.name)

        if FileManager.default.fileExists(atPath: destination.path),
           try await verifyAsset(at: destination, asset: release.asset) {
            return destination
        }

        let (temporaryURL, response) = try await URLSession.shared.download(
            from: release.asset.downloadURL
        )
        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode)
        else { throw UpdateError.downloadFailed }

        let staged = cacheRoot.appending(path: UUID().uuidString + ".download")
        try FileManager.default.moveItem(at: temporaryURL, to: staged)
        do {
            guard try await verifyAsset(at: staged, asset: release.asset) else {
                throw UpdateError.integrityCheckFailed
            }
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.moveItem(at: staged, to: destination)
            return destination
        } catch {
            try? FileManager.default.removeItem(at: staged)
            throw error
        }
    }

    static func verifyAsset(at url: URL, asset: AppUpdateAsset) async throws -> Bool {
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else { return false }
        if asset.size > 0, Int64(values.fileSize ?? -1) != asset.size { return false }
        guard let digest = asset.digest, validDigest(digest) else {
            throw UpdateError.missingDigest
        }
        let expected = String(digest.dropFirst("sha256:".count)).lowercased()
        let actual = try await Task.detached(priority: .utility) {
            try sha256(at: url)
        }.value
        return actual == expected
    }

    nonisolated static func sha256(at url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hasher = SHA256()
        while true {
            let data = try handle.read(upToCount: 4 * 1_024 * 1_024) ?? Data()
            if data.isEmpty { break }
            hasher.update(data: data)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }

    nonisolated private static func stageInstaller(
        diskImage: URL,
        currentApp: URL,
        currentVersion: String,
        currentBuild: Int,
        release: AppUpdateRelease
    ) throws {
        guard currentApp.pathExtension == "app" else { throw UpdateError.notRunningFromApp }
        let parent = currentApp.deletingLastPathComponent()
        guard FileManager.default.isWritableFile(atPath: parent.path),
              try currentApp.resourceValues(forKeys: [.volumeIsReadOnlyKey]).volumeIsReadOnly != true
        else { throw UpdateError.applicationNotWritable }

        guard try verifyFile(source: diskImage, asset: release.asset) else { throw UpdateError.integrityCheckFailed }
        let mount = try mountDiskImage(diskImage)
        var shouldDetach = true
        defer {
            if shouldDetach { try? detachDiskImage(mount) }
        }

        let entries = try FileManager.default.contentsOfDirectory(
            at: mount,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        )
        guard let sourceApp = entries.first(where: {
            $0.pathExtension == "app" && $0.lastPathComponent == "MLXL3 Desktop.app"
        }) ?? entries.first(where: { $0.pathExtension == "app" }) else {
            throw UpdateError.invalidDiskImage
        }
        try validateApplication(sourceApp, newerThan: currentVersion, currentBuild: currentBuild, release: release)
        // Validate the bundled Rust/Metal runtime before stopping the working app.
        _ = try runProcess(sourceApp.appending(path: "Contents/Resources/runtime/mlxl3").path,
                           arguments: ["list", "--json"])

        let helperRoot = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appending(path: "io.mlxl3.desktop/Installers", directoryHint: .isDirectory)
        try FileManager.default.createDirectory(at: helperRoot, withIntermediateDirectories: true)
        let logRoot = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask)[0]
            .appending(path: "Logs/MLXL3", directoryHint: .isDirectory)
        try FileManager.default.createDirectory(at: logRoot, withIntermediateDirectories: true)
        let logURL = logRoot.appending(path: "updater.log")
        let helper = helperRoot.appending(path: "install-\(UUID().uuidString).zsh")
        try installerScript.write(to: helper, atomically: true, encoding: .utf8)
        try FileManager.default.setAttributes(
            [.posixPermissions: 0o700],
            ofItemAtPath: helper.path
        )
        _ = try runProcess("/bin/zsh", arguments: ["-n", helper.path])

        try spawnDetached(
            "/bin/zsh",
            arguments: [
            "/bin/zsh",
            helper.path,
            String(ProcessInfo.processInfo.processIdentifier),
            sourceApp.path,
            currentApp.path,
            mount.path,
            logURL.path,
            release.version,
            String(release.build),
            ]
        )
        shouldDetach = false
    }

    nonisolated private static func spawnDetached(
        _ executable: String,
        arguments: [String]
    ) throws {
        var processID: pid_t = 0
        var argv = arguments.map { strdup($0) }
        argv.append(nil)
        defer {
            for pointer in argv where pointer != nil { free(pointer) }
        }
        let result = executable.withCString { executablePath in
            argv.withUnsafeMutableBufferPointer { buffer in
                posix_spawn(
                    &processID,
                    executablePath,
                    nil,
                    nil,
                    buffer.baseAddress!,
                    environ
                )
            }
        }
        guard result == 0 else {
            throw UpdateError.commandFailed(String(cString: strerror(result)))
        }
    }

    nonisolated private static func validateApplication(
        _ app: URL,
        newerThan currentVersion: String,
        currentBuild: Int,
        release: AppUpdateRelease
    ) throws {
        _ = try runProcess(
            "/usr/bin/codesign",
            arguments: ["--verify", "--deep", "--strict", app.path]
        )
        let infoURL = app.appending(path: "Contents/Info.plist")
        let data = try Data(contentsOf: infoURL)
        guard let info = try PropertyListSerialization.propertyList(
            from: data,
            format: nil
        ) as? [String: Any],
              info["CFBundleIdentifier"] as? String == "io.mlxl3.desktop",
              let version = info["CFBundleShortVersionString"] as? String,
              let current = SemanticVersion(currentVersion),
              let incoming = SemanticVersion(version),
              version == release.version,
              Int(info["CFBundleVersion"] as? String ?? "0") == release.build,
              let minimumOS = info["LSMinimumSystemVersion"] as? String,
              let required = SemanticVersion(minimumOS),
              let installedOS = SemanticVersion(EngineRuntimeStore.osVersion), installedOS >= required,
              incoming > current || (incoming == current && (Int(info["CFBundleVersion"] as? String ?? "0") ?? 0) > currentBuild)
        else { throw UpdateError.invalidApplication }
        _ = try runProcess("/usr/bin/lipo", arguments: ["-verify_arch", "arm64", app.appending(path: "Contents/MacOS/MLXL3Studio").path])
        try EngineRuntimeStore.verify(app.appending(path: "Contents/Resources/runtime"), appVersion: version, expectedVersion: version)
    }

    nonisolated private static func verifyFile(source: URL, asset: AppUpdateAsset) throws -> Bool {
        let values = try source.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true,
              values.fileSize.map(Int64.init) == asset.size,
              let digest = asset.digest, validDigest(digest) else { return false }
        return try sha256(at: source) == digest.dropFirst(7).lowercased()
    }

    nonisolated private static func mountDiskImage(_ diskImage: URL) throws -> URL {
        let data = try runProcess(
            "/usr/bin/hdiutil",
            arguments: ["attach", "-nobrowse", "-readonly", "-plist", diskImage.path]
        )
        guard let plist = try PropertyListSerialization.propertyList(
            from: data,
            format: nil
        ) as? [String: Any],
              let entities = plist["system-entities"] as? [[String: Any]],
              let mountPath = entities.compactMap({ $0["mount-point"] as? String }).first
        else { throw UpdateError.invalidDiskImage }
        return URL(fileURLWithPath: mountPath, isDirectory: true)
    }

    nonisolated private static func detachDiskImage(_ mount: URL) throws {
        _ = try runProcess("/usr/bin/hdiutil", arguments: ["detach", mount.path, "-quiet"])
    }

    nonisolated static func runProcess(
        _ executable: String,
        arguments: [String],
        outputLimit: Int = 256 * 1_024 * 1_024
    ) throws -> Data {
        let process = Process()
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("mlxl3-updater-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let outURL = root.appendingPathComponent("stdout")
        let errURL = root.appendingPathComponent("stderr")
        FileManager.default.createFile(atPath: outURL.path, contents: nil)
        FileManager.default.createFile(atPath: errURL.path, contents: nil)
        let output = try FileHandle(forWritingTo: outURL)
        let errors = try FileHandle(forWritingTo: errURL)
        defer { try? output.close(); try? errors.close() }
        let finished = DispatchSemaphore(value: 0)
        process.terminationHandler = { _ in finished.signal() }
        // Pass metadata as positional arguments and bound output on disk.
        process.executableURL = URL(fileURLWithPath: "/bin/sh")
        process.arguments = ["-c", "ulimit -f \"$1\" || exit 77; shift; exec \"$@\"", "mlxl3-helper",
                             String(max(1, (outputLimit + 511) / 512)), executable] + arguments
        process.standardOutput = output
        process.standardError = errors
        try process.run()
        if finished.wait(timeout: .now() + 60) == .timedOut {
            process.terminate()
            if finished.wait(timeout: .now() + 2) == .timedOut { Darwin.kill(process.processIdentifier, SIGKILL) }
            throw UpdateError.commandFailed("Update helper timed out")
        }
        guard (try outURL.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= outputLimit,
              (try errURL.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= outputLimit else {
            throw UpdateError.commandFailed("Update helper output limit exceeded")
        }
        let data = try Data(contentsOf: outURL)
        let errorData = try Data(contentsOf: errURL)
        guard process.terminationStatus == 0 else {
            let message = String(data: errorData, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            throw UpdateError.commandFailed(message ?? executable)
        }
        return data
    }

    nonisolated static let installerScript = #"""
#!/bin/zsh
set -u
parent_pid="$1"
source_app="$2"
destination_app="$3"
mount_path="$4"
log_path="$5"
backup_app="${destination_app}.mlxl3-backup"
staged_app="${destination_app}.mlxl3-stage-${$}"
expected_version="$6"
expected_build="$7"
replacing=0
cleanup() {
    local status="$?"
    if (( replacing )); then
        /bin/rm -rf "$destination_app"
        [[ ! -e "$backup_app" ]] || /bin/mv "$backup_app" "$destination_app"
    fi
    /bin/rm -rf "$staged_app"
    /usr/bin/hdiutil detach "$mount_path" -quiet >/dev/null 2>&1 || true
    return "$status"
}
trap cleanup EXIT
trap 'exit 23' HUP INT TERM

exec >> "$log_path" 2>&1
echo "[$(/bin/date -u +%Y-%m-%dT%H:%M:%SZ)] update start"
echo "source=$source_app"
echo "destination=$destination_app"

parent_is_alive() {
    local state
    state="$(/bin/ps -o stat= -p "$parent_pid" 2>/dev/null | /usr/bin/tr -d ' ')"
    [[ -n "$state" && "$state" != Z* ]]
}

for _ in {1..300}; do
    if ! parent_is_alive; then
        break
    fi
    /bin/sleep 0.1
done

if parent_is_alive; then
    echo "parent process did not terminate"
    /usr/bin/hdiutil detach "$mount_path" -quiet >/dev/null 2>&1 || true
    exit 22
fi

# Copy and verify before moving the working application. A failed copy or
# signature/version check leaves both the installed app and its backup intact.
/usr/bin/ditto "$source_app" "$staged_app" || exit 21
/usr/bin/codesign --verify --deep --strict "$staged_app" || exit 24
/usr/bin/lipo -verify_arch arm64 "$staged_app/Contents/MacOS/MLXL3Studio" || exit 24
[[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$staged_app/Contents/Info.plist")" == "$expected_version" ]] || exit 24
[[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$staged_app/Contents/Info.plist")" == "$expected_build" ]] || exit 24
"$staged_app/Contents/Resources/runtime/mlxl3" runtime-info || exit 24

if [[ -e "$backup_app" ]]; then
    /bin/mv "$backup_app" "${backup_app}.previous-${$}" || exit 20
fi
if [[ -e "$destination_app" ]]; then
    /bin/mv "$destination_app" "$backup_app" || exit 20
    replacing=1
fi
/bin/mv "$staged_app" "$destination_app" || exit 21
/usr/bin/open -n "$destination_app" || exit 25
replacing=0
echo "new application installed; previous application retained"

/bin/rm -f "$0"
"""#
}

private struct GitHubRelease: Decodable, Sendable {
    let tagName: String
    let name: String?
    let body: String?
    let htmlURL: String
    let draft: Bool
    let prerelease: Bool
    let assets: [GitHubAsset]

    enum CodingKeys: String, CodingKey {
        case tagName = "tag_name"
        case name
        case body
        case htmlURL = "html_url"
        case draft
        case prerelease
        case assets
    }
}

private struct GitHubAsset: Decodable, Sendable {
    let name: String
    let browserDownloadURL: String
    let size: Int64
    let digest: String?

    enum CodingKeys: String, CodingKey {
        case name
        case browserDownloadURL = "browser_download_url"
        case size
        case digest
    }
}

enum UpdateError: LocalizedError {
    case releaseLookupFailed
    case invalidRelease
    case invalidVersion(String)
    case missingDiskImage
    case downloadFailed
    case missingDigest
    case integrityCheckFailed
    case notRunningFromApp
    case applicationNotWritable
    case invalidDiskImage
    case invalidApplication
    case commandFailed(String)

    var errorDescription: String? {
        switch self {
        case .releaseLookupFailed:
            L("GitHub ne répond pas correctement. Réessaie dans quelques instants.", "GitHub is not responding correctly. Try again shortly.")
        case .invalidRelease:
            L("La dernière release GitHub n’est pas valide.", "The latest GitHub release is invalid.")
        case let .invalidVersion(version):
            L("Version de release invalide : \(version).", "Invalid release version: \(version).")
        case .missingDiskImage:
            L("Cette release ne contient pas de DMG Apple Silicon.", "This release has no Apple Silicon DMG.")
        case .downloadFailed:
            L("Le téléchargement de la mise à jour a échoué.", "The update download failed.")
        case .missingDigest:
            L("GitHub n’a pas fourni l’empreinte SHA-256 de la release.", "GitHub did not provide a SHA-256 checksum for the release.")
        case .integrityCheckFailed:
            L("L’empreinte SHA-256 du DMG ne correspond pas à la release GitHub.", "The DMG checksum does not match the GitHub release.")
        case .notRunningFromApp:
            L("L’installation automatique fonctionne depuis MLXL3 Desktop.app.", "Automatic installation requires MLXL3 Desktop.app.")
        case .applicationNotWritable:
            L("MLXL3 Desktop doit être placé dans un dossier modifiable, par exemple Applications.", "MLXL3 Desktop must be in a writable folder, such as Applications.")
        case .invalidDiskImage:
            L("Le DMG téléchargé ne contient pas une application MLXL3 valide.", "The downloaded DMG does not contain a valid MLXL3 app.")
        case .invalidApplication:
            L("La nouvelle application a une identité ou une version invalide.", "The new app has an invalid identity or version.")
        case let .commandFailed(message):
            L("La préparation de la mise à jour a échoué : \(message)", "Update preparation failed: \(message)")
        }
    }
}
import AppKit
import Combine
import Foundation
import SwiftUI

// Combined with the production source by check-desktop.sh; no test setter ships.
extension UpdateManager {
    func setStatesForCheck(app: AppUpdateState, engine: AppUpdateState) {
        state = app
        engineState = engine
    }
}

@main struct HardeningCheck {
    @MainActor static func main() async throws {
        setenv("MLXL3_EXECUTABLE", CommandLine.arguments[1], 1)
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("mlxl3-check-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        setenv("MLXL3_HOME", root.path, 1)
        defer { try? FileManager.default.removeItem(at: root) }
        let suite = "io.mlxl3.check." + UUID().uuidString
        let prefs = UserDefaults(suiteName: suite)!
        defer { prefs.removePersistentDomain(forName: suite) }
        func make(_ name: String) async throws -> StudioModel {
            let model = StudioModel(conversationFileURL: root.appendingPathComponent(name + ".json"), preferences: prefs)
            let path = name.hasPrefix("dflash-") ? root.appendingPathComponent(name).path : root.path
            model.models = [LocalModel(name: name, path: path, modelType: "audit", format: "EXL3", bits: 3, sizeBytes: 1, modules: 1, addedAt: "", size: "1 B")]
            model.selectModel(name)
            for _ in 0..<200 where !model.engineState.isReady || model.mtpDownloading || model.dflashDownloading { try await Task.sleep(for: .milliseconds(20)) }
            precondition(model.engineState.isReady, "Fixture not ready")
            return model
        }
        // shortcut: the fixture error is the only red content; use accessibility text if another red control is added.
        func tuningErrorIsVisible(_ model: StudioModel) async throws -> Bool {
            _ = NSApplication.shared
            let host = NSHostingView(rootView: GenerationInspector().environmentObject(model).preferredColorScheme(.dark))
            let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 286, height: 600),
                styleMask: .borderless, backing: .buffered, defer: false)
            window.isReleasedWhenClosed = false
            window.contentView = host
            host.frame = NSRect(x: 0, y: 0, width: 286, height: 600)
            defer { window.close() }
            for _ in 0..<100 {
                try await Task.sleep(for: .milliseconds(20))
                host.layoutSubtreeIfNeeded()
                guard let bitmap = host.bitmapImageRepForCachingDisplay(in: host.bounds) else {
                    preconditionFailure("Inspector bitmap unavailable")
                }
                host.cacheDisplay(in: host.bounds, to: bitmap)
                var redPixels = 0
                for y in stride(from: 0, to: bitmap.pixelsHigh, by: 4) {
                    for x in stride(from: 0, to: bitmap.pixelsWide, by: 4) {
                        if let color = bitmap.colorAt(x: x, y: y)?.usingColorSpace(.deviceRGB),
                           color.redComponent > 0.6 && color.greenComponent < 0.45 && color.blueComponent < 0.45 {
                            redPixels += 1
                            if redPixels >= 5 { return true }
                        }
                    }
                }
            }
            return false
        }
        func renderTuneToolbar(_ model: StudioModel, _ state: String, dflash: Bool = false) async throws {
            _ = NSApplication.shared
            let host = NSHostingView(rootView: MTPTuningToolbarControl(dflash: dflash).environmentObject(model)
                .padding(12).background(StudioTheme.sidebar).preferredColorScheme(.dark))
            let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 260, height: 95),
                                  styleMask: [.borderless], backing: .buffered, defer: false)
            window.contentView = host
            defer { window.orderOut(nil) }
            host.layoutSubtreeIfNeeded()
            try await Task.sleep(for: .milliseconds(20))
            precondition(host.fittingSize.height > 0, "Tune toolbar must render in state \(state)")
            guard let bitmap = host.bitmapImageRepForCachingDisplay(in: host.bounds) else {
                preconditionFailure("Tune toolbar failed native rendering")
            }
            host.cacheDisplay(in: host.bounds, to: bitmap)
            if let output = ProcessInfo.processInfo.environment["MLXL3_TUNE_CHECK_IMAGE_DIR"],
               let data = bitmap.representation(using: .png, properties: [:]) {
                try data.write(to: URL(fileURLWithPath: output).appendingPathComponent("toolbar-\(state).png"))
            }
        }
        let updates = try await make("updates")
        defer { updates.ejectModel() }
        updates.draft = "send during background update"
        updates.updateManager.setStatesForCheck(app: .checking, engine: .checking)
        if !updates.canSend {
            FileHandle.standardError.write(Data("Composer regression: ready=\(updates.engineState.isReady), updateBusy=\(updates.updateManager.isBusy), canSend=false\n".utf8))
        }
        precondition(updates.canSend, "A background update check must not disable Send")
        let release = AppUpdateRelease(version: "9.0.0", tag: "v9.0.0", title: "fixture", notes: "",
            pageURL: root, asset: AppUpdateAsset(name: "fixture", downloadURL: root, size: 1, digest: nil))
        let states: [AppUpdateState] = [.idle, .checking, .upToDate(checkedAt: Date()),
            .downloading(release), .ready(release: release, diskImage: root), .installing(release), .failed("fixture")]
        var notifications = 0
        let observation = updates.objectWillChange.sink { notifications += 1 }
        for (appIndex, app) in states.enumerated() {
            for (engineIndex, engine) in states.enumerated() {
                let before = notifications
                updates.updateManager.setStatesForCheck(app: app, engine: engine)
                precondition(updates.canSend == (appIndex != 5 && engineIndex != 5), "Only installation blocks ready inference")
                precondition(notifications > before, "Update transitions must refresh the composer")
            }
        }
        observation.cancel()
        updates.updateManager.setStatesForCheck(app: .downloading(release), engine: .downloading(release))
        updates.draft = " \n "; precondition(!updates.canSend)
        updates.draft = "send during background update"; updates.send()
        precondition(updates.isGenerating && !updates.canSend && updates.draft.isEmpty)
        for _ in 0..<200 where updates.isGenerating { try await Task.sleep(for: .milliseconds(20)) }
        precondition(updates.engineState.isReady && updates.conversations[0].messages.last?.role == .assistant
            && updates.conversations[0].messages.last?.content.isEmpty == false, "Send must reach the bridge and complete")
        updates.draft = "next message"; precondition(updates.canSend)
        updates.ejectModel(); precondition(!updates.canSend)
        precondition(!updates.memorySaverEnabled, "Memory saving must be opt-in")
        updates.setMemorySaverEnabled(true)
        precondition(prefs.bool(forKey: "studio.memorySaverEnabled"), "Memory preference not persisted")
        let saver = try await make("mtp-memory-saver")
        defer { saver.ejectModel() }
        precondition(saver.memorySaverEnabled && saver.memorySaverSupported, "Memory preference/capability not restored")
        let advised = saver.recommendedContextLength
        precondition(advised == 2048, "Ready profile must reach the production context adviser")
        precondition(saver.contextLengthDraft == 0, "Recommendation must preserve the user's setting")
        saver.contextLengthDraft = advised!
        precondition(saver.canSaveContext)
        saver.saveContextAndReload()
        for _ in 0..<200 where !saver.engineState.isReady { try await Task.sleep(for: .milliseconds(20)) }
        precondition(saver.engineState.isReady && !saver.canSaveContext)
        precondition((prefs.dictionary(forKey: "studio.contextLengths")?["mtp-memory-saver"] as? Int) == advised)
        saver.setMTPEnabled(true)
        for _ in 0..<200 where saver.mtpDownloading { try await Task.sleep(for: .milliseconds(20)) }
        precondition(saver.canTuneMTP)
        saver.draft = "memory fixture"; saver.send()
        saver.setMemorySaverEnabled(false)
        precondition(saver.memorySaverEnabled, "Memory policy changed during generation")
        for _ in 0..<200 where saver.isGenerating { try await Task.sleep(for: .milliseconds(20)) }
        precondition(!saver.isGenerating && saver.conversations[0].messages.count == 2)
        saver.tuneMTP()
        saver.setMemorySaverEnabled(false)
        precondition(saver.memorySaverEnabled, "Memory policy changed during tuning")
        for _ in 0..<200 where saver.isTuningMTP { try await Task.sleep(for: .milliseconds(20)) }
        precondition(!saver.isTuningMTP && saver.mtpTuneRows.count == 4)
        saver.setMemorySaverEnabled(false)
        saver.draft = "normal fixture"; saver.send()
        for _ in 0..<200 where saver.isGenerating { try await Task.sleep(for: .milliseconds(20)) }
        precondition(!saver.isGenerating)
        let wire = try String(contentsOf: root.appendingPathComponent("memory-saver-requests.jsonl"), encoding: .utf8)
        let requests = try wire.split(separator: "\n").map {
            try JSONSerialization.jsonObject(with: Data($0.utf8)) as! [String: Any]
        }
        let generations = requests.filter { $0["type"] as? String == "generate" }
        let tunes = requests.filter { $0["type"] as? String == "tune_mtp" }
        precondition(generations.count == 2 && tunes.count == 1, "Missing production requests")
        precondition(generations[0]["memory_saver"] as? Bool == true && generations[1]["memory_saver"] as? Bool == false)
        precondition(tunes[0]["memory_saver"] as? Bool == true, "Tune did not receive memory policy")
        precondition(generations[0]["mtp"] as? Bool == true && saver.mtpEnabled, "Memory saving disabled MTP")
        precondition(saver.conversations[0].messages.count == 4, "Memory saving lost history")
        saver.ejectModel()
        precondition(!saver.memorySaverSupported, "Old engine capability survived unload")
        saver.setMemorySaverEnabled(true)
        let legacySaver = try await make("mtp-old")
        precondition(legacySaver.memorySaverEnabled && !legacySaver.memorySaverSupported, "Legacy capability assumed")
        precondition(legacySaver.recommendedContextLength == nil, "Legacy engine must not fabricate a recommendation")
        legacySaver.ejectModel(); legacySaver.setMemorySaverEnabled(false)
        let flashSaver = try await make("dflash-memory-saver")
        defer { flashSaver.ejectModel() }
        flashSaver.setMemorySaverEnabled(true)
        flashSaver.setDFlash2Enabled(true)
        for _ in 0..<200 where flashSaver.dflashDownloading { try await Task.sleep(for: .milliseconds(20)) }
        precondition(flashSaver.canTuneDFlash && flashSaver.memorySaverSupported)
        for saverEnabled in [true, false] {
            flashSaver.setMemorySaverEnabled(saverEnabled)
            flashSaver.tuneDFlash()
            for _ in 0..<200 where flashSaver.isTuningDFlash { try await Task.sleep(for: .milliseconds(20)) }
            precondition(flashSaver.dflash2Enabled && flashSaver.dflashTuneRows.count == 4)
        }
        let flashWire = try String(contentsOf: root.appendingPathComponent("memory-saver-requests.jsonl"), encoding: .utf8)
        let flashTunes = try flashWire.split(separator: "\n").map {
            try JSONSerialization.jsonObject(with: Data($0.utf8)) as! [String: Any]
        }.filter { $0["type"] as? String == "tune_dflash" }
        precondition(flashTunes.count == 2 && flashTunes[0]["memory_saver"] as? Bool == true
                     && flashTunes[1]["memory_saver"] as? Bool == false, "DFlash Tune did not receive the memory policy")
        precondition(flashSaver.conversations[0].messages.isEmpty, "DFlash Tune changed history")
        flashSaver.ejectModel()
        print("Memory saving checks passed: opt-in/persistence, generation/Tune wire, busy guards, MTP/history, legacy capability")
        print("Composer update checks passed: 49 app/engine states, UI notifications, empty draft, send/completion, ejection")
        let flash = try await make("dflash-good")
        flash.setDFlash2Enabled(true)
        for _ in 0..<200 where flash.dflashDownloading { try await Task.sleep(for: .milliseconds(20)) }
        precondition(flash.dflash2Enabled && flash.dflashActive == true && flash.canTuneDFlash, "One click must install and activate the matching draft")
        precondition(flash.temperature == 0 && flash.topK == 1 && flash.repetitionPenalty == 1)
        let history = flash.conversations[0].messages.count
        try await renderTuneToolbar(flash, "dflash-idle", dflash: true)
        precondition(!flash.showInspector)
        flash.tuneDFlash()
        precondition(flash.isTuningDFlash && !flash.canSend)
        precondition(!flash.showInspector, "DFlash Tune must preserve the conversation")
        try await renderTuneToolbar(flash, "dflash-running", dflash: true)
        for _ in 0..<200 where flash.isTuningDFlash { try await Task.sleep(for: .milliseconds(20)) }
        precondition(flash.dflash2Enabled && flash.dflashMode == 2 && flash.dflashTuneRows.count == 4)
        precondition(flash.conversations[0].messages.count == history, "Tune DFlash entered chat history")
        try await renderTuneToolbar(flash, "dflash-complete", dflash: true)
        flash.draft = "use selected mode"; flash.send()
        for _ in 0..<200 where flash.isGenerating { try await Task.sleep(for: .milliseconds(20)) }
        precondition(flash.conversations[0].messages.last!.content.contains("\"dflash_mode\": 2"), "Selected DFlash policy must reach production request")
        flash.tuneDFlash(); flash.cancelDFlashTuning()
        for _ in 0..<200 where flash.isTuningDFlash { try await Task.sleep(for: .milliseconds(20)) }
        precondition(flash.dflashMode == 2 && flash.dflashDownloadError != nil, "Cancelled tuning changed setting")
        try await renderTuneToolbar(flash, "dflash-cancelled", dflash: true)
        flash.setDFlash2Enabled(false)
        for _ in 0..<200 where flash.dflashActive != false { try await Task.sleep(for: .milliseconds(20)) }
        precondition(flash.dflashActive == false, "OFF did not release the resident draft")
        flash.ejectModel()
        let flashAgain = try await make("dflash-good")
        precondition(flashAgain.dflashMode == 2 && flashAgain.dflashTuneRows.count == 4, "DFlash tuning was not restored")
        flashAgain.setDFlash2Enabled(true)
        for _ in 0..<200 where flashAgain.dflashDownloading { try await Task.sleep(for: .milliseconds(20)) }
        flashAgain.ejectModel()
        for name in ["dflash-error", "dflash-malformed", "dflash-invalid", "dflash-mismatch", "dflash-baseline", "dflash-load-error", "dflash-dense"] {
            let candidate = try await make(name)
            candidate.setDFlash2Enabled(true)
            for _ in 0..<200 where candidate.dflashDownloading { try await Task.sleep(for: .milliseconds(20)) }
            if name == "dflash-load-error" {
                precondition(!candidate.dflash2Enabled && candidate.dflashDownloadError != nil)
            } else {
                precondition(candidate.dflash2Enabled && candidate.dflashActive == true, "DFlash activation failed for \(name): \(candidate.dflashDownloadError ?? "no error")")
                candidate.showInspector = name == "dflash-dense"
                candidate.tuneDFlash()
                for _ in 0..<200 where candidate.isTuningDFlash { try await Task.sleep(for: .milliseconds(20)) }
                if name == "dflash-baseline" { precondition(!candidate.dflash2Enabled && candidate.dflashTuneRows.count == 4) }
                else if name == "dflash-dense" { precondition(candidate.dflashMode == 2 && candidate.dflashDraftPath.hasSuffix("dense")) }
                else { precondition(candidate.dflashMode == 1 && candidate.dflashTuneRows.isEmpty && candidate.dflashDownloadError != nil) }
                precondition(candidate.showInspector == (name == "dflash-dense"), "DFlash Tune changed inspector navigation")
                try await renderTuneToolbar(candidate, name, dflash: true)
            }
            candidate.ejectModel()
        }
        for name in ["dflash-off-error", "dflash-off-malformed", "dflash-off-missing", "dflash-off-wrong", "dflash-off-silent"] {
            let candidate = try await make(name)
            candidate.setDFlash2Enabled(true)
            for _ in 0..<200 where candidate.dflashDownloading { try await Task.sleep(for: .milliseconds(20)) }
            precondition(candidate.dflashActive == true)
            candidate.setDFlash2Enabled(false)
            candidate.draft = "next request"
            precondition(!candidate.canSend, "OFF must wait for resident release")
            for _ in 0..<1600 where !candidate.canSend { try await Task.sleep(for: .milliseconds(20)) }
            precondition(candidate.canSend && candidate.dflashDownloadError != nil, "Failed OFF left composer blocked: \(name)")
            candidate.ejectModel()
        }
        print("DFlash Desktop checks passed: one-click setup, production policy, Tune/restore, cancellation, OFF, dense selection and failures")
        let tuned = try await make("mtp-good")
        tuned.setMTPEnabled(true)
        for _ in 0..<200 where tuned.mtpDownloading { try await Task.sleep(for: .milliseconds(20)) }
        precondition(tuned.canTuneMTP && tuned.mtpMaxDepth == 3)
        try await renderTuneToolbar(tuned, "idle")
        tuned.updateManager.setStatesForCheck(app: .checking, engine: .downloading(release))
        precondition(tuned.canTuneMTP, "Background updates must not disable MTP tuning")
        tuned.updateManager.setStatesForCheck(app: .idle, engine: .installing(release))
        precondition(!tuned.canTuneMTP)
        tuned.tuneMTP()
        precondition(!tuned.showInspector && !tuned.isTuningMTP, "An ineligible tune must leave the inspector closed")
        tuned.updateManager.setStatesForCheck(app: .idle, engine: .idle)
        let before = tuned.conversations[0].messages.count
        precondition(!tuned.showInspector)
        tuned.tuneMTP()
        precondition(!tuned.showInspector, "Header tuning must keep the conversation visible")
        precondition(tuned.isTuningMTP && tuned.isGenerating)
        try await renderTuneToolbar(tuned, "running")
        tuned.draft = "should wait"; tuned.send()
        precondition(tuned.conversations[0].messages.count == before && !tuned.canSend)
        for _ in 0..<200 where tuned.isTuningMTP { try await Task.sleep(for: .milliseconds(20)) }
        precondition(tuned.mtpEnabled && tuned.mtpDepth == 2 && tuned.mtpTuneRows.count == 4 && tuned.mtpTuneProgress == 1)
        precondition(!tuned.showInspector, "Finishing Tune must preserve the user's navigation")
        try await renderTuneToolbar(tuned, "complete")
        precondition(tuned.conversations[0].messages.count == before, "Tuning must not enter chat history")
        tuned.send()
        for _ in 0..<200 where tuned.isGenerating { try await Task.sleep(for: .milliseconds(20)) }
        precondition(tuned.conversations[0].messages.last!.content.contains("\"mtp_depth\": 2"), "Selected depth must reach the bridge")
        tuned.ejectModel()
        let restoredTune = try await make("mtp-good")
        precondition(restoredTune.mtpEnabled && restoredTune.mtpDepth == 2 && restoredTune.mtpTuneRows.count == 4)
        restoredTune.showInspector = true
        restoredTune.tuneMTP()
        precondition(restoredTune.showInspector, "Tune must preserve an already open inspector")
        for _ in 0..<200 where restoredTune.mtpTuneProgress == 0 { try await Task.sleep(for: .milliseconds(10)) }
        restoredTune.cancelMTPTuning()
        try await renderTuneToolbar(restoredTune, "cancelled")
        for _ in 0..<200 where restoredTune.isTuningMTP { try await Task.sleep(for: .milliseconds(20)) }
        precondition(restoredTune.mtpDepth == 2 && restoredTune.mtpTuneRows.count == 4 && restoredTune.mtpError != nil)
        precondition(restoredTune.showInspector, "Tuning cancellation must stay visible")
        restoredTune.setMTPDepth(3); restoredTune.ejectModel()
        let manual = try await make("mtp-good")
        precondition(manual.mtpDepth == 3, "Manual depth selection must persist")
        manual.ejectModel()
        for name in ["mtp-baseline", "mtp-collapse", "mtp-invalid", "mtp-error", "mtp-malformed"] {
            let candidate = try await make(name)
            candidate.setMTPEnabled(true)
            for _ in 0..<200 where candidate.mtpDownloading { try await Task.sleep(for: .milliseconds(20)) }
            precondition(!candidate.showInspector)
            candidate.tuneMTP()
            for _ in 0..<200 where candidate.isTuningMTP { try await Task.sleep(for: .milliseconds(20)) }
            if name == "mtp-baseline" {
                precondition(!candidate.mtpEnabled && candidate.mtpTuneRows.count == 4)
            } else if name == "mtp-collapse" {
                precondition(candidate.mtpDepth == 2 && candidate.mtpEnabled, "Zero acceptance must not win")
            } else {
                precondition(candidate.mtpDepth == 1 && candidate.mtpEnabled && candidate.mtpError != nil)
            }
            precondition(!candidate.showInspector, "Baseline, invalid replies and errors must preserve the conversation")
            try await renderTuneToolbar(candidate, name)
            if name == "mtp-error" || name == "mtp-malformed" {
                let visible = try await tuningErrorIsVisible(candidate)
                precondition(visible, "Tuning error must be rendered inside the 600-point inspector viewport")
            }
            candidate.ejectModel()
        }
        print("MTP inspector checks passed: eligible start, success, cancellation, errors, malformed replies and ineligible start")
        let old = try await make("mtp-old")
        precondition(old.mtpAvailable && old.mtpMaxDepth == 1 && !old.canTuneMTP)
        old.tuneMTP()
        precondition(!old.showInspector && !old.isTuningMTP, "An unsupported engine must leave the inspector closed")
        old.setMTPDepth(3); precondition(old.mtpDepth == 1)
        old.ejectModel()
        prefs.set(true, forKey: "studio.mtpEnabled")
        let baselineAgain = try await make("mtp-baseline")
        precondition(baselineAgain.mtpEnabled && baselineAgain.mtpTuneRows.count == 4
            && MTPTuning.winner(baselineAgain.mtpTuneRows) == 0,
            "Saved baseline results must persist without overriding an explicit global ON")
        let measuredBaselineRows = baselineAgain.mtpTuneRows
        baselineAgain.ejectModel()
        // The real StudioModel/CLI pipe/bridge must select per-target heads,
        // preserve the user's ON preference, and suppress cancelled callbacks.
        let automatic = StudioModel(conversationFileURL: root.appendingPathComponent("automatic.json"), preferences: prefs)
        automatic.models = ["auto-dense", "auto-moe", "auto-slow", "auto-fail", "plain"].map {
            LocalModel(name: $0, path: root.appendingPathComponent($0).path, modelType: "qwen3_5",
                format: "EXL3", bits: 2, sizeBytes: 1, modules: 1, addedAt: "", size: "1 B")
        }
        func waitAutomatic() async throws {
            for _ in 0..<300 where !automatic.engineState.isReady || automatic.mtpDownloading {
                try await Task.sleep(for: .milliseconds(20))
            }
            precondition(automatic.engineState.isReady && !automatic.mtpDownloading, "Automatic head load timed out")
        }
        prefs.set(true, forKey: "studio.mtpEnabled")
        // Migrate an old, foreign head: inspection must reject it and install
        // the managed head selected from the new target, never forward it.
        prefs.set("/tmp/mlxl3-fixture-mtp-moe", forKey: "studio.mtpHead.\(root.appendingPathComponent("auto-dense").path)")
        automatic.selectModel("auto-dense"); try await waitAutomatic()
        precondition(automatic.mtpHeadPath == "/tmp/mlxl3-fixture-mtp-dense" && automatic.mtpEnabled && automatic.mtpActive == true,
            "Dense head: \(automatic.mtpHeadPath), enabled=\(automatic.mtpEnabled), active=\(String(describing: automatic.mtpActive)), error=\(String(describing: automatic.mtpError))")
        automatic.selectModel("auto-moe"); try await waitAutomatic()
        precondition(automatic.mtpHeadPath == "/tmp/mlxl3-fixture-mtp-moe" && automatic.mtpEnabled && automatic.mtpActive == true)
        MTPTuning.save(MTPSelection(key: MTPConfigurationKey(
            modelPath: root.appendingPathComponent("auto-dense").path,
            headPath: "/tmp/mlxl3-fixture-mtp-dense", runtime: "fixture-runtime:auto-dense"),
            depth: 0, rows: measuredBaselineRows, tunedAt: Date()), preferences: prefs)
        automatic.selectModel("auto-dense"); try await waitAutomatic()
        precondition(automatic.mtpHeadPath == "/tmp/mlxl3-fixture-mtp-dense" && automatic.mtpActive == true,
            "An explicit global ON must override an old measured baseline")
        automatic.setMTPEnabled(false)
        for _ in 0..<200 where automatic.mtpActive != false { try await Task.sleep(for: .milliseconds(10)) }
        precondition(automatic.mtpActive == false && !prefs.bool(forKey: "studio.mtpEnabled"))
        automatic.selectModel("auto-moe"); try await waitAutomatic()
        precondition(!automatic.mtpEnabled && automatic.mtpActive == nil, "MTP OFF must stay off on model switch")
        automatic.setMTPEnabled(true); try await waitAutomatic()
        automatic.selectModel("auto-slow")
        for _ in 0..<200 where automatic.mtpDownloadCompleted == 0 { try await Task.sleep(for: .milliseconds(10)) }
        precondition(automatic.mtpDownloading)
        automatic.selectModel("auto-moe"); try await waitAutomatic()
        try await Task.sleep(for: .milliseconds(1100))
        precondition(automatic.selectedModelName == "auto-moe" && automatic.mtpHeadPath.hasSuffix("-moe")
            && automatic.mtpActive == true && !automatic.mtpDownloading && automatic.mtpError == nil)
        automatic.selectModel("auto-fail"); try await waitAutomatic()
        precondition(automatic.mtpError?.contains("fixture head download failed") == true && !automatic.mtpEnabled)
        for _ in 0..<100 {
            let log = try String(contentsOf: root.appendingPathComponent("mtp-operations.jsonl"), encoding: .utf8)
            if log.contains("\"model\": \"auto-fail\"") { break }
            try await Task.sleep(for: .milliseconds(20))
        }
        automatic.selectModel("plain"); try await waitAutomatic()
        precondition(!automatic.mtpAvailable && automatic.mtpHeadPath.isEmpty && !automatic.mtpDownloading)
        automatic.selectModel("auto-dense"); try await waitAutomatic()
        precondition(automatic.mtpActive == true && automatic.mtpError == nil, "Failure must not disable the saved ON preference")
        automatic.ejectModel()
        let operations = try String(contentsOf: root.appendingPathComponent("mtp-operations.jsonl"), encoding: .utf8)
            .split(separator: "\n").map { try JSONSerialization.jsonObject(with: Data($0.utf8)) as! [String: Any] }
        let configured = operations.compactMap { $0["request"] as? [String: Any] }
        precondition(configured.contains { $0["enabled"] as? Bool == false }, "MTP OFF did not reach the engine")
        precondition(operations.contains {
            $0["model"] as? String == "auto-fail"
                && ($0["request"] as? [String: Any])?["enabled"] as? Bool == false
        }, "Failed preparation did not unload the engine head")
        for _ in 0..<200 where operations.contains(where: {
            ($0["pid"] as? Int32).map { kill($0, 0) == 0 } ?? false
        }) { try await Task.sleep(for: .milliseconds(20)) }
        for operation in operations {
            if let pid = operation["pid"] as? Int32 {
                precondition(kill(pid, 0) == -1 && errno == ESRCH, "Previous engine/download process still lives")
            }
        }
        print("Automatic MTP checks passed: dense→MoE→dense, foreign head, OFF, cancellation, download failure, unsupported target, process cleanup")
        let key = MTPConfigurationKey(modelPath: root.path, headPath: "/tmp/mlxl3-fixture-mtp", runtime: "fixture-runtime:mtp-good")
        precondition(MTPTuning.load(key: key, preferences: prefs)?.depth == 3)
        precondition(MTPTuning.load(key: MTPConfigurationKey(modelPath: root.path, headPath: key.headPath, runtime: "new-engine"), preferences: prefs) == nil)
        let tuningHead = root.appendingPathComponent("head")
        try FileManager.default.createDirectory(at: tuningHead, withIntermediateDirectories: true)
        try Data("{}".utf8).write(to: tuningHead.appendingPathComponent("config.json"))
        let keyBefore = MTPConfigurationKey(modelPath: root.path, headPath: tuningHead.path, runtime: "engine-context-4096")
        MTPTuning.save(MTPSelection(key: keyBefore, depth: 2, rows: [], tunedAt: nil), preferences: prefs)
        try Data("{\"changed\":true}".utf8).write(to: tuningHead.appendingPathComponent("config.json"))
        let keyAfter = MTPConfigurationKey(modelPath: root.path, headPath: tuningHead.path, runtime: "engine-context-4096")
        precondition(keyAfter != keyBefore && MTPTuning.load(key: keyAfter, preferences: prefs) == nil)
        let interrupted = try await make("mtp-good")
        interrupted.tuneMTP(); interrupted.ejectModel()
        precondition(!interrupted.isTuningMTP && interrupted.mtpTuneRows.isEmpty)
        let counted = try await make("context-count")
        counted.draft = "salut"; counted.send()
        for _ in 0..<200 where counted.isGenerating { try await Task.sleep(for: .milliseconds(20)) }
        precondition(counted.contextUsed == 42, "Context only shows input tokens after completion")
        precondition(counted.currentConversation?.contextUsage?.used == 42, "Final context was not saved to the conversation")
        let mcp = try JSONSerialization.jsonObject(with: Data(contentsOf: root.appendingPathComponent("mcp.json"))) as! [String: Any]
        precondition((mcp["mcpServers"] as! [String: Any])["exa"] != nil, "Startup did not register Exa")
        counted.conversations[0].contextUsage = ContextUsage(used: 12, limit: 2048, model: "context-count")
        precondition(counted.contextUsed == 42, "Old history still displays only input tokens")
        counted.settingsDidChange()
        for _ in 0..<600 where !FileManager.default.fileExists(atPath: root.appendingPathComponent("context-count.json").path) {
            try await Task.sleep(for: .milliseconds(20))
        }
        let reopened = StudioModel(conversationFileURL: root.appendingPathComponent("context-count.json"), isPreview: true, preferences: prefs)
        precondition(reopened.contextUsed == 42, "Context count did not survive relaunch")
        reopened.selectedModelName = "other"
        precondition(reopened.contextUsed == nil, "Token count leaked to another model")
        var stats = counted.currentConversation!.messages.last!.stats!
        let baseline = ContextUsage(used: 12, limit: 2048, model: "test")
        stats.contextUsed = 77; stats.toolRounds = 3
        precondition(baseline.finalized(with: stats)?.used == 77, "MCP aggregated counts replaced final context")
        stats.contextUsed = nil
        precondition(baseline.finalized(with: stats) == nil, "Unknown multi-round context was guessed")
        stats.toolRounds = 0
        precondition(baseline.finalized(with: stats)?.used == 42)
        for value in [-1, 0, 1, 12, 42, 2048, Int.max] {
            stats.contextUsed = value
            let actual = baseline.finalized(with: stats)
            precondition(value < 0 ? actual == nil : actual?.used == min(value, 2048))
        }
        stats.contextUsed = 42; stats.contextLimit = 0
        precondition(baseline.finalized(with: stats) == nil)
        for (input, output) in [(Int.max, 1), (-1, 30), (12, -1)] {
            let payload = "{\"ttft_seconds\":0,\"prefill_tps\":0,\"decode_tps\":0,\"prompt_tokens\":\(input),\"generated_tokens\":\(output)}"
            let invalid = try JSONDecoder().decode(GenerationStats.self, from: Data(payload.utf8))
            precondition(baseline.finalized(with: invalid) == nil, "Invalid legacy token counts were accepted")
        }
        // Hub metadata crosses the real CLI pipe before ModelLibrary decodes it.
        // The previous Bool-only decoder rejected null/auto/manual.
        for (fragment, expected) in [
            ("", false), (",\"gated\":null", false),
            (",\"gated\":false", false), (",\"gated\":true", true),
            (",\"gated\":\"auto\"", true), (",\"gated\":\"manual\"", true),
            (",\"gated\":\"false\"", false), (",\"gated\":\"true\"", true),
        ] {
            let data = Data(("{\"id\":\"fixture/model-exl3\",\"downloads\":73,\"likes\":0" + fragment + "}").utf8)
            let value = try JSONDecoder().decode(HubModel.self, from: data)
            precondition(value.id == "fixture/model-exl3" && value.downloads == 73 && value.likes == 0)
            precondition(value.gated == expected, fragment)
        }
        for invalid in ["0", "1", "[]", "{}", "\"unknown\""] {
            do {
                _ = try JSONDecoder().decode(HubModel.self, from: Data(
                    ("{\"id\":\"fixture/model\",\"downloads\":1,\"likes\":0,\"gated\":" + invalid + "}").utf8))
                preconditionFailure("Invalid access metadata accepted: " + invalid)
            } catch is DecodingError {}
        }
        let library = ModelLibrary()
        func search(_ query: String) async throws {
            library.query = query
            library.search()
            for _ in 0..<200 where library.searching { try await Task.sleep(for: .milliseconds(20)) }
            precondition(!library.searching, "Catalogue search timed out")
        }
        try await search("qwen3.6")
        precondition(library.error == nil && library.results.count == 3)
        precondition(library.results[0].id == "fixture/qwen3.6-exl3" && !library.results[0].gated)
        precondition(library.results[1].gated && !library.results[2].gated)
        library.open(library.results[0].id)
        for _ in 0..<200 where library.loadingDetail { try await Task.sleep(for: .milliseconds(20)) }
        precondition(library.detail?.id == "fixture/qwen3.6-exl3")
        precondition(library.selectedVariant?.sizeBytes == 128)
        library.back()
        try await search("error")
        precondition(library.error?.contains("fixture catalogue unavailable") == true)
        try await search("invalid")
        precondition(library.error != nil)
        try await search("empty")
        precondition(library.error == nil && library.results.isEmpty)
        library.query = "slow"; library.search()
        try await Task.sleep(for: .milliseconds(400))
        try await search("latest")
        try await Task.sleep(for: .milliseconds(750))
        precondition(library.results[0].id == "fixture/latest-exl3" && library.error == nil,
                     "Cancelled search replaced the current results")
        // Previously cancelled/failed commands must not poison cached results.
        try await search("qwen3.6")
        precondition(library.results[0].id == "fixture/qwen3.6-exl3" && library.error == nil)
        library.moreResults()
        for _ in 0..<200 where library.searching { try await Task.sleep(for: .milliseconds(20)) }
        precondition(library.error == nil && library.results.count == 3)
        library.refresh()
        for _ in 0..<200 where library.searching { try await Task.sleep(for: .milliseconds(20)) }
        precondition(library.error == nil && library.results.count == 3)
        let downloadStudio = StudioModel(conversationFileURL: root.appendingPathComponent("downloads.json"),
                                         isPreview: true, preferences: prefs)
        library.open("fixture/download-exl3")
        for _ in 0..<200 where library.loadingDetail { try await Task.sleep(for: .milliseconds(20)) }
        library.download(studio: downloadStudio)
        for _ in 0..<200 where library.downloadProgress.bytesPerSecond == nil {
            try await Task.sleep(for: .milliseconds(20))
        }
        precondition(library.downloadStatus == .transferring && library.downloading != nil)
        precondition((library.downloadProgress.bytesPerSecond ?? 0) > 0)
        precondition((library.downloadProgress.fraction ?? 0) > 0)
        library.cancelDownload()
        for _ in 0..<200 where library.downloading != nil || library.pending.isEmpty {
            try await Task.sleep(for: .milliseconds(20))
        }
        precondition(library.downloadStatus == .paused && library.downloadProgress.completed > 0)
        precondition(library.lastDownloadRepo == "fixture/download-exl3")
        let paused = library.pending.first!
        library.resume(paused, studio: downloadStudio)
        precondition(library.downloadProgress.bytesPerSecond == nil && library.downloadStatus == .transferring,
                     "Resume retained the previous transfer's speed")
        for _ in 0..<200 where library.downloading != nil { try await Task.sleep(for: .milliseconds(20)) }
        precondition(library.downloadStatus == .complete && library.downloadProgress.fraction == 1)
        precondition(library.downloadMessage?.contains("fixture-model") == true)
        library.open("fixture/fail-exl3")
        for _ in 0..<200 where library.loadingDetail { try await Task.sleep(for: .milliseconds(20)) }
        library.download(studio: downloadStudio)
        for _ in 0..<200 where library.downloading != nil { try await Task.sleep(for: .milliseconds(20)) }
        precondition(library.downloadStatus == .failed && library.downloadMessage?.contains("fixture download failed") == true)
        let crash = try await make("crash")
        crash.draft = "test"; crash.send()
        try await Task.sleep(for: .milliseconds(500))
        precondition(!crash.engineState.isReady, "Dead engine still ready")

        let deleted = try await make("delete")
        deleted.draft = "test"; deleted.send()
        deleted.deleteConversation(deleted.selectedConversationID!)
        try await Task.sleep(for: .milliseconds(600))
        precondition(!deleted.isGenerating, "Deleted response wedged generation")
        deleted.ejectModel()
        deleted.newConversation(); deleted.draft = "draft one"
        let first = deleted.selectedConversationID!
        deleted.newConversation(); deleted.draft = "draft two"
        deleted.selectConversation(first)
        precondition(deleted.draft == "draft one")

        let broken = root.appendingPathComponent("broken.json")
        try "{broken".write(to: broken, atomically: true, encoding: .utf8)
        let recovered = StudioModel(conversationFileURL: broken, isPreview: true, preferences: prefs)
        precondition(recovered.storageError != nil && !recovered.persistNow())
        let original = try String(contentsOf: broken, encoding: .utf8)
        precondition(original == "{broken")
        recovered.recoverConversations()
        precondition(recovered.persistNow())
        let store = ConversationStore(fileURL: root.appendingPathComponent("ordered.json"))
        let a = WorkspaceSnapshot(selectedConversationID: nil, selectedModelName: "old", conversations: [], temperature: 0, topK: 0, repetitionPenalty: 1, systemPrompt: "")
        let b = WorkspaceSnapshot(selectedConversationID: nil, selectedModelName: "new", conversations: [], temperature: 0, topK: 0, repetitionPenalty: 1, systemPrompt: "")
        try store.save(b, revision: 2); try store.save(a, revision: 1)
        let latest = try ConversationStore.load(from: store.fileURL)
        precondition(latest?.selectedModelName == "new")
        let message = ChatMessage(role: .assistant, content: "", isStreaming: true)
        message.startTool(id: "tool", serverName: "local", toolName: "test")
        message.fail("interrupted")
        precondition(ChatMessage(snapshot: message.snapshot)!.toolActivities[0].state == .failed)
        precondition(SemanticVersion("1.0") == SemanticVersion("1.0.0"))
        let renamed = try await make("renamed")
        precondition(renamed.mtpAvailable, "MTP capability must come from the engine")
        renamed.setMTPEnabled(true)
        for _ in 0..<200 where renamed.mtpDownloading { try await Task.sleep(for: .milliseconds(20)) }
        precondition(renamed.mtpEnabled && renamed.mtpHeadPath == "/tmp/mlxl3-fixture-mtp")
        precondition(renamed.temperature == 0 && renamed.topK == 1 && renamed.repetitionPenalty == 1)
        precondition(renamed.dflash2Available, "Engine capability must override the directory name")
        precondition(renamed.runtimeIdentity == "fixture · release · MLX 0.32.2")
        renamed.ejectModel()
        precondition(!renamed.mtpAvailable, "Ejection must discard the MTP capability")
        precondition(!renamed.dflash2Available && renamed.runtimeIdentity == nil)
        let complete = try JSONDecoder().decode(BridgeEvent.self, from: Data(#"{"type":"complete","stats":{"ttft_seconds":0.4,"prefill_tps":300,"decode_tps":16,"prompt_tokens":300,"generated_tokens":42,"model_size_gb":12.5,"elapsed_seconds":8,"end_to_end_ttft_seconds":0.5,"tool_rounds":1,"dflash_proposed_tokens":50,"dflash_accepted_tokens":28,"memory":{"mlx_active_bytes":12000000000,"mlx_cache_bytes":500000000,"mlx_peak_bytes":13000000000,"process_footprint_bytes":14000000000,"process_lifetime_peak_bytes":15000000000}}}"#.utf8))
        precondition(complete.stats?.peakMemoryGB == nil && complete.stats?.modelSizeGB == 12.5)
        precondition(complete.stats?.memory?.processFootprintBytes == 14_000_000_000)
        precondition(complete.stats?.endToEndTTFTSeconds == 0.5 && complete.stats?.toolRounds == 1)
        precondition(complete.stats?.dflashAcceptedTokens == 28)
        let legacy = try JSONDecoder().decode(GenerationStats.self, from: Data(#"{"ttft_seconds":1,"prefill_tps":1,"decode_tps":1,"prompt_tokens":1,"generated_tokens":1,"peak_memory_gb":12}"#.utf8))
        precondition(legacy.peakMemoryGB == 12 && legacy.memory == nil)
        MarkdownRegressionCheck.run()
        print("Desktop hardening checks passed: Hub metadata/search/detail/cancellation/errors, transfer rate/pause/resume/success/failure, crash, deletion, drafts, recovery, save ordering, tool state")
    }
}
