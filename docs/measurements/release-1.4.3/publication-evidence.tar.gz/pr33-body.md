DFlash2 can now be activated from Desktop for Qwen3.6-35B-A3B and Qwen3.8-27B: one switch downloads/verifies the pinned draft, loads it, and enables generation. A dedicated Tune button compares baseline, Auto and fixed policies, preserves the conversation, supports cancellation, and stores a separate runtime calibration.

The target still verifies every proposed token. The retained Metal-cache key optimization removes allocations on cache hits; context-copy drafting remains opt-in. This integration includes the reviewed memory/context features from #31/#32 and repairs DFlash Tune memory-saving wiring plus the cancellation test fixture. Desktop and engine are versioned 1.4.3 (Desktop build25), with changelogs, provenance and negative experiment evidence.

Validation after integration:
- CPU Rust: 74 passed / 3 ignored; shipped mlx/chat: strict Clippy, release build, 94 passed / 77 ignored.
- Python: 380 passed / 4 unavailable-model/adapter cases skipped; Desktop complete fixture suite passed, including deterministic before-fix regressions and rendered DFlash Tune states.
- Eight individually selected physical 35B tests passed: exact logits/states/cache, MTP transitions, packed embeddings, compaction and DFlash copy/verification. No new 27B inference.
- Signed app/engine/DMG built and metadata, signatures, archive hashes and mounted DMG contents checked. Packaged updater and production-bridge validation are being finalized.
- Latest-head Kani/CI are pending. Earlier invocation/setup failures and runner shutdown remain recorded; no failed run is represented as a proof.

No new global tokens/s gain or superiority over MTP is claimed. Formal CPU checks are bounded; C++/Swift/Python verifier limitations and the inherited direct-Q4 alignment fixture remain documented.

See docs/release-v1.4.3-validation.md and opti.md for commands, bounds, identities and limits.
