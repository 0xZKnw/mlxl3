//! Optional approximate Q8 KV. Recurrent GDN and MTP-head states stay unchanged.
use crate::array::{Array, Dtype};
use anyhow::{Context, Result, ensure};

#[derive(Clone)]
pub enum CacheTensor {
    Half(Array),
    Q8 {
        shape: Vec<i32>,
        parts: Box<[Array; 3]>,
    },
}

impl CacheTensor {
    fn quantize(a: &Array) -> Result<Self> {
        let parts: [Array; 3] = a
            .quantize8()?
            .try_into()
            .map_err(|_| anyhow::anyhow!("invalid KV8 part count"))?;
        Ok(Self::Q8 {
            shape: a.shape().to_vec(),
            parts: Box::new(parts),
        })
    }
    pub fn append(previous: Option<&Self>, next: Array, threshold: Option<i32>) -> Result<Self> {
        ensure!(
            next.shape().len() == 4
                && next.shape().iter().all(|&n| n > 0)
                && next.shape()[0] == 1
                && next.dtype() == Dtype::Float16,
            "invalid KV cache append"
        );
        if let Some(p) = previous {
            ensure!(
                p.shape().len() == 4
                    && p.shape()[0] == 1
                    && p.shape()[1] == next.shape()[1]
                    && p.shape()[3] == next.shape()[3],
                "incompatible KV append shape"
            );
        }
        let previous_time = previous.map_or(0, |p| p.shape()[2]);
        previous_time
            .checked_add(next.shape()[2])
            .context("KV cache position overflow")?;
        let quantized = matches!(previous, Some(Self::Q8 { .. }))
            || threshold
                .map(|limit| {
                    crate::memory_policy::kv8_transition(previous_time, next.shape()[2], limit)
                        .context("invalid KV8 threshold or position")
                })
                .transpose()?
                .unwrap_or(false);
        if !quantized {
            return Ok(Self::Half(match previous {
                Some(Self::Half(p)) => Array::concatenate(&[p, &next], 2)?,
                None => next,
                _ => unreachable!(),
            }));
        }
        let next = Self::quantize(&next)?;
        let Some(previous) = previous else {
            return Ok(next);
        };
        let converted;
        let previous = match previous {
            Self::Half(a) => {
                converted = Self::quantize(a)?;
                &converted
            }
            _ => previous,
        };
        let (Self::Q8 { shape, parts }, Self::Q8 { parts: tail, .. }) = (previous, next) else {
            unreachable!()
        };
        let mut output_shape = shape.clone();
        output_shape[2] = output_shape[2]
            .checked_add(tail[0].shape()[2])
            .context("KV8 position overflow")?;
        let joined = (0..3)
            .map(|i| Array::concatenate(&[&parts[i], &tail[i]], 2))
            .collect::<Result<Vec<_>>>()?;
        Ok(Self::Q8 {
            shape: output_shape,
            parts: Box::new(
                joined
                    .try_into()
                    .map_err(|_| anyhow::anyhow!("KV8 append count"))?,
            ),
        })
    }
    pub fn shape(&self) -> &[i32] {
        match self {
            Self::Half(a) => a.shape(),
            Self::Q8 { shape, .. } => shape,
        }
    }
    pub fn dtype(&self) -> Dtype {
        match self {
            Self::Half(a) => a.dtype(),
            _ => Dtype::Float16,
        }
    }
    pub fn try_clone(&self) -> Result<Self> {
        Ok(self.clone())
    }
    pub fn half(&self) -> Result<&Array> {
        match self {
            Self::Half(a) => Ok(a),
            _ => anyhow::bail!("cache uses approximate KV8"),
        }
    }
    #[cfg(test)]
    pub fn array(&self) -> Result<Array> {
        match self {
            Self::Half(a) => a.try_clone(),
            Self::Q8 { parts, .. } => Array::dequantize8(parts),
        }
    }
    #[cfg(test)]
    pub fn to_f32(&self) -> Result<Vec<f32>> {
        self.array()?.to_f32()
    }
    pub fn bytes(&self, retained: bool) -> Result<usize> {
        let arrays: Vec<&Array> = match self {
            Self::Half(a) => vec![a],
            Self::Q8 { parts, .. } => parts.iter().collect(),
        };
        arrays.into_iter().try_fold(0usize, |sum, a| {
            sum.checked_add(if retained {
                a.retained_bytes()?
            } else {
                a.byte_len()?
            })
            .context("KV8 byte size overflow")
        })
    }
    pub fn slice(&self, axis: i32, start: i32, end: i32) -> Result<Self> {
        match self {
            Self::Half(a) => Ok(Self::Half(a.slice(axis, start, end)?)),
            Self::Q8 { shape, parts } => {
                ensure!(
                    axis == 2 && start >= 0 && start < end && end <= shape[2],
                    "invalid KV8 retained prefix"
                );
                let values = parts
                    .iter()
                    .map(|a| a.slice(axis, start, end))
                    .collect::<Result<Vec<_>>>()?;
                let mut shape = shape.clone();
                shape[2] = end - start;
                Ok(Self::Q8 {
                    shape,
                    parts: Box::new(
                        values
                            .try_into()
                            .map_err(|_| anyhow::anyhow!("KV8 slice count"))?,
                    ),
                })
            }
        }
    }
    pub fn attention(q: &Array, k: &Self, v: &Self, scale: f32, causal: bool) -> Result<Array> {
        ensure!(
            q.shape().len() == 4
                && q.shape().iter().all(|&n| n > 0)
                && q.shape()[0] == 1
                && q.dtype() == Dtype::Float16
                && k.shape() == v.shape()
                && k.shape().len() == 4
                && k.shape()[1] > 0
                && q.shape()[1] % k.shape()[1] == 0
                && q.shape()[3] == k.shape()[3]
                && q.shape()[2] <= k.shape()[2]
                && scale.is_finite()
                && scale > 0.,
            "invalid KV attention"
        );
        match (k, v) {
            (Self::Half(k), Self::Half(v)) => Array::sdpa(q, k, v, scale, causal),
            (Self::Q8 { parts: k, .. }, Self::Q8 { parts: v, .. }) => {
                Array::qsdpa8(q, k, v, scale, causal)
            }
            _ => anyhow::bail!("inconsistent KV cache precision"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use half::f16;
    fn fixture(heads: usize, rows: usize, width: usize, seed: usize) -> Result<Array> {
        let values = (0..heads * rows * width)
            .map(|i| f16::from_f32(((i * 73 + seed * 97) % 401) as f32 / 200. - 1.).to_bits())
            .collect::<Vec<_>>();
        Array::from_f16_bits(&values, &[1, heads as i32, rows as i32, width as i32])
    }
    // Decode packed bytes independently of MLX dequantize / attention.
    fn oracle(cache: &CacheTensor) -> Result<Vec<f32>> {
        let CacheTensor::Q8 { shape, parts } = cache else {
            anyhow::bail!("oracle expected Q8")
        };
        let words = parts[0].to_u32()?;
        let scales = parts[1].to_f32()?;
        let biases = parts[2].to_f32()?;
        let count = shape.iter().map(|&x| x as usize).product();
        Ok((0..count)
            .map(|i| {
                let byte = (words[i / 4] >> ((i % 4) * 8)) & 255;
                f16::from_f32((byte as f32).mul_add(scales[i / 64], biases[i / 64])).to_f32()
            })
            .collect())
    }
    #[test]
    #[ignore = "physical Apple GPU; run alone"]
    fn kv8_attention_matches_independent_oracle_and_retained_prefixes() -> Result<()> {
        let mut cases = 0;
        for seed in [1, 17] {
            for time in 1..=4usize {
                let (heads, kv_heads, width, length) = (6usize, 2usize, 64usize, 256 + time);
                let k = CacheTensor::append(
                    Some(&CacheTensor::Half(fixture(kv_heads, 256, width, seed)?)),
                    fixture(kv_heads, time, width, seed + 1)?,
                    Some(256),
                )?;
                let v = CacheTensor::append(
                    Some(&CacheTensor::Half(fixture(kv_heads, 256, width, seed + 2)?)),
                    fixture(kv_heads, time, width, seed + 3)?,
                    Some(256),
                )?;
                assert!(matches!(k, CacheTensor::Q8 { .. }));
                assert!(k.bytes(false)? < length * kv_heads * width * 2);
                let keys = oracle(&k)?;
                let values = oracle(&v)?;
                let reconstructed = k.to_f32()?;
                assert_eq!(keys.len(), length * kv_heads * width);
                assert!(
                    reconstructed
                        .iter()
                        .zip(&keys)
                        .all(|(a, b)| a.is_finite() && (*a - *b).abs() <= 0.002)
                );
                for retained in 1..=time {
                    let q = fixture(heads, retained, width, seed + 4)?;
                    let queries = q.to_f32()?;
                    let end = 256 + retained;
                    let kp = k.slice(2, 0, end as i32)?;
                    let vp = v.slice(2, 0, end as i32)?;
                    for causal in [false, true] {
                        let out = CacheTensor::attention(&q, &kp, &vp, 0.125, causal)?;
                        assert_eq!(
                            out.shape(),
                            &[1, heads as i32, retained as i32, width as i32]
                        );
                        let actual = out.to_f32()?;
                        assert_eq!(actual.len(), heads * retained * width);
                        for head in 0..heads {
                            let kv = head / (heads / kv_heads);
                            for row in 0..retained {
                                let upto = if causal { 257 + row } else { end };
                                let scores = (0..upto)
                                    .map(|token| {
                                        (0..width)
                                            .map(|d| {
                                                f64::from(
                                                    queries[(head * retained + row) * width + d],
                                                ) * f64::from(
                                                    keys[(kv * length + token) * width + d],
                                                )
                                            })
                                            .sum::<f64>()
                                            * 0.125
                                    })
                                    .collect::<Vec<_>>();
                                let max = scores.iter().copied().fold(f64::NEG_INFINITY, f64::max);
                                let weights =
                                    scores.iter().map(|s| (s - max).exp()).collect::<Vec<_>>();
                                let sum: f64 = weights.iter().sum();
                                for d in 0..width {
                                    let expected = weights
                                        .iter()
                                        .enumerate()
                                        .map(|(token, w)| {
                                            w * f64::from(values[(kv * length + token) * width + d])
                                        })
                                        .sum::<f64>()
                                        / sum;
                                    let a = actual[(head * retained + row) * width + d];
                                    assert!(
                                        a.is_finite() && (f64::from(a) - expected).abs() <= 0.03,
                                        "Q8 independent attention head{head}/row{row}/d{d}: {a}/{expected}"
                                    );
                                }
                            }
                        }
                        cases += 1;
                    }
                }
                assert!(k.slice(2, 0, 0).is_err());
                assert!(k.slice(2, 0, (length + 1) as i32).is_err());
                assert!(
                    CacheTensor::attention(&fixture(5, 1, width, 1)?, &k, &v, 0.125, false)
                        .is_err()
                );
            }
        }
        assert_eq!(cases, 40);
        assert!(CacheTensor::append(None, Array::zeros(&[1, 2, 1, 64])?, Some(256)).is_err());
        println!(
            "KV8: {cases} independent attention cases, packed/affine oracle, prefixes, memory payload and errors"
        );
        Ok(())
    }
}
