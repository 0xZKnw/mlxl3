use super::*;

#[test]
#[ignore = "physical Apple GPU; real EXL3 records at shared slots 512 and 2543, including masked maps"]
fn shared_bank_edge_slots_preserve_exact_exl3_projections_and_masks() -> Result<()> {
    let checkpoint =
        crate::checkpoint::inspect(std::path::Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
    let mut reference = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 53, true)?;
    reference.fill_many(&[(0, 0), (1, 1)])?;
    for uniform in [true, false] {
        let pool = SsdMoe::new_shared_pool(uniform)?;
        let mut candidate = SsdMoe::load_with_pool(
            &checkpoint,
            "model.language_model.layers.0.mlp",
            53,
            true,
            Some((47, pool)),
        )?;
        candidate.fill_many(&[(0, 512), (1, 2543)])?;
        for dtype in [Dtype::Float16, Dtype::Float32] {
            for rows in [1, 2, 4, 8] {
                let values = (0..rows * 10 * 2560)
                    .map(|i| ((i * 37 + 19) % 97) as f32 / 97. - 0.5)
                    .collect::<Vec<_>>();
                let x = Array::from_f32(&values, &[rows * 10, 2560])?.astype(dtype)?;
                let old = (0..rows * 10).map(|i| (i % 2) as u32).collect::<Vec<_>>();
                let new = old
                    .iter()
                    .map(|id| if *id == 0 { 512 } else { 2543 })
                    .collect::<Vec<_>>();
                let expected = reference.calculate(&x, &old)?;
                let actual = candidate.calculate(&x, &new)?;
                ensure!(actual.shape() == [rows * 10, 2560]);
                let host = actual.to_f32()?;
                ensure!(
                    host.len() == rows as usize * 10 * 2560 && host.iter().all(|v| v.is_finite())
                );
                ensure!(
                    actual.to_bytes()? == expected.to_bytes()?,
                    "shared slot projection differs uniform={uniform} dtype={dtype:?} rows={rows}"
                );
                for mask in [0, 1, 2] {
                    let mut oldmap = [u32::MAX; 512];
                    let mut newmap = oldmap;
                    for id in 0..2 {
                        if mask == 2 || (mask == 1 && id == 0) {
                            oldmap[id] = id as u32;
                            newmap[id] = if id == 0 { 512 } else { 2543 };
                        }
                    }
                    let selected = Array::from_u32(&old, &[rows * 10])?;
                    let before = linear::ExpertSlots::residents(&selected, &oldmap, 53)?;
                    let after = linear::ExpertSlots::residents(&selected, &newmap, 2544)?;
                    let expected = reference.calculate_slots(&x, &before)?;
                    let actual = candidate.calculate_slots(&x, &after)?;
                    ensure!(actual.to_f32()?.iter().all(|v| v.is_finite()));
                    ensure!(
                        actual.to_bytes()? == expected.to_bytes()?,
                        "shared mask differs"
                    );
                }
            }
        }
        for slots in [vec![2544], vec![u32::MAX]] {
            ensure!(linear::ExpertSlots::new(&slots, 2544).is_err());
        }
    }
    println!("SHARED_POOL_EDGES projections=16 masks=48 exact slots=512,2543 capacity=2544");
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU; shared ARC/uniform actual MoE path, labels, pending Hot and recovery"]
fn shared_runtime_preserves_moe_outputs_labels_pending_consumers_and_recovery() -> Result<()> {
    let (checkpoint, input, expected) = super::tests::admission_fixture()?;
    for uniform in [true, false] {
        let pool = SsdMoe::new_shared_pool(uniform)?;
        let mut first = SsdMoe::load_with_pool(
            &checkpoint,
            "model.language_model.layers.0.mlp",
            53,
            true,
            Some((0, Rc::clone(&pool))),
        )?;
        let mut second = SsdMoe::load_with_pool(
            &checkpoint,
            "model.language_model.layers.0.mlp",
            53,
            true,
            Some((47, Rc::clone(&pool))),
        )?;
        first.gpu_hot = true;
        second.gpu_hot = true;
        for turn in 0..3 {
            let moe = if turn % 2 == 0 {
                &mut first
            } else {
                &mut second
            };
            let actual = moe.forward(&input)?;
            ensure!(actual.to_bytes()? == expected, "global MoE output differs");
            ensure!(actual.to_f32()?.len() == 2560);
            ensure!(
                moe.cache
                    .borrow()
                    .resident_slot_map()?
                    .iter()
                    .filter(|s| **s != u32::MAX)
                    .count()
                    >= 10
            );
        }
        let a = first.cache.borrow().resident_slot_map()?;
        let b = second.cache.borrow().resident_slot_map()?;
        ensure!(
            a.iter()
                .zip(b)
                .filter(|(x, _)| **x != u32::MAX)
                .all(|(x, y)| *x != y),
            "same expert in different layers aliases"
        );
        first.cache.borrow_mut().invalidate();
        let ids = first.route(&input)?.0.to_u32()?;
        let fill = ExpertFill::new(&first.cache);
        let mapped = first.cache.borrow_mut().reserve(&ids[..5])?;
        first.fill_many(
            &ids[..5]
                .iter()
                .zip(mapped)
                .map(|(&id, (slot, _))| (id, slot))
                .collect::<Vec<_>>(),
        )?;
        fill.commit();
        first.slow_hot_for_test = true;
        let pending = first.forward(&input)?;
        ensure!(
            first.hot_ready_at_demand == Some(false),
            "shared pool serialized current Hot before demanded I/O"
        );
        pending.async_eval()?;
        ensure!(
            second.forward(&input)?.to_bytes()? == expected,
            "foreign pending consumer changed output"
        );
        ensure!(
            pending.to_bytes()? == expected,
            "pending foreign output changed"
        );
        first.slow_hot_for_test = false;
        first.cache.borrow_mut().invalidate();
        second.records[0].data_offsets[0] = u64::MAX;
        // Force the corrupted real expert into a demanded, unfilled reservation.
        let fill = ExpertFill::new(&second.cache);
        let slot = second.cache.borrow_mut().reserve(&[0])?[0].0;
        ensure!(second.fill_many(&[(0, slot)]).is_err());
        drop(fill);
        ensure!(
            first
                .cache
                .borrow()
                .resident_slot_map()?
                .iter()
                .all(|s| *s == u32::MAX)
        );
        ensure!(
            second
                .cache
                .borrow()
                .resident_slot_map()?
                .iter()
                .all(|s| *s == u32::MAX)
        );
        first.drain()?;
        second.drain()?;
        ensure!(
            first.forward(&input)?.to_bytes()? == expected,
            "shared pool did not recover"
        );
        first.drain()?;
    }
    Ok(())
}

#[cfg(all(kani, test))]
#[kani::proof]
fn actual_shared_exl3_bank_edge_projection_and_runtime() {
    shared_bank_edge_slots_preserve_exact_exl3_projections_and_masks().unwrap();
}
