//! Shared demand-only expert addresses; physical consumers are drained by SsdMoe.
use crate::flash_support::{CacheError, ExpertCache};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Key {
    pub(crate) layer: usize,
    pub(crate) expert: u32,
}

#[path = "flash_cache_profile/shared/arc.rs"]
mod arc;
pub(crate) use arc::ReplayArc;

fn uniform_slot(layer: usize, local: usize) -> Option<usize> {
    (layer < 48 && local < 53).then(|| layer * 53 + local)
}

#[cfg(any(feature = "mlx", test, kani))]
pub(crate) fn parse_mode(value: &str) -> Result<Option<bool>, CacheError> {
    match value {
        "off" => Ok(None),
        "uniform" => Ok(Some(true)),
        "arc" => Ok(Some(false)),
        _ => Err(CacheError::Capacity),
    }
}

pub(crate) enum SharedCache {
    Uniform {
        layers: Vec<ExpertCache>,
        ready: Vec<bool>,
        pending: Vec<usize>,
    },
    Arc {
        cache: ReplayArc,
        ready: Vec<bool>,
        pending: Vec<usize>,
    },
}

impl SharedCache {
    #[cfg(any(feature = "mlx", test, kani))]
    pub(crate) fn new(uniform: bool) -> Result<Self, CacheError> {
        let ready = vec![false; 2544];
        let pending = Vec::new();
        Ok(if uniform {
            Self::Uniform {
                layers: (0..48)
                    .map(|_| ExpertCache::new(53))
                    .collect::<Result<_, _>>()?,
                ready,
                pending,
            }
        } else {
            Self::Arc {
                cache: ReplayArc::new(48, 2544)?,
                ready,
                pending,
            }
        })
    }

    pub(crate) fn capacity(&self) -> usize {
        2544
    }

    pub(crate) fn available_slots(&self) -> usize {
        match self {
            Self::Uniform { .. } => 53,
            Self::Arc { .. } => 2544,
        }
    }

    pub(crate) fn reserve(
        &mut self,
        layer: usize,
        ids: &[u32],
    ) -> Result<Vec<(usize, bool)>, CacheError> {
        if layer >= 48 || ids.is_empty() || ids.len() > 80 || ids.iter().any(|id| *id >= 512) {
            return Err(CacheError::InvalidIds);
        }
        let pending = match self {
            Self::Uniform { pending, .. } | Self::Arc { pending, .. } => pending,
        };
        if !pending.is_empty() {
            return Err(CacheError::NoSlot);
        }
        let (mapped, ready, pending) = match self {
            Self::Uniform {
                layers,
                ready,
                pending,
            } => {
                let cache = layers.get_mut(layer).ok_or(CacheError::InvalidIds)?;
                (
                    cache
                        .reserve(ids)?
                        .into_iter()
                        .map(|(slot, hit)| {
                            (uniform_slot(layer, slot).expect("bounded layer/slot"), hit)
                        })
                        .collect::<Vec<_>>(),
                    ready,
                    pending,
                )
            }
            Self::Arc {
                cache,
                ready,
                pending,
            } => (cache.reserve(layer, ids)?, ready, pending),
        };
        for &(slot, hit) in &mapped {
            if !hit && !pending.contains(&slot) {
                ready[slot] = false;
                pending.push(slot);
            }
        }
        Ok(mapped)
    }

    pub(crate) fn publish(&mut self) {
        let (ready, pending) = match self {
            Self::Uniform { ready, pending, .. } | Self::Arc { ready, pending, .. } => {
                (ready, pending)
            }
        };
        for slot in pending.drain(..) {
            ready[slot] = true;
        }
    }

    pub(crate) fn resident_map(&self, layer: usize) -> Result<[u32; 512], CacheError> {
        if layer >= 48 {
            return Err(CacheError::InvalidIds);
        }
        let mut map = [u32::MAX; 512];
        match self {
            Self::Uniform { layers, ready, .. } => {
                for (id, local) in layers[layer].resident_slot_map()?.into_iter().enumerate() {
                    if local != u32::MAX {
                        let slot = uniform_slot(layer, local as usize).expect("bounded layer/slot");
                        if ready[slot] {
                            map[id] = slot as u32;
                        }
                    }
                }
            }
            Self::Arc { cache, ready, .. } => {
                for (slot, key) in cache.slots.iter().enumerate() {
                    if ready[slot]
                        && let Some(key) = key
                        && key.layer == layer
                    {
                        map[key.expert as usize] = slot as u32;
                    }
                }
            }
        }
        Ok(map)
    }

    pub(crate) fn invalidate(&mut self) {
        match self {
            Self::Uniform {
                layers,
                ready,
                pending,
            } => {
                for layer in layers {
                    layer.invalidate();
                }
                ready.fill(false);
                pending.clear();
            }
            Self::Arc {
                cache,
                ready,
                pending,
            } => {
                cache.invalidate();
                ready.fill(false);
                pending.clear();
            }
        }
    }
}

#[cfg(kani)]
#[kani::proof]
fn shared_uniform_slot_addresses_are_exact_and_bounded_for_all_usize() {
    let layer: usize = kani::any();
    let local: usize = kani::any();
    let actual = uniform_slot(layer, local);
    assert!(actual.is_some() == (layer < 48 && local < 53));
    if let Some(slot) = actual {
        assert!(slot < 2544 && slot as u128 == layer as u128 * 53 + local as u128);
        assert!(slot / 53 == layer && slot % 53 == local);
    }
    kani::cover!(layer == 47 && local == 52 && actual == Some(2543));
    kani::cover!(layer == 0 && local == 0 && actual == Some(0));
    kani::cover!(layer == 48 && local == 0 && actual.is_none());
    kani::cover!(layer == 0 && local == 53 && actual.is_none());
}

#[cfg(all(kani, test))]
#[kani::proof]
#[kani::unwind(2546)]
fn actual_global_first_fill_publishes_only_after_explicit_completion() {
    let layer = kani::any::<u8>() as usize;
    let id = kani::any::<u16>() as u32;
    let mut pool = SharedCache::new(false).unwrap();
    let actual = pool.reserve(layer, &[id]);
    let valid = layer < 48 && id < 512;
    assert!(actual.is_ok() == valid);
    if valid {
        assert!(actual.unwrap() == vec![(0, false)]);
    }
    let SharedCache::Arc {
        cache,
        ready,
        pending,
    } = &pool
    else {
        unreachable!()
    };
    assert!(!ready[0]);
    assert!(pending.len() == usize::from(valid));
    assert!(
        cache.slots[0]
            == if valid {
                Some(Key { layer, expert: id })
            } else {
                None
            }
    );
    pool.publish();
    let SharedCache::Arc { ready, pending, .. } = &pool else {
        unreachable!()
    };
    assert!(ready[0] == valid && pending.is_empty());
    pool.invalidate();
    let SharedCache::Arc {
        cache,
        ready,
        pending,
    } = &pool
    else {
        unreachable!()
    };
    assert!(!ready[0] && pending.is_empty() && cache.slots[0].is_none());
    kani::cover!(valid && layer == 47 && id == 511);
    kani::cover!(!valid && layer == 48);
    kani::cover!(!valid && id >= 512);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::flash_support::ExpertFill;
    use std::{cell::RefCell, rc::Rc};

    #[test]
    fn shared_views_publish_only_complete_demand_and_invalidate_on_failure() -> anyhow::Result<()> {
        for uniform in [true, false] {
            let pool = Rc::new(RefCell::new(SharedCache::new(uniform)?));
            let a = Rc::new(RefCell::new(ExpertCache::shared_view(0, Rc::clone(&pool))?));
            let b = Rc::new(RefCell::new(ExpertCache::shared_view(
                47,
                Rc::clone(&pool),
            )?));
            assert_eq!(a.borrow().capacity(), 2544);
            assert_eq!(
                b.borrow().available_slots(),
                if uniform { 53 } else { 2544 }
            );
            let mut slots = Vec::new();
            for view in [&a, &b] {
                let fill = ExpertFill::new(view);
                let mapped = view.borrow_mut().reserve(&[7, 8, 7])?;
                assert_eq!(mapped[0], mapped[2]);
                assert!(!mapped[0].1 && !mapped[1].1 && mapped[0].0 != mapped[1].0);
                assert!(!view.borrow().contains(7));
                assert_eq!(view.borrow().resident_slot_map()?[7], u32::MAX);
                assert!(view.borrow_mut().reserve(&[9]).is_err());
                fill.commit();
                assert!(view.borrow().contains(7));
                assert_eq!(view.borrow().resident_slot_map()?[7], mapped[0].0 as u32);
                slots.push(mapped[0].0);
                let fill = ExpertFill::new(view);
                assert!(
                    view.borrow_mut()
                        .reserve(&[7, 8])?
                        .iter()
                        .all(|(_, hit)| *hit)
                );
                fill.commit();
                assert!(view.borrow_mut().protect_predictions(&[1]).is_err());
                assert!(view.borrow_mut().claim_prefetch(1).is_err());
            }
            assert_ne!(slots[0], slots[1]);
            if uniform {
                assert!(slots[1] >= 2491);
            }
            {
                let _failed = ExpertFill::new(&a);
                a.borrow_mut().reserve(&[99])?;
            }
            assert!(!a.borrow().contains(7) && !b.borrow().contains(7));
            let fill = ExpertFill::new(&b);
            assert!(!b.borrow_mut().reserve(&[7])?[0].1);
            fill.commit();
            assert!(b.borrow().contains(7));
            assert!(ExpertCache::shared_view(48, Rc::clone(&pool)).is_err());
        }
        for (text, mode) in [("off", None), ("uniform", Some(true)), ("arc", Some(false))] {
            assert_eq!(parse_mode(text)?, mode);
        }
        for text in ["", "1", "ARC", " arc", "uniform "] {
            assert!(parse_mode(text).is_err());
        }
        Ok(())
    }

    #[test]
    fn shared_uniform_control_is_exactly_the_existing_forty_eight_caches() -> anyhow::Result<()> {
        let mut pool = SharedCache::new(true)?;
        let mut baseline = (0..48)
            .map(|_| ExpertCache::new(53))
            .collect::<Result<Vec<_>, _>>()?;
        let mut random = 17u32;
        for step in 0..4096 {
            let layer = step % 48;
            let ids = (0..1 + step % 40)
                .map(|_| {
                    random = random.wrapping_mul(1664525).wrapping_add(1013904223);
                    random % 127
                })
                .collect::<Vec<_>>();
            let expected = baseline[layer]
                .reserve(&ids)?
                .into_iter()
                .map(|(slot, hit)| (slot + layer * 53, hit))
                .collect::<Vec<_>>();
            let actual = pool.reserve(layer, &ids)?;
            assert_eq!(actual, expected);
            pool.publish();
            let expected = baseline[layer].resident_slot_map()?.map(|slot| {
                if slot == u32::MAX {
                    slot
                } else {
                    slot + layer as u32 * 53
                }
            });
            assert_eq!(pool.resident_map(layer)?, expected);
        }
        assert!(pool.resident_map(48).is_err());
        for (layer, ids) in [(48, vec![0]), (0, vec![]), (0, vec![512]), (0, vec![0; 81])] {
            let before = pool.resident_map(0)?;
            assert!(pool.reserve(layer, &ids).is_err());
            assert_eq!(pool.resident_map(0)?, before);
        }
        Ok(())
    }
}
