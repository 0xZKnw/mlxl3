import Foundation

private struct ResolverFailure: Error, CustomStringConvertible {
    let description: String
}

@main struct FinalResolverCheck {
    @MainActor static func main() {
        do {
            guard CommandLine.arguments.count == 4 else {
                throw ResolverFailure(description: "Expected final .app path, engine version and old managed version")
            }
            let sourceApp = URL(fileURLWithPath: CommandLine.arguments[1]).standardizedFileURL
            let expectedEngine = CommandLine.arguments[2]
            let expectedManaged = CommandLine.arguments[3]
            let sourceRuntime = sourceApp.appendingPathComponent("Contents/Resources/runtime")
            let sourceInfo = sourceApp.appendingPathComponent("Contents/Info.plist")
            guard let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String,
                  let resources = Bundle.main.resourceURL,
                  let executableName = Bundle.main.object(forInfoDictionaryKey: "CFBundleExecutable") as? String else {
                throw ResolverFailure(description: "Helper must run inside the copied final app metadata")
            }
            guard appVersion == "1.4.4" else {
                throw ResolverFailure(description: "Unexpected Desktop version in final copied Bundle.main")
            }
            let runtime = resources.appendingPathComponent("runtime")
            let expectedExecutable = runtime.appendingPathComponent("mlxl3").standardizedFileURL
            let pointer = EngineRuntimeStore.root.appendingPathComponent("current.json")
            let before = try Data(contentsOf: pointer)
            let pointerJSON = try JSONSerialization.jsonObject(with: before) as? [String: Any]
            guard pointerJSON?["version"] as? String == expectedManaged else {
                throw ResolverFailure(description: "Real managed pointer no longer has the expected old version")
            }
            guard try Data(contentsOf: sourceInfo) == Data(contentsOf: Bundle.main.bundleURL.appendingPathComponent("Contents/Info.plist")) else {
                throw ResolverFailure(description: "Helper Info.plist differs from final packaged app")
            }
            let sourceManifest = try EngineRuntimeStore.readManifest(sourceRuntime)
            guard sourceManifest.version == expectedEngine, EngineRuntimeStore.bundledVersion == expectedEngine else {
                throw ResolverFailure(description: "Final packaged engine manifest version mismatch")
            }
            try EngineRuntimeStore.verify(sourceRuntime, appVersion: appVersion, expectedVersion: expectedEngine)
            try EngineRuntimeStore.verify(runtime, appVersion: appVersion, expectedVersion: expectedEngine)
            let sourceEngineHash = try UpdateManager.sha256(at: sourceRuntime.appendingPathComponent("mlxl3"))
            guard try UpdateManager.sha256(at: expectedExecutable) == sourceEngineHash else {
                throw ResolverFailure(description: "Helper engine differs from final packaged engine")
            }
            // Validate the real old target first, so nil below proves the version
            // policy on this installation rather than merely a broken pointer.
            guard let oldManaged = EngineRuntimeStore.resolve(appVersion: appVersion, bundledVersion: expectedManaged) else {
                throw ResolverFailure(description: "Real old managed engine is invalid/disabled; version-suppression control is inconclusive")
            }
            let managed = EngineRuntimeStore.resolve(appVersion: appVersion)
            let installedVersion = EngineRuntimeStore.installedVersion()
            let resolved = CLIResolver.executable()?.standardizedFileURL
            guard managed == nil, installedVersion == expectedEngine, resolved == expectedExecutable else {
                throw ResolverFailure(description: "Old managed engine masked the final packaged runtime")
            }
            guard try Data(contentsOf: pointer) == before else {
                throw ResolverFailure(description: "Real managed pointer changed during the read-only check")
            }
            let sourceExecutable = sourceApp.appendingPathComponent("Contents/MacOS/" + executableName)
            let report: [String: Any] = [
                "status": "complete",
                "source_bundle": sourceApp.path,
                "helper_bundle": Bundle.main.bundleURL.path,
                "bundle_identifier": Bundle.main.bundleIdentifier ?? "",
                "app_version": appVersion,
                "bundled_engine_version": EngineRuntimeStore.bundledVersion,
                "installed_engine_version": installedVersion,
                "managed_root": EngineRuntimeStore.root.path,
                "managed_pointer_version": expectedManaged,
                "managed_pointer_sha256": try UpdateManager.sha256(at: pointer),
                "managed_pointer_bytes_unchanged": true,
                "old_managed_engine_valid_at_old_floor": oldManaged.path,
                "old_managed_engine_suppressed_at_bundle_floor": managed == nil,
                "cli_resolver_path": resolved?.path ?? "",
                "cli_resolver_is_bundle_runtime": resolved == expectedExecutable,
                "source_engine_path": sourceRuntime.appendingPathComponent("mlxl3").path,
                "source_engine_sha256": sourceEngineHash,
                "source_desktop_sha256": try UpdateManager.sha256(at: sourceExecutable),
                "source_engine_manifest_sha256": try UpdateManager.sha256(at: sourceRuntime.appendingPathComponent("engine.json")),
                "scope": "Production Swift resolver/store sources; actual Bundle.main from disposable metadata/runtime copy of final app; real managed pointer read only; no engine executed or GUI/model loaded"
            ]
            print(String(decoding: try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]), as: UTF8.self))
        } catch {
            let report = ["status": "failed", "error": String(describing: error)]
            if let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) {
                print(String(decoding: data, as: UTF8.self))
            }
            exit(1)
        }
    }
}
