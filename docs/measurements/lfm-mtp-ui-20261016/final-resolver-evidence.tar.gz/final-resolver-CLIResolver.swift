import Foundation
enum CLIResolver {
    static func executable() -> URL? {
        let environment = ProcessInfo.processInfo.environment
        var candidates: [String] = []
        if let override = environment["MLXL3_EXECUTABLE"], !override.isEmpty {
            candidates.append((override as NSString).expandingTildeInPath)
        }

        if let managed = EngineRuntimeStore.resolve(appVersion: Bundle.main.object(
            forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.2.0") {
            candidates.append(managed.path)
        }

        if let resources = Bundle.main.resourceURL {
            candidates.append(resources.appending(path: "runtime/mlxl3").path)
        }

        var sourceProbe = URL(fileURLWithPath: #filePath)
        for _ in 0..<8 {
            sourceProbe.deleteLastPathComponent()
            candidates.append(sourceProbe.appending(path: "target/release/mlxl3-rs").path)
            candidates.append(sourceProbe.appending(path: "target/debug/mlxl3-rs").path)
        }
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
            .map { URL(fileURLWithPath: $0) }
    }

    static func workingDirectory(for executable: URL) -> URL {
        let bin = executable.deletingLastPathComponent()
        let environment = bin.deletingLastPathComponent()
        if environment.lastPathComponent == ".venv" {
            return environment.deletingLastPathComponent()
        }
        return FileManager.default.homeDirectoryForCurrentUser
    }
}

