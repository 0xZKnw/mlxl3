#!/bin/zsh
set -euo pipefail
repo_dir="${0:A:h:h:h}"
cd "${repo_dir}"
if [[ "${1:-}" != "--final-package-confirmed" || $# -ne 2 ]]; then
    print -u2 'Run only after final packaging: check-final-resolver.zsh --final-package-confirmed /absolute/path/to/MLXL3\ Desktop.app'
    exit 2
fi
final_app="${2:A}"
out_dir="${repo_dir}/build/lfm-mtp-ui-state"
probe_dir="$(mktemp -d "${out_dir}/resolver-check.XXXXXX")"
trap 'rm -rf "${probe_dir}"' EXIT
helper_app="${probe_dir}/Resolver.app"
source_dir="${repo_dir}/apps/MLXL3Studio/Sources/MLXL3Studio"
executable_name="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "${final_app}/Contents/Info.plist")"
mkdir -p "${helper_app}/Contents/MacOS" "${helper_app}/Contents/Resources"
cp "${final_app}/Contents/Info.plist" "${helper_app}/Contents/Info.plist"
ditto "${final_app}/Contents/Resources/runtime" "${helper_app}/Contents/Resources/runtime"
# Extract the real enum verbatim; no bridge transport/model dependencies or stub.
awk 'BEGIN { print "import Foundation" } /^enum CLIResolver \{/ { copying=1 } /^private struct PendingDelta/ { exit } copying { print }' \
    "${source_dir}/MLXL3Bridge.swift" > "${probe_dir}/CLIResolver.swift"
cp "${probe_dir}/CLIResolver.swift" "${out_dir}/final-resolver-CLIResolver.swift"
print '{"status":"pending","stage":"compile"}' > "${out_dir}/final-resolver.json"
if ! swiftc -swift-version 6 -parse-as-library -warnings-as-errors \
    -sdk /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk \
    -module-cache-path "${out_dir}/resolver-modules" \
    "${source_dir}/EngineRuntimeStore.swift" "${source_dir}/UpdateManager.swift" \
    "${source_dir}/Localization.swift" "${probe_dir}/CLIResolver.swift" \
    "${out_dir}/final-resolver-check.swift" \
    -o "${helper_app}/Contents/MacOS/${executable_name}" \
    > "${out_dir}/final-resolver-build.log" 2>&1; then
    print '{"status":"failed","stage":"compile","log":"final-resolver-build.log"}' > "${out_dir}/final-resolver.json"
    exit 1
fi
# A caller override must not bypass the default managed/bundled policy being checked.
if env -u MLXL3_EXECUTABLE "${helper_app}/Contents/MacOS/${executable_name}" \
    "${final_app}" 1.4.5 1.4.4 > "${out_dir}/final-resolver.stdout" \
    2> "${out_dir}/final-resolver.log"; then
    cp "${out_dir}/final-resolver.stdout" "${out_dir}/final-resolver.json"
else
    print '{"status":"failed","stage":"resolver","stdout":"final-resolver.stdout","log":"final-resolver.log"}' > "${out_dir}/final-resolver.json"
    exit 1
fi
