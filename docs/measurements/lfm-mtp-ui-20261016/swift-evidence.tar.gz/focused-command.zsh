#!/bin/zsh
set -euo pipefail
cd /Users/justin/.codex/worktrees/lfm-mtp-ui-state/mix-stq1_0
out=build/lfm-mtp-ui-state
bin=apps/MLXL3Studio/.build/debug
sources=(apps/MLXL3Studio/Sources/MLXL3Studio/*.swift)
sources=("${(@)sources:#*/MLXL3StudioApp.swift}")
sources=("${(@)sources:#*/StudioModel.swift}")
awk '{ print }' apps/MLXL3Studio/Sources/MLXL3Studio/StudioModel.swift tests/speculative-sampling-check.swift > "${out}/SamplingCombined.swift"
objects=("${bin}/SwiftMath.o")
swiftc -whole-module-optimization -Onone -swift-version 6 -parse-as-library -warnings-as-errors -sdk /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk -module-cache-path "${out}/modules" -I "${bin}" "${sources[@]}" "${objects[@]}" "${out}/SamplingCombined.swift" -o "${out}/sampling-check"
MLXL3_SKIP_METAL_CHECK=1 "${out}/sampling-check" "$PWD/tests/fake-desktop-engine.py" "$PWD/apps/MLXL3Studio/Sources/MLXL3Studio/GenerationInspector.swift"
