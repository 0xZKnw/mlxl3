from scripts.kani_ci import check_verdict


def warning_always_rejects(prefix: str, name: str, count: int) -> bool:
    """post: __return__ is False"""
    return check_verdict(
        prefix + "not enough arguments, inserting non-deterministic value", name, count
    )
