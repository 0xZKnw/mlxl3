import importlib.util
import json
import os
import sys
from pathlib import Path

spec = importlib.util.spec_from_file_location("kani_ci", "/workspace/mlxl3/scripts/kani_ci.py")
ci = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ci)
out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=False)
results = []
for name in sys.argv[2:]:
    log = out / (name.replace("::", "-") + ".log")
    command = ["cargo", "kani", "--manifest-path", os.environ.get("KANI_TRIAL_MANIFEST", "/workspace/kani-metadata-trial/Cargo.toml"), "--lib", "--no-default-features", "-Z", "stubbing", "--exact", "--harness", name, "--jobs", "1", "--output-format", os.environ.get("KANI_TRIAL_FORMAT", "terse")]
    r = ci.run_process(command, log, 600)
    if r["status"] == "completed":
        r["status"] = "success" if ci.check_verdict(log.read_text(), name, 1) else "invalid_output"
    r["name"] = name
    results.append(r)
    (out / "report.json").write_text(json.dumps(results, indent=2))
    print(name, r["status"], r["seconds"], flush=True)
sys.exit(not all(r["status"] == "success" for r in results))
