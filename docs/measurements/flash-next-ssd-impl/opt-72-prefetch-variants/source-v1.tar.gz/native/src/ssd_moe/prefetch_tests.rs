use super::*;

#[test]
#[ignore = "physical Apple GPU; DFlash B1..8, Hot with pending banks and next-layer reads"]
fn draft_prefetch_preserves_hot_splits_and_next_layer_outputs() -> Result<()> {
    let (checkpoint, input, expected_first) = super::tests::admission_fixture()?;
    let base = input.to_f32()?;
    ensure!(base.len() == H as usize && base.iter().all(|v| v.is_finite()));
    let mut reference = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 80, false)?;
    let mut next_reference =
        SsdMoe::load(&checkpoint, "model.language_model.layers.1.mlp", 80, false)?;
    let mut cases = 0;
    let mut split_cases = 0;
    for variant in [
        PrefetchVariant::Legacy,
        PrefetchVariant::Late,
        PrefetchVariant::Bounded,
        PrefetchVariant::Unused,
        PrefetchVariant::Lfu,
        PrefetchVariant::Weighted,
        PrefetchVariant::Packed,
    ] {
        let mut used_by_variant = 0;
        for capacity in [24, 53] {
            let pool = Rc::new(RefCell::new(ReaderPool::new()?));
            let mut current = SsdMoe::load(
                &checkpoint,
                "model.language_model.layers.0.mlp",
                capacity,
                true,
            )?;
            let mut next = SsdMoe::load(
                &checkpoint,
                "model.language_model.layers.1.mlp",
                capacity,
                true,
            )?;
            for (index, moe) in [&mut current, &mut next].into_iter().enumerate() {
                for bank in &mut moe.banks {
                    // An accidental read of an unfilled scale becomes NaN, not a plausible zero.
                    *bank = Array::from_bytes(
                        &vec![0xff; bank.byte_len()?],
                        bank.shape(),
                        bank.dtype(),
                    )?;
                }
                moe.prefetch_pipeline = true;
                moe.prefetch_variant = variant;
                moe.cache.borrow_mut().prefer_unused_prefetch = variant == PrefetchVariant::Unused;
                moe.gpu_hot = true;
                moe.gpu_hot_wide = true;
                moe.unique_cohorts = true;
                moe.prefetcher = Some((index, Rc::clone(&pool)));
            }
            for rows in 1..=8 {
                pool.borrow_mut().wait_for_test()?;
                current.drain()?;
                next.drain()?;
                current.cache.borrow_mut().invalidate();
                next.cache.borrow_mut().invalidate();
                current.cohort_sizes.clear();
                let values = (0..rows)
                    .flat_map(|r| {
                        base.iter().enumerate().map(move |(c, &v)| {
                            if r == 0 {
                                v
                            } else {
                                ((r * 73 + c * 29) % 1021) as f32 / 256. - 2.
                            }
                        })
                    })
                    .collect::<Vec<_>>();
                let x = Array::from_f32(&values, &[rows as i32, H])?;
                let expected = reference.forward_draft_rows(&x)?;
                ensure!(expected.slice(0, 0, 1)?.to_bytes()? == expected_first);
                let expected_next = next_reference.forward_draft_rows(&x)?;
                let ids = current.route(&input)?.0.to_u32()?;
                let routes = current.cache.borrow_mut().reserve(&ids[..5])?;
                current.fill_many(
                    &ids[..5]
                        .iter()
                        .zip(routes)
                        .map(|(&id, (slot, _))| (id, slot))
                        .collect::<Vec<_>>(),
                )?;
                let submitted = pool
                    .borrow()
                    .counters
                    .submitted
                    .load(std::sync::atomic::Ordering::Relaxed);
                let predicted = next.prefetch_profile[0];
                let hot = current.hybrid_submissions;
                let actual = current.forward_draft_lookahead(&x, Some(&mut next), 2)?;
                let protected = next.cache.borrow().prediction_count_for_test();
                ensure!(
                    if variant == PrefetchVariant::Bounded {
                        (1..=2).contains(&protected)
                    } else {
                        protected >= 16
                    },
                    "prediction protection did not use the selected variant"
                );
                if variant == PrefetchVariant::Late && rows * 10 <= capacity {
                    let hot = current
                        .schedule_events
                        .iter()
                        .position(|p| p.0 == "hot_submitted");
                    let prediction = current
                        .schedule_events
                        .iter()
                        .position(|p| p.0 == "prediction_submitted");
                    ensure!(
                        hot.zip(prediction).is_some_and(|(h, p)| h < p),
                        "prediction ran before Hot"
                    );
                }
                ensure!(actual.shape() == [rows as i32, H]);
                let actual_values = actual.to_f32()?;
                ensure!(
                    actual_values.len() == rows * H as usize
                        && actual_values.iter().all(|v| v.is_finite())
                );
                ensure!(
                    actual.to_bytes()? == expected.to_bytes()?,
                    "draft prefetch changed routed values"
                );
                ensure!(
                    current.hybrid_submissions > hot,
                    "prefetch disabled early Hot"
                );
                let prediction_rows = if variant == PrefetchVariant::Weighted {
                    1
                } else {
                    rows.min(2)
                };
                ensure!(next.prefetch_profile[0] - predicted == (prediction_rows * 16) as u64);
                ensure!(
                    pool.borrow()
                        .counters
                        .submitted
                        .load(std::sync::atomic::Ordering::Relaxed)
                        - submitted
                        == 2
                );
                split_cases += usize::from(current.cohort_sizes.len() > 1);
                pool.borrow_mut().wait_for_test()?;
                let used = pool
                    .borrow()
                    .counters
                    .used
                    .load(std::sync::atomic::Ordering::Relaxed);
                let actual_next = next.forward_draft_rows(&x)?;
                let requested_lru =
                    std::env::var("MLXL3_SSD_CACHE_POLICY").ok().as_deref() == Some("lru");
                ensure!(
                    next.cache.borrow().predictive_lru_for_test()
                        == (variant != PrefetchVariant::Lfu || requested_lru),
                    "prefetch demand changed the requested LFU policy"
                );
                ensure!(
                    actual_next.shape() == [rows as i32, H]
                        && actual_next.to_bytes()? == expected_next.to_bytes()?
                );
                let consumed = pool
                    .borrow()
                    .counters
                    .used
                    .load(std::sync::atomic::Ordering::Relaxed)
                    - used;
                ensure!(consumed <= 2);
                if variant != PrefetchVariant::Weighted {
                    ensure!(consumed > 0);
                }
                used_by_variant += consumed;
                cases += 1;
            }
            current.drain()?;
            next.drain()?;
            pool.borrow_mut().wait_for_test()?;
        }
        ensure!(used_by_variant > 0, "predictions were never used");
        println!("PREFETCH_VARIANT variant={variant:?} cases=16 used={used_by_variant}");
    }
    ensure!(cases == 112 && split_cases > 0);
    println!(
        "SSD_DRAFT_PIPELINE cases={cases} split_cases={split_cases} hot_preserved=true predictions=verified next_outputs=byte_exact"
    );
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU and Flash checkpoint; one variant per process"]
fn environment_controls_reach_the_production_moe_cache() -> Result<()> {
    let (checkpoint, _, _) = super::tests::admission_fixture()?;
    let moe = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 24, true)?;
    let name = std::env::var("MLXL3_SSD_PREFETCH_VARIANT")?;
    let expected = PrefetchVariant::parse(&name).context("invalid test variant")?;
    ensure!(moe.prefetch_variant == expected);
    ensure!(moe.cache.borrow().prefer_unused_prefetch == (expected == PrefetchVariant::Unused));
    ensure!(
        moe.early_shared == (std::env::var("MLXL3_SSD_EARLY_SHARED").ok().as_deref() == Some("1"))
    );
    println!(
        "PREFETCH_CONFIG variant={expected:?} cache_wiring=true early_shared={}",
        moe.early_shared
    );
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU and real Flash router weights; run alone"]
fn pooled_predictions_match_independent_probability_sums() -> Result<()> {
    let (moe, x) = super::tests::resident_gate_fixture()?.remove(0);
    let x = Array::concatenate(&[&x[0], &x[1]], 0)?;
    let scores = moe.gate.forward(&x)?;
    let probabilities = scores.softmax_precise()?.to_f32()?;
    ensure!(probabilities.len() == 1024 && probabilities.iter().all(|p| p.is_finite()));
    let sums = (0..512)
        .map(|i| probabilities[i] + probabilities[512 + i])
        .collect::<Vec<_>>();
    let ids = moe.predict_with_pooling(&x, true)?.to_u32()?;
    ensure!(ids.len() == 16 && ids.iter().all(|&id| id < 512));
    let unique = ids
        .iter()
        .copied()
        .collect::<std::collections::BTreeSet<_>>();
    ensure!(unique.len() == 16);
    let minimum = ids
        .iter()
        .map(|&id| sums[id as usize])
        .fold(f32::INFINITY, f32::min);
    ensure!(
        (0..512)
            .filter(|id| !unique.contains(id))
            .all(|id| sums[id as usize] <= minimum)
    );
    ensure!(
        ids.windows(2)
            .all(|pair| sums[pair[0] as usize] <= sums[pair[1] as usize])
    );
    println!("POOLED_PREDICTIONS rows=2 unique=16 cpu_sum_oracle=true");
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU; delayed independent graph checks prediction readback"]
fn packed_prediction_readback_preserves_ids_without_waiting_for_later_work() -> Result<()> {
    let (mut moe, inputs) = super::tests::resident_gate_fixture()?.remove(0);
    let x = Array::concatenate(&[&inputs[0], &inputs[1]], 0)?;
    let value = Array::from_f32(&[1.0], &[1])?.astype(Dtype::Float16)?;
    let mut oracle = None;
    let mut observed = Vec::new();
    for variant in [PrefetchVariant::Legacy, PrefetchVariant::Packed] {
        moe.prefetch_variant = variant;
        let prediction = moe.predict(&x)?;
        ensure!(
            prediction.shape()
                == if variant == PrefetchVariant::Packed {
                    &[32][..]
                } else {
                    &[2, 16][..]
                }
        );
        prediction.eval()?;
        let delayed = hybrid_tests::delay(&value)?;
        let ids = prediction.to_u32();
        let ready = delayed.is_available_for_test();
        let completion = delayed.eval();
        let ids = ids?;
        let ready = ready?;
        completion?;
        ensure!(ids.len() == 32 && ids.iter().all(|&id| id < 512));
        match &oracle {
            Some(expected) => ensure!(&ids == expected, "packing changed predicted IDs"),
            None => oracle = Some(ids),
        }
        observed.push((variant, ready));
    }
    println!("PREDICTION_READBACK ids=32 exact=true later_ready={observed:?}");
    ensure!(
        observed
            == [
                (PrefetchVariant::Legacy, true),
                (PrefetchVariant::Packed, false)
            ],
        "prediction readback did not reproduce the expected queue behavior"
    );
    Ok(())
}

#[cfg(kani)]
#[kani::proof]
fn actual_uninitialized_slot_reads_preserve_outputs() {
    draft_prefetch_preserves_hot_splits_and_next_layer_outputs().unwrap();
}

#[cfg(kani)]
#[kani::proof]
fn actual_draft_prefetch_pipeline_preserves_outputs() {
    draft_prefetch_preserves_hot_splits_and_next_layer_outputs().unwrap();
}
