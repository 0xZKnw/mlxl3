use super::*;

#[test]
#[ignore = "physical Apple GPU/checkpoint; actual Flash F01 loader and MoE paths"]
fn real_flash_half_output_preserves_cold_hot_and_wide_moe() -> Result<()> {
    let root = std::path::PathBuf::from(std::env::var("MLXL3_FLASH_REFERENCE")?);
    let reference: serde_json::Value =
        serde_json::from_reader(std::fs::File::open(root.join("reference.json"))?)?;
    ensure!(reference["status"] == "complete" && reference["mode"] == "eval");
    let checkpoint =
        crate::checkpoint::inspect(std::path::Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
    crate::array::set_default_cache_limit(64 << 20)?;
    let mut checked = 0;
    for layer in [0usize, 15, 31, 47] {
        let entry = &reference["steps"][0]["components"][layer]["mlp"]["input"];
        ensure!(entry["count"] == H);
        let bytes =
            std::fs::read(root.join(entry["file"].as_str().context("missing input fixture")?))?;
        ensure!(bytes.len() == H as usize * 4);
        let input = Array::from_bytes(&bytes, &[1, H], Dtype::Float32)?;
        ensure!(input.to_f32()?.iter().all(|v| v.is_finite()));
        for dtype in [Dtype::Float16, Dtype::Float32] {
            for rows in [1, 2, 4, 8] {
                let one = input.astype(dtype)?;
                let x = Array::concatenate(&vec![&one; rows], 0)?;
                let prefix = format!("model.language_model.layers.{layer}.mlp");
                let mut baseline = SsdMoe::load(&checkpoint, &prefix, 20, true)?;
                let mut candidate = SsdMoe::load(&checkpoint, &prefix, 20, true)?;
                ensure!(
                    baseline.qmv_half_output && candidate.qmv_half_output,
                    "load-time F01 flag was not enabled"
                );
                baseline.qmv_half_output = false;
                for round in 0..2 {
                    let (old, old_partials) =
                        crate::linear::half_output_tests::capture_all(|| {
                            baseline.forward_draft_rows(&x)
                        })?;
                    let (new, new_partials) =
                        crate::linear::half_output_tests::capture_all(|| {
                            candidate.forward_draft_rows(&x)
                        })?;
                    ensure!(
                        !old_partials.is_empty() && old_partials.len() == new_partials.len(),
                        "missing real partials"
                    );
                    for (old_partial, new_partial) in old_partials.iter().zip(&new_partials) {
                        ensure!(
                            old_partial.dtype() == Dtype::Float32
                                && new_partial.dtype() == Dtype::Float16,
                            "F01 real store not exercised"
                        );
                        ensure!(
                            old_partial.shape() == new_partial.shape()
                                && old_partial.astype(Dtype::Float16)?.to_bytes()?
                                    == new_partial.to_bytes()?,
                            "real GU/down partial mismatch"
                        );
                    }
                    ensure!(
                        old.shape() == [rows as i32, H]
                            && new.shape() == old.shape()
                            && new.dtype() == dtype
                    );
                    let values = new.to_f32()?;
                    ensure!(
                        values.len() == rows * H as usize && values.iter().all(|v| v.is_finite())
                    );
                    ensure!(
                        old.to_bytes()? == new.to_bytes()?,
                        "F01 MoE mismatch layer={layer},rows={rows},dtype={dtype:?},round={round}"
                    );
                    baseline.drain()?;
                    candidate.drain()?;
                    checked += 1;
                }
                ensure!(
                    candidate.hits > 0 && candidate.misses > 0,
                    "cold/hot coverage missing"
                );
                if rows == 8 {
                    ensure!(
                        !candidate.cohort_sizes.is_empty(),
                        "wide cohort path not exercised"
                    );
                }
            }
        }
    }
    ensure!(checked == 64);
    println!(
        "FLASH_HALF_REAL cases={checked} layers=4 rows=1,2,4,8 dtypes=F16,F32 rounds=cold,hot loader=true parity=byte_exact"
    );
    Ok(())
}
