use super::*;
use std::path::Path;

#[test]
#[ignore = "physical Flash checkpoint; 82F06 all 48 gates on two captured inputs"]
fn top10_early_exit_preserves_real_routes_and_normalization() -> Result<()> {
    let root = std::env::var("MLXL3_FLASH_REFERENCE")?;
    let root = Path::new(&root);
    let reference: serde_json::Value =
        serde_json::from_reader(std::fs::File::open(root.join("reference.json"))?)?;
    ensure!(reference["status"] == "complete" && reference["mode"] == "eval");
    let checkpoint = crate::checkpoint::inspect(Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
    let mut cases = 0;
    for layer in 0..48 {
        let mut moe = SsdMoe::load(
            &checkpoint,
            &format!("model.language_model.layers.{layer}.mlp"),
            20,
            true,
        )?;
        for step in 0..2 {
            let components = reference["steps"][step]["components"]
                .as_array()
                .context("missing components")?;
            ensure!(components.len() == 48);
            let entry = &components[layer]["mlp"]["input"];
            ensure!(entry["count"] == H);
            let bytes = std::fs::read(
                root.join(entry["file"].as_str().context("missing captured input")?),
            )?;
            ensure!(bytes.len() == H as usize * 4);
            let input = Array::from_bytes(&bytes, &[1, H], Dtype::Float32)?;
            ensure!(input.to_f32()?.iter().all(|v| v.is_finite()));
            for dtype in [Dtype::Float16, Dtype::Float32] {
                for strided in [false, true] {
                    let x = if strided {
                        let interleaved = input
                            .to_f32()?
                            .into_iter()
                            .flat_map(|value| [value, value * 0.5])
                            .collect::<Vec<_>>();
                        Array::from_f32(&interleaved, &[H, 2])?
                            .astype(dtype)?
                            .transpose(&[1, 0])?
                            .slice(0, 0, 1)?
                    } else {
                        input.astype(dtype)?
                    };
                    let probabilities = moe.gate_logits(&x)?.softmax_precise()?;
                    ensure!(
                        probabilities.shape() == [1, 512]
                            && probabilities.to_f32()?.iter().all(|v| v.is_finite())
                    );
                    let old = if dtype == Dtype::Float16 {
                        let (ids, scores) = router::topk(&probabilities, 10, false)?;
                        let normalized = scores.div(&scores.sum(1, true)?)?;
                        (ids, normalized)
                    } else {
                        router::topk(&probabilities, 10, true)?
                    };
                    for enabled in [false, true] {
                        moe.top10_early_exit = enabled;
                        let actual = moe.route(&x)?;
                        ensure!(actual.0.shape() == [1, 10] && actual.1.shape() == [1, 10]);
                        ensure!(actual.0.to_u32()? == old.0.to_u32()?);
                        ensure!(actual.1.to_bytes()? == old.1.to_bytes()?);
                        ensure!(actual.1.to_f32()?.iter().all(|v| v.is_finite()));
                    }
                    cases += 1;
                }
            }
        }
        moe.drain()?;
    }
    ensure!(cases == 384);
    println!(
        "SSD_TOP10_EARLY_EXIT cases={cases} layers=48 inputs=2 f16_f32=true strides=true ids_scores=byte_exact"
    );
    Ok(())
}

#[test]
#[ignore = "physical Flash checkpoint; environment fixed before process start; run default, flag0 and flag1 separately"]
fn top10_early_exit_flag_reaches_production_loader() -> Result<()> {
    let (checkpoint, input, _) = super::tests::admission_fixture()?;
    let expected = match std::env::var("MLXL3_SSD_TOP10_EARLY_EXIT") {
        Ok(value) => {
            crate::flash_support::parse_gpu_hot_wide(&value).context("invalid test flag")?
        }
        Err(std::env::VarError::NotPresent) => false,
        Err(error) => return Err(error.into()),
    };
    let moe = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 20, true)?;
    ensure!(moe.top10_early_exit == expected);
    let routed = moe.route(&input)?;
    ensure!(routed.0.to_u32()?.len() == 10 && routed.1.to_f32()?.len() == 10);
    println!("SSD_TOP10_EARLY_EXIT_LOADER configured={expected} environment_mutated=false");
    Ok(())
}
