use super::*;
use std::cell::RefCell;

thread_local! {
    static PARTIALS: RefCell<Option<Vec<Array>>> = const { RefCell::new(None) };
}

pub(super) fn observe(partials: &Array) -> Result<()> {
    PARTIALS.with_borrow_mut(|capture| {
        if let Some(capture) = capture {
            capture.push(partials.try_clone()?);
        }
        Ok(())
    })
}

pub(crate) fn capture_all(run: impl FnOnce() -> Result<Array>) -> Result<(Array, Vec<Array>)> {
    struct Clear;
    impl Drop for Clear {
        fn drop(&mut self) {
            PARTIALS.with_borrow_mut(|capture| *capture = None);
        }
    }
    PARTIALS.with_borrow_mut(|capture| {
        assert!(capture.is_none());
        *capture = Some(Vec::new());
    });
    let _clear = Clear;
    let output = run()?;
    let captures = PARTIALS.with_borrow_mut(|capture| capture.take().unwrap());
    Ok((output, captures))
}

fn capture(run: impl FnOnce() -> Result<Array>) -> Result<(Array, Array)> {
    let (output, mut captures) = capture_all(run)?;
    ensure!(
        captures.len() == 1,
        "expected one actual QMV dispatch result"
    );
    Ok((output, captures.remove(0)))
}

#[test]
#[ignore = "physical Apple GPU; exact F32 to F16 store boundaries"]
fn half_store_matches_mlx_cast_at_every_finite_half_boundary() -> Result<()> {
    let mut values = vec![0.0f32, -0.0, f32::from_bits(1), -f32::from_bits(1)];
    for bits in 0..0x7bffu16 {
        let low = half::f16::from_bits(bits).to_f32();
        let high = half::f16::from_bits(bits + 1).to_f32();
        let midpoint = (low + high) * 0.5;
        for value in [
            low,
            midpoint,
            f32::from_bits(midpoint.to_bits() - 1),
            f32::from_bits(midpoint.to_bits() + 1),
        ] {
            values.extend([value, -value]);
        }
    }
    for value in [
        65504.0f32,
        65520.0,
        f32::from_bits(65520.0f32.to_bits() - 1),
        f32::from_bits(65520.0f32.to_bits() + 1),
        f32::MAX,
        f32::INFINITY,
    ] {
        values.extend([value, -value]);
    }
    values.extend([f32::from_bits(0x7fc00000), f32::from_bits(0xffc00000)]);
    let x = Array::from_f32(&values, &[values.len() as i32])?;
    let expected = x.astype(Dtype::Float16)?;
    let actual = array::metal_kernel(
        "mlxl3_half_store_boundary",
        &["x"],
        &["out"],
        "",
        "uint i=thread_position_in_grid.x; if(i<uint(x_shape[0])) out[i]=x[i];",
        &[&x],
        &[x.shape().to_vec()],
        &[Dtype::Float16],
        [values.len() as i32, 1, 1],
        [256, 1, 1],
    )?
    .remove(0);
    ensure!(
        actual.to_bytes()? == expected.to_bytes()?,
        "Metal store differs from MLX cast"
    );
    println!(
        "FLASH_HALF_STORE boundaries={} parity=byte_exact",
        values.len()
    );
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU; F01 actual QMV partials and full expert outputs"]
fn half_qmv_preserves_partials_outputs_masks_and_multisplit_fallback() -> Result<()> {
    let cases = [
        vec![2u32],
        vec![0, 1],
        vec![2, 0, 2, 1],
        (0..10).map(|i| i % 3).collect(),
        (0..20).map(|i| i % 3).collect(),
    ];
    let (mut checked, mut fast, mut fallback) = (0, 0, 0);
    for (input, output, projections) in [
        (2560usize, 640usize, 2usize),
        (640, 2560, 1),
        (6144, 2560, 1),
    ] {
        let words = input / 16 * (output / 16) * 32;
        let packed = (0..3 * projections * words)
            .map(|i| (i as u16).wrapping_mul(1777))
            .collect::<Vec<_>>();
        let bank = Array::from_u16(
            &packed,
            &[
                3,
                projections as i32,
                (input / 16) as i32,
                (output / 16) as i32,
                32,
            ],
        )?;
        for dtype in [Dtype::Float16, Dtype::Float32] {
            for strided in [false, true] {
                for routes in &cases {
                    if input == 6144 && routes.len() > 2 {
                        continue;
                    }
                    let rows = routes.len() * projections;
                    let at = |r: usize, c: usize| match (r * input + c) % 17 {
                        0 => -0.0,
                        1 => 2.0f32.powi(-24),
                        2 => -2.0f32.powi(-14),
                        _ => ((r * 37 + c * 13) % 997) as f32 / 2048.0 - 0.25,
                    };
                    let x = if strided {
                        let values = (0..input)
                            .flat_map(|c| (0..rows).map(move |r| at(r, c)))
                            .collect::<Vec<_>>();
                        Array::from_f32(&values, &[input as i32, rows as i32])?
                            .astype(dtype)?
                            .transpose(&[1, 0])?
                    } else {
                        let values = (0..rows)
                            .flat_map(|r| (0..input).map(move |c| at(r, c)))
                            .collect::<Vec<_>>();
                        Array::from_f32(&values, &[rows as i32, input as i32])?.astype(dtype)?
                    };
                    let scale = |width: usize| -> Result<Array> {
                        Array::from_f32(
                            &(0..rows * width)
                                .map(|i| 0.125 + (i % 11) as f32 / 128.0)
                                .collect::<Vec<_>>(),
                            &[rows as i32, width as i32],
                        )?
                        .astype(Dtype::Float16)
                    };
                    let (su, sv) = (scale(input)?, scale(output)?);
                    for kind in 0..5 {
                        let slots = match kind {
                            0 => ExpertSlots::new(routes, 3)?,
                            1 => ExpertSlots::grouped(routes, 3)?,
                            _ => {
                                let mut map = [u32::MAX; 512];
                                for (id, slot) in map.iter_mut().enumerate().take(3) {
                                    if kind == 4 || (kind == 3 && id % 2 == 0) {
                                        *slot = id as u32;
                                    }
                                }
                                ExpertSlots::residents(
                                    &Array::from_u32(routes, &[routes.len() as i32])?,
                                    &map,
                                    3,
                                )?
                            }
                        };
                        let run = |enabled| {
                            capture(|| {
                                expert_slots(
                                    &x,
                                    &bank,
                                    &su,
                                    &sv,
                                    &slots,
                                    output as i32,
                                    projections as i32,
                                    2,
                                    Codebook::Mul1,
                                    false,
                                    enabled,
                                )
                            })
                        };
                        let (old, old_partial) = run(false)?;
                        let (new, new_partial) = run(true)?;
                        let eligible = input != 6144;
                        ensure!(old_partial.dtype() == Dtype::Float32);
                        ensure!(
                            new_partial.dtype()
                                == if eligible {
                                    Dtype::Float16
                                } else {
                                    Dtype::Float32
                                },
                            "fast path/fallback not exercised"
                        );
                        let expected = if eligible {
                            old_partial.astype(Dtype::Float16)?
                        } else {
                            old_partial
                        };
                        ensure!(
                            new_partial.shape() == expected.shape()
                                && new_partial.to_bytes()? == expected.to_bytes()?,
                            "QMV partial differs input={input},kind={kind},dtype={dtype:?}"
                        );
                        ensure!(
                            new.dtype() == dtype && new.shape() == [rows as i32, output as i32]
                        );
                        let values = new.to_f32()?;
                        ensure!(
                            values.len() == rows * output && values.iter().all(|v| v.is_finite())
                        );
                        ensure!(
                            new.to_bytes()? == old.to_bytes()?,
                            "expert output differs input={input},kind={kind},dtype={dtype:?},strided={strided},routes={routes:?}"
                        );
                        fast += usize::from(eligible);
                        fallback += usize::from(!eligible);
                        checked += 1;
                    }
                }
            }
        }
    }
    ensure!((checked, fast, fallback) == (240, 200, 40));
    println!(
        "FLASH_HALF_QMV cases={checked} fast={fast} multisplit_fallback={fallback} masks=none,mixed,all groups=singleton,shared partials=byte_exact outputs=byte_exact"
    );
    Ok(())
}
