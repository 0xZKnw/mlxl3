use super::*;
use std::cmp::Ordering;

fn expected_ids(values: &[f32; 512]) -> Vec<u32> {
    let mut ids = (0..512u32).collect::<Vec<_>>();
    ids.sort_by(|&a, &b| {
        let (a_value, b_value) = (values[a as usize], values[b as usize]);
        let order = match (a_value.is_nan(), b_value.is_nan()) {
            (true, false) => Ordering::Greater,
            (false, true) => Ordering::Less,
            (true, true) => Ordering::Equal,
            (false, false) => a_value
                .partial_cmp(&b_value)
                .expect("finite/inf comparison"),
        };
        order.then(a.cmp(&b))
    });
    ids[502..].to_vec()
}

fn values_for(rows: i32, fixture: usize) -> Vec<f32> {
    (0..rows * 512)
        .map(|i| {
            let column = i % 512;
            match fixture {
                0 => 1.,
                1 => (column + 1) as f32 / 1024.,
                2 => (512 - column) as f32 / 1024.,
                3 => {
                    if i % 2 == 0 {
                        0.
                    } else {
                        -0.
                    }
                }
                4 => [
                    f32::NAN,
                    -f32::NAN,
                    f32::INFINITY,
                    f32::NEG_INFINITY,
                    1.,
                    -1.,
                    0.,
                    -0.,
                ][i as usize % 8],
                5 => ((i * 179 + 71) % 1009) as f32 / 257. - 2.,
                6 => [
                    f32::from_bits(1),
                    -f32::from_bits(1),
                    f32::from_bits(0x3380_0000),
                    -f32::from_bits(0x3380_0000),
                    65504.,
                    -65504.,
                    f32::MAX,
                    -f32::MAX,
                ][i as usize % 8],
                7 => f32::from_bits(0x3f80_0000 + ((i * 53) % 19) as u32),
                _ => unreachable!(),
            }
        })
        .collect()
}

#[test]
#[ignore = "physical Apple GPU; 82F06 exact legacy Flash top-10 component"]
fn flash_top10_early_exit_matches_independent_ranks_and_legacy_scores() -> Result<()> {
    let mut cases = 0;
    for rows in [1, 2, 4, 8] {
        for dtype in [Dtype::Float16, Dtype::Float32] {
            for strided in [false, true] {
                for fixture in 0..8 {
                    let values = values_for(rows, fixture);
                    let input = if strided {
                        let mut columns = vec![0.; values.len()];
                        for row in 0..rows as usize {
                            for column in 0..512 {
                                columns[column * rows as usize + row] = values[row * 512 + column];
                            }
                        }
                        Array::from_f32(&columns, &[512, rows])?
                            .astype(dtype)?
                            .transpose(&[1, 0])?
                    } else {
                        Array::from_f32(&values, &[rows, 512])?.astype(dtype)?
                    };
                    // Sort the values actually represented by each input dtype.
                    let represented = input.to_f32()?;
                    ensure!(represented.len() == rows as usize * 512);
                    let expected = represented
                        .as_chunks::<512>()
                        .0
                        .iter()
                        .flat_map(expected_ids)
                        .collect::<Vec<_>>();
                    for normalize in [false, true] {
                        let legacy = topk_legacy(&input, 10, normalize)?;
                        let disabled = flash_top10(&input, normalize, false)?;
                        let enabled = flash_top10(&input, normalize, true)?;
                        ensure!(crate::flash_support::flash_top10_early_exit(512, 10, true));
                        for actual in [&legacy, &disabled, &enabled] {
                            ensure!(
                                actual.0.shape() == [rows, 10] && actual.0.dtype() == Dtype::UInt32
                            );
                            ensure!(actual.1.shape() == [rows, 10] && actual.1.dtype() == dtype);
                            ensure!(
                                actual.0.to_u32()? == expected,
                                "independent rank oracle rows={rows} fixture={fixture}"
                            );
                            ensure!(
                                actual.1.to_bytes()?.len()
                                    == rows as usize
                                        * 10
                                        * if dtype == Dtype::Float16 { 2 } else { 4 }
                            );
                        }
                        ensure!(
                            enabled.1.to_bytes()? == legacy.1.to_bytes()?,
                            "score bits rows={rows} fixture={fixture} normalize={normalize}"
                        );
                        ensure!(disabled.1.to_bytes()? == legacy.1.to_bytes()?);
                        if !normalize {
                            let actual = enabled.1.to_f32()?;
                            for row in 0..rows as usize {
                                for column in 0..10 {
                                    let reference = represented
                                        [row * 512 + expected[row * 10 + column] as usize];
                                    let score = actual[row * 10 + column];
                                    if reference.is_nan() {
                                        ensure!(score.is_nan());
                                    } else {
                                        ensure!(
                                            score.to_bits() == reference.to_bits(),
                                            "raw score bits, including signed zero"
                                        );
                                    }
                                }
                            }
                        }
                        if matches!(fixture, 0..=2 | 7) {
                            ensure!(enabled.1.to_f32()?.iter().all(|v| v.is_finite()));
                        }
                        cases += 1;
                    }
                }
            }
        }
    }
    ensure!(cases == 256);
    println!(
        "FLASH_TOP10_EARLY_EXIT cases={cases} independent_ranks=true scores=byte_exact ties=true nan=true signed_zero=true strides=true"
    );
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU; 82F06 metadata rejection and unchanged generic routers"]
fn flash_top10_early_exit_rejects_invalid_metadata_and_preserves_other_domains() -> Result<()> {
    for shape in [vec![512], vec![1, 511], vec![1, 513], vec![1, 1, 512]] {
        let count = shape.iter().product::<i32>() as usize;
        let input = Array::from_f32(&vec![1.; count], &shape)?;
        ensure!(flash_top10(&input, true, true).is_err());
    }
    let invalid_dtype = Array::from_u32(&[1; 512], &[1, 512])?;
    ensure!(flash_top10(&invalid_dtype, true, true).is_err());
    let mut fallbacks = 0;
    for (experts, top_k) in [
        (17, 10),
        (256, 8),
        (511, 10),
        (512, 9),
        (512, 11),
        (513, 10),
    ] {
        let values = (0..experts)
            .map(|i| ((i * 53) % 409) as f32 / 1000.)
            .collect::<Vec<_>>();
        let input = Array::from_f32(&values, &[1, experts])?;
        ensure!(!crate::flash_support::flash_top10_early_exit(
            experts, top_k, true
        ));
        let legacy = topk_legacy(&input, top_k, true)?;
        let requested = topk_legacy_mode(&input, top_k, true, true)?;
        ensure!(legacy.0.to_u32()? == requested.0.to_u32()?);
        ensure!(legacy.1.to_bytes()? == requested.1.to_bytes()?);
        fallbacks += 1;
    }
    let valid = Array::from_f32(&[1.; 512], &[1, 512])?;
    ensure!(flash_top10(&valid, true, true)?.0.to_u32()? == (502..512).collect::<Vec<_>>());
    ensure!(fallbacks == 6);
    println!(
        "FLASH_TOP10_EARLY_EXIT_ERRORS fallbacks={fallbacks} invalid_metadata=true recovery=true"
    );
    Ok(())
}
