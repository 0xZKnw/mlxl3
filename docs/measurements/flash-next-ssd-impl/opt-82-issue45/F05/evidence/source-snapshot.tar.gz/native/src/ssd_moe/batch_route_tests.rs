use super::*;
use serde_json::Value;
use std::{fs, path::Path};

fn fixture() -> Result<(Checkpoint, std::path::PathBuf, Value)> {
    let checkpoint = crate::checkpoint::inspect(Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
    let root = std::path::PathBuf::from(std::env::var("MLXL3_FLASH_REFERENCE")?);
    let reference: Value = serde_json::from_reader(fs::File::open(root.join("reference.json"))?)?;
    ensure!(reference["status"] == "complete" && reference["mode"] == "eval");
    Ok((checkpoint, root, reference))
}

fn semantic_bytes(root: &Path, entry: &Value) -> Result<Vec<u8>> {
    ensure!(entry["count"] == H, "invalid MoE fixture count");
    let bytes = fs::read(root.join(entry["file"].as_str().context("missing fixture")?))?;
    ensure!(
        bytes.len() == H as usize * 4
            && bytes
                .as_chunks::<4>()
                .0
                .iter()
                .all(|&v| f32::from_le_bytes(v).is_finite()),
        "empty or nonfinite MoE fixture"
    );
    Ok(bytes)
}

fn input(values: &[Vec<f32>], rows: i32, dtype: Dtype, strided: bool) -> Result<Array> {
    let data = if strided {
        (0..H)
            .flat_map(|column| {
                (0..rows).map(move |row| values[row as usize % values.len()][column as usize])
            })
            .collect::<Vec<_>>()
    } else {
        (0..rows)
            .flat_map(|row| values[row as usize % values.len()].iter().copied())
            .collect()
    };
    let shape = if strided { [H, rows] } else { [rows, H] };
    let value = Array::from_f32(&data, &shape)?.astype(dtype)?;
    if strided {
        value.transpose(&[1, 0])
    } else {
        Ok(value)
    }
}

#[test]
#[ignore = "physical Apple GPU; scalar/batched softmax+top10 edge contracts, no model"]
fn batch_probability_rows_preserve_extremes_ties_and_nonfinite_bits() -> Result<()> {
    let mut cases = 0;
    for rows in [2, 3, 4, 8] {
        for pattern in 0..7 {
            let values = (0..rows * 512)
                .map(|i| {
                    let row = i / 512;
                    let col = i % 512;
                    match pattern {
                        0 => {
                            if (row + col) % 2 == 0 {
                                0.
                            } else {
                                -0.
                            }
                        }
                        1 => {
                            if col == row + 1 {
                                10000.
                            } else {
                                -10000.
                            }
                        }
                        2 => ((col * 17 + row * 37) % 97) as f32 / 1048576.,
                        3 => f32::NEG_INFINITY,
                        4 => {
                            if col == row {
                                f32::from_bits(0x7fc00017)
                            } else {
                                col as f32 / 512.
                            }
                        }
                        5 => {
                            if col == row {
                                f32::INFINITY
                            } else {
                                -1.
                            }
                        }
                        6 => {
                            if col < 10 + row {
                                1.
                            } else {
                                f32::NEG_INFINITY
                            }
                        }
                        _ => unreachable!(),
                    }
                })
                .collect::<Vec<_>>();
            let logits = Array::from_f32(&values, &[rows, 512])?;
            let probabilities = (0..rows)
                .map(|r| logits.slice(0, r, r + 1)?.softmax_precise())
                .collect::<Result<Vec<_>>>()?;
            let expected_p = Array::concatenate(&probabilities.iter().collect::<Vec<_>>(), 0)?;
            let expected = probabilities
                .iter()
                .map(|p| router::topk(p, 10, true))
                .collect::<Result<Vec<_>>>()?;
            let expected_ids =
                Array::concatenate(&expected.iter().map(|p| &p.0).collect::<Vec<_>>(), 0)?;
            let expected_weights =
                Array::concatenate(&expected.iter().map(|p| &p.1).collect::<Vec<_>>(), 0)?;
            let actual_p = logits.softmax_precise()?;
            let (actual_ids, actual_weights) = router::topk(&actual_p, 10, true)?;
            ensure!(
                actual_p.shape() == [rows, 512]
                    && actual_ids.shape() == [rows, 10]
                    && actual_weights.shape() == [rows, 10]
            );
            ensure!(
                actual_p.to_bytes()? == expected_p.to_bytes()?,
                "edge probabilities changed B{rows}/pattern{pattern}"
            );
            ensure!(
                actual_ids.to_bytes()? == expected_ids.to_bytes()?
                    && actual_weights.to_bytes()? == expected_weights.to_bytes()?,
                "edge route bits changed B{rows}/pattern{pattern}"
            );
            cases += 1;
        }
    }
    ensure!(cases == 28);
    println!(
        "FLASH_BATCH_ROUTE_EDGES cases={cases} probability_ids_weight_bits=exact nonfinite_historical_contract=true"
    );
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU; 48 real gates, scalar GEMV oracle and FP32 batch routes; run alone"]
fn batch_routes_match_real_scalar_logits_probabilities_ids_and_weights() -> Result<()> {
    let (checkpoint, root, reference) = fixture()?;
    let mut cases = 0;
    let mut fast_cases = 0;
    for layer in 0..48 {
        let prefix = format!("model.language_model.layers.{layer}.mlp");
        let mut moe = SsdMoe::load(&checkpoint, &prefix, 20, true)?;
        ensure!(
            moe.batch_routes,
            "requires BATCH_ROUTES=1 through the real loader"
        );
        let values = [0, 1]
            .into_iter()
            .map(|step| {
                let bytes = semantic_bytes(
                    &root,
                    &reference["steps"][step]["components"][layer]["mlp"]["input"],
                )?;
                Ok(bytes
                    .as_chunks::<4>()
                    .0
                    .iter()
                    .map(|&b| f32::from_le_bytes(b))
                    .collect::<Vec<_>>())
            })
            .collect::<Result<Vec<_>>>()?;
        let widths: &[i32] = if layer == 0 {
            &[1, 2, 3, 4, 5, 6, 7, 8]
        } else {
            &[1, 2, 3, 4, 8]
        };
        for resident in [false, true] {
            if resident && layer != 0 {
                continue;
            }
            moe.resident_gate = if resident {
                Some(
                    linear::checkpoint_array(&checkpoint, &format!("{prefix}.gate.weight"))?
                        .astype(Dtype::Float16)?
                        .transpose(&[1, 0])?
                        .astype(Dtype::Float32)?,
                )
            } else {
                None
            };
            for &rows in widths {
                for dtype in [Dtype::Float16, Dtype::Float32] {
                    for strided in [false, true] {
                        let x = input(&values, rows, dtype, strided)?;
                        let logits = (0..rows)
                            .map(|r| moe.gate.forward(&x.slice(0, r, r + 1)?))
                            .collect::<Result<Vec<_>>>()?;
                        let probabilities = logits
                            .iter()
                            .map(Array::softmax_precise)
                            .collect::<Result<Vec<_>>>()?;
                        let serial_logits =
                            Array::concatenate(&logits.iter().collect::<Vec<_>>(), 0)?;
                        let serial_probabilities =
                            Array::concatenate(&probabilities.iter().collect::<Vec<_>>(), 0)?;
                        moe.route_gate_calls.set(0);
                        let actual_logits = moe.gate_logits_rows(&x)?;
                        ensure!(
                            moe.route_gate_calls.get() == rows as usize,
                            "scalar GEMV count changed"
                        );
                        ensure!(
                            actual_logits.shape() == [rows, 512] && actual_logits.dtype() == dtype
                        );
                        ensure!(
                            actual_logits.to_bytes()? == serial_logits.to_bytes()?,
                            "gate logits differ layer={layer}"
                        );
                        let actual_probabilities = if dtype == Dtype::Float32 && rows > 1 {
                            actual_logits.softmax_precise()?
                        } else {
                            let rows = (0..rows)
                                .map(|r| actual_logits.slice(0, r, r + 1)?.softmax_precise())
                                .collect::<Result<Vec<_>>>()?;
                            Array::concatenate(&rows.iter().collect::<Vec<_>>(), 0)?
                        };
                        ensure!(
                            actual_probabilities.to_bytes()? == serial_probabilities.to_bytes()?,
                            "probabilities differ layer={layer}/B{rows}/{dtype:?}/strided={strided}/resident={resident}"
                        );
                        let pairs = (0..rows)
                            .map(|r| moe.route(&x.slice(0, r, r + 1)?))
                            .collect::<Result<Vec<_>>>()?;
                        let expected_ids =
                            Array::concatenate(&pairs.iter().map(|p| &p.0).collect::<Vec<_>>(), 0)?;
                        let expected_weights =
                            Array::concatenate(&pairs.iter().map(|p| &p.1).collect::<Vec<_>>(), 0)?;
                        moe.route_gate_calls.set(0);
                        moe.route_batch_calls.set(0);
                        let (ids, weights) = moe.route_rows(&x)?;
                        let fast = dtype == Dtype::Float32 && rows > 1;
                        ensure!(
                            moe.route_gate_calls.get() == rows as usize
                                && moe.route_batch_calls.get() == usize::from(fast),
                            "routing branch or scalar GEMV count changed"
                        );
                        ensure!(
                            ids.shape() == [rows, 10]
                                && weights.shape() == [rows, 10]
                                && weights.dtype() == dtype
                        );
                        ensure!(
                            ids.to_bytes()? == expected_ids.to_bytes()?
                                && weights.to_bytes()? == expected_weights.to_bytes()?,
                            "routes differ layer={layer}/B{rows}/{dtype:?}/strided={strided}/resident={resident}"
                        );
                        let p = serial_probabilities.to_f32()?;
                        let ids = ids.to_u32()?;
                        let weights = weights.to_f32()?;
                        ensure!(p.len() == rows as usize * 512 && p.iter().all(|v| v.is_finite()));
                        ensure!(
                            ids.len() == rows as usize * 10
                                && weights.len() == ids.len()
                                && weights.iter().all(|v| v.is_finite())
                        );
                        for r in 0..rows as usize {
                            let mut order = (0..512u32).collect::<Vec<_>>();
                            order.sort_by(|&a, &b| {
                                p[r * 512 + a as usize]
                                    .total_cmp(&p[r * 512 + b as usize])
                                    .then(a.cmp(&b))
                            });
                            ensure!(
                                ids[r * 10..(r + 1) * 10] == order[502..],
                                "independent CPU rank oracle differs"
                            );
                        }
                        cases += 1;
                        fast_cases += usize::from(fast);
                    }
                }
            }
        }
        if layer == 0 {
            let before = (
                moe.hits,
                moe.misses,
                moe.read_bytes,
                moe.route_gate_calls.get(),
                moe.route_batch_calls.get(),
            );
            for shape in [
                vec![],
                vec![H],
                vec![0, H],
                vec![9, H],
                vec![2, H - 1],
                vec![1, 2, H],
            ] {
                ensure!(
                    moe.route_rows(&Array::zeros_dtype(&shape, Dtype::Float32)?)
                        .is_err()
                );
            }
            ensure!(
                moe.route_rows(&Array::zeros_dtype(&[2, H], Dtype::UInt32)?)
                    .is_err()
            );
            ensure!(
                before
                    == (
                        moe.hits,
                        moe.misses,
                        moe.read_bytes,
                        moe.route_gate_calls.get(),
                        moe.route_batch_calls.get()
                    )
            );
        }
        moe.drain()?;
    }
    ensure!(
        cases == 1004 && fast_cases == 404,
        "incomplete gate coverage"
    );
    println!(
        "FLASH_BATCH_ROUTES gates=48 cases={cases} fast_cases={fast_cases} scalar_gemv=true logits_probabilities_ids_weights=byte_exact"
    );
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU; real MoE outputs, overflow-U Hot ordering, both cohorts and pending leases"]
fn batch_routes_preserve_hot_cohorts_pending_slots_and_outputs() -> Result<()> {
    let (checkpoint, root, reference) = fixture()?;
    let inputs = [0, 1, 4]
        .into_iter()
        .map(|step| {
            let entry = &reference["steps"][step]["components"][0]["mlp"];
            let x = Array::from_bytes(
                &semantic_bytes(&root, &entry["input"])?,
                &[1, H],
                Dtype::Float32,
            )?;
            Ok((x, semantic_bytes(&root, &entry["output"])?))
        })
        .collect::<Result<Vec<_>>>()?;
    let mut cases = 0;
    let mut hot_windows_checked = 0;
    for (capacity, pending) in [(20, 0), (53, 0), (53, 4)] {
        for unique in [false, true] {
            for rows in [1usize, 2, 3, 8] {
                let mut moe = SsdMoe::load(
                    &checkpoint,
                    "model.language_model.layers.0.mlp",
                    capacity,
                    true,
                )?;
                ensure!(
                    moe.batch_routes,
                    "requires BATCH_ROUTES=1 through the real loader"
                );
                moe.gpu_hot = true;
                moe.gpu_hot_wide = true;
                moe.unique_cohorts = unique;
                let x = Array::concatenate(
                    &(0..rows).map(|r| &inputs[r % 3].0).collect::<Vec<_>>(),
                    0,
                )?;
                let all_ids = (0..rows)
                    .map(|r| moe.route(&x.slice(0, r as i32, r as i32 + 1)?)?.0.to_u32())
                    .collect::<Result<Vec<_>>>()?
                    .concat();
                let prime = &all_ids[..5];
                let routes = moe.cache.borrow_mut().reserve(prime)?;
                let jobs = prime
                    .iter()
                    .zip(routes)
                    .map(|(&id, (slot, _))| (id, slot))
                    .collect::<Vec<_>>();
                moe.fill_many(&jobs)?;
                let mut claims = Vec::new();
                for id in (0..512).filter(|id| !all_ids.contains(id)) {
                    if claims.len() == pending {
                        break;
                    }
                    claims.push((
                        moe.cache
                            .borrow_mut()
                            .claim_prefetch(id)?
                            .context("missing pending slot")?,
                        id,
                    ));
                }
                ensure!(claims.len() == pending);
                moe.route_batch_calls.set(0);
                moe.route_gate_calls.set(0);
                let output = moe.forward_draft_rows(&x)?;
                let expected = (0..rows)
                    .flat_map(|r| inputs[r % 3].1.iter().copied())
                    .collect::<Vec<_>>();
                ensure!(output.shape() == [rows as i32, H] && output.to_bytes()? == expected);
                ensure!(
                    moe.route_batch_calls.get() > 0 || rows == 1,
                    "batch routes not exercised"
                );
                ensure!(moe.hybrid_submissions > 0 && moe.route_readbacks > 0);
                if unique && rows * 10 > capacity - pending {
                    ensure!(
                        moe.window_hot_before_readback == [true],
                        "U moved Hot behind route readback"
                    );
                    hot_windows_checked += 1;
                }
                moe.drain()?;
                ensure!(moe.cache.borrow().available_slots() == capacity - pending);
                for (slot, id) in claims {
                    ensure!(!moe.cache.borrow_mut().publish_prefetch(slot, id, false));
                }
                ensure!(moe.cache.borrow().available_slots() == capacity);
                cases += 1;
            }
        }
    }
    ensure!(cases == 24 && hot_windows_checked == 4);
    println!(
        "FLASH_BATCH_ROUTE_MOE cases={cases} cohorts=legacy,unique hot_before_readback_checked={hot_windows_checked} unique_overflow_only=true pending=preserved parity=byte_exact"
    );
    Ok(())
}

#[test]
#[ignore = "fresh process with fixed environment; physical Apple GPU for accepted loader options"]
fn batch_route_flag_reaches_real_loader_and_rejects_invalid_literals() -> Result<()> {
    const KEY: &str = "MLXL3_SSD_BATCH_ROUTES";
    let raw = std::env::var(KEY);
    let expected = match &raw {
        Err(std::env::VarError::NotPresent) => Some(false),
        Ok(value) if value == "0" => Some(false),
        Ok(value) if value == "1" => Some(true),
        _ => None,
    };
    let checkpoint = crate::checkpoint::inspect(Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
    let loaded = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 20, true);
    let Some(expected) = expected else {
        let error = loaded
            .err()
            .context("invalid fixed-environment flag accepted")?;
        if raw.is_ok() {
            ensure!(
                error
                    .to_string()
                    .contains("MLXL3_SSD_BATCH_ROUTES must be 0 or 1")
            );
        }
        println!("FLASH_BATCH_ROUTE_FLAG fixed_env=invalid accepted=false real_loader=true");
        return Ok(());
    };
    let moe = loaded?;
    ensure!(moe.batch_routes == expected, "real loader ignored option");
    let x = Array::from_f32(
        &(0..2 * H)
            .map(|i| ((i * 17 % 251) - 125) as f32 / 128.)
            .collect::<Vec<_>>(),
        &[2, H],
    )?;
    let pairs = (0..2)
        .map(|r| moe.route(&x.slice(0, r, r + 1)?))
        .collect::<Result<Vec<_>>>()?;
    let expected_ids = Array::concatenate(&pairs.iter().map(|p| &p.0).collect::<Vec<_>>(), 0)?;
    let expected_weights = Array::concatenate(&pairs.iter().map(|p| &p.1).collect::<Vec<_>>(), 0)?;
    for _ in 0..2 {
        moe.route_batch_calls.set(0);
        moe.route_gate_calls.set(0);
        let (ids, weights) = moe.route_rows(&x)?;
        ensure!(
            moe.batch_routes == expected
                && moe.route_batch_calls.get() == usize::from(expected)
                && moe.route_gate_calls.get() == 2,
            "loaded branch or scalar GEMV count changed"
        );
        ensure!(
            ids.shape() == [2, 10]
                && weights.shape() == [2, 10]
                && weights.dtype() == Dtype::Float32
                && ids.to_bytes()? == expected_ids.to_bytes()?
                && weights.to_bytes()? == expected_weights.to_bytes()?,
            "fixed-environment routing differs from scalar oracle"
        );
    }
    let mode = raw.as_deref().unwrap_or("default");
    println!(
        "FLASH_BATCH_ROUTE_FLAG fixed_env={mode} accepted=true stored={expected} route_calls=2 real_loader=true"
    );
    Ok(())
}

#[cfg(kani)]
#[kani::proof]
fn actual_batch_routes_preserve_real_gate_logits_and_weights() {
    batch_routes_match_real_scalar_logits_probabilities_ids_and_weights().unwrap();
}
