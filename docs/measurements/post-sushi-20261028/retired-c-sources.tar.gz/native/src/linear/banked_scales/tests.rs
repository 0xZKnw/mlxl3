use super::*;

#[test]
#[ignore = "physical Apple GPU; banked products must preserve the canonical gather/multiply bits"]
fn banked_products_match_stock_for_masks_strides_and_half_boundaries() -> Result<()> {
    let input_bits = [0, 0x8000, 1, 0x8001, 0x03ff, 0x3555, 0x3c00, 0xbc00, 0x7bff];
    let scale_bits = [0, 0x8000, 0x3800, 0xb800, 0x3c00, 0xbc00];
    let mut cases = 0;
    for routes in [1, 10, 80] {
        for projections in [1, 2] {
            for width in [640, 2560] {
                for masked in [false, true] {
                    for strided in [false, true] {
                        let capacity = 2;
                        let rows = routes * projections;
                        let input = (0..rows * width)
                            .map(|i| input_bits[i as usize % input_bits.len()])
                            .collect::<Vec<_>>();
                        let scales = (0..capacity * projections * width)
                            .map(|i| scale_bits[(i as usize / 17 + i as usize) % scale_bits.len()])
                            .collect::<Vec<_>>();
                        let tensor = |bits: &[u16], shape: &[i32]| -> Result<Array> {
                            if !strided {
                                return Array::from_f16_bits(bits, shape);
                            }
                            let values = bits
                                .iter()
                                .flat_map(|&b| [b, half::f16::NAN.to_bits()])
                                .collect::<Vec<_>>();
                            let mut stored_shape = shape.to_vec();
                            stored_shape.push(2);
                            Array::from_f16_bits(&values, &stored_shape)?
                                .slice(shape.len() as i32, 0, 1)?
                                .reshape(shape)
                        };
                        let x = tensor(&input, &[rows, width])?;
                        let bank = tensor(&scales, &[capacity, projections, width])?;
                        let slots = if masked {
                            let mut map = [u32::MAX; 512];
                            map[0] = 1;
                            map[1] = 0;
                            map[511] = 1;
                            let ids = (0..routes)
                                .map(|i| [0, 1, 511, 512, u32::MAX][i as usize % 5])
                                .collect::<Vec<_>>();
                            ExpertSlots::residents(
                                &Array::from_u32(&ids, &[routes])?,
                                &map,
                                capacity,
                            )?
                        } else {
                            ExpertSlots::new(
                                &(0..routes)
                                    .map(|i| (i % capacity) as u32)
                                    .collect::<Vec<_>>(),
                                capacity,
                            )?
                        };
                        let before = Array::host_readbacks_for_test();
                        let actual = scale_rows(&x, &bank, &slots)?;
                        ensure!(
                            Array::host_readbacks_for_test() == before,
                            "banked construction read a GPU result"
                        );
                        let expected =
                            x.mul(&slots.gather_scales(&bank)?.reshape(&[rows, width])?)?;
                        ensure!(
                            actual.shape() == [rows, width] && actual.dtype() == Dtype::Float16
                        );
                        let bytes = actual.to_bytes()?;
                        ensure!(bytes.len() == input.len() * 2 && !bytes.is_empty());
                        ensure!(actual.to_f32()?.iter().all(|v| v.is_finite()));
                        ensure!(
                            bytes == expected.to_bytes()?,
                            "banked product divergence routes={routes} projections={projections} width={width} masked={masked} strided={strided}"
                        );
                        cases += 1;
                    }
                }
            }
        }
    }
    for capacity in [1, 512] {
        let width = 2560;
        let slots = ExpertSlots::new(&[capacity as u32 - 1], capacity)?;
        let bank = Array::from_f16_bits(
            &vec![0x3800; (capacity * 2 * width) as usize],
            &[capacity, 2, width],
        )?;
        let x = Array::from_f16_bits(&vec![0x3c00; (2 * width) as usize], &[2, width])?;
        let actual = scale_rows(&x, &bank, &slots)?;
        ensure!(
            actual.to_bytes()?
                == vec![0x3800u16; (2 * width) as usize]
                    .into_iter()
                    .flat_map(u16::to_le_bytes)
                    .collect::<Vec<_>>()
        );
        cases += 1;
    }
    let slots = ExpertSlots::residents(
        &Array::from_u32(&[512, u32::MAX], &[2])?,
        &[u32::MAX; 512],
        2,
    )?;
    let x = Array::from_f16_bits(&vec![0x3c00; 2 * 640], &[2, 640])?;
    let poison = Array::from_f16_bits(&vec![half::f16::NAN.to_bits(); 2 * 640], &[2, 1, 640])?;
    ensure!(scale_rows(&x, &poison, &slots)?.to_bytes()? == vec![0; 2 * 640 * 2]);
    let valid_bank = Array::from_f16_bits(&vec![0x3c00; 2 * 640], &[2, 1, 640])?;
    ensure!(scale_rows(&x.astype(Dtype::Float32)?, &valid_bank, &slots).is_err());
    ensure!(scale_rows(&x, &valid_bank.astype(Dtype::Float32)?, &slots).is_err());
    ensure!(scale_rows(&x.reshape(&[-1])?, &valid_bank, &slots).is_err());
    ensure!(scale_rows(&x, &valid_bank.reshape(&[1, 2, 640])?, &slots).is_err());
    let bad_slots = ExpertSlots {
        indices: Array::from_f32(&[0., 0.], &[2])?,
        capacity: 2,
        masked: false,
        groups: None,
    };
    ensure!(scale_rows(&x, &valid_bank, &bad_slots).is_err());
    println!(
        "BANKED_SCALE_QUALITY cases={cases} poison=true errors=5 parity=byte_exact finite=true host_readback_during_build=false"
    );
    Ok(())
}

#[cfg(kani)]
#[kani::proof]
fn actual_banked_scale_api_matches_canonical_mlx() {
    banked_products_match_stock_for_masks_strides_and_half_boundaries().unwrap();
}

#[test]
#[ignore = "physical Apple GPU; compare complete Flash projections with canonical gathered scales"]
fn complete_banked_projections_match_stock_and_reject_invalid_metadata() -> Result<()> {
    let capacity = 3;
    let mut cases = 0;
    for (input, output, projections) in [(2560, 640, 2), (640, 2560, 1)] {
        let words = capacity * projections * (input / 16) * (output / 16) * 32;
        let packed = (0..words)
            .map(|i| (i as u16).wrapping_mul(1777))
            .collect::<Vec<_>>();
        let bank = Array::from_u16(
            &packed,
            &[capacity, projections, input / 16, output / 16, 32],
        )?;
        let scales = |width: i32| {
            let values = (0..capacity * projections * width)
                .map(|i| {
                    if i / (projections * width) == 2 {
                        half::f16::NAN.to_bits()
                    } else {
                        half::f16::from_f32(0.5 + (i % 11) as f32 / 32.).to_bits()
                    }
                })
                .collect::<Vec<_>>();
            Array::from_f16_bits(&values, &[capacity, projections, width])
        };
        let suh = scales(input)?;
        let svh = scales(output)?;
        for routes in [1, 3, 10] {
            let rows = routes * projections;
            for dtype in [Dtype::Float16, Dtype::Float32] {
                for masked in [false, true] {
                    let slots = if masked {
                        let mut map = [u32::MAX; 512];
                        map[0] = 1;
                        map[511] = 0;
                        let ids = (0..routes)
                            .map(|i| [0, 1, 511, 512, u32::MAX][i as usize % 5])
                            .collect::<Vec<_>>();
                        ExpertSlots::residents(&Array::from_u32(&ids, &[routes])?, &map, capacity)?
                    } else {
                        ExpertSlots::new(
                            &(0..routes).map(|i| (i % 2) as u32).collect::<Vec<_>>(),
                            capacity,
                        )?
                    };
                    for strided in [false, true] {
                        let value = |row, col| ((row * 37 + col * 13) % 997) as f32 / 1024. - 0.5;
                        let x = if strided {
                            let values = (0..input)
                                .flat_map(|col| (0..rows).map(move |row| value(row, col)))
                                .collect::<Vec<_>>();
                            Array::from_f32(&values, &[input, rows])?
                                .astype(dtype)?
                                .transpose(&[1, 0])?
                        } else {
                            let values = (0..rows)
                                .flat_map(|row| (0..input).map(move |col| value(row, col)))
                                .collect::<Vec<_>>();
                            Array::from_f32(&values, &[rows, input])?.astype(dtype)?
                        };
                        for stable in [false, true] {
                            let before = Array::host_readbacks_for_test();
                            let actual = project(
                                &x,
                                &bank,
                                &suh,
                                &svh,
                                &slots,
                                output,
                                projections,
                                2,
                                Codebook::Mul1,
                                stable,
                            )?;
                            ensure!(Array::host_readbacks_for_test() == before);
                            let expected = super::super::expert_slots(
                                &x,
                                &bank,
                                &slots.gather_scales(&suh)?.reshape(&[rows, input])?,
                                &slots.gather_scales(&svh)?.reshape(&[rows, output])?,
                                &slots,
                                output,
                                projections,
                                2,
                                Codebook::Mul1,
                                stable,
                            )?;
                            ensure!(actual.shape() == [rows, output] && actual.dtype() == dtype);
                            let values = actual.to_f32()?;
                            ensure!(values.len() == (rows * output) as usize && !values.is_empty());
                            ensure!(
                                values.iter().all(|v| v.is_finite()),
                                "unused NaN bank leaked"
                            );
                            ensure!(
                                actual.to_bytes()? == expected.to_bytes()?,
                                "projection divergence input={input} output={output} routes={routes} dtype={dtype:?} masked={masked} strided={strided} stable={stable}"
                            );
                            cases += 1;
                        }
                    }
                }
            }
        }
        let x = Array::zeros_dtype(&[projections, input], Dtype::Float16)?;
        let slots = ExpertSlots::new(&[0], capacity)?;
        let call = |x: &Array, bank: &Array, suh: &Array, svh: &Array, slots: &ExpertSlots| {
            project(
                x,
                bank,
                suh,
                svh,
                slots,
                output,
                projections,
                2,
                Codebook::Mul1,
                false,
            )
        };
        ensure!(call(&x.reshape(&[-1])?, &bank, &suh, &svh, &slots).is_err());
        ensure!(call(&x, &bank.reshape(&[capacity, -1])?, &suh, &svh, &slots).is_err());
        ensure!(call(&x.astype(Dtype::UInt32)?, &bank, &suh, &svh, &slots).is_err());
        ensure!(call(&x, &bank, &suh.astype(Dtype::Float32)?, &svh, &slots).is_err());
        ensure!(call(&x, &bank, &suh, &svh.reshape(&[-1])?, &slots).is_err());
        ensure!(call(&x, &bank, &suh, &svh, &ExpertSlots::new(&[0], 2)?).is_err());
        ensure!(
            call(
                &x,
                &bank,
                &suh,
                &svh,
                &ExpertSlots::grouped(&[0; 16], capacity)?
            )
            .is_err()
        );
        let bad_slots = ExpertSlots {
            indices: slots.indices.reshape(&[1, 1])?,
            capacity,
            masked: false,
            groups: None,
        };
        ensure!(call(&x, &bank, &suh, &svh, &bad_slots).is_err());
    }
    ensure!(cases == 96, "projection matrix was incomplete: {cases}");
    println!(
        "BANKED_PROJECTION_QUALITY cases={cases} errors=16 parity=byte_exact finite=true unused_nan=true host_readback_during_build=false"
    );
    Ok(())
}

#[cfg(kani)]
#[kani::proof]
fn actual_complete_banked_projection_matches_canonical_mlx() {
    complete_banked_projections_match_stock_and_reject_invalid_metadata().unwrap();
}
