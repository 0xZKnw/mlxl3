"""Small default-specific regressions plus the eleven unchanged controller tests."""

import json
import runpy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
N = runpy.run_path(str(ROOT / "build/ar34/default-run.py"))
OLD = runpy.run_path(str(ROOT / "build/ar34/test_run.py"))


class Default(unittest.TestCase):
    def test_missing_plan_records_failed_without_launch_and_preserves_old_run(self):
        fresh = runpy.run_path(str(ROOT / "build/ar34/default-run.py"))
        with tempfile.TemporaryDirectory(prefix="ar34-default-preflight-") as folder:
            out = Path(folder)
            argv = [
                "default-run.py",
                "quality",
                "--run-after-root-grant",
                "--plan",
                str(out / "missing.json"),
                "--out",
                str(out),
            ]
            with patch("sys.argv", argv), self.assertRaises(FileNotFoundError):
                fresh["main"]()
            sink = out / "quality/report.json"
            report = json.loads(sink.read_text())
            self.assertFalse(report["parity"])
            self.assertEqual(report["status"], "failed")
            self.assertEqual(report["phases"], [])
            self.assertTrue(report["all_children_joined"])
            before = sink.read_bytes()
            with patch("sys.argv", argv), self.assertRaises(SystemExit):
                fresh["main"]()
            self.assertEqual(sink.read_bytes(), before)

    def test_environment_removes_inherited_flag_and_preserves_scope(self):
        with patch.dict("os.environ", {N["FLAG"]: "0", "MLXL3_NATIVE_DEVICE_GREEDY": "1"}):
            env = N["environment"]()
        self.assertNotIn(N["FLAG"], env)
        self.assertTrue(all(env[key] == "1" for key in N["D"]["FLAGS"]))
        for key in [*N["R"]["C"]["NEW"], *N["R"]["AR30"], *N["R"]["AR33"]]:
            self.assertEqual(env["MLXL3_NATIVE_" + key], "0")
        for bad in (0, False, True, 2, "1"):
            with self.subTest(bad=bad), self.assertRaises(AssertionError):
                N["environment"](bad)

    def test_default_marker_requires_actual_unset_evidence(self):
        function = N["check_marker"]
        for value in (False, 1, "true", None):
            with (
                patch.dict(
                    function.__globals__,
                    {
                        "_original_marker": lambda *_, value=value: {
                            "device_hot_default_environment_unset": value
                        }
                    },
                ),
                self.subTest(value=value),
                self.assertRaises(AssertionError),
            ):
                function("unused", ("model", "unused", "unused"))
        with patch.dict(
            function.__globals__,
            {"_original_marker": lambda *_: {"device_hot_default_environment_unset": True}},
        ):
            self.assertTrue(
                function("unused", ("model", "unused", "unused"))[
                    "device_hot_default_environment_unset"
                ]
            )

    def test_plan_rejects_empty_or_missing_default_sources(self):
        sources = {
            str(ROOT / "build/ar34" / name): "digest"
            for name in ("default-run.py", "default-freeze.py", "test_default.py")
        }
        good = {"source_files": sources, "artifacts": {"native-libtest": {}, "direct-cli": {}}}
        N["checked_plan"](good)
        for bad in (
            {**good, "source_files": {}},
            {**good, "artifacts": {}},
            {**good, "source_files": dict(list(sources.items())[:-1])},
        ):
            with self.subTest(bad=bad), self.assertRaises(AssertionError):
                N["checked_plan"](bad)


def load_tests(loader, tests, pattern):
    tests.addTests(loader.loadTestsFromTestCase(OLD["Controller"]))
    return tests


if __name__ == "__main__":
    unittest.main()
