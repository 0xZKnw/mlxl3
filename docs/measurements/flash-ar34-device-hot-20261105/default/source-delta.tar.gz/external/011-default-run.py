"""Reuse the audited AR34 controller for final default model/CLI and one MAIN128 arm."""

import argparse
import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "docs/measurements/flash-ar34-device-hot-20261105/default"
R = runpy.run_path(str(ROOT / "build/ar34/run.py"))
D = R["D"]
FLAG = "MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE"
_original_environment = R["environment"]
_original_marker = R["check_marker"]


def environment(enabled=1):
    assert type(enabled) is int and enabled == 1
    env = _original_environment(enabled)
    env.pop(FLAG, None)
    assert FLAG not in env
    return env


def check_marker(text, spec):
    evidence = _original_marker(text, spec)
    D["OLD"]["exact_fields"](evidence, {"device_hot_default_environment_unset": True})
    return evidence


def checked_plan(plan):
    assert plan["source_files"] and set(plan["artifacts"]) >= {"native-libtest", "direct-cli"}
    frozen = {str((ROOT / name).resolve()) for name in plan["source_files"]}
    for name in ("default-run.py", "default-freeze.py", "test_default.py"):
        assert str((ROOT / "build/ar34" / name).resolve()) in frozen, "unfrozen default helper"


def journal(message):
    with (ROOT / "opti.md").open("a") as stream:
        stream.write("\nAR34 DEFAULT " + message + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=["quality", "speed"])
    parser.add_argument("--run-after-root-grant", action="store_true")
    parser.add_argument("--plan", type=Path, default=ROOT / "build/ar34/default-plan.json")
    parser.add_argument("--out", type=Path, default=HERE)
    args = parser.parse_args()
    if not args.run_after_root_grant:
        parser.error("exclusive root GPU grant required")
    # The original controller preserves subprocess cleanup, hash preflight,
    # independent model markers, CLI checks and quality-before-speed gating.
    globals_ = R["main"].__globals__
    globals_.update(
        __file__=__file__,
        HERE=HERE,
        SPECS=(next(spec for spec in R["SPECS"] if spec[0] == "model"),),
        ARMS=(("default", 1),),
        environment=environment,
        check_marker=check_marker,
        journal=journal,
    )
    argv = sys.argv
    sys.argv = [
        __file__,
        args.kind,
        "--run-after-root-grant",
        "--tokens",
        "128",
        "--plan",
        str(args.plan),
        "--out",
        str(args.out),
    ]
    sink = args.out / ("quality" if args.kind == "quality" else "speed128") / "report.json"
    if sink.parent.exists():
        sys.argv = argv
        parser.error("refusing to replace an earlier default run")
    try:
        checked_plan(D["read_json"](args.plan))
        R["main"]()
    except BaseException as error:
        if not sink.exists():
            sink.parent.mkdir(parents=True, exist_ok=True)
            D["save"](
                {
                    "status": "failed",
                    "parity": False,
                    "all_children_joined": True,
                    "phases": [],
                    "error": repr(error),
                },
                sink,
            )
        raise
    finally:
        sys.argv = argv
        if sink.exists():
            report = D["read_json"](sink)
            report.update(
                flags=[],
                default_flag=FLAG,
                default_environment_absent=bool(report["phases"])
                and all(FLAG not in phase.get("environment", {}) for phase in report["phases"]),
                limits="Default qualification only: model+CLI quality, then one MAIN128 warm1+measure1 arm. No new OFF/ON/OFF comparison or speedup claim.",
            )
            D["save"](report, sink)


if __name__ == "__main__":
    main()
