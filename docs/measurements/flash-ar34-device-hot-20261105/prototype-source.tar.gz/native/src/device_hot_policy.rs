//! CPU admission/identity/ownership guards used by the native device-Hot transaction.

pub(crate) const SLOTS: usize = 53;
pub(crate) const EXPERTS: usize = 512;
pub(crate) const ROUTES: usize = 10;
pub(crate) const RECORD_BYTES: u64 = 1_248_012;
pub(crate) const CONTRIBUTION_BYTES: u64 = 2 * 2560;
pub(crate) const AUXILIARY_LIMIT: u64 = 2 * 1024 * 1024;
pub(crate) const RESERVE_BYTES: u64 = ROUTES as u64 * RECORD_BYTES + AUXILIARY_LIMIT;

pub(crate) fn admitted(
    gpu_available: bool,
    slots: usize,
    direct: bool,
    depth: usize,
    prefetch: bool,
    record_reuse: bool,
) -> bool {
    gpu_available && slots == SLOTS && direct && depth == 0 && !prefetch && record_reuse
}

pub(crate) fn identity_matches(expert: u32, generation: u64, current: Option<(u32, u64)>) -> bool {
    expert < EXPERTS as u32 && current == Some((expert, generation))
}

pub(crate) fn contribution_offset(route: usize) -> Option<u64> {
    (route < ROUTES).then(|| route as u64 * CONTRIBUTION_BYTES)
}

pub(crate) fn retirement_bytes(records: usize) -> Option<u64> {
    (records <= ROUTES).then(|| records as u64 * RECORD_BYTES)
}

pub(crate) fn checked_peak(retired: usize, auxiliary: u64) -> Option<u64> {
    let records = retirement_bytes(retired)?;
    (auxiliary <= AUXILIARY_LIMIT).then(|| records + auxiliary)
}

pub(crate) fn readers_after(readers: usize, acquire: bool) -> Option<usize> {
    if acquire {
        readers.checked_add(1)
    } else {
        readers.checked_sub(1)
    }
}

pub(crate) fn hot_publishable(producers_complete: bool, hot_error_absent: bool) -> bool {
    producers_complete && hot_error_absent
}

pub(crate) fn pending_route_needs_wait(submitted: bool, terminal: bool) -> bool {
    submitted && !terminal
}

pub(crate) fn pending_route_publishable(submitted: bool, completed: bool) -> bool {
    submitted && completed
}

#[test]
fn device_hot_guard_rejects_every_scope_escape_and_bad_identity() {
    assert!(admitted(true, 53, true, 0, false, true));
    for slots in [0, 10, 52, 54, usize::MAX] {
        assert!(!admitted(true, slots, true, 0, false, true));
    }
    assert!(!admitted(false, 53, true, 0, false, true));
    assert!(!admitted(true, 53, false, 0, false, true));
    assert!(!admitted(true, 53, true, 1, false, true));
    assert!(!admitted(true, 53, true, 0, true, true));
    assert!(!admitted(true, 53, true, 0, false, false));
    assert!(identity_matches(511, u64::MAX, Some((511, u64::MAX))));
    assert!(!identity_matches(512, 1, Some((512, 1))));
    assert!(!identity_matches(2, 1, Some((2, 2))));
    assert!(!identity_matches(2, 1, Some((3, 1))));
    assert!(!identity_matches(2, 1, None));
}

#[test]
fn device_hot_bounds_ownership_and_latched_errors_are_explicit() {
    assert_eq!(contribution_offset(9), Some(46_080));
    assert_eq!(contribution_offset(10), None);
    assert_eq!(contribution_offset(usize::MAX), None);
    assert_eq!(checked_peak(10, AUXILIARY_LIMIT), Some(14_577_272));
    assert_eq!(checked_peak(11, 0), None);
    assert_eq!(checked_peak(0, u64::MAX), None);
    assert_eq!(readers_after(0, false), None);
    assert_eq!(readers_after(usize::MAX, true), None);
    assert_eq!(readers_after(1, false), Some(0));
    assert_eq!(readers_after(0, true), Some(1));
    assert!(!hot_publishable(true, false));
    assert!(!hot_publishable(false, true));
    assert!(hot_publishable(true, true));
    assert!(!pending_route_needs_wait(false, false));
    assert!(pending_route_needs_wait(true, false));
    assert!(!pending_route_needs_wait(true, true));
    assert!(!pending_route_publishable(false, true));
    assert!(pending_route_publishable(true, true));
}

#[cfg(kani)]
#[kani::proof]
fn device_hot_actual_admission_offsets_and_peak_are_bounded() {
    let gpu: bool = kani::any();
    let slots: usize = kani::any();
    let direct: bool = kani::any();
    let depth: usize = kani::any();
    let prefetch: bool = kani::any();
    let reuse: bool = kani::any();
    let accepted = admitted(gpu, slots, direct, depth, prefetch, reuse);
    assert!(accepted == (gpu && slots == 53 && direct && depth == 0 && !prefetch && reuse));
    let route: usize = kani::any();
    let offset = contribution_offset(route);
    assert!(offset.is_some() == (route < 10));
    if let Some(offset) = offset {
        assert!(offset + CONTRIBUTION_BYTES <= 51_200);
    }
    let retired: usize = kani::any();
    let auxiliary: u64 = kani::any();
    let peak = checked_peak(retired, auxiliary);
    assert!(peak.is_some() == (retired <= 10 && auxiliary <= AUXILIARY_LIMIT));
    if let Some(peak) = peak {
        assert!(peak <= RESERVE_BYTES);
    }
    kani::cover!(accepted);
    kani::cover!(!accepted && depth > 0);
    kani::cover!(route == 9 && offset == Some(46_080));
    kani::cover!(retired == 10 && auxiliary == AUXILIARY_LIMIT);
}

#[cfg(kani)]
#[kani::proof]
fn device_hot_actual_identity_readers_and_pending_lifecycle_are_fail_closed() {
    let expert: u32 = kani::any();
    let generation: u64 = kani::any();
    let current: Option<(u32, u64)> = kani::any();
    let matches = identity_matches(expert, generation, current);
    assert!(matches == (expert < 512 && current == Some((expert, generation))));
    let readers: usize = kani::any();
    let acquire: bool = kani::any();
    let next = readers_after(readers, acquire);
    assert!(
        next.is_some()
            == if acquire {
                readers < usize::MAX
            } else {
                readers > 0
            }
    );
    let submitted: bool = kani::any();
    let terminal: bool = kani::any();
    let completed: bool = kani::any();
    let error_absent: bool = kani::any();
    assert!(pending_route_needs_wait(submitted, terminal) == (submitted && !terminal));
    assert!(pending_route_publishable(submitted, completed) == (submitted && completed));
    assert!(!hot_publishable(completed, error_absent) || (completed && error_absent));
    kani::cover!(matches && expert == 511 && generation == u64::MAX);
    kani::cover!(current.is_none() && !matches);
    kani::cover!(submitted && !terminal && !completed);
    kani::cover!(!submitted && completed && !pending_route_publishable(submitted, completed));
}
