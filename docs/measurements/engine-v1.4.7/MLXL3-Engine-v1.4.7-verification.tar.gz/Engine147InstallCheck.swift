import Foundation

@main struct Engine147InstallCheck {
  @MainActor static func main() throws {
    precondition(CommandLine.arguments.count == 2)
    let archive = URL(fileURLWithPath: CommandLine.arguments[1])
    let root = FileManager.default.temporaryDirectory.appendingPathComponent("mlxl3-engine147-" + UUID().uuidString)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let release = AppUpdateRelease(
      version: "1.4.7", tag: "engine-v1.4.7", title: "Engine1.4.7", notes: "",
      pageURL: URL(string: "https://github.com/0xZKnw/mlxl3/releases/tag/engine-v1.4.7")!,
      asset: AppUpdateAsset(name: archive.lastPathComponent, downloadURL: archive,
        size: Int64(try Data(contentsOf: archive).count),
        digest: "sha256:" + (try UpdateManager.sha256(at: archive))))
    try EngineRuntimeStore.install(archive: archive, release: release, appVersion: "1.4.6", root: root)
    guard let selected = EngineRuntimeStore.resolve(appVersion: "1.4.6", root: root, bundledVersion: "1.4.6") else {
      preconditionFailure("Engine1.4.7 not selected by Desktop1.4.6")
    }
    let manifest = try EngineRuntimeStore.readManifest(selected.deletingLastPathComponent())
    precondition(manifest.version == "1.4.7")
    try manifest.validate(appVersion: "1.4.6", expectedVersion: "1.4.7")
    let output = try UpdateManager.runProcess(selected.path, arguments: ["runtime-info"])
    let info = try JSONSerialization.jsonObject(with: output) as! [String: Any]
    precondition(info["version"] as? String == "1.4.7")
    precondition(info["bridge_protocol"] as? Int == 1)
    precondition(info["mlx_enabled"] as? Bool == true)
    precondition(EngineRuntimeStore.reject(selected, root: root))
    precondition(EngineRuntimeStore.resolve(appVersion: "1.4.6", root: root, bundledVersion: "1.4.6") == nil)
    print("Engine1.4.7: signed archive verified, installed in disposable store, selected by Desktop1.4.6, relocated executable ran, rejected version fell back; user store untouched")
  }
}
