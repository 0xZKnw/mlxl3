import hashlib
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "benchmarks"))
from compare_native import JsonProcess, event, generate

base = ROOT / "build/engine-v1.4.7"
binary = base / "runtime/mlxl3"
model = "/Users/justin/Library/Application Support/io.mlxl3.desktop/Models/Qwen3.8-27B-exl3-6a9ca9d0"
head = Path("/Users/justin/Library/Application Support/io.mlxl3.desktop/Drafts/Qwen3.8-27B-MTP-4bit")
reference = json.loads((ROOT / "docs/measurements/qwen27-20261016/final-bridge-d1-default-abba/results.json").read_text())["passes"][0]
prompts = {"short": "Explique en français, en trois points concis, pourquoi le ciel est bleu.", "document": (ROOT / "docs/measurements/qwen27-20261016/prompt-code.txt").read_text()}
report = {"status": "running", "parity": False, "kind": "functional comparison to historical golden hashes/counters, not a speed campaign", "passes": []}
output = base / "golden-status.json"
assert not output.exists()
output.write_text(json.dumps(report, indent=2))
try:
    for lane in [0, 1]:
        env = {k: v for k, v in os.environ.items() if not k.startswith("MLXL3_")}
        env.update(MLXL3_QWEN_PIPELINE="0", MLXL3_MTP_ADAPTIVE="0", MLXL3_MTP_LOOKUP="0")
        if lane:
            env["MLXL3_EXL3_LANE_ORDER"] = "1"
        current = {"lane": lane, "default_environment": lane == 0, "status": "running", "prompts": {}}
        report["passes"].append(current)
        with (base / f"golden-{lane}.stderr").open("w") as stderr:
            with JsonProcess([str(binary), "--registry", str(base / f"golden-{lane}-registry.json"), "bridge", model, "--context-length", "4096"], stderr=stderr, env=env) as process:
                deadline = time.monotonic() + 120
                while True:
                    ready = event(process, deadline)
                    if ready["type"] == "ready":
                        break
                assert ready["runtime_version"] == "1.4.7" and ready["runtime_commit"] == "957b19469e2a"
                assert f":lanelayout-v1={lane}:smallm-v2=1" in ready["mtp_tuning_key"]
                assert ":allocator-cache-v1=0:" in ready["mtp_tuning_key"] and ready["mlx_version"] == "0.32.2"
                current["ready"] = ready
                for name, prompt in prompts.items():
                    result = generate(process, prompt, 256, f"golden-{name}", 180, 1, head)
                    oracle = reference["prompts"][name]["runs"][0]
                    for key in ["token_hash", "text_sha256", "history_sha256"]:
                        assert result[key] and result[key] == oracle[key], (name, key)
                    for key in ["generated_tokens", "decode_tokens", "mtp_blocks", "mtp_proposed_tokens", "mtp_accepted_tokens", "mtp_lookup_blocks", "mtp_depth_blocks"]:
                        assert result["stats"][key] == oracle["stats"][key], (name, key)
                    current["prompts"][name] = result
                    output.write_text(json.dumps(report, indent=2))
                process.send({"type": "shutdown"}, time.monotonic() + 10)
            assert process.process.returncode == 0
            current.update(status="complete", exit_code=0, reaped=True)
        output.write_text(json.dumps(report, indent=2))
    report.update(status="complete", parity=True)
except BaseException as error:
    report.update(status="failed", parity=False, error=repr(error))
    raise
finally:
    output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "parity": report["parity"], "passes": len(report["passes"])}))
