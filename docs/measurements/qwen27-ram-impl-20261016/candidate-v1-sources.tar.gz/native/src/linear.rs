//! Rust dispatch of the existing MLXL3 serialized QMV shaders through native MLX.
use crate::{
    array::{self, Array, Dtype},
    checkpoint::Checkpoint,
    codec::{self, Codebook},
};
use anyhow::{Context, Result, ensure};

fn grouped_mb3_enabled() -> bool {
    #[cfg(test)]
    if let Some(enabled) = GROUPED_MB3_TEST_OVERRIDE.with(std::cell::Cell::get) {
        return enabled;
    }
    static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ENABLED.get_or_init(|| std::env::var("MLXL3_EXPERIMENTAL_GROUPED_MB3").as_deref() == Ok("1"))
}

#[cfg(test)]
thread_local! {
    static GROUPED_MB3_TEST_OVERRIDE: std::cell::Cell<Option<bool>> = const { std::cell::Cell::new(None) };
}

#[cfg(test)]
pub(crate) fn with_grouped_mb3_test<T>(enabled: bool, run: impl FnOnce() -> T) -> T {
    struct Restore(Option<bool>);
    impl Drop for Restore {
        fn drop(&mut self) {
            GROUPED_MB3_TEST_OVERRIDE.with(|flag| flag.set(self.0));
        }
    }
    let _restore = Restore(GROUPED_MB3_TEST_OVERRIDE.with(|flag| flag.replace(Some(enabled))));
    run()
}

fn dense_decode_nt4_enabled() -> bool {
    #[cfg(test)]
    if let Some(enabled) = DENSE_DECODE_TEST_OVERRIDE.with(std::cell::Cell::get) {
        return enabled;
    }
    static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ENABLED.get_or_init(|| std::env::var("MLXL3_DENSE_DECODE_NT4").as_deref() != Ok("0"))
}

#[cfg(test)]
thread_local! {
    static DENSE_DECODE_TEST_OVERRIDE: std::cell::Cell<Option<bool>> = const { std::cell::Cell::new(None) };
}

/// Test-only override: compare geometries with one model and the same GPU clock.
#[cfg(test)]
pub(crate) fn with_dense_decode_nt4_test<T>(enabled: bool, run: impl FnOnce() -> T) -> T {
    struct Restore(Option<bool>);
    impl Drop for Restore {
        fn drop(&mut self) {
            DENSE_DECODE_TEST_OVERRIDE.with(|flag| flag.set(self.0));
        }
    }
    let _restore = Restore(DENSE_DECODE_TEST_OVERRIDE.with(|flag| flag.replace(Some(enabled))));
    run()
}

fn checkpoint_dtype(dtype: &str, name: &str) -> Result<Dtype> {
    Ok(match dtype {
        "F16" => Dtype::Float16,
        "BF16" => Dtype::BFloat16,
        "F32" => Dtype::Float32,
        "U16" => Dtype::UInt16,
        "I16" => Dtype::Int16,
        "U32" => Dtype::UInt32,
        "I32" => Dtype::Int32,
        "BOOL" => Dtype::Bool,
        other => anyhow::bail!("unsupported model tensor dtype {other} ({name})"),
    })
}

pub fn checkpoint_array(checkpoint: &Checkpoint, name: &str) -> Result<Array> {
    let info = checkpoint
        .tensors
        .get(name)
        .with_context(|| format!("missing tensor {name}"))?;
    let dtype = checkpoint_dtype(&info.dtype, name)?;
    let shape = info
        .shape
        .iter()
        .map(|&n| i32::try_from(n))
        .collect::<std::result::Result<Vec<_>, _>>()?;
    if dtype == Dtype::Bool {
        return Array::from_bytes(&info.read_bytes()?, &shape, dtype);
    }
    let (file, offset) = info.source()?;
    Array::from_file(file, offset, &shape, dtype)
        .with_context(|| format!("cannot load checkpoint tensor {name}"))
}

pub fn checkpoint_arrays(
    checkpoint: &Checkpoint,
    names: &[String],
    workers: usize,
) -> Result<Vec<Array>> {
    let infos = names
        .iter()
        .map(|name| {
            checkpoint
                .tensors
                .get(name)
                .with_context(|| format!("missing tensor {name}"))
        })
        .collect::<Result<Vec<_>>>()?;
    let dtypes = infos
        .iter()
        .zip(names)
        .map(|(info, name)| checkpoint_dtype(&info.dtype, name))
        .collect::<Result<Vec<_>>>()?;
    ensure!(
        dtypes.iter().all(|&dtype| dtype != Dtype::Bool),
        "batched boolean tensors are unsupported"
    );
    let shapes = infos
        .iter()
        .map(|info| {
            info.shape
                .iter()
                .map(|&n| i32::try_from(n))
                .collect::<std::result::Result<Vec<_>, _>>()
                .map_err(Into::into)
        })
        .collect::<Result<Vec<_>>>()?;
    let sources = infos
        .iter()
        .map(|info| info.source())
        .collect::<Result<Vec<_>>>()?;
    let files = sources.iter().map(|&(file, _)| file).collect::<Vec<_>>();
    let offsets = sources
        .iter()
        .map(|&(_, offset)| offset)
        .collect::<Vec<_>>();
    Array::from_files(&files, &offsets, &shapes, &dtypes, workers)
}

pub struct Exl3Linear {
    trellis: Array,
    suh: Array,
    svh: Array,
    bias: Option<Array>,
    k: usize,
    cb: Codebook,
    rows: i32,
    cols: i32,
    simdgroups: i32,
}

impl Exl3Linear {
    pub fn from_checkpoint(checkpoint: &Checkpoint, prefix: &str) -> Result<Self> {
        let trellis = checkpoint_array(checkpoint, &format!("{prefix}.trellis"))?;
        let scale = |primary, legacy| {
            let key = format!("{prefix}.{primary}");
            checkpoint_array(
                checkpoint,
                if checkpoint.tensors.contains_key(&key) {
                    &key
                } else {
                    return checkpoint_array(checkpoint, &format!("{prefix}.{legacy}"));
                },
            )
        };
        let cb = if checkpoint.tensors.contains_key(&format!("{prefix}.mul1")) {
            Codebook::Mul1
        } else if checkpoint.tensors.contains_key(&format!("{prefix}.mcg")) {
            Codebook::Mcg
        } else {
            Codebook::Default
        };
        let bias_key = format!("{prefix}.bias");
        let bias = if checkpoint.tensors.contains_key(&bias_key) {
            Some(checkpoint_array(checkpoint, &bias_key)?.astype(Dtype::Float16)?)
        } else {
            None
        };
        let k = *trellis
            .shape()
            .last()
            .context("trellis must have dimensions")? as usize
            / 16;
        Self::new(
            trellis,
            scale("suh", "su")?,
            scale("svh", "sv")?,
            bias,
            k,
            cb,
        )
    }

    pub fn new(
        trellis: Array,
        suh: Array,
        svh: Array,
        bias: Option<Array>,
        k: usize,
        cb: Codebook,
    ) -> Result<Self> {
        codec::check_k(k)?;
        let shape = trellis.shape();
        ensure!(
            shape.len() == 3 && shape[2] == (16 * k) as i32 && shape.iter().all(|&n| n > 0),
            "invalid trellis shape"
        );
        let rows = shape[0].checked_mul(16).context("row overflow")?;
        let cols = shape[1].checked_mul(16).context("column overflow")?;
        ensure!(
            rows % 128 == 0 && cols % 128 == 0,
            "public EXL3 projections require 128-aligned dimensions"
        );
        ensure!(
            suh.shape() == [rows] && svh.shape() == [cols],
            "EXL3 scales have wrong dimensions"
        );
        ensure!(
            bias.as_ref().is_none_or(|b| b.shape() == [cols]),
            "EXL3 bias has wrong dimensions"
        );
        ensure!(
            matches!(trellis.dtype(), Dtype::UInt16 | Dtype::Int16),
            "EXL3 trellis must contain 16-bit integers"
        );
        let trellis = trellis.view(Dtype::UInt16)?;
        let simdgroups = if array::is_m5_gpu()? { 8 } else { 4 };
        // Materialize each loaded matrix so temporary CPU buffers/casts can be
        // released promptly instead of retaining an entire model load graph.
        trellis.eval()?;
        suh.eval()?;
        svh.eval()?;
        if let Some(bias) = &bias {
            bias.eval()?;
        }
        Ok(Self {
            trellis,
            suh,
            svh,
            bias,
            k,
            cb,
            rows,
            cols,
            simdgroups,
        })
    }

    pub fn input_dims(&self) -> i32 {
        self.rows
    }
    pub fn output_dims(&self) -> i32 {
        self.cols
    }

    pub fn forward(&self, x: &Array) -> Result<Array> {
        let elements = x
            .shape()
            .iter()
            .try_fold(1i64, |count, &dimension| {
                count.checked_mul(i64::from(dimension))
            })
            .context("linear input size overflow")?;
        ensure!(
            x.shape().last() == Some(&self.rows) && elements % i64::from(self.rows) == 0,
            "invalid EXL3 linear input for {} inputs",
            self.rows
        );
        let matrix_rows = i32::try_from(elements / i64::from(self.rows))?;
        ensure!(matrix_rows > 0, "EXL3 linear input cannot be empty");
        if crate::contracts::use_tensor_ops(matrix_rows, array::is_m5_gpu()?) {
            return self.forward_qmm_tensor(x);
        }
        if matrix_rows >= 24 {
            let matrix = x.reshape(&[matrix_rows, self.rows])?;
            let mut batches = Vec::new();
            for start in (0..matrix_rows).step_by(23) {
                batches.push(self.forward(&matrix.slice(
                    0,
                    start,
                    start.saturating_add(23).min(matrix_rows),
                )?)?);
            }
            let mut shape = x.shape().to_vec();
            *shape.last_mut().context("empty EXL3 input shape")? = self.cols;
            return Array::concatenate(&batches.iter().collect::<Vec<_>>(), 0)?.reshape(&shape);
        }
        if matrix_rows > 1 {
            if self.k != 7 {
                return self.forward_qmv_batch(x, matrix_rows);
            }
            let matrix = x.reshape(&[matrix_rows, self.rows])?;
            let rows = (0..matrix_rows)
                .map(|row| self.forward(&matrix.slice(0, row, row + 1)?))
                .collect::<Result<Vec<_>>>()?;
            let mut shape = x.shape().to_vec();
            *shape.last_mut().context("empty EXL3 batch shape")? = self.cols;
            return Array::concatenate(&rows.iter().collect::<Vec<_>>(), 0)?.reshape(&shape);
        }
        let xhat = x
            .astype(Dtype::Float16)?
            .reshape(&[1, self.rows])?
            .mul(&self.suh.astype(Dtype::Float16)?)?
            .reshape(&[1, self.rows / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[self.rows])?;
        let input_tiles = self.rows / 16;
        let output_tiles = self.cols / 16;
        let mut header = codebook_header(self.cb);
        let output = if self.k == 7 {
            let inverse = codec::permutation_inverse()
                .map(|v| v.to_string())
                .join(",");
            header += &format!(
                "\nconstant ushort mlxl3_perm_inv[256] = {{{inverse}}};\n#define K 7\n#define CB {}\n#define INPUT_DIMS {}\n#define TILES_N {}\n",
                self.cb as u32, self.rows, output_tiles
            );
            array::metal_kernel(
                &format!(
                    "mlxl3_rs_inner_{}_{}_{}",
                    self.rows, self.cols, self.cb as u32
                ),
                &["xhat", "trellis"],
                &["yhat"],
                &header,
                include_str!("../shaders/_qmv_inner_kernel.metal"),
                &[&xhat, &self.trellis],
                &[vec![self.cols]],
                &[Dtype::Float32],
                [
                    self.cols.checked_mul(128).context("QMV grid overflow")?,
                    1,
                    1,
                ],
                [128, 1, 1],
            )?
            .remove(0)
        } else {
            let splits = split_count(input_tiles, output_tiles);
            let nt = if dense_decode_nt4_enabled()
                && crate::contracts::dense_decode_nt4(
                    self.rows,
                    self.cols,
                    self.k,
                    self.cb == Codebook::Mul1,
                    array::is_m5_gpu()?,
                ) {
                4
            } else if output_tiles >= 1024 {
                if output_tiles % 2 == 0 { 2 } else { 1 }
            } else if output_tiles % 4 == 0 {
                4
            } else if output_tiles % 2 == 0 {
                2
            } else {
                1
            };
            header += &format!(
                "\n#define MLXL3_QMV_NT {nt}u\n#define MLXL3_QMV_MB 1u\n#define MLXL3_MATRIX_ROWS 1u\n#define MLXL3_QMV_SG {}u\n#define MLXL3_K_BITS {}u\n#define MLXL3_FUSE_OUTPUT 0\n#define K {}\n#define CB {}\n#define PACKED_U32 {}\n#define INPUT_DIMS {}\n#define TILES_K {input_tiles}\n#define TILES_N {output_tiles}\n#define N_SPLITS {splits}\n#define OUTPUT_DIMS {}\n",
                self.simdgroups,
                self.k,
                self.k,
                self.cb as u32,
                self.k * 8,
                self.rows,
                self.cols
            );
            let words = self.trellis.reshape(&[-1])?.view(Dtype::UInt32)?;
            let partials = array::metal_kernel(
                &format!(
                    "mlxl3_rs_tile_{}_{}_{}_{}_{}_{}_{}",
                    self.rows, self.cols, self.k, self.cb as u32, nt, self.simdgroups, splits
                ),
                &["xhat", "trellis", "svh"],
                &["yhat"],
                &header,
                include_str!("../shaders/_qmv_tile_kernel.metal"),
                &[&xhat, &words, &self.svh],
                &[vec![splits, self.cols]],
                &[Dtype::Float32],
                [
                    (output_tiles / nt)
                        .checked_mul(self.simdgroups * 32)
                        .context("QMV grid overflow")?,
                    1,
                    splits,
                ],
                [self.simdgroups * 32, 1, 1],
            )?
            .remove(0);
            if splits == 1 {
                partials.reshape(&[self.cols])?
            } else {
                partials.sum(0, false)?
            }
        };
        let y = output
            .astype(Dtype::Float16)?
            .reshape(&[1, self.cols / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[self.cols])?
            .mul(&self.svh.astype(Dtype::Float16)?)?;
        let mut shape = x.shape().to_vec();
        *shape.last_mut().context("empty input shape")? = self.cols;
        let y = y.astype(x.dtype())?.reshape(&shape)?;
        match &self.bias {
            Some(bias) => y.add(bias),
            None => Ok(y),
        }
    }

    fn forward_qmv_batch(&self, x: &Array, matrix_rows: i32) -> Result<Array> {
        ensure!(
            self.k != 7 && (2..24).contains(&matrix_rows),
            "batch QMV requires 2 to 23 rows"
        );
        let xhat = x
            .astype(Dtype::Float16)?
            .reshape(&[matrix_rows, self.rows])?
            .mul(&self.suh.astype(Dtype::Float16)?)?
            .reshape(&[matrix_rows, self.rows / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[matrix_rows, self.rows])?;
        let input_tiles = self.rows / 16;
        let output_tiles = self.cols / 16;
        let splits = split_count(input_tiles, output_tiles);
        let use_nt4 = matrix_rows >= 8 && output_tiles % 4 == 0 && array::is_m5_gpu()?;
        let mut nt = if use_nt4 {
            4
        } else if output_tiles >= 1024 {
            if output_tiles % 2 == 0 { 2 } else { 1 }
        } else if output_tiles % 4 == 0 {
            4
        } else if output_tiles % 2 == 0 {
            2
        } else {
            1
        };
        let (mb, batch_groups) =
            crate::contracts::qmv_batch_layout(matrix_rows, false, output_tiles >= 1024)
                .context("invalid batch QMV rows")?;
        if mb == 2 {
            nt = nt.min(2);
        }
        if mb == 3 {
            nt = 1;
        }
        let header = codebook_header(self.cb)
            + &format!(
                "\n#define MLXL3_QMV_NT {nt}u\n#define MLXL3_QMV_MB {mb}u\n#define MLXL3_MATRIX_ROWS {matrix_rows}u\n#define MLXL3_QMV_SG {}u\n#define MLXL3_K_BITS {}u\n#define MLXL3_FUSE_OUTPUT 0\n#define K {}\n#define CB {}\n#define PACKED_U32 {}\n#define INPUT_DIMS {input}\n#define TILES_K {input_tiles}\n#define TILES_N {output_tiles}\n#define N_SPLITS {splits}\n#define OUTPUT_DIMS {output}\n",
                self.simdgroups,
                self.k,
                self.k,
                self.cb as u32,
                self.k * 8,
                input = self.rows,
                output = self.cols,
            );
        let words = self.trellis.reshape(&[-1])?.view(Dtype::UInt32)?;
        let partials = array::metal_kernel(
            &format!(
                "mlxl3_rs_tile_batch_{}_{}_{}_{}_{}_{}_{}_{}_{}",
                self.rows,
                self.cols,
                self.k,
                self.cb as u32,
                matrix_rows,
                nt,
                mb,
                self.simdgroups,
                splits
            ),
            &["xhat", "trellis", "svh"],
            &["yhat"],
            &header,
            include_str!("../shaders/_qmv_tile_kernel.metal"),
            &[&xhat, &words, &self.svh],
            &[vec![matrix_rows, splits, self.cols]],
            &[Dtype::Float32],
            [
                (output_tiles / nt)
                    .checked_mul(self.simdgroups * 32)
                    .context("QMV grid overflow")?,
                batch_groups,
                splits,
            ],
            [self.simdgroups * 32, 1, 1],
        )?
        .remove(0);
        let output = if splits == 1 {
            partials.reshape(&[matrix_rows, self.cols])?
        } else {
            partials.sum(1, false)?
        };
        let y = output
            .astype(Dtype::Float16)?
            .reshape(&[matrix_rows, self.cols / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[matrix_rows, self.cols])?
            .mul(&self.svh.astype(Dtype::Float16)?)?;
        let mut shape = x.shape().to_vec();
        *shape.last_mut().context("empty input shape")? = self.cols;
        let y = y.astype(x.dtype())?.reshape(&shape)?;
        match &self.bias {
            Some(bias) => y.add(bias),
            None => Ok(y),
        }
    }

    fn forward_qmm_tensor(&self, x: &Array) -> Result<Array> {
        let output = qmm_tensor(
            x,
            &self.trellis,
            &self.suh,
            &self.svh,
            self.rows,
            self.cols,
            self.k,
            self.cb,
            self.cols / 16,
            0,
        )?;
        match &self.bias {
            Some(bias) => output.add(bias),
            None => Ok(output),
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn qmm_tensor(
    x: &Array,
    trellis: &Array,
    suh: &Array,
    svh: &Array,
    input_dims: i32,
    output_dims: i32,
    k: usize,
    cb: Codebook,
    weight_tiles_n: i32,
    weight_tile_offset: i32,
) -> Result<Array> {
    ensure!(array::is_m5_gpu()?, "TensorOps QMM requires Apple M5");
    let block_columns = 32;
    let block_depth = 16;
    ensure!(
        input_dims % block_depth == 0
            && output_dims % block_columns == 0
            && weight_tile_offset >= 0
            && weight_tile_offset + output_dims / 16 <= weight_tiles_n,
        "TensorOps QMM dimensions are not tiled"
    );
    let elements = x
        .shape()
        .iter()
        .try_fold(1i64, |count, &dimension| {
            count.checked_mul(i64::from(dimension))
        })
        .context("QMM input size overflow")?;
    ensure!(
        x.shape().last() == Some(&input_dims) && elements % i64::from(input_dims) == 0,
        "invalid TensorOps QMM input"
    );
    let matrix_rows = i32::try_from(elements / i64::from(input_dims))?;
    ensure!(matrix_rows >= 24, "TensorOps QMM requires at least 24 rows");
    static DENSE_PREFILL_M64: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    let enabled = *DENSE_PREFILL_M64
        .get_or_init(|| std::env::var("MLXL3_DENSE_PREFILL_M64").as_deref() != Ok("0"));
    let block_rows = crate::contracts::dense_qmm_block_rows(
        matrix_rows,
        input_dims,
        output_dims,
        enabled && cb == Codebook::Mul1,
    );
    let padded_rows = ((matrix_rows + block_rows - 1) / block_rows) * block_rows;
    let xhat = x
        .astype(Dtype::Float16)?
        .reshape(&[matrix_rows, input_dims])?
        .mul(&suh.astype(Dtype::Float16)?)?
        .reshape(&[matrix_rows, input_dims / 128, 128])?
        .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
        .reshape(&[matrix_rows, input_dims])?;
    let xhat = if matrix_rows == padded_rows {
        xhat
    } else {
        Array::concatenate(
            &[
                &xhat,
                &Array::zeros_dtype(&[padded_rows - matrix_rows, input_dims], Dtype::Float16)?,
            ],
            0,
        )?
    };
    let inverse = codec::permutation_inverse()
        .map(|value| value.to_string())
        .join(",");
    let header = format!(
        "#include <metal_tensor>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal;\nusing namespace mpp;\n{}constant ushort mlxl3_perm_inv[256] = {{{inverse}}};\n#define BM {block_rows}u\n#define BN {block_columns}u\n#define BK {block_depth}u\n#define K_BITS {k}u\n#define PACKED_U32 {}u\n#define INPUT_DIMS {input_dims}u\n#define OUTPUT_DIMS {output_dims}u\n#define TILES_N {weight_tiles_n}u\n#define WEIGHT_TILE_OFFSET {weight_tile_offset}u\n",
        codebook_header(cb),
        k * 8,
    );
    let words = trellis.reshape(&[-1])?.view(Dtype::UInt32)?;
    let raw = array::metal_kernel(
            &format!(
                "mlxl3_rs_qmm_tensor_{input_dims}_{output_dims}_{k}_{}_s{weight_tiles_n}_o{weight_tile_offset}_bm{block_rows}",
                cb as u32
            ),
            &["xhat", "trellis"],
            &["yhat"],
            &header,
            include_str!("../shaders/_qmm_tensor_kernel.metal"),
            &[&xhat, &words],
            &[vec![padded_rows, output_dims]],
            &[Dtype::Float16],
            [
                (output_dims / block_columns)
                    .checked_mul(32)
                    .context("QMM grid overflow")?,
                padded_rows / block_rows,
                1,
            ],
            [32, 1, 1],
        )?
        .remove(0)
        .slice(0, 0, matrix_rows)?;
    let output = raw
        .reshape(&[matrix_rows, output_dims / 128, 128])?
        .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
        .reshape(&[matrix_rows, output_dims])?
        .mul(&svh.astype(Dtype::Float16)?)?
        .astype(x.dtype())?;
    let mut shape = x.shape().to_vec();
    *shape.last_mut().context("empty QMM input shape")? = output_dims;
    output.reshape(&shape)
}

/// Ragged projections with independent input scales, packed once at load time.
pub struct Exl3Group {
    trellis: Array,
    suh: Array,
    svh: Array,
    tile_sub: Array,
    identity: Array,
    widths: Vec<i32>,
    biases: Vec<Option<Array>>,
    rows: i32,
    cols: i32,
    k: usize,
    cb: Codebook,
    simdgroups: i32,
}

impl Exl3Group {
    pub fn compatible(linears: &[&Exl3Linear]) -> bool {
        linears.first().is_some_and(|first| {
            linears.len() >= 2
                && first.k != 7
                && linears
                    .iter()
                    .all(|l| l.rows == first.rows && l.k == first.k && l.cb == first.cb)
        })
    }

    pub fn new(linears: Vec<Exl3Linear>) -> Result<Self> {
        ensure!(
            Self::compatible(&linears.iter().collect::<Vec<_>>()),
            "incompatible grouped projections"
        );
        let first = &linears[0];
        let rows = first.rows;
        let k = first.k;
        let cb = first.cb;
        let simdgroups = if first.simdgroups == 8 && k == 2 {
            4
        } else {
            first.simdgroups
        };
        let widths: Vec<_> = linears.iter().map(|l| l.cols).collect();
        let cols = widths
            .iter()
            .try_fold(0i32, |sum, n| sum.checked_add(*n))
            .context("group width overflow")?;
        let trellis =
            Array::concatenate(&linears.iter().map(|l| &l.trellis).collect::<Vec<_>>(), 1)?;
        let scales = linears
            .iter()
            .map(|l| l.suh.reshape(&[1, rows]))
            .collect::<Result<Vec<_>>>()?;
        let suh = Array::concatenate(&scales.iter().collect::<Vec<_>>(), 0)?;
        let svh = Array::concatenate(&linears.iter().map(|l| &l.svh).collect::<Vec<_>>(), 0)?;
        let indices: Vec<u8> = widths
            .iter()
            .enumerate()
            .flat_map(|(index, width)| std::iter::repeat_n(index as u32, (width / 16) as usize))
            .flat_map(u32::to_ne_bytes)
            .collect();
        let tile_sub = Array::from_bytes(&indices, &[cols / 16], Dtype::UInt32)?;
        let identity = Array::from_bytes(&0u32.to_ne_bytes(), &[1], Dtype::UInt32)?;
        for array in [&trellis, &suh, &svh, &tile_sub] {
            array.eval()?;
        }
        let biases = linears.into_iter().map(|l| l.bias).collect();
        Ok(Self {
            trellis,
            suh,
            svh,
            tile_sub,
            identity,
            widths,
            biases,
            rows,
            cols,
            k,
            cb,
            simdgroups,
        })
    }

    pub fn forward(&self, x: &Array) -> Result<Vec<Array>> {
        let elements = x
            .shape()
            .iter()
            .try_fold(1i64, |count, &n| count.checked_mul(i64::from(n)))
            .context("grouped EXL3 input size overflow")?;
        ensure!(
            x.shape().last() == Some(&self.rows) && elements % i64::from(self.rows) == 0,
            "invalid grouped EXL3 input"
        );
        let matrix_rows = i32::try_from(elements / i64::from(self.rows))?;
        ensure!(matrix_rows > 0, "grouped EXL3 input cannot be empty");
        if crate::contracts::use_tensor_ops(matrix_rows, array::is_m5_gpu()?) {
            let mut tile_cursor = 0;
            let mut scale_cursor = 0;
            let mut outputs = Vec::with_capacity(self.widths.len());
            for (index, (width, bias)) in self.widths.iter().zip(&self.biases).enumerate() {
                let output = qmm_tensor(
                    x,
                    &self.trellis,
                    &self
                        .suh
                        .slice(0, index as i32, index as i32 + 1)?
                        .reshape(&[self.rows])?,
                    &self.svh.slice(0, scale_cursor, scale_cursor + width)?,
                    self.rows,
                    *width,
                    self.k,
                    self.cb,
                    self.cols / 16,
                    tile_cursor,
                )?;
                outputs.push(match bias {
                    Some(value) => output.add(value)?,
                    None => output,
                });
                tile_cursor += width / 16;
                scale_cursor += width;
            }
            return Ok(outputs);
        }
        if matrix_rows >= 24 {
            let matrix = x.reshape(&[matrix_rows, self.rows])?;
            let mut batches: Vec<Vec<Array>> = self.widths.iter().map(|_| Vec::new()).collect();
            for start in (0..matrix_rows).step_by(23) {
                for (batch, value) in batches.iter_mut().zip(self.forward(&matrix.slice(
                    0,
                    start,
                    start.saturating_add(23).min(matrix_rows),
                )?)?) {
                    batch.push(value);
                }
            }
            return batches
                .into_iter()
                .zip(&self.widths)
                .map(|(batch, &width)| {
                    let mut shape = x.shape().to_vec();
                    *shape.last_mut().context("empty grouped input shape")? = width;
                    Array::concatenate(&batch.iter().collect::<Vec<_>>(), 0)?.reshape(&shape)
                })
                .collect();
        }
        if matrix_rows > 1 {
            return self.forward_qmv_batch(x, matrix_rows);
        }
        let groups = i32::try_from(self.widths.len())?;
        let xhat = x
            .astype(Dtype::Float16)?
            .reshape(&[1, self.rows])?
            .mul(&self.suh.astype(Dtype::Float16)?)?
            .reshape(&[groups, self.rows / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[-1])?;
        let tiles = self.cols / 16;
        let splits = split_count(self.rows / 16, tiles);
        let nt = if dense_decode_nt4_enabled()
            && crate::contracts::dense_decode_nt4(
                self.rows,
                self.cols,
                self.k,
                self.cb == Codebook::Mul1,
                array::is_m5_gpu()?,
            ) {
            4
        } else if tiles >= 1024 {
            if tiles % 2 == 0 { 2 } else { 1 }
        } else if tiles % 4 == 0 {
            4
        } else if tiles % 2 == 0 {
            2
        } else {
            1
        };
        let header = codebook_header(self.cb)
            + &format!(
                "\n#define MLXL3_QMV_NT {nt}u\n#define MLXL3_QMV_SG {sg}u\n#define MLXL3_K_BITS {k}u\n#define MLXL3_K3_WINDOW_DECODE 0\n#define K {k}\n#define CB {cb}\n#define PACKED_U32 {words}\n#define INPUT_DIMS {rows}\n#define TILES_K {kt}\n#define TILES_N {tiles}\n#define N_SPLITS {splits}\n#define LOCAL_OUTPUT_DIMS {cols}\n#define IDENTITY_MAP 1\n#define EXPERT_MAP 0\n#define OUTPUT_TILES {tiles}\n#define ROUTING_REPEAT 1\n#define PROJECTION_STRIDE_TILES 0\n",
                sg = self.simdgroups,
                k = self.k,
                cb = self.cb as u32,
                words = self.k * 8,
                rows = self.rows,
                kt = self.rows / 16,
                cols = self.cols
            );
        let words = self.trellis.reshape(&[-1])?.view(Dtype::UInt32)?;
        let partials = array::metal_kernel(
            "mlxl3_rs_grouped",
            &["xhat", "trellis", "tile_map", "tile_sub"],
            &["yhat"],
            &header,
            include_str!("../shaders/_qmv_mapped_tile_kernel.metal"),
            &[&xhat, &words, &self.identity, &self.tile_sub],
            &[vec![splits, self.cols]],
            &[Dtype::Float32],
            [
                (tiles / nt)
                    .checked_mul(self.simdgroups * 32)
                    .context("grouped grid overflow")?,
                1,
                splits,
            ],
            [self.simdgroups * 32, 1, 1],
        )?
        .remove(0);
        let yhat = if splits == 1 {
            partials.reshape(&[self.cols])?
        } else {
            partials.sum(0, false)?
        };
        let output = yhat
            .astype(Dtype::Float16)?
            .reshape(&[1, self.cols / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[self.cols])?
            .mul(&self.svh.astype(Dtype::Float16)?)?
            .astype(x.dtype())?;
        let mut begin = 0;
        let mut outputs = Vec::new();
        for (width, bias) in self.widths.iter().zip(&self.biases) {
            let mut shape = x.shape().to_vec();
            *shape.last_mut().context("empty grouped input")? = *width;
            let y = output.slice(0, begin, begin + width)?.reshape(&shape)?;
            outputs.push(match bias {
                Some(b) => y.add(b)?,
                None => y,
            });
            begin += width;
        }
        Ok(outputs)
    }

    fn forward_qmv_batch(&self, x: &Array, matrix_rows: i32) -> Result<Vec<Array>> {
        ensure!(
            (2..24).contains(&matrix_rows),
            "grouped batch QMV requires 2 to 23 rows"
        );
        let groups = i32::try_from(self.widths.len())?;
        let xhat = x
            .astype(Dtype::Float16)?
            .reshape(&[matrix_rows, 1, self.rows])?
            .mul(
                &self
                    .suh
                    .astype(Dtype::Float16)?
                    .reshape(&[1, groups, self.rows])?,
            )?
            .reshape(&[matrix_rows * groups, self.rows / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[-1])?;
        let tiles = self.cols / 16;
        let splits = split_count(self.rows / 16, tiles);
        let mut nt = if tiles >= 1024 {
            if tiles % 2 == 0 { 2 } else { 1 }
        } else if tiles % 4 == 0 {
            4
        } else if tiles % 2 == 0 {
            2
        } else {
            1
        };
        let (mb, batch_groups) = crate::contracts::qmv_grouped_batch_layout(
            matrix_rows,
            self.rows,
            self.cols,
            self.k,
            self.cb == Codebook::Mul1,
            array::is_m5_gpu()?,
            grouped_mb3_enabled(),
        )
        .context("invalid grouped batch QMV rows")?;
        if mb == 2 {
            nt = nt.min(2);
        }
        if mb == 3 {
            nt = 1;
        }
        let header = codebook_header(self.cb)
            + &format!(
                "\n#define MLXL3_QMV_NT {nt}u\n#define MLXL3_QMV_MB {mb}u\n#define MLXL3_MATRIX_ROWS {matrix_rows}u\n#define MLXL3_QMV_SG {sg}u\n#define MLXL3_K_BITS {k}u\n#define MLXL3_K3_WINDOW_DECODE 0\n#define MLXL3_BATCH_ROWS 1\n#define GROUPS {groups}\n#define K {k}\n#define CB {cb}\n#define PACKED_U32 {words}\n#define INPUT_DIMS {rows}\n#define TILES_K {kt}\n#define TILES_N {tiles}\n#define N_SPLITS {splits}\n#define LOCAL_OUTPUT_DIMS {cols}\n#define IDENTITY_MAP 1\n#define EXPERT_MAP 0\n#define OUTPUT_TILES {tiles}\n#define ROUTING_REPEAT 1\n#define PROJECTION_STRIDE_TILES 0\n",
                sg = self.simdgroups,
                k = self.k,
                cb = self.cb as u32,
                words = self.k * 8,
                rows = self.rows,
                kt = self.rows / 16,
                cols = self.cols,
            );
        let words = self.trellis.reshape(&[-1])?.view(Dtype::UInt32)?;
        let partials = array::metal_kernel(
            &format!(
                "mlxl3_rs_grouped_batch_{}_{}_{}_{}_{}_{}_{}_{}",
                self.rows, self.cols, self.k, self.cb as u32, nt, mb, self.simdgroups, splits,
            ),
            &["xhat", "trellis", "tile_map", "tile_sub"],
            &["yhat"],
            &header,
            include_str!("../shaders/_qmv_mapped_tile_kernel.metal"),
            &[&xhat, &words, &self.identity, &self.tile_sub],
            &[vec![matrix_rows, splits, self.cols]],
            &[Dtype::Float32],
            [
                (tiles / nt)
                    .checked_mul(self.simdgroups * 32)
                    .context("grouped batch grid overflow")?,
                batch_groups,
                splits,
            ],
            [self.simdgroups * 32, 1, 1],
        )?
        .remove(0);
        let yhat = if splits == 1 {
            partials.reshape(&[matrix_rows, self.cols])?
        } else {
            partials.sum(1, false)?
        };
        let output = yhat
            .astype(Dtype::Float16)?
            .reshape(&[matrix_rows, self.cols / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[matrix_rows, self.cols])?
            .mul(&self.svh.astype(Dtype::Float16)?)?
            .astype(x.dtype())?;
        let mut begin = 0;
        let mut outputs = Vec::with_capacity(self.widths.len());
        for (width, bias) in self.widths.iter().zip(&self.biases) {
            let mut shape = x.shape().to_vec();
            *shape.last_mut().context("empty grouped batch input")? = *width;
            let y = output.slice(1, begin, begin + width)?.reshape(&shape)?;
            outputs.push(match bias {
                Some(value) => y.add(value)?,
                None => y,
            });
            begin += width;
        }
        Ok(outputs)
    }
}

#[allow(clippy::too_many_arguments)]
pub fn expert_mapped(
    x: &Array,
    trellis: &Array,
    suh: Option<&Array>,
    svh: Option<&Array>,
    selected: &Array,
    output_dims: i32,
    projections_per_route: i32,
    projection_stride_tiles: i32,
    k: usize,
    cb: Codebook,
    input_pretransformed: bool,
    return_raw: bool,
) -> Result<Array> {
    codec::check_k(k)?;
    ensure!(k != 7, "mapped K=7 is not supported");
    let [rows, input_dims]: [i32; 2] = x
        .shape()
        .try_into()
        .map_err(|_| anyhow::anyhow!("expert QMV input must have rank 2"))?;
    ensure!(
        trellis.shape().len() == 3
            && trellis.shape()[0] * 16 == input_dims
            && trellis.shape()[2] == (16 * k) as i32,
        "invalid expert trellis"
    );
    ensure!(
        output_dims > 0 && output_dims % 128 == 0,
        "expert output width must be 128-aligned"
    );
    ensure!(
        projections_per_route > 0
            && selected
                .shape()
                .iter()
                .map(|&n| i64::from(n))
                .product::<i64>()
                * i64::from(projections_per_route)
                == i64::from(rows),
        "expert route count does not match input rows"
    );
    ensure!(
        selected.dtype() == Dtype::UInt32
            && (input_pretransformed || suh.is_some_and(|s| s.shape() == x.shape())),
        "invalid expert routes or input scales"
    );
    ensure!(
        return_raw || svh.is_some_and(|s| s.shape() == [rows, output_dims]),
        "invalid expert output scales"
    );
    let xhat = if input_pretransformed {
        x.astype(Dtype::Float16)?.reshape(&[-1])?
    } else {
        x.astype(Dtype::Float16)?
            .mul(
                &suh.expect("validated input scales")
                    .astype(Dtype::Float16)?,
            )?
            .reshape(&[rows, input_dims / 128, 128])?
            .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
            .reshape(&[-1])?
    };
    let output_tiles = output_dims / 16;
    let local_tiles = rows
        .checked_mul(output_tiles)
        .context("expert tile count overflow")?;
    let splits = split_count(trellis.shape()[0], local_tiles);
    let m5 = array::is_m5_gpu()?;
    let use_nt4 = m5 && rows >= 64 && output_tiles % 4 == 0;
    let mut nt = if use_nt4 {
        4
    } else if local_tiles >= 1024 {
        if local_tiles % 2 == 0 { 2 } else { 1 }
    } else if local_tiles % 4 == 0 {
        4
    } else if local_tiles % 2 == 0 {
        2
    } else {
        1
    };
    if output_tiles % nt != 0 {
        nt = 1;
    }
    let simdgroups = if m5 && k == 2 {
        4
    } else if m5 {
        8
    } else {
        4
    };
    let header = codebook_header(cb)
        + &format!(
            "\n#define MLXL3_QMV_NT {nt}u\n#define MLXL3_QMV_SG {simdgroups}u\n#define MLXL3_K_BITS {k}u\n#define MLXL3_K3_WINDOW_DECODE {}\n#define K {k}\n#define CB {}\n#define PACKED_U32 {}\n#define INPUT_DIMS {input_dims}\n#define TILES_K {}\n#define TILES_N {}\n#define N_SPLITS {splits}\n#define LOCAL_OUTPUT_DIMS {}\n#define IDENTITY_MAP 0\n#define EXPERT_MAP 1\n#define OUTPUT_TILES {output_tiles}\n#define ROUTING_REPEAT {projections_per_route}\n#define PROJECTION_STRIDE_TILES {projection_stride_tiles}\n",
            u8::from(k == 3),
            cb as u32,
            k * 8,
            trellis.shape()[0],
            trellis.shape()[1],
            local_tiles * 16,
        );
    let words = trellis.reshape(&[-1])?.view(Dtype::UInt32)?;
    let partials = array::metal_kernel(
        &format!(
            "mlxl3_rs_expert_{}_{}_{}_{}_{}_{}_{}",
            input_dims, output_dims, k, cb as u32, nt, simdgroups, splits
        ),
        &["xhat", "trellis", "tile_map", "tile_sub"],
        &["yhat"],
        &header,
        include_str!("../shaders/_qmv_mapped_tile_kernel.metal"),
        &[&xhat, &words, selected, selected],
        &[vec![splits, rows, output_dims]],
        &[Dtype::Float32],
        [
            (local_tiles / nt)
                .checked_mul(simdgroups * 32)
                .context("expert QMV grid overflow")?,
            1,
            splits,
        ],
        [simdgroups * 32, 1, 1],
    )?
    .remove(0);
    let yhat = if splits == 1 {
        partials.reshape(&[rows, output_dims])?
    } else {
        partials.sum(0, false)?
    };
    if return_raw {
        return Ok(yhat);
    }
    yhat.astype(Dtype::Float16)?
        .reshape(&[rows, output_dims / 128, 128])?
        .hadamard_transform(Some(1.0 / 128.0f32.sqrt()))?
        .reshape(&[rows, output_dims])?
        .mul(svh.expect("validated output scales"))?
        .astype(x.dtype())
}

fn split_count(input_tiles: i32, output_tiles: i32) -> i32 {
    let target = if output_tiles <= 64 {
        (output_tiles / 2).max(32)
    } else {
        output_tiles.clamp(32, 256)
    };
    let mut splits = 1;
    while input_tiles / (splits * 2) >= target {
        splits *= 2;
    }
    splits
}

pub(crate) fn codebook_header(cb: Codebook) -> String {
    let body = match cb {
        Codebook::Default => {
            "uint bits=x*89226354u+64248484u; bits=0x3B603B60u^(bits&0x8FFF8FFFu); half2 v=as_type<half2>(bits); return float(v.x+v.y);"
        }
        Codebook::Mcg => {
            "uint bits=x*0xCBAC1FEDu; bits=0x3B603B60u^(bits&0x8FFF8FFFu); half2 v=as_type<half2>(bits); return float(v.x+v.y);"
        }
        Codebook::Mul1 => {
            "uint bits=x*0x83DCD12Du; uint pairs=(bits&0x00ff00ffu)+((bits>>8)&0x00ff00ffu); uint sum=0x6400u+(pairs&0xffffu)+(pairs>>16); half value=as_type<half>(ushort(sum)); half inv=as_type<half>(ushort(0x1EEEu)); half bias=as_type<half>(ushort(0xC931u)); return float(value*inv+bias);"
        }
    };
    format!("inline float mlxl3_decode_codeword(uint x,int unused_cb) {{ x &= 0xffffu; {body} }}\n")
}

#[cfg(test)]
mod tests {
    #[test]
    #[ignore = "requires disposable draft Q4 projection and physical Apple GPU"]
    fn q4_draft_matches_exl3_rotation_reference() -> anyhow::Result<()> {
        use crate::{affine::AffineLinear, checkpoint::Checkpoint};
        use std::path::Path;
        let root = Path::new("build/mtp-followup/q4-head");
        let reference: serde_json::Value =
            serde_json::from_reader(std::fs::File::open(root.join("reference.json"))?)?;
        let original =
            crate::checkpoint::inspect(Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw"))?;
        let exl3 = super::Exl3Linear::from_checkpoint(&original, "lm_head")?;
        let checkpoint = Checkpoint {
            path: root.to_owned(),
            model_type: "draft_head_q4".into(),
            bits: Some(4.),
            size_bytes: 0,
            modules: Vec::new(),
            tensors: crate::checkpoint::read_header(&root.join("draft_head_q4.safetensors"))?,
        };
        let q4 = AffineLinear::load(&checkpoint, "lm_head", 2048, 248320, None)?;
        let mut compact = None;
        if let Some(path) = std::env::var_os("MLXL3_MTP_TEST_COMPACT_HEAD") {
            let path = std::path::PathBuf::from(path);
            let metadata: serde_json::Value =
                serde_json::from_reader(std::fs::File::open(path.join("draft_head_q4.json"))?)?;
            let ids = metadata["token_ids"]
                .as_array()
                .unwrap()
                .iter()
                .map(|id| u32::try_from(id.as_u64().unwrap()).unwrap())
                .collect::<Vec<_>>();
            assert!(!ids.is_empty() && ids.len() < 248320);
            assert!(
                ids.iter().all(|&id| id < 248320) && ids.windows(2).all(|pair| pair[0] < pair[1])
            );
            let checkpoint = Checkpoint {
                path: path.clone(),
                model_type: "draft_head_q4".into(),
                bits: Some(4.),
                size_bytes: 0,
                modules: Vec::new(),
                tensors: crate::checkpoint::read_header(&path.join("draft_head_q4.safetensors"))?,
            };
            compact = Some((
                AffineLinear::load(&checkpoint, "lm_head", 2048, ids.len() as i32, None)?,
                ids,
            ));
        }
        let inputs = reference["inputs"].as_array().unwrap();
        let logits = reference["logits"].as_array().unwrap();
        assert_eq!(inputs.len(), 3, "missing numerical fixtures");
        assert_eq!(inputs.len(), logits.len());
        for (input, logits) in inputs.iter().zip(logits) {
            let input = input
                .as_array()
                .unwrap()
                .iter()
                .map(|v| half::f16::from_f32(v.as_f64().unwrap() as f32).to_bits())
                .collect::<Vec<_>>();
            let expected = logits
                .as_array()
                .unwrap()
                .iter()
                .map(|v| v.as_f64().unwrap())
                .collect::<Vec<_>>();
            assert_eq!(input.len(), 2048);
            assert_eq!(expected.len(), 4096);
            assert!(expected.iter().all(|v| v.is_finite()));
            let input = crate::array::Array::from_f16_bits(&input, &[1, 2048])?;
            let actual = exl3.forward(&input)?.to_f16_bits()?;
            let quantized = q4.forward(&input)?.to_f16_bits()?;
            assert_eq!(actual.len(), 248320);
            assert_eq!(quantized.len(), actual.len());
            assert!(
                actual
                    .iter()
                    .chain(&quantized)
                    .all(|&b| half::f16::from_bits(b).is_finite())
            );
            let energy = expected.iter().map(|v| v * v).sum::<f64>();
            assert!(energy.is_finite() && energy > 0.);
            let error = |values: &[u16]| {
                values
                    .iter()
                    .zip(&expected)
                    .map(|(&b, &v)| (half::f16::from_bits(b).to_f64() - v).powi(2))
                    .sum::<f64>()
                    / energy
            };
            let reconstruction = error(&actual).sqrt();
            let quantization = error(&quantized).sqrt();
            eprintln!(
                "head relative output RMSE: reconstructed={reconstruction}, affine4={quantization}"
            );
            assert!(
                reconstruction < 0.01,
                "EXL3 rotations/scales reconstructed incorrectly"
            );
            assert!(quantization < 0.2, "poor draft quantization");
            if let Some((head, ids)) = &compact {
                let values = head.forward(&input)?.to_f16_bits()?;
                let selected = ids
                    .iter()
                    .map(|&id| quantized[id as usize])
                    .collect::<Vec<_>>();
                assert_eq!(values.len(), ids.len());
                assert_eq!(
                    values, selected,
                    "compact projection differs from full Q4 rows"
                );
                eprintln!(
                    "compact projection: {} finite rows exactly match full Q4",
                    ids.len()
                );
            }
        }
        Ok(())
    }
    use super::*;

    #[test]
    fn grouped_mb3_override_restores_and_stays_thread_local() {
        assert_eq!(GROUPED_MB3_TEST_OVERRIDE.with(std::cell::Cell::get), None);
        with_grouped_mb3_test(false, || {
            assert!(!grouped_mb3_enabled());
            with_grouped_mb3_test(true, || assert!(grouped_mb3_enabled()));
            assert!(!grouped_mb3_enabled());
            std::thread::spawn(|| {
                assert_eq!(GROUPED_MB3_TEST_OVERRIDE.with(std::cell::Cell::get), None);
            })
            .join()
            .unwrap();
            assert!(
                std::panic::catch_unwind(|| {
                    with_grouped_mb3_test(true, || panic!("temporary test failure"));
                })
                .is_err()
            );
            assert!(!grouped_mb3_enabled());
        });
        assert_eq!(GROUPED_MB3_TEST_OVERRIDE.with(std::cell::Cell::get), None);
    }

    #[test]
    fn dense_decode_test_override_restores_and_stays_thread_local() {
        assert_eq!(DENSE_DECODE_TEST_OVERRIDE.with(std::cell::Cell::get), None);
        with_dense_decode_nt4_test(false, || {
            assert!(!dense_decode_nt4_enabled());
            with_dense_decode_nt4_test(true, || {
                assert!(dense_decode_nt4_enabled());
            });
            assert!(!dense_decode_nt4_enabled());
            let other = std::thread::spawn(|| {
                assert_eq!(DENSE_DECODE_TEST_OVERRIDE.with(std::cell::Cell::get), None);
            });
            other.join().unwrap();
            let panicked = std::panic::catch_unwind(|| {
                with_dense_decode_nt4_test(true, || panic!("temporary benchmark failure"));
            });
            assert!(panicked.is_err());
            assert!(!dense_decode_nt4_enabled());
        });
        assert_eq!(DENSE_DECODE_TEST_OVERRIDE.with(std::cell::Cell::get), None);
    }
    use half::f16;
    use std::{path::Path, time::Instant};

    fn serial_rows(linear: &Exl3Linear, x: &Array) -> Result<Array> {
        let rows = x.shape()[0];
        let outputs = (0..rows)
            .map(|row| linear.forward(&x.slice(0, row, row + 1)?))
            .collect::<Result<Vec<_>>>()?;
        Array::concatenate(&outputs.iter().collect::<Vec<_>>(), 0)
    }

    fn serial_group_rows(group: &Exl3Group, x: &Array) -> Result<Vec<Array>> {
        let rows = (0..x.shape()[0])
            .map(|row| group.forward(&x.slice(0, row, row + 1)?))
            .collect::<Result<Vec<_>>>()?;
        (0..group.widths.len())
            .map(|projection| {
                Array::concatenate(
                    &rows.iter().map(|row| &row[projection]).collect::<Vec<_>>(),
                    0,
                )
            })
            .collect()
    }

    #[test]
    #[ignore = "requires local Qwen checkpoint and Apple M5 GPU"]
    fn batch_qmv_eight_rows_matches_serial() -> Result<()> {
        let checkpoint =
            crate::checkpoint::inspect(Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw"))?;
        let linear = Exl3Linear::from_checkpoint(
            &checkpoint,
            "model.language_model.layers.0.linear_attn.in_proj_qkv",
        )?;
        let input = |rows| {
            let values = (0..rows * linear.rows)
                .map(|index| f16::from_f32(((index % 251) as f32 - 125.0) / 128.0).to_bits())
                .collect::<Vec<_>>();
            Array::from_f16_bits(&values, &[rows, linear.rows])
        };
        for rows in [2, 4, 16, 23] {
            let x = input(rows)?;
            assert_eq!(
                serial_rows(&linear, &x)?.to_f16_bits()?,
                linear.forward(&x)?.to_f16_bits()?,
                "batch QMV differs at M={rows}"
            );
        }
        let x = input(8)?;

        let serial = serial_rows(&linear, &x)?;
        let batched = linear.forward(&x)?;
        let serial_bits = serial.to_f16_bits()?;
        let batched_bits = batched.to_f16_bits()?;
        let mismatches = serial_bits
            .iter()
            .zip(&batched_bits)
            .filter(|(left, right)| left != right)
            .count();
        let max_abs = serial_bits
            .iter()
            .zip(&batched_bits)
            .map(|(&left, &right)| {
                (f16::from_bits(left).to_f32() - f16::from_bits(right).to_f32()).abs()
            })
            .fold(0.0f32, f32::max);

        for _ in 0..2 {
            serial_rows(&linear, &x)?.eval()?;
            linear.forward(&x)?.eval()?;
        }
        let repeats = 5;
        let start = Instant::now();
        for _ in 0..repeats {
            serial_rows(&linear, &x)?.eval()?;
        }
        let serial_ms = start.elapsed().as_secs_f64() * 1000.0 / f64::from(repeats);
        let start = Instant::now();
        for _ in 0..repeats {
            linear.forward(&x)?.eval()?;
        }
        let batched_ms = start.elapsed().as_secs_f64() * 1000.0 / f64::from(repeats);
        eprintln!(
            "M=8 projection: serial={serial_ms:.3}ms batch_qmv={batched_ms:.3}ms speedup={:.2}x mismatches={mismatches}/{} max_abs={max_abs}",
            serial_ms / batched_ms,
            serial_bits.len()
        );
        assert_eq!(serial.shape(), batched.shape());
        assert_eq!(mismatches, 0);
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen checkpoint and Apple M5 GPU"]
    fn batch_grouped_qmv_shared_rows_match_serial() -> Result<()> {
        let checkpoint =
            crate::checkpoint::inspect(Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw"))?;
        let group = Exl3Group::new(vec![
            Exl3Linear::from_checkpoint(
                &checkpoint,
                "model.language_model.layers.0.linear_attn.in_proj_qkv",
            )?,
            Exl3Linear::from_checkpoint(
                &checkpoint,
                "model.language_model.layers.0.linear_attn.in_proj_z",
            )?,
        ])?;
        for matrix_rows in [6, 8] {
            let values = (0..matrix_rows * group.rows)
                .map(|index| f16::from_f32(((index % 251) as f32 - 125.0) / 128.0).to_bits())
                .collect::<Vec<_>>();
            let x = Array::from_f16_bits(&values, &[matrix_rows, group.rows])?;
            let expected = serial_group_rows(&group, &x)?;
            let actual = group.forward(&x)?;
            for (index, (left, right)) in expected.iter().zip(&actual).enumerate() {
                assert_eq!(
                    left.to_f16_bits()?,
                    right.to_f16_bits()?,
                    "grouped batch M={matrix_rows} output {index} differs"
                );
            }
        }
        let matrix_rows = 8;
        let values = (0..matrix_rows * group.rows)
            .map(|index| f16::from_f32(((index % 251) as f32 - 125.0) / 128.0).to_bits())
            .collect::<Vec<_>>();
        let x = Array::from_f16_bits(&values, &[matrix_rows, group.rows])?;
        for _ in 0..2 {
            for value in serial_group_rows(&group, &x)? {
                value.eval()?;
            }
            for value in group.forward(&x)? {
                value.eval()?;
            }
        }
        let repeats = 5;
        let start = Instant::now();
        for _ in 0..repeats {
            for value in serial_group_rows(&group, &x)? {
                value.eval()?;
            }
        }
        let serial_ms = start.elapsed().as_secs_f64() * 1000.0 / f64::from(repeats);
        let start = Instant::now();
        for _ in 0..repeats {
            for value in group.forward(&x)? {
                value.eval()?;
            }
        }
        let batched_ms = start.elapsed().as_secs_f64() * 1000.0 / f64::from(repeats);
        eprintln!(
            "Qwen grouped QMV M=8: serial={serial_ms:.3}ms batch={batched_ms:.3}ms speedup={:.2}x",
            serial_ms / batched_ms
        );
        Ok(())
    }
}
