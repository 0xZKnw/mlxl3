#include <metal_stdlib>
using namespace metal;
kernel void router(device const half* probabilities, device const half* bias, device uint* indices, device half* scores, uint thread_index_in_simdgroup [[thread_index_in_simdgroup]]) {

            constexpr uint EXPERTS = 64u;
            constexpr uint TOP_K = 4u;
            uint lane = thread_index_in_simdgroup;
            half probability = lane < EXPERTS ? probabilities[lane] : half(0);
            float candidate = lane < EXPERTS
                ? float(probability) + float(bias[lane])
                : -INFINITY;
            uint second_expert = lane + 32u;
            float second = second_expert < EXPERTS
                ? float(probabilities[second_expert]) + float(bias[second_expert])
                : -INFINITY;
            uint chosen[TOP_K];
            for (uint rank = 0u; rank < TOP_K; ++rank) {
                float best = simd_max(max(candidate, second));
                uint possible = min(candidate == best ? lane : 0xffffffffu,
                    second == best ? second_expert : 0xffffffffu);
                uint winner = simd_min(possible);
                if (lane == 0u) chosen[rank] = winner;
                if (lane == winner) candidate = -INFINITY;
                if (second_expert == winner) second = -INFINITY;
            }
            if (lane == 0u) {
                for (uint slot = 0u; slot < TOP_K; ++slot) {
                    uint expert = chosen[TOP_K - 1u - slot];
                    indices[slot] = expert;
                    scores[slot] = probabilities[expert];
                }
            }
        
}
