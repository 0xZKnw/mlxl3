use anyhow::{Context, Result, bail};
use clap::{Parser, Subcommand, ValueEnum};
use mlxl3_native::{
    checkpoint,
    codec::{self, Codebook},
    registry,
    streaming::ThinkingSplitter,
};
use serde::Deserialize;
#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
use serde::Serialize;
use serde_json::{Value, json};
#[cfg(all(feature = "mlx", feature = "chat"))]
use std::collections::VecDeque;
#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
use std::{
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::{Instant, SystemTime, UNIX_EPOCH},
};

#[cfg(all(
    not(feature = "mlx"),
    feature = "chat",
    target_os = "macos",
    feature = "direct-metal"
))]
mod direct_bridge;
#[cfg(all(feature = "mlx", feature = "chat"))]
mod mtp_tune;
#[cfg(all(
    not(feature = "mlx"),
    feature = "chat",
    target_os = "macos",
    feature = "direct-metal"
))]
use direct_bridge::{ChatMtpHead, NativeChatModel, PromptCache};
#[cfg(all(feature = "mlx", feature = "chat"))]
type RoundDraft = mlxl3_native::dflash::DFlashWeights;
#[cfg(all(
    not(feature = "mlx"),
    feature = "chat",
    target_os = "macos",
    feature = "direct-metal"
))]
type RoundDraft = mlxl3_native::native_draft::Session;
#[cfg(any(
    test,
    all(
        feature = "chat",
        any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
    )
))]
mod openai;
use std::{
    io::{self, BufRead, Read, Write},
    path::PathBuf,
};

#[derive(Parser)]
#[command(
    version,
    about = "Native MLXL3 Rust/Metal runtime",
    after_help = "Powered by MTPLX https://github.com/youssofal/MTPLX"
)]
struct Cli {
    #[arg(long, global = true)]
    registry: Option<PathBuf>,
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Machine-readable engine identity; no model or registry mutation.
    RuntimeInfo,
    #[command(alias = "ls")]
    List {
        #[arg(long)]
        json: bool,
    },
    Inspect {
        path: PathBuf,
    },
    #[command(alias = "add")]
    Register {
        name: String,
        path: PathBuf,
        #[arg(long)]
        force: bool,
    },
    #[command(alias = "rm")]
    Remove {
        name: String,
        #[arg(long)]
        expected_path: Option<PathBuf>,
    },
    /// JSON-line codec oracle used for differential tests (not a chat bridge).
    Codec,
    /// Quantize complete FP32 kernel-order tiles with the autonomous Metal trellis.
    QuantizeTiles {
        input: PathBuf,
        output: PathBuf,
        #[arg(long)]
        k: u32,
        #[arg(long, default_value_t = 0)]
        codebook: u32,
        #[arg(long, default_value_t = 256 * 1024 * 1024)]
        max_scratch_bytes: u64,
    },
    /// Multiply finite FP32 matrices for the converter's feedback boundary.
    ConvertMatmul {
        left: PathBuf,
        right: PathBuf,
        output: PathBuf,
        #[arg(long)]
        m: u32,
        #[arg(long)]
        n: u32,
        #[arg(long)]
        k: u32,
        #[arg(long)]
        full_fp32: bool,
    },
    /// Feed a JSON array of text chunks on stdin; return reasoning/answer fragments.
    Split {
        #[arg(long, default_value = "")]
        prompt: String,
    },
    /// Chat with a local or registered model using the compiled inference backend.
    Run {
        model: String,
        #[arg(short, long)]
        prompt: Option<String>,
        #[arg(long, default_value_t = 128)]
        max_tokens: usize,
    },
    /// Resident JSON-lines bridge consumed by MLXL3 Desktop.
    Bridge {
        model: String,
        #[arg(long, default_value_t = 0)]
        context_length: i32,
    },
    /// Serve an EXL3 model through an OpenAI-compatible HTTP API.
    Serve {
        model: String,
        #[arg(long, default_value = "127.0.0.1")]
        host: String,
        #[arg(long, default_value_t = 8000)]
        port: u16,
        #[arg(long, default_value = "")]
        api_key: String,
        #[arg(long, default_value_t = 0)]
        context_length: i32,
    },
    /// Browse EXL3 repositories on Hugging Face.
    Hub {
        #[arg(value_enum)]
        action: HubAction,
        query: String,
        #[arg(long)]
        revision: Option<String>,
        #[arg(long, default_value = "")]
        folder: String,
        #[arg(long, default_value_t = 60)]
        limit: usize,
    },
    /// Install or validate the pinned Qwen DFlash2 draft (no target weights).
    DflashDraft {
        #[arg(long)]
        inspect: Option<PathBuf>,
        /// Download/validate the draft matching this target's configuration.
        #[arg(long)]
        target: Option<PathBuf>,
    },
    /// Install or inspect a native Qwen MTP head without downloading the target.
    MtpHead {
        #[arg(long)]
        inspect: Option<PathBuf>,
        /// Select/validate the head against this target's configuration.
        #[arg(long)]
        target: Option<PathBuf>,
    },
    /// Configure and inspect Model Context Protocol servers.
    Mcp {
        #[command(subcommand)]
        action: McpAction,
    },
    /// Emit logits for an imposed token sequence (native parity check).
    #[cfg(all(
        feature = "chat",
        any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
    ))]
    Forward {
        model: PathBuf,
        #[arg(long, value_delimiter = ',', required = true)]
        tokens: Vec<u32>,
        #[arg(long)]
        states: bool,
        #[arg(long)]
        batch: bool,
    },
}

#[derive(Clone, Copy, ValueEnum)]
enum HubAction {
    Search,
    Details,
    Download,
    Pending,
    Resume,
    Discard,
    Auth,
}

#[derive(Subcommand)]
enum McpAction {
    #[command(alias = "ls")]
    List {
        #[arg(long)]
        json: bool,
    },
    Check {
        #[arg(long)]
        json: bool,
    },
    Config,
    Add {
        name: String,
        command: String,
        args: Vec<String>,
    },
    #[command(alias = "rm")]
    Remove {
        name: String,
    },
}

#[derive(Deserialize)]
struct CodecRequest {
    op: String,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    path: String,
    #[serde(default)]
    #[cfg(all(target_os = "macos", feature = "direct-metal"))]
    prefix: String,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    prefixes: Vec<String>,
    #[serde(default)]
    #[cfg(all(target_os = "macos", feature = "direct-metal"))]
    slots: Option<usize>,
    #[serde(default)]
    #[cfg(all(target_os = "macos", feature = "direct-metal"))]
    token_ids: Vec<u32>,
    #[serde(default = "default_k")]
    k: usize,
    #[serde(default)]
    mode: u32,
    #[serde(default)]
    data: Vec<u16>,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    x: Vec<u16>,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    x_f32: Option<Vec<f32>>,
    #[serde(default)]
    #[cfg(all(target_os = "macos", feature = "direct-metal"))]
    x_layout: Option<mlxl3_native::tensor_layout::MatrixLayout>,
    #[serde(default)]
    #[cfg(all(target_os = "macos", feature = "direct-metal"))]
    scale_layout: Option<mlxl3_native::tensor_layout::MatrixLayout>,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    cols: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    suh: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    svh: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    widths: Vec<usize>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    q: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    v: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    g: Vec<f32>,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    beta: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    state: Vec<f32>,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    key_heads: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    value_heads: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    value_dims: usize,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    normalize: bool,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    groups: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    top_groups: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    scale: f32,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    selected: Vec<u32>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    projections_per_route: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    projection_stride_tiles: usize,
    #[serde(default)]
    #[cfg(any(all(target_os = "macos", feature = "direct-metal"), feature = "mlx"))]
    return_raw: bool,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    down_data: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    down_suh: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    down_svh: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    layer: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    top_k: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    conv_length: usize,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    conv_state: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    keys: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    values: Vec<u16>,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    token: u32,
    #[serde(default)]
    #[cfg(feature = "mlx")]
    tokens: Vec<u32>,
}
#[cfg(all(target_os = "macos", feature = "direct-metal"))]
impl CodecRequest {
    fn input_view(&self, gpu: &mlxl3_native::gpu::Metal) -> Result<mlxl3_native::gpu::MatrixView> {
        let layout = self.x_layout.context("missing input matrix layout")?;
        let storage = if let Some(data) = &self.x_f32 {
            anyhow::ensure!(self.x.is_empty(), "conflicting input buffer dtypes");
            gpu.f32_storage(data)?
        } else {
            gpu.f16_storage(&self.x)?
        };
        storage.matrix(layout)
    }
}

fn default_k() -> usize {
    4
}

#[cfg(all(target_os = "macos", feature = "direct-metal"))]
fn flash_checkpoint_epsilon(checkpoint: &checkpoint::Checkpoint) -> Result<f32> {
    let config: serde_json::Value =
        serde_json::from_reader(std::fs::File::open(checkpoint.path.join("config.json"))?)?;
    Ok(config["text_config"]["rms_norm_eps"]
        .as_f64()
        .context("missing Flash norm epsilon")? as f32)
}

fn codec_loop() -> Result<()> {
    #[cfg(all(target_os = "macos", feature = "direct-metal"))]
    let mut gpu = None;
    let stdout = io::stdout();
    let mut output = stdout.lock();
    for line in io::stdin().lock().lines() {
        let result = (|| -> Result<Value> {
            let request: CodecRequest =
                serde_json::from_str(&line?).context("invalid codec request")?;
            let cb = Codebook::try_from(request.mode)?;
            match request.op.as_str() {
                "pack" => Ok(json!(codec::pack(&request.data, request.k)?)),
                "unpack" => Ok(json!(codec::unpack(&request.data, request.k)?)),
                "codebook" => Ok(json!(
                    request
                        .data
                        .iter()
                        .map(|&s| codec::decode_codeword(s, cb).to_bits())
                        .collect::<Vec<_>>()
                )),
                "permutation" => Ok(json!(codec::permutation().to_vec())),
                #[cfg(feature = "mlx")]
                "mlx-linear" => {
                    use mlxl3_native::{array::Array, linear::Exl3Linear};
                    codec::check_k(request.k)?;
                    let rows = i32::try_from(request.suh.len())?;
                    anyhow::ensure!(
                        rows > 0 && request.x.len().is_multiple_of(rows as usize),
                        "invalid linear input rows"
                    );
                    let matrix_rows = i32::try_from(request.x.len() / rows as usize)?;
                    let cols = i32::try_from(request.cols)?;
                    let trellis = Array::from_u16(
                        &request.data,
                        &[rows / 16, cols / 16, (16 * request.k) as i32],
                    )?;
                    let layer = Exl3Linear::new(
                        trellis,
                        Array::from_f16_bits(&request.suh, &[rows])?,
                        Array::from_f16_bits(&request.svh, &[cols])?,
                        None,
                        request.k,
                        cb,
                    )?;
                    let x = Array::from_f16_bits(&request.x, &[matrix_rows, rows])?;
                    Ok(json!(layer.forward(&x)?.to_f16_bits()?))
                }
                #[cfg(feature = "mlx")]
                "mlx-group" => {
                    use mlxl3_native::{
                        array::Array,
                        linear::{Exl3Group, Exl3Linear},
                    };
                    codec::check_k(request.k)?;
                    anyhow::ensure!(!request.widths.is_empty(), "missing group widths");
                    anyhow::ensure!(
                        request.suh.len().is_multiple_of(request.widths.len()),
                        "invalid grouped input scales"
                    );
                    let rows = request.suh.len() / request.widths.len();
                    anyhow::ensure!(
                        rows > 0
                            && rows.is_multiple_of(128)
                            && request.x.len().is_multiple_of(rows),
                        "invalid grouped input size"
                    );
                    let matrix_rows = request.x.len() / rows;
                    anyhow::ensure!(
                        request.widths.len() >= 2 && request.k != 7,
                        "unsupported group"
                    );
                    anyhow::ensure!(
                        request.suh.len()
                            == rows
                                .checked_mul(request.widths.len())
                                .context("scale overflow")?,
                        "invalid grouped input scales"
                    );
                    let mut data_offset = 0usize;
                    let mut scale_offset = 0usize;
                    let mut linears = Vec::new();
                    for (index, width) in request.widths.iter().copied().enumerate() {
                        anyhow::ensure!(
                            width > 0 && width.is_multiple_of(128),
                            "invalid group width"
                        );
                        let words = (rows / 16)
                            .checked_mul(width / 16)
                            .and_then(|n| n.checked_mul(16 * request.k))
                            .context("trellis overflow")?;
                        let end = data_offset
                            .checked_add(words)
                            .context("trellis offset overflow")?;
                        let scale_end = scale_offset
                            .checked_add(width)
                            .context("scale offset overflow")?;
                        let r = i32::try_from(rows)?;
                        let c = i32::try_from(width)?;
                        linears.push(Exl3Linear::new(
                            Array::from_u16(
                                request
                                    .data
                                    .get(data_offset..end)
                                    .context("truncated grouped trellis")?,
                                &[r / 16, c / 16, (16 * request.k) as i32],
                            )?,
                            Array::from_f16_bits(
                                &request.suh[index * rows..(index + 1) * rows],
                                &[r],
                            )?,
                            Array::from_f16_bits(
                                request
                                    .svh
                                    .get(scale_offset..scale_end)
                                    .context("truncated grouped scales")?,
                                &[c],
                            )?,
                            None,
                            request.k,
                            cb,
                        )?);
                        data_offset = end;
                        scale_offset = scale_end;
                    }
                    anyhow::ensure!(
                        data_offset == request.data.len() && scale_offset == request.svh.len(),
                        "extra grouped data"
                    );
                    let group = Exl3Group::new(linears)?;
                    let outputs = group.forward(&Array::from_f16_bits(
                        &request.x,
                        &[i32::try_from(matrix_rows)?, i32::try_from(rows)?],
                    )?)?;
                    Ok(json!(
                        outputs
                            .iter()
                            .map(Array::to_f16_bits)
                            .collect::<Result<Vec<_>>>()?
                    ))
                }
                #[cfg(feature = "mlx")]
                "mlx-gdn" => {
                    use mlxl3_native::{array::Array, gated_delta};
                    let batch = 1;
                    let key_heads = i32::try_from(request.key_heads)?;
                    let value_heads = i32::try_from(request.value_heads)?;
                    let value_dims = i32::try_from(request.value_dims)?;
                    let row_width = usize::try_from(key_heads)? * 128;
                    anyhow::ensure!(
                        row_width > 0 && request.q.len().is_multiple_of(row_width),
                        "invalid GDN time dimension"
                    );
                    let time = i32::try_from(request.q.len() / row_width)?;
                    let q_shape = [batch, time, key_heads, 128];
                    let v_shape = [batch, time, value_heads, value_dims];
                    let state_shape = [batch, value_heads, value_dims, 128];
                    let (output, state) = gated_delta::step(
                        &Array::from_f16_bits(&request.q, &q_shape)?,
                        &Array::from_f16_bits(&request.x, &q_shape)?,
                        &Array::from_f16_bits(&request.v, &v_shape)?,
                        &Array::from_f32(&request.g, &[batch, time, value_heads])?,
                        &Array::from_f16_bits(&request.beta, &[batch, time, value_heads])?,
                        &Array::from_f32(&request.state, &state_shape)?,
                    )?;
                    Ok(json!({
                        "output": output.to_f16_bits()?,
                        "state": state.to_f32()?,
                    }))
                }
                #[cfg(feature = "mlx")]
                "mlx-gdn-vector" => {
                    use mlxl3_native::{array::Array, gated_delta};
                    let heads = i32::try_from(request.key_heads)?;
                    let shape = [1, 1, heads, 128];
                    let state_shape = [1, heads, 128, 128];
                    let (output, state) = gated_delta::step_vector(
                        &Array::from_f16_bits(&request.q, &shape)?,
                        &Array::from_f16_bits(&request.x, &shape)?,
                        &Array::from_f16_bits(&request.v, &shape)?,
                        &Array::from_f32(&request.g, &shape)?,
                        &Array::from_f16_bits(&request.beta, &[1, 1, heads])?,
                        &Array::from_f32(&request.state, &state_shape)?,
                    )?;
                    Ok(json!({
                        "output": output.to_f16_bits()?,
                        "state": state.to_f32()?,
                    }))
                }
                #[cfg(feature = "mlx")]
                "mlx-router" => {
                    use mlxl3_native::{array::Array, router};
                    let elements = request.x_f32.as_ref().map_or(request.data.len(), Vec::len);
                    let experts = if request.cols == 0 {
                        elements
                    } else {
                        request.cols
                    };
                    anyhow::ensure!(
                        experts > 0 && elements > 0 && elements.is_multiple_of(experts),
                        "invalid router rows"
                    );
                    let shape = [i32::try_from(elements / experts)?, i32::try_from(experts)?];
                    let input = if let Some(data) = &request.x_f32 {
                        anyhow::ensure!(request.data.is_empty(), "conflicting router input dtypes");
                        Array::from_f32(data, &shape)?
                    } else {
                        Array::from_f16_bits(&request.data, &shape)?
                    };
                    let (indices, scores) = router::topk(&input, request.k, request.normalize)?;
                    let words = if request.x_f32.is_some() {
                        scores
                            .to_f32()?
                            .into_iter()
                            .map(f32::to_bits)
                            .collect::<Vec<_>>()
                    } else {
                        scores.to_f16_bits()?.into_iter().map(u32::from).collect()
                    };
                    Ok(json!({"indices": indices.to_u32()?, "scores": words}))
                }
                #[cfg(feature = "mlx")]
                "mlx-router-biased" => {
                    use mlxl3_native::{array::Array, router};
                    let experts = i32::try_from(request.data.len())?;
                    let (indices, scores) = router::topk_biased(
                        &Array::from_f16_bits(&request.data, &[1, experts])?,
                        &Array::from_f16_bits(&request.beta, &[experts])?,
                        request.k,
                    )?;
                    Ok(json!({
                        "indices": indices.to_u32()?,
                        "scores": scores.to_f16_bits()?,
                    }))
                }
                #[cfg(feature = "mlx")]
                "mlx-router-grouped" => {
                    use mlxl3_native::{array::Array, router};
                    let experts = i32::try_from(request.g.len())?;
                    let (indices, scores) = router::grouped_topk_biased(
                        &Array::from_f32(&request.g, &[1, experts])?,
                        &Array::from_f32(&request.state, &[experts])?,
                        request.k,
                        request.groups,
                        request.top_groups,
                        request.scale,
                    )?;
                    Ok(json!({
                        "indices": indices.to_u32()?,
                        "scores": scores.to_f32()?,
                    }))
                }
                #[cfg(feature = "mlx")]
                "mlx-expert" => {
                    use mlxl3_native::{array::Array, linear::expert_mapped};
                    codec::check_k(request.k)?;
                    let projections = i32::try_from(request.projections_per_route)?;
                    anyhow::ensure!(projections > 0, "invalid projection count");
                    let rows = i32::try_from(
                        request
                            .selected
                            .len()
                            .checked_mul(request.projections_per_route)
                            .context("expert row count overflow")?,
                    )?;
                    anyhow::ensure!(rows > 0, "missing expert routes");
                    let input_dims = i32::try_from(request.x.len())?
                        .checked_div(rows)
                        .context("invalid expert input dimensions")?;
                    let output_dims = i32::try_from(request.cols)?;
                    let input_tiles = input_dims / 16;
                    let packed_per_tile = i32::try_from(16 * request.k)?;
                    let source_tiles = i32::try_from(request.data.len())?
                        .checked_div(
                            input_tiles
                                .checked_mul(packed_per_tile)
                                .context("expert trellis size overflow")?,
                        )
                        .context("invalid expert trellis dimensions")?;
                    let trellis = Array::from_u16(
                        &request.data,
                        &[input_tiles, source_tiles, packed_per_tile],
                    )?;
                    let x = Array::from_f16_bits(&request.x, &[rows, input_dims])?;
                    let suh = Array::from_f16_bits(&request.suh, &[rows, input_dims])?;
                    let svh = (!request.return_raw)
                        .then(|| Array::from_f16_bits(&request.svh, &[rows, output_dims]))
                        .transpose()?;
                    let output = expert_mapped(
                        &x,
                        &trellis,
                        Some(&suh),
                        svh.as_ref(),
                        &Array::from_u32(
                            &request.selected,
                            &[i32::try_from(request.selected.len())?],
                        )?,
                        output_dims,
                        projections,
                        i32::try_from(request.projection_stride_tiles)?,
                        request.k,
                        cb,
                        false,
                        request.return_raw,
                    )?;
                    Ok(if request.return_raw {
                        json!({ "f32": output.to_f32()? })
                    } else {
                        json!({ "f16": output.to_f16_bits()? })
                    })
                }
                #[cfg(feature = "mlx")]
                "mlx-swiglu-prepare" => {
                    use mlxl3_native::{array::Array, moe};
                    let hidden = i32::try_from(request.cols)?;
                    let slots = i32::try_from(request.selected.len())?;
                    let experts = i32::try_from(request.suh.len())?
                        .checked_div(2 * hidden)
                        .context("invalid gate/up scales")?;
                    let output = moe::swiglu_down_input(
                        &Array::from_f32(&request.state, &[slots * 2, hidden])?,
                        &Array::from_f16_bits(&request.suh, &[experts, 2, hidden])?,
                        &Array::from_f16_bits(&request.svh, &[experts, hidden])?,
                        &Array::from_u32(&request.selected, &[slots])?,
                    )?;
                    Ok(json!(output.to_f16_bits()?))
                }
                #[cfg(feature = "mlx")]
                "mlx-expert-reduce" => {
                    use mlxl3_native::{array::Array, moe};
                    let width = i32::try_from(request.cols)?;
                    let slots = i32::try_from(request.beta.len())?;
                    let output = moe::finish_and_reduce(
                        &Array::from_f32(&request.state, &[slots, width])?,
                        &Array::from_f16_bits(&request.svh, &[slots, width])?,
                        &Array::from_f16_bits(&request.beta, &[1, slots])?,
                    )?;
                    Ok(json!(output.to_f16_bits()?))
                }
                #[cfg(feature = "mlx")]
                "mlx-switch" => {
                    use mlxl3_native::{array::Array, moe::Exl3SwitchGlu};
                    let experts = i32::try_from(request.key_heads)?;
                    let top_k = i32::try_from(if request.top_k > 0 {
                        request.top_k
                    } else {
                        request.selected.len()
                    })?;
                    anyhow::ensure!(
                        top_k > 0
                            && request
                                .selected
                                .len()
                                .is_multiple_of(usize::try_from(top_k)?),
                        "invalid SwitchGLU routes"
                    );
                    let rows = i32::try_from(request.selected.len() / usize::try_from(top_k)?)?;
                    anyhow::ensure!(
                        request.x.len().is_multiple_of(usize::try_from(rows)?),
                        "invalid SwitchGLU rows"
                    );
                    let input = i32::try_from(request.x.len() / usize::try_from(rows)?)?;
                    let hidden = i32::try_from(request.cols)?;
                    let gu = Array::from_u16(
                        &request.data,
                        &[input / 16, experts * hidden / 8, (16 * request.k) as i32],
                    )?;
                    let down = Array::from_u16(
                        &request.down_data,
                        &[hidden / 16, experts * input / 16, (16 * request.k) as i32],
                    )?;
                    let switch = Exl3SwitchGlu::new(
                        gu,
                        Array::from_f16_bits(&request.suh, &[experts, 2, input])?,
                        Array::from_f16_bits(&request.svh, &[experts, 2, hidden])?,
                        down,
                        Array::from_f16_bits(&request.down_suh, &[experts, hidden])?,
                        Array::from_f16_bits(&request.down_svh, &[experts, input])?,
                        top_k,
                        request.k,
                        cb,
                    )?;
                    let output = switch.forward(
                        &Array::from_f16_bits(&request.x, &[rows, input])?,
                        &Array::from_u32(&request.selected, &[rows, top_k])?,
                        &Array::from_f16_bits(&request.beta, &[rows, top_k])?,
                    )?;
                    Ok(json!(output.to_f16_bits()?))
                }
                #[cfg(feature = "mlx")]
                "mlx-checkpoint-group" => {
                    use mlxl3_native::{
                        array::Array,
                        linear::{Exl3Group, Exl3Linear},
                    };
                    let c = checkpoint::inspect(std::path::Path::new(&request.path))?;
                    anyhow::ensure!(!request.prefixes.is_empty(), "empty projection bundle");
                    let layers = request
                        .prefixes
                        .iter()
                        .map(|p| Exl3Linear::from_checkpoint(&c, p))
                        .collect::<Result<Vec<_>>>()?;
                    let grouped = Exl3Group::compatible(&layers.iter().collect::<Vec<_>>());
                    let input =
                        Array::from_f16_bits(&request.x, &[1, i32::try_from(request.x.len())?])?;
                    let outputs = if grouped {
                        Exl3Group::new(layers)?.forward(&input)?
                    } else {
                        layers
                            .iter()
                            .map(|p| p.forward(&input))
                            .collect::<Result<Vec<_>>>()?
                    };
                    Ok(
                        json!({"grouped":grouped,"outputs":outputs.iter().map(|v|v.to_f16_bits()).collect::<Result<Vec<_>>>()?}),
                    )
                }
                #[cfg(feature = "mlx")]
                "mlx-checkpoint-switch" => {
                    use mlxl3_native::{array::Array, moe::Exl3SwitchGlu};
                    let c = checkpoint::inspect(std::path::Path::new(&request.path))?;
                    let experts = i32::try_from(request.key_heads)?;
                    let count = i32::try_from(request.selected.len())?;
                    let input = i32::try_from(request.x.len())?;
                    let layer = if c.model_type == "lfm2_moe" {
                        Exl3SwitchGlu::from_lfm_checkpoint(&c, &request.prefix, experts, count)?
                    } else {
                        Exl3SwitchGlu::from_checkpoint(&c, &request.prefix, experts, count)?
                    };
                    Ok(json!(
                        layer
                            .forward(
                                &Array::from_f16_bits(&request.x, &[1, input])?,
                                &Array::from_u32(&request.selected, &[1, count])?,
                                &Array::from_f16_bits(&request.beta, &[1, count])?
                            )?
                            .to_f16_bits()?
                    ))
                }
                #[cfg(feature = "mlx")]
                "mlx-qwen-moe" => {
                    use mlxl3_native::{array::Array, checkpoint, qwen35::Moe};
                    let checkpoint = checkpoint::inspect(std::path::Path::new(&request.path))?;
                    let hidden = i32::try_from(request.cols)?;
                    let expert_hidden = i32::try_from(request.value_dims)?;
                    let experts = i32::try_from(request.key_heads)?;
                    let block = Moe::load(
                        &checkpoint,
                        &format!("model.language_model.layers.{}.mlp", request.layer),
                        hidden,
                        expert_hidden,
                        experts,
                        request.top_k,
                    )?;
                    let output = block.forward(&Array::from_f16_bits(&request.x, &[1, hidden])?)?;
                    Ok(json!(output.to_f16_bits()?))
                }
                #[cfg(feature = "mlx")]
                "mlx-qwen-gdn" | "mlx-qwen-gdn-sequence" => {
                    use mlxl3_native::{array::Array, checkpoint, qwen35::GatedDelta};
                    let checkpoint = checkpoint::inspect(std::path::Path::new(&request.path))?;
                    let hidden = i32::try_from(request.cols)?;
                    let key_heads = i32::try_from(request.key_heads)?;
                    let value_heads = i32::try_from(request.value_heads)?;
                    let value_dims = i32::try_from(request.value_dims)?;
                    let conv_length = i32::try_from(request.conv_length)?;
                    let key_dims = 128;
                    let conv_dims = 2 * key_heads * key_dims + value_heads * value_dims;
                    let mut block = GatedDelta::load(
                        &checkpoint,
                        &format!("model.language_model.layers.{}.linear_attn", request.layer),
                        hidden,
                        key_heads,
                        value_heads,
                        key_dims,
                        value_dims,
                        conv_length,
                        1e-6,
                    )?;
                    block.set_state(
                        (!request.conv_state.is_empty())
                            .then(|| {
                                Array::from_f16_bits(
                                    &request.conv_state,
                                    &[1, conv_length - 1, conv_dims],
                                )
                            })
                            .transpose()?,
                        (!request.state.is_empty())
                            .then(|| {
                                Array::from_f32(
                                    &request.state,
                                    &[1, value_heads, value_dims, key_dims],
                                )
                            })
                            .transpose()?,
                    )?;
                    let output = if request.op == "mlx-qwen-gdn-sequence" {
                        anyhow::ensure!(
                            hidden > 0
                                && !request.x.is_empty()
                                && request.x.len().is_multiple_of(hidden as usize),
                            "invalid Qwen sequence rows"
                        );
                        let mut rows = Vec::new();
                        for row in request.x.chunks_exact(hidden as usize) {
                            let output =
                                block.forward(&Array::from_f16_bits(row, &[1, 1, hidden])?)?;
                            output.eval()?;
                            let (conv, state) = block.states()?;
                            conv.eval()?;
                            state.eval()?;
                            rows.push(output);
                        }
                        Array::concatenate(&rows.iter().collect::<Vec<_>>(), 1)?
                    } else {
                        block.forward(&Array::from_f16_bits(&request.x, &[1, 1, hidden])?)?
                    };
                    let (conv, recurrent) = block.states()?;
                    Ok(json!({
                        "output": output.to_f16_bits()?,
                        "conv_state": conv.to_f16_bits()?,
                        "state": recurrent.to_f32()?,
                    }))
                }
                #[cfg(feature = "mlx")]
                "mlx-qwen-layer" => {
                    use mlxl3_native::{array::Array, checkpoint, qwen35::LinearLayer};
                    let checkpoint = checkpoint::inspect(std::path::Path::new(&request.path))?;
                    let hidden = i32::try_from(request.cols)?;
                    let key_heads = i32::try_from(request.key_heads)?;
                    let value_heads = i32::try_from(request.value_heads)?;
                    let value_dims = i32::try_from(request.value_dims)?;
                    let conv_length = i32::try_from(request.conv_length)?;
                    let conv_dims = 2 * key_heads * 128 + value_heads * value_dims;
                    let mut layer = LinearLayer::load(
                        &checkpoint,
                        request.layer,
                        hidden,
                        key_heads,
                        value_heads,
                        128,
                        value_dims,
                        conv_length,
                        512,
                        256,
                        request.top_k,
                        1e-6,
                    )?;
                    layer.set_state(
                        (!request.conv_state.is_empty())
                            .then(|| {
                                Array::from_f16_bits(
                                    &request.conv_state,
                                    &[1, conv_length - 1, conv_dims],
                                )
                            })
                            .transpose()?,
                        (!request.state.is_empty())
                            .then(|| {
                                Array::from_f32(&request.state, &[1, value_heads, value_dims, 128])
                            })
                            .transpose()?,
                    )?;
                    let (output, trace) =
                        layer.trace(&Array::from_f16_bits(&request.x, &[1, 1, hidden])?)?;
                    let (conv, recurrent) = layer.states()?;
                    Ok(json!({
                        "output": output.to_f16_bits()?,
                        "trace": trace.iter().map(Array::to_f16_bits).collect::<Result<Vec<_>>>()?,
                        "conv_state": conv.to_f16_bits()?,
                        "state": recurrent.to_f32()?,
                    }))
                }
                #[cfg(feature = "mlx")]
                "mlx-qwen-attn-layer" => {
                    use mlxl3_native::{array::Array, checkpoint, qwen35::AttentionLayer};
                    let checkpoint = checkpoint::inspect(std::path::Path::new(&request.path))?;
                    let hidden = i32::try_from(request.cols)?;
                    let heads = i32::try_from(request.key_heads)?;
                    let kv_heads = i32::try_from(request.value_heads)?;
                    let head_dim = i32::try_from(request.value_dims)?;
                    anyhow::ensure!(
                        request.keys.len() == request.values.len(),
                        "KV cache lengths differ"
                    );
                    let cache_tokens = if request.keys.is_empty() {
                        0
                    } else {
                        i32::try_from(request.keys.len())?
                            .checked_div(kv_heads * head_dim)
                            .context("invalid KV cache size")?
                    };
                    let mut layer = AttentionLayer::load(
                        &checkpoint,
                        request.layer,
                        hidden,
                        heads,
                        kv_heads,
                        head_dim,
                        64,
                        10_000_000.,
                        512,
                        256,
                        request.top_k,
                        1e-6,
                    )?;
                    layer.set_state(
                        (!request.keys.is_empty())
                            .then(|| {
                                Array::from_f16_bits(
                                    &request.keys,
                                    &[1, kv_heads, cache_tokens, head_dim],
                                )
                            })
                            .transpose()?,
                        (!request.values.is_empty())
                            .then(|| {
                                Array::from_f16_bits(
                                    &request.values,
                                    &[1, kv_heads, cache_tokens, head_dim],
                                )
                            })
                            .transpose()?,
                    )?;
                    let output =
                        layer.forward(&Array::from_f16_bits(&request.x, &[1, 1, hidden])?)?;
                    let (keys, values) = layer.states()?;
                    Ok(json!({
                        "output": output.to_f16_bits()?,
                        "keys": keys.to_f16_bits()?,
                        "values": values.to_f16_bits()?,
                    }))
                }
                #[cfg(feature = "mlx")]
                "mlx-qwen-model" => {
                    use mlxl3_native::qwen35::Qwen35Moe;
                    let mut model = Qwen35Moe::load(std::path::Path::new(&request.path))?;
                    let tokens = if request.tokens.is_empty() {
                        vec![request.token]
                    } else {
                        request.tokens
                    };
                    Ok(json!(
                        tokens
                            .into_iter()
                            .map(|token| model.forward(token)?.to_f16_bits())
                            .collect::<Result<Vec<_>>>()?
                    ))
                }
                #[cfg(feature = "mlx")]
                "mlx-qwen-trace" => {
                    use mlxl3_native::qwen35::Qwen35Moe;
                    let mut model = Qwen35Moe::load(std::path::Path::new(&request.path))?;
                    let (logits, layers) = model.trace(request.token)?;
                    Ok(json!({ "layers": layers, "logits": logits.to_f16_bits()? }))
                }
                #[cfg(all(target_os = "macos", feature = "direct-metal"))]
                "metal-pack"
                | "metal-decode"
                | "metal-qmv"
                | "metal-prepare128"
                | "metal-checkpoint-linear"
                | "metal-exl3-linear"
                | "metal-qwen-gdn"
                | "metal-checkpoint-switch"
                | "metal-checkpoint-group"
                | "metal-checkpoint-expert"
                | "metal-swiglu"
                | "metal-prepare-view"
                | "metal-router"
                | "metal-checkpoint-router"
                | "metal-checkpoint-moe"
                | "metal-checkpoint-hc"
                | "metal-checkpoint-mlp"
                | "metal-checkpoint-qsa-layer"
                | "metal-checkpoint-qsa"
                | "metal-checkpoint-gdn"
                | "metal-checkpoint-gdn-layer"
                | "metal-checkpoint-ple"
                | "metal-checkpoint-ple-layer" => {
                    if gpu.is_none() {
                        gpu = Some(mlxl3_native::gpu::Metal::new()?);
                    }
                    let gpu = gpu.as_ref().context("Metal is unavailable")?;
                    match request.op.as_str() {
                        "metal-checkpoint-ple" | "metal-checkpoint-ple-layer" => {
                            let input = request.input_view(gpu)?;
                            let [rows, width] = input.shape();
                            anyhow::ensure!(
                                (1..=16).contains(&rows)
                                    && width == 10240
                                    && request.token_ids.len() == rows as usize
                                    && request.token_ids.iter().all(|&id| id < 248320),
                                "invalid PLE tokens or streams"
                            );
                            let c = checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let eps = flash_checkpoint_epsilon(&c)?;
                            let mut out = Vec::new();
                            if request.op.ends_with("-layer") {
                                let mut block = mlxl3_native::gpu::FlashPleLayer::load(
                                    gpu,
                                    &c,
                                    &request.prefix,
                                    eps,
                                    request.slots.unwrap_or(10),
                                )?;
                                for (i, &t) in request.token_ids.iter().enumerate() {
                                    out.push(json!(
                                        block.forward(&input.row(i as u32)?, t)?.read_output()?
                                    ));
                                }
                            } else {
                                let mut ple = mlxl3_native::gpu::FlashPle::load(
                                    gpu,
                                    &c,
                                    &request.prefix,
                                    eps,
                                )?;
                                for (i, &t) in request.token_ids.iter().enumerate() {
                                    let r =
                                        ple.forward(&input.row(i as u32)?, t, request.return_raw)?;
                                    out.push(json!({"values":r.values.read_output()?,"trace":r.trace,"read_bytes":r.read_bytes}));
                                }
                            }
                            Ok(json!(out))
                        }
                        "metal-checkpoint-qsa" | "metal-checkpoint-qsa-layer" => {
                            let input = request.input_view(gpu)?;
                            let [rows, width] = input.shape();
                            anyhow::ensure!(
                                (1..=512).contains(&rows)
                                    && width
                                        == if request.op.ends_with("-layer") {
                                            10240
                                        } else {
                                            2560
                                        },
                                "invalid Flash QSA rows"
                            );
                            let c = checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let config: serde_json::Value = serde_json::from_reader(
                                std::fs::File::open(c.path.join("config.json"))?,
                            )?;
                            let theta = config["text_config"]["rope_parameters"]["rope_theta"]
                                .as_f64()
                                .context("missing Flash RoPE")?
                                as f32;
                            if request.op.ends_with("-layer") {
                                let mut layer = mlxl3_native::gpu::FlashQsaLayer::load(
                                    gpu,
                                    &c,
                                    &request.prefix,
                                    flash_checkpoint_epsilon(&c)?,
                                    theta,
                                    rows,
                                    request.slots.unwrap_or(10),
                                )?;
                                return (0..rows)
                                    .map(|r| {
                                        Ok(json!(layer.forward(&input.row(r)?)?.read_output()?))
                                    })
                                    .collect::<Result<Vec<_>>>()
                                    .map(|v| json!(v));
                            }
                            let mut a = mlxl3_native::gpu::FlashQsa::load(
                                gpu,
                                &c,
                                &request.prefix,
                                flash_checkpoint_epsilon(&c)?,
                                theta,
                                rows,
                            )?;
                            let mut result = Vec::new();
                            for r in 0..rows {
                                let row = a.forward(&input.row(r)?, request.return_raw)?;
                                result.push(
                                    json!({"values":row.values.read_output()?,"trace":row.trace}),
                                );
                            }
                            Ok(json!(result))
                        }
                        "metal-checkpoint-gdn" | "metal-checkpoint-gdn-layer" => {
                            let input = request.input_view(gpu)?;
                            let [rows, width] = input.shape();
                            let full = request.op.ends_with("-layer");
                            anyhow::ensure!(
                                (1..=8).contains(&rows) && width == if full { 10240 } else { 2560 },
                                "invalid Flash GDN row count or width"
                            );
                            let checkpoint =
                                checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let eps = flash_checkpoint_epsilon(&checkpoint)?;
                            let mut result = Vec::new();
                            if full {
                                let mut layer = mlxl3_native::gpu::FlashGdnLayer::load(
                                    gpu,
                                    &checkpoint,
                                    &request.prefix,
                                    eps,
                                    request.slots.unwrap_or(10),
                                )?;
                                for r in 0..rows {
                                    result
                                        .push(json!(layer.forward(&input.row(r)?)?.read_output()?));
                                }
                            } else {
                                let mut layer = mlxl3_native::gpu::FlashGdn::load(
                                    gpu,
                                    &checkpoint,
                                    &request.prefix,
                                    eps,
                                )?;
                                for r in 0..rows {
                                    let row = layer.forward(&input.row(r)?, request.return_raw)?;
                                    result.push(json!({"values":row.values.read_output()?,"trace":row.trace}));
                                }
                            }
                            Ok(json!(result))
                        }
                        "metal-checkpoint-hc" | "metal-checkpoint-mlp" => {
                            let streams = request.input_view(gpu)?;
                            anyhow::ensure!(
                                streams.shape() == [1, 10240],
                                "expected one Flash row of four streams"
                            );
                            let path = std::path::Path::new(&request.path);
                            let checkpoint = checkpoint::inspect(path)?;
                            let eps = flash_checkpoint_epsilon(&checkpoint)?;
                            let mlp = request.op == "metal-checkpoint-mlp";
                            let prefix = if mlp {
                                format!("{}.mlp_hyper_connection", request.prefix)
                            } else {
                                request.prefix.clone()
                            };
                            let hc = mlxl3_native::gpu::FlashHc::load(
                                gpu,
                                &checkpoint,
                                &prefix,
                                eps,
                                !prefix.ends_with(".hyper_connection_mixer"),
                            )?;
                            let (read, output, route) = if mlp {
                                let mut experts = mlxl3_native::gpu::FlashMoeRow::load(
                                    gpu,
                                    &checkpoint,
                                    &format!("{}.mlp", request.prefix),
                                    request.slots.unwrap_or(10),
                                )?;
                                let (out, route, read) =
                                    hc.forward_moe(&streams, &mut experts, request.return_raw)?;
                                (read, Some(out.read_output()?), Some(route.indices))
                            } else {
                                (hc.read(&streams, request.return_raw)?, None, None)
                            };
                            Ok(
                                json!({"mixed":read.mixed.read_output()?,"gate":read.gate.as_ref().map(|g|g.read_output()).transpose()?,"output":output,"indices":route,"trace":read.trace}),
                            )
                        }
                        "metal-checkpoint-moe" => {
                            let input = request.input_view(gpu)?;
                            let [rows, width] = input.shape();
                            anyhow::ensure!(
                                (1..=8).contains(&rows) && width == 2560,
                                "expected one to eight Flash AR rows"
                            );
                            let checkpoint =
                                checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let mut layer = mlxl3_native::gpu::FlashMoeRow::load(
                                gpu,
                                &checkpoint,
                                &request.prefix,
                                request.slots.unwrap_or(10),
                            )?;
                            let mut results = Vec::new();
                            for r in 0..rows {
                                let x = input.row(r)?;
                                let out = if request.return_raw {
                                    layer.trace(&x)?
                                } else {
                                    layer.submit(&x)?
                                };
                                results.push(json!({"indices":out.indices,"hits":out.hits,"read_bytes":out.read_bytes,"values":out.read()?,"switch":out.multiplier_trace()?}));
                            }
                            Ok(json!(results))
                        }
                        "metal-checkpoint-group" => {
                            let c = checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let layer = mlxl3_native::gpu::ProjectionGroup::load(
                                gpu,
                                &c,
                                &request.prefixes,
                            )?;
                            let input = if request.x_layout.is_some() {
                                request.input_view(gpu)?
                            } else {
                                anyhow::ensure!(
                                    request.x.len() == layer.input_width() as usize,
                                    "invalid grouped input row length"
                                );
                                gpu.f16_storage(&request.x)?.matrix(
                                    mlxl3_native::tensor_layout::MatrixLayout {
                                        shape: [1, layer.input_width()],
                                        strides: [i64::from(layer.input_width()), 1],
                                        offset: 0,
                                    },
                                )?
                            };
                            let outputs = layer
                                .forward(&input)?
                                .iter()
                                .map(|v| v.read_output())
                                .collect::<Result<Vec<_>>>()?;
                            Ok(json!({"grouped":layer.is_grouped(),"outputs":outputs}))
                        }
                        "metal-checkpoint-switch" => {
                            let c = checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let names = if c.model_type == "lfm2_moe" {
                                ["w1", "w3", "w2"]
                            } else {
                                ["gate_proj", "up_proj", "down_proj"]
                            };
                            let layer = mlxl3_native::gpu::MappedSwitchGlu::load(
                                gpu,
                                &c,
                                &request.prefix,
                                u32::try_from(request.key_heads)?,
                                u32::try_from(request.selected.len())?,
                                names,
                            )?;
                            anyhow::ensure!(
                                request.x.len() == layer.hidden_size() as usize,
                                "invalid mapped input row length"
                            );
                            let input = gpu.f16_storage(&request.x)?.matrix(
                                mlxl3_native::tensor_layout::MatrixLayout {
                                    shape: [1, layer.hidden_size()],
                                    strides: [i64::from(layer.hidden_size()), 1],
                                    offset: 0,
                                },
                            )?;
                            let count = u32::try_from(request.beta.len())?;
                            let scores = gpu.f16_storage(&request.beta)?.matrix(
                                mlxl3_native::tensor_layout::MatrixLayout {
                                    shape: [1, count],
                                    strides: [i64::from(count), 1],
                                    offset: 0,
                                },
                            )?;
                            Ok(json!(
                                layer
                                    .forward(&input, &request.selected, &scores)?
                                    .read_output()?
                            ))
                        }
                        "metal-qwen-gdn" => {
                            let c = checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let mut layer = mlxl3_native::gpu::QwenGdn::from_checkpoint(
                                gpu,
                                &c,
                                &request.prefix,
                            )?;
                            let width = layer.hidden_size();
                            anyhow::ensure!(
                                !request.x.is_empty()
                                    && request.x.len().is_multiple_of(width as usize),
                                "invalid Qwen GDN input rows"
                            );
                            let mut output = Vec::new();
                            for row in request.x.chunks_exact(width as usize) {
                                let input = gpu.f16_storage(row)?.matrix(
                                    mlxl3_native::tensor_layout::MatrixLayout {
                                        shape: [1, width],
                                        strides: [i64::from(width), 1],
                                        offset: 0,
                                    },
                                )?;
                                output.extend(layer.forward(&input)?.read_output()?);
                            }
                            let states = layer.states()?.context("missing Qwen GDN state")?;
                            Ok(
                                json!({"output":output,"conv_state":states.conv_state,"state":states.state}),
                            )
                        }
                        "metal-checkpoint-router" => {
                            let input = request.input_view(gpu)?;
                            let checkpoint =
                                checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let gate = mlxl3_native::gpu::FlashGate::load(
                                gpu,
                                &checkpoint,
                                &request.prefix,
                            )?;
                            if request.return_raw {
                                Ok(json!(gate.trace(&input)?))
                            } else {
                                let (indices, scores) = gate.submit(&input)?.read()?;
                                Ok(json!({"indices":indices,"scores":scores}))
                            }
                        }
                        "metal-router" => {
                            let input = request.input_view(gpu)?;
                            let (indices, scores) = gpu
                                .route(&input, u32::try_from(request.k)?, request.normalize)?
                                .read()?;
                            Ok(json!({"indices":indices,"scores":scores}))
                        }
                        "metal-prepare-view" => {
                            let x = request.input_view(gpu)?;
                            let scales = gpu.f16_storage(&request.data)?.matrix(
                                request
                                    .scale_layout
                                    .context("missing scale matrix layout")?,
                            )?;
                            Ok(json!(gpu.prepare_view(&x, &scales)?))
                        }
                        "metal-swiglu" => Ok(json!(gpu.swiglu(&request.x, &request.data)?.read()?)),
                        "metal-checkpoint-linear"
                        | "metal-checkpoint-expert"
                        | "metal-exl3-linear" => {
                            let checkpoint =
                                checkpoint::inspect(std::path::Path::new(&request.path))?;
                            let view = if request.x_layout.is_some() || request.x_f32.is_some() {
                                Some(request.input_view(gpu)?)
                            } else {
                                None
                            };
                            let flight = if request.op == "metal-checkpoint-expert" {
                                let expert = mlxl3_native::gpu::FlashExpert::load(
                                    gpu,
                                    &checkpoint,
                                    &request.prefix,
                                )?;
                                match &view {
                                    Some(x) => expert.submit_fp16_view(x)?,
                                    None => expert.submit(&request.x)?,
                                }
                            } else {
                                let load = if request.op == "metal-exl3-linear" {
                                    mlxl3_native::gpu::FlashProjection::load_exl3
                                } else {
                                    mlxl3_native::gpu::FlashProjection::load
                                };
                                let layer = load(gpu, &checkpoint, &request.prefix)?;
                                match &view {
                                    Some(x) => layer.submit_fp16_view(x)?,
                                    None => layer.submit(&request.x)?,
                                }
                            };
                            Ok(json!(flight.read()?))
                        }
                        "metal-prepare128" => Ok(json!(gpu.prepare128(
                            &request.x,
                            request.cols,
                            &request.data
                        )?)),
                        "metal-pack" => Ok(json!(gpu.pack(&request.data, request.k)?)),
                        "metal-decode" => {
                            let (states, values) = gpu.decode(&request.data, request.k, cb)?;
                            Ok(json!({ "states": states, "values": values }))
                        }
                        _ => Ok(json!(gpu.qmv_inner(
                            &request.x,
                            &request.data,
                            request.cols,
                            request.k,
                            cb
                        )?)),
                    }
                }
                _ => bail!("unknown or unavailable codec operation {}", request.op),
            }
        })();
        let value = match result {
            Ok(data) => json!({"data": data}),
            Err(e) => json!({"error": format!("{e:#}")}),
        };
        serde_json::to_writer(&mut output, &value)?;
        writeln!(output)?;
        output.flush()?;
    }
    Ok(())
}

fn main() -> std::process::ExitCode {
    if let Err(error) = run(Cli::parse()) {
        eprintln!("Error: {error:#}");
        std::process::ExitCode::from(2)
    } else {
        std::process::ExitCode::SUCCESS
    }
}

fn run(cli: Cli) -> Result<()> {
    match cli.command {
        Command::QuantizeTiles {
            input,
            output,
            k,
            codebook,
            max_scratch_bytes,
        } => {
            #[cfg(all(target_os = "macos", feature = "direct-metal"))]
            mlxl3_native::quantize::run_tiles(&input, &output, k, codebook, max_scratch_bytes)?;
            #[cfg(not(all(target_os = "macos", feature = "direct-metal")))]
            {
                let _ = (input, output, k, codebook, max_scratch_bytes);
                bail!("tile quantization requires native Metal on macOS");
            }
        }
        Command::ConvertMatmul {
            left,
            right,
            output,
            m,
            n,
            k,
            full_fp32,
        } => {
            #[cfg(all(target_os = "macos", feature = "direct-metal"))]
            mlxl3_native::convert_matmul::run(&left, &right, &output, m, n, k, full_fp32)?;
            #[cfg(not(all(target_os = "macos", feature = "direct-metal")))]
            {
                let _ = (left, right, output, m, n, k, full_fp32);
                bail!("converter matrix multiplication requires native Metal on macOS");
            }
        }
        Command::RuntimeInfo => {
            println!(
                "{}",
                json!({
                    "version": env!("CARGO_PKG_VERSION"),
                    "bridge_protocol": 1,
                    "architecture": std::env::consts::ARCH,
                    "mlx_enabled": cfg!(feature = "mlx"),
                    "backend": if cfg!(feature = "mlx") { "mlx" } else if cfg!(all(target_os = "macos", feature = "direct-metal")) { "metal" } else { "cpu" },
                    "chat_enabled": cfg!(feature = "chat"),
                    "commit": env!("MLXL3_BUILD_REVISION"),
                    "profile": env!("MLXL3_BUILD_PROFILE")
                })
            );
        }
        Command::List { json: as_json } => {
            let path = cli
                .registry
                .map(Ok)
                .unwrap_or_else(registry::default_path)?;
            let entries = registry::load(&path)?;
            let mut models = Vec::new();
            for (name, entry) in entries {
                let mut value = serde_json::to_value(&entry)?;
                value["name"] = json!(name);
                value["size"] = json!(human_size(entry.size_bytes));
                models.push(value);
            }
            models.sort_by_key(|v| v["name"].as_str().unwrap_or("").to_lowercase());
            if as_json {
                println!("{}", serde_json::to_string(&models)?);
            } else {
                println!("NAME\tFORMAT\tBPW\tSIZE\tMODEL TYPE\tPATH");
                for value in models {
                    println!(
                        "{}\t{}\t{}\t{}\t{}\t{}",
                        value["name"].as_str().unwrap(),
                        value["format"].as_str().unwrap(),
                        value["bits"],
                        value["size"].as_str().unwrap(),
                        value["model_type"].as_str().unwrap(),
                        value["path"].as_str().unwrap()
                    );
                }
            }
        }
        Command::Inspect { path } => println!(
            "{}",
            serde_json::to_string_pretty(&checkpoint::inspect(&registry::expand_home(&path)?)?)?
        ),
        Command::Register { name, path, force } => {
            let registry_path = cli
                .registry
                .map(Ok)
                .unwrap_or_else(registry::default_path)?;
            let entry = registry::register(&registry_path, &name, &path, force)?;
            println!("Registered {name} ({})", human_size(entry.size_bytes));
        }
        Command::Remove {
            name,
            expected_path,
        } => {
            let path = cli
                .registry
                .map(Ok)
                .unwrap_or_else(registry::default_path)?;
            registry::remove(&path, &name, expected_path.as_deref())?;
            println!("Removed {name} from registry; model files retained.");
        }
        Command::Codec => codec_loop()?,
        Command::Split { prompt } => {
            let chunks: Vec<String> = serde_json::from_reader(io::stdin().lock())?;
            let mut splitter = ThinkingSplitter::new(&prompt);
            let mut result = Vec::new();
            for chunk in chunks {
                result.extend(splitter.feed(&chunk));
            }
            result.extend(splitter.finish());
            println!("{}", serde_json::to_string(&result)?);
        }
        #[cfg(all(
            not(feature = "mlx"),
            feature = "chat",
            target_os = "macos",
            feature = "direct-metal"
        ))]
        Command::Forward {
            model,
            tokens,
            states,
            batch,
        } => {
            anyhow::ensure!(
                !tokens.is_empty()
                    && tokens.len() <= mlxl3_native::flash_support::FLASH_MAX_CONTEXT as usize
                    && tokens.iter().all(|&t| t < 248320),
                "invalid native Flash tokens or context"
            );
            let gpu = mlxl3_native::gpu::Metal::new()?;
            let c = checkpoint::inspect(&model)?;
            let mut target = mlxl3_native::gpu::FlashNext::load(&gpu, &c, tokens.len() as u32)?;
            target.admit_request(tokens.len())?;
            let mut out = io::stdout().lock();
            #[derive(serde::Serialize)]
            struct Row {
                token: u32,
                logits: Vec<u16>,
                states: Vec<mlxl3_native::gpu::FlashTraceTensor>,
            }
            let mut emit = |row: Row| -> Result<()> {
                serde_json::to_writer(&mut out, &row)?;
                writeln!(out)?;
                out.flush()?;
                Ok(())
            };
            if batch {
                emit(Row {
                    token: *tokens.last().context("empty Flash input")?,
                    logits: target.prefill(&tokens)?,
                    states: Vec::new(),
                })?;
            } else {
                for token in tokens {
                    let (logits, trace) = if states {
                        target.forward_trace(token)?
                    } else {
                        (target.forward(token)?, Vec::new())
                    };
                    emit(Row {
                        token,
                        logits,
                        states: trace,
                    })?;
                }
            }
        }
        #[cfg(all(feature = "mlx", feature = "chat"))]
        Command::Forward {
            model,
            tokens,
            states,
            batch,
        } => {
            let mut model = NativeChatModel::load(&model)?;
            let mut out = io::stdout().lock();
            if batch {
                let token = *tokens.last().context("empty token batch")?;
                let logits = match &mut model {
                    NativeChatModel::Ling(model) => model.forward_tokens(&tokens)?,
                    _ => model.forward_many(&tokens)?,
                };
                let arrays = match (&model, states) {
                    (NativeChatModel::Lfm2(model), true) => model
                        .state_arrays()
                        .into_iter()
                        .map(|(name, array)| Ok((name, array.try_clone()?)))
                        .collect::<Result<Vec<_>>>()?,
                    _ => Vec::new(),
                };
                let state = arrays
                    .into_iter()
                    .map(|(name, array)| -> Result<_> {
                        Ok(json!({"name": name, "shape": array.shape(), "data": array.to_bytes()?}))
                    })
                    .collect::<Result<Vec<_>>>()?;
                serde_json::to_writer(
                    &mut out,
                    &json!({"token":token,"logits":logits.to_f16_bits()?,"states":state}),
                )?;
                writeln!(out)?;
                out.flush()?;
                return Ok(());
            }
            for token in tokens {
                let (logits, arrays) = match (&mut model, states) {
                    (NativeChatModel::Flash(model), true) => model.forward_trace(token)?,
                    (NativeChatModel::Gemma4(model), true) => model.forward_trace(token)?,
                    (NativeChatModel::Lfm2(model), true) => {
                        let logits = model.forward(&[token])?;
                        let arrays = model
                            .state_arrays()
                            .into_iter()
                            .map(|(name, array)| Ok((name, array.try_clone()?)))
                            .collect::<Result<Vec<_>>>()?;
                        (logits, arrays)
                    }
                    (NativeChatModel::Ling(model), true) => {
                        let logits = model.forward(token)?;
                        let arrays = model
                            .state_arrays()
                            .into_iter()
                            .map(|(name, array)| Ok((name, array.try_clone()?)))
                            .collect::<Result<Vec<_>>>()?;
                        (logits, arrays)
                    }
                    _ => (model.forward(token)?, Vec::new()),
                };
                let state = arrays
                    .into_iter()
                    .map(|(name, array)| -> Result<_> {
                        Ok(json!({"name": name, "shape": array.shape(), "data": array.to_bytes()?}))
                    })
                    .collect::<Result<Vec<_>>>()?;
                serde_json::to_writer(
                    &mut out,
                    &json!({"token":token,"logits":logits.to_f16_bits()?,"states":state}),
                )?;
                writeln!(out)?;
                out.flush()?;
            }
        }
        Command::Run {
            model,
            prompt,
            max_tokens,
        } => {
            #[cfg(all(
                feature = "chat",
                any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
            ))]
            {
                let model_path = resolve_model_path(cli.registry.as_deref(), &model)?;
                native_chat(&model_path, prompt, max_tokens)?;
            }
            #[cfg(not(all(
                feature = "chat",
                any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
            )))]
            {
                let _ = (prompt, max_tokens);
                bail!(
                    "native execution for {model:?} requires a build with --features mlx,chat; the installed app is separate"
                );
            }
        }
        Command::Bridge {
            model,
            context_length,
        } => {
            #[cfg(all(feature = "mlx", feature = "chat"))]
            native_bridge(cli.registry.as_deref(), &model, context_length)?;
            #[cfg(all(
                not(feature = "mlx"),
                feature = "chat",
                target_os = "macos",
                feature = "direct-metal"
            ))]
            direct_bridge::run(cli.registry.as_deref(), &model, context_length)?;
            #[cfg(not(all(
                feature = "chat",
                any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
            )))]
            {
                let _ = (model, context_length);
                bail!("the Desktop bridge requires chat and an inference backend");
            }
        }
        Command::Serve {
            model,
            host,
            port,
            api_key,
            context_length,
        } => {
            #[cfg(all(
                feature = "chat",
                any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
            ))]
            {
                let runtime = tokio::runtime::Builder::new_multi_thread()
                    .enable_all()
                    .build()?;
                runtime.block_on(openai::serve(
                    cli.registry.as_deref(),
                    &model,
                    &host,
                    port,
                    &api_key,
                    context_length,
                ))?;
            }
            #[cfg(not(all(
                feature = "chat",
                any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
            )))]
            {
                let _ = (model, host, port, api_key, context_length);
                bail!("the OpenAI API requires chat and an inference backend");
            }
        }
        Command::Hub {
            action,
            query,
            revision,
            folder,
            limit,
        } => {
            let registry_path = cli
                .registry
                .map(Ok)
                .unwrap_or_else(registry::default_path)?;
            let progress = |completed, total| {
                println!(
                    "{}",
                    json!({"type":"progress", "completed":completed, "total":total})
                );
                let _ = io::stdout().flush();
            };
            match action {
                HubAction::Search => println!(
                    "{}",
                    serde_json::to_string(&mlxl3_native::hub::search(&query, limit)?)?
                ),
                HubAction::Details => println!(
                    "{}",
                    serde_json::to_string(&mlxl3_native::hub::details(
                        &query,
                        revision.as_deref()
                    )?)?
                ),
                HubAction::Download => {
                    let (name, entry) = mlxl3_native::hub::download(
                        &query,
                        revision.as_deref().context("--revision is required")?,
                        &folder,
                        &registry_path,
                        progress,
                    )?;
                    println!(
                        "{}",
                        json!({"type":"installed", "model":model_payload(&name, &entry)?})
                    );
                }
                HubAction::Pending => println!(
                    "{}",
                    serde_json::to_string(&mlxl3_native::hub::pending_downloads()?)?
                ),
                HubAction::Resume => {
                    let (name, entry) =
                        mlxl3_native::hub::resume(&query, &registry_path, progress)?;
                    println!(
                        "{}",
                        json!({"type":"installed", "model":model_payload(&name, &entry)?})
                    );
                }
                HubAction::Discard => {
                    mlxl3_native::hub::discard(&query)?;
                    println!("{{}}");
                }
                HubAction::Auth => {
                    match query.as_str() {
                        "login" => {
                            let mut token = String::new();
                            io::stdin().take(4096).read_to_string(&mut token)?;
                            mlxl3_native::hub::login(token.trim())?;
                        }
                        "logout" => mlxl3_native::hub::logout()?,
                        _ => bail!("expected login or logout"),
                    }
                    println!("{{}}");
                }
            }
        }
        Command::DflashDraft { inspect, target } => {
            use mlxl3_native::dflash::{Family, ManagedDraft};
            let expected = target
                .as_deref()
                .map(ManagedDraft::from_target)
                .transpose()?;
            let path = if let Some(path) = inspect {
                if let Some(expected) = expected {
                    expected.inspect(&path)?
                } else {
                    mlxl3_native::dflash::inspect(path)?.directory
                }
            } else {
                let progress = |completed, total| {
                    println!(
                        "{}",
                        json!({"type":"progress", "completed":completed, "total":total})
                    );
                    let _ = io::stdout().flush();
                };
                match expected.unwrap_or(ManagedDraft::Packed(Family::Qwen36Moe)) {
                    ManagedDraft::Packed(family) => {
                        mlxl3_native::hub::download_dflash(family, progress)?
                    }
                    ManagedDraft::FlashNext => mlxl3_native::hub::download_flash_dflash(progress)?,
                }
            };
            println!("{}", json!({"type":"installed", "path":path}));
        }
        Command::MtpHead { inspect, target } => {
            let target = target
                .as_deref()
                .map(mlxl3_native::mtp::target_layout)
                .transpose()?;
            let path = if let Some(path) = inspect {
                let (checkpoint, layout) = mlxl3_native::mtp::inspect(&path)?;
                if let Some((expected, _)) = &target {
                    anyhow::ensure!(
                        &layout == expected,
                        "MTP head does not match the target model dimensions"
                    );
                }
                checkpoint.path
            } else {
                let kind = if let Some((layout, layers)) = &target {
                    layout
                        .managed_head(*layers)
                        .context("No managed MTP head for this target")?
                } else {
                    mlxl3_native::mtp::ManagedHead::Qwen36Moe
                };
                mlxl3_native::hub::download_mtp(kind, |completed, total| {
                    println!(
                        "{}",
                        json!({"type":"progress", "completed":completed, "total":total})
                    );
                    let _ = io::stdout().flush();
                })?
            };
            println!("{}", json!({"type":"installed", "path":path}));
        }
        Command::Mcp { action } => {
            let registry_path = cli
                .registry
                .map(Ok)
                .unwrap_or_else(registry::default_path)?;
            match action {
                McpAction::List { json: as_json } => {
                    let servers = mlxl3_native::mcp::list_servers(&registry_path)?;
                    if as_json {
                        println!("{}", serde_json::to_string(&servers)?);
                    } else {
                        for (name, server) in servers {
                            println!(
                                "{name}\t{}\t{}",
                                if server.enabled {
                                    "enabled"
                                } else {
                                    "disabled"
                                },
                                server.url.as_deref().unwrap_or(&server.command)
                            );
                        }
                    }
                }
                McpAction::Check { json: as_json } => {
                    let mut manager = mlxl3_native::mcp::Manager::disabled();
                    manager.set_enabled(&registry_path, true, true);
                    let result = json!({
                        "servers":manager.server_count(),
                        "tools":manager.chat_tools(),
                        "errors":manager.errors,
                    });
                    if as_json {
                        println!("{result}");
                    } else {
                        println!(
                            "{} server(s), {} tool(s)",
                            manager.server_count(),
                            manager.tools.len()
                        );
                        for name in manager.tools.keys() {
                            println!("- {name}");
                        }
                        for (name, error) in &manager.errors {
                            eprintln!("{name}: {error}");
                        }
                    }
                }
                McpAction::Config => println!(
                    "{}",
                    mlxl3_native::mcp::config_path(&registry_path).display()
                ),
                McpAction::Add {
                    name,
                    command,
                    args,
                } => {
                    mlxl3_native::mcp::add_server(&registry_path, &name, &command, args)?;
                    println!("Added {name}");
                }
                McpAction::Remove { name } => {
                    mlxl3_native::mcp::remove_server(&registry_path, &name)?;
                    println!("Removed {name}");
                }
            }
        }
    }
    Ok(())
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn resolve_model_path(registry_path: Option<&std::path::Path>, model: &str) -> Result<PathBuf> {
    let candidate = registry::expand_home(&PathBuf::from(model))?;
    if candidate.is_dir() {
        return Ok(candidate);
    }
    let path = registry_path
        .map(PathBuf::from)
        .map(Ok)
        .unwrap_or_else(registry::default_path)?;
    Ok(PathBuf::from(
        &registry::load(&path)?
            .get(model)
            .context("unknown registered model")?
            .path,
    ))
}

fn human_size(size: u64) -> String {
    let mut value = size as f64;
    for unit in ["B", "KB", "MB", "GB", "TB"] {
        if value < 1000.0 || unit == "TB" {
            return if unit == "B" {
                format!("{size} B")
            } else {
                format!("{value:.1} {unit}")
            };
        }
        value /= 1000.0;
    }
    unreachable!()
}

fn model_payload(name: &str, entry: &registry::ModelEntry) -> Result<Value> {
    let mut value = serde_json::to_value(entry)?;
    value["name"] = json!(name);
    value["size"] = json!(human_size(entry.size_bytes));
    Ok(value)
}

#[cfg(all(feature = "mlx", feature = "chat"))]
enum NativeChatModel {
    Gemma4(mlxl3_native::gemma4::Gemma4),
    Lfm2(mlxl3_native::lfm2::Lfm2),
    Ling(mlxl3_native::ling::Ling),
    Qwen(mlxl3_native::qwen35::Qwen35Moe),
    Flash(Box<mlxl3_native::qwen4::FlashNext>),
}

#[cfg(all(feature = "mlx", feature = "chat"))]
impl NativeChatModel {
    fn load(path: &std::path::Path) -> Result<Self> {
        let checkpoint = checkpoint::inspect(path)?;
        Self::from_checkpoint(&checkpoint)
    }

    fn from_checkpoint(checkpoint: &checkpoint::Checkpoint) -> Result<Self> {
        match checkpoint.model_type.as_str() {
            "qwen4_exp" => Ok(Self::Flash(Box::new(
                mlxl3_native::qwen4::FlashNext::from_checkpoint(checkpoint)?,
            ))),
            "gemma4" => Ok(Self::Gemma4(mlxl3_native::gemma4::Gemma4::from_checkpoint(
                checkpoint,
            )?)),
            "bailing_hybrid" => Ok(Self::Ling(mlxl3_native::ling::Ling::from_checkpoint(
                checkpoint,
            )?)),
            "lfm2" | "lfm2_moe" => Ok(Self::Lfm2(mlxl3_native::lfm2::Lfm2::from_checkpoint(
                checkpoint,
            )?)),
            "qwen3_5" | "qwen3_5_moe" => Ok(Self::Qwen(
                mlxl3_native::qwen35::Qwen35Moe::from_checkpoint(checkpoint)?,
            )),
            other => bail!("native chat does not support model type {other:?}"),
        }
    }

    fn forward(&mut self, token: u32) -> Result<mlxl3_native::array::Array> {
        match self {
            Self::Gemma4(model) => model.forward(token),
            Self::Lfm2(model) => model.forward(&[token]),
            Self::Ling(model) => model.forward(token),
            Self::Qwen(model) => model.forward(token),
            Self::Flash(model) => model.forward(token),
        }
    }

    fn forward_many(&mut self, tokens: &[u32]) -> Result<mlxl3_native::array::Array> {
        anyhow::ensure!(!tokens.is_empty(), "empty token batch");
        if let Self::Lfm2(model) = self
            && model.uses_moe_exact_prefill()
        {
            let (output, stats) = model.prefill_moe_exact(tokens)?;
            if std::env::var_os("MLXL3_LFM_PREFILL_TRACE").is_some_and(|value| value == "1") {
                eprintln!(
                    "{}",
                    json!({
                        "type": "lfm_prefill_dispatch",
                        "tokens": stats.tokens,
                        "blocks": stats.blocks,
                        "grouped_moe_calls": stats.grouped_moe_calls,
                        "router_rows": stats.router_rows,
                        "max_block": stats.max_block,
                    })
                );
            }
            return Ok(output);
        }
        if tokens.len() >= 24 {
            return match self {
                Self::Gemma4(model) if model.can_batch(tokens.len()) => {
                    model.forward_tokens(tokens)
                }
                Self::Lfm2(model) if model.supports_batched_prefill() => model.forward(tokens),
                Self::Ling(_) => self.forward_many_serial(tokens),
                Self::Qwen(model) => model.forward_tokens(tokens),
                Self::Flash(model) => model.forward_tokens(tokens),
                Self::Gemma4(_) | Self::Lfm2(_) => self.forward_many_serial(tokens),
            };
        }
        self.forward_many_serial(tokens)
    }

    fn forward_many_serial(&mut self, tokens: &[u32]) -> Result<mlxl3_native::array::Array> {
        match self {
            Self::Qwen(model) => return model.prefill_serial(tokens),
            Self::Flash(model) => return model.forward_tokens(tokens),
            Self::Ling(model) => return model.prefill_serial(tokens),
            _ => {}
        }
        let mut output = None;
        for &token in tokens {
            output = Some(self.forward(token)?);
        }
        output.context("empty token batch")
    }

    fn prefill_chunk_size(&self) -> usize {
        match self {
            Self::Gemma4(_) => 256,
            Self::Lfm2(model) if model.supports_batched_prefill() => 256,
            Self::Lfm2(model) if model.uses_moe_exact_prefill() => 8,
            Self::Qwen(_) => 256,
            Self::Flash(_) => mlxl3_native::flash_support::PREFILL_CHUNK,
            Self::Ling(_) => 128,
            Self::Lfm2(_) => 1,
        }
    }

    fn context_limit(&self) -> i32 {
        match self {
            Self::Gemma4(model) => model.context_limit(),
            Self::Lfm2(model) => model.context_limit(),
            Self::Ling(model) => model.context_limit(),
            Self::Qwen(model) => model.context_limit(),
            Self::Flash(model) => model.context_limit(),
        }
    }

    fn reset(&mut self) {
        match self {
            Self::Gemma4(model) => model.reset(),
            Self::Lfm2(model) => model.reset(),
            Self::Ling(model) => model.reset(),
            Self::Qwen(model) => model.reset(),
            Self::Flash(model) => model.reset(),
        }
    }

    fn eval_state(&self) -> Result<()> {
        match self {
            Self::Lfm2(model) => {
                for (_, state) in model.state_arrays() {
                    state.eval()?;
                }
            }
            Self::Gemma4(_) | Self::Ling(_) | Self::Qwen(_) | Self::Flash(_) => {}
        }
        Ok(())
    }

    fn name(&self) -> &'static str {
        match self {
            Self::Gemma4(_) => "Gemma 4",
            Self::Lfm2(_) => "LFM2",
            Self::Ling(_) => "Ling 3",
            Self::Qwen(_) => "Qwen3.5",
            Self::Flash(_) => "Qwen3.8 Flash Next",
        }
    }
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
#[derive(Deserialize)]
struct BridgeRequest {
    #[serde(rename = "type")]
    kind: String,
    #[serde(default)]
    request_id: String,
    #[serde(default)]
    conversation_id: String,
    #[serde(default = "reuse_cache_by_default")]
    reuse_prompt_cache: bool,
    #[serde(default)]
    memory_saver: bool,
    #[serde(default)]
    messages: Vec<Value>,
    #[serde(default = "unlimited_tokens")]
    max_tokens: i64,
    #[serde(default)]
    temperature: f32,
    #[serde(default)]
    top_k: usize,
    #[serde(default = "unit_penalty")]
    repetition_penalty: f32,
    #[serde(default)]
    enabled: bool,
    #[serde(default)]
    mcp_enabled: bool,
    #[serde(default)]
    allowed_tools: Option<Vec<String>>,
    #[serde(default)]
    response_schema: Option<String>,
    #[serde(default)]
    dflash2: bool,
    #[serde(default)]
    dflash_draft_path: String,
    #[serde(default = "default_mtp_depth")]
    dflash_mode: usize,
    #[serde(default)]
    mtp: bool,
    #[serde(default)]
    mtp_head_path: String,
    #[serde(default = "default_mtp_depth")]
    mtp_depth: usize,
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn default_mtp_depth() -> usize {
    1
}

#[cfg(all(feature = "mlx", feature = "chat"))]
enum ChatMtpHead {
    Qwen(Box<mlxl3_native::mtp::Head>),
    Flash(Box<mlxl3_native::qwen4::FlashMtpHead>),
}
#[cfg(all(feature = "mlx", feature = "chat"))]
impl ChatMtpHead {
    fn load(path: &std::path::Path, model: &NativeChatModel) -> Result<Self> {
        match model {
            NativeChatModel::Qwen(target) => Ok(Self::Qwen(Box::new(
                mlxl3_native::mtp::Head::load(path, target)?,
            ))),
            NativeChatModel::Flash(target) => Ok(Self::Flash(Box::new(
                mlxl3_native::qwen4::FlashMtpHead::load(&checkpoint::inspect(path)?, target)?,
            ))),
            _ => bail!("MTP requires a supported Qwen target"),
        }
    }
    fn reset(&mut self) -> Result<()> {
        match self {
            Self::Qwen(head) => head.reset(),
            Self::Flash(head) => {
                head.reset();
                Ok(())
            }
        }
    }
}
#[cfg(all(feature = "mlx", feature = "chat"))]
enum ChatMtpSession {
    Qwen(mlxl3_native::mtp::Session),
    Flash(mlxl3_native::qwen4::FlashMtpSession),
}
#[cfg(all(feature = "mlx", feature = "chat"))]
impl ChatMtpSession {
    fn new(head: &ChatMtpHead, depth: usize) -> Result<Self> {
        match head {
            ChatMtpHead::Qwen(_) => Ok(Self::Qwen(mlxl3_native::mtp::Session::new(depth)?)),
            ChatMtpHead::Flash(_) => {
                anyhow::ensure!(depth == 1, "Flash MTP supports depth 1");
                Ok(Self::Flash(Default::default()))
            }
        }
    }
    fn advance(
        &mut self,
        model: &mut NativeChatModel,
        head: &mut ChatMtpHead,
        anchor: u32,
        context: usize,
        remaining: usize,
        allow_lookup: impl Fn(&[u32]) -> bool,
    ) -> Result<u32> {
        match (self, model, head) {
            (Self::Qwen(session), NativeChatModel::Qwen(target), ChatMtpHead::Qwen(head)) => {
                session.advance(target, head, anchor, context, remaining, allow_lookup)
            }
            (Self::Flash(session), NativeChatModel::Flash(target), ChatMtpHead::Flash(head)) => {
                session.advance(target, head, anchor, context, remaining)
            }
            _ => bail!("MTP head and target do not match"),
        }
    }
    fn enable_adaptive(&mut self) {
        if let Self::Qwen(session) = self {
            session.enable_adaptive();
        }
    }
    fn enable_prompt_lookup(&mut self, tokens: &[u32]) {
        if let Self::Qwen(session) = self {
            session.enable_prompt_lookup(tokens);
        }
    }
    fn stats(&self) -> (usize, usize, usize, usize, [usize; 4]) {
        match self {
            Self::Qwen(s) => (
                s.proposed,
                s.accepted,
                s.blocks,
                s.lookup_blocks,
                s.depth_blocks,
            ),
            Self::Flash(s) => (s.proposed, s.accepted, s.blocks, 0, [0, s.blocks, 0, 0]),
        }
    }
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn prefill_flash_mtp(
    model: &mut NativeChatModel,
    head: &mut mlxl3_native::qwen4::FlashMtpHead,
    tokens: &[u32],
    cache: &mut Option<PromptCache>,
    cancelled: &AtomicBool,
) -> Result<(mlxl3_native::array::Array, Option<DFlashChat>, usize)> {
    let NativeChatModel::Flash(target) = model else {
        bail!("Flash MTP requires Flash Next");
    };
    *cache = None;
    Ok((target.prefill_mtp(head, tokens, cancelled)?, None, 0))
}

#[cfg(all(feature = "mlx", feature = "chat"))]
struct DFlashChat {
    cache: mlxl3_native::dflash::DFlashCache,
    pending: VecDeque<u32>,
    recent: VecDeque<(usize, usize)>,
    proposed: usize,
    accepted: usize,
    blocks: usize,
    block_seconds: f64,
    mode: usize,
    copy: Option<mlxl3_native::speculative::DFlashCopy>,
    lookup_blocks: usize,
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn reuse_cache_by_default() -> bool {
    true
}

#[cfg(all(test, feature = "mlx", feature = "chat"))]
#[test]
fn bridge_memory_saver_is_opt_in_and_requires_boolean() -> Result<()> {
    let legacy: BridgeRequest = serde_json::from_value(json!({"type":"generate"}))?;
    assert!(!legacy.memory_saver && legacy.reuse_prompt_cache);
    for saver in [false, true] {
        let request: BridgeRequest = serde_json::from_value(json!({
            "type":"generate", "memory_saver":saver, "reuse_prompt_cache":true
        }))?;
        assert_eq!(request.memory_saver, saver);
        assert!(request.reuse_prompt_cache);
    }
    for invalid in [json!(null), json!(1), json!("true"), json!([])] {
        assert!(
            serde_json::from_value::<BridgeRequest>(json!({
                "type":"generate", "memory_saver":invalid
            }))
            .is_err()
        );
    }
    Ok(())
}

/// One prefill checkpoint, never speculative/pending decode state. The resident
/// bridge owns one immutable model/tokenizer/context configuration. Draft reload
/// clears this cache; exact rendered IDs cover changes to system/tools/templates.
#[cfg(all(feature = "mlx", feature = "chat"))]
struct PromptCache {
    conversation: String,
    tokens: Vec<u32>,
    state: mlxl3_native::qwen35::QwenSnapshot,
    logits: mlxl3_native::array::Array,
    draft: Option<mlxl3_native::dflash::DFlashCache>,
    mtp: Option<mlxl3_native::mtp::Cache>,
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn prompt_cache_budget() -> Result<usize> {
    Ok(match std::env::var("MLXL3_PROMPT_CACHE_MIB") {
        Ok(value) => value
            .parse::<usize>()
            .ok()
            .and_then(mlxl3_native::memory_policy::mib_budget)
            .context("MLXL3_PROMPT_CACHE_MIB must be an integer in 0..4096")?,
        Err(std::env::VarError::NotPresent) => {
            mlxl3_native::memory_policy::DEFAULT_PROMPT_CACHE_BYTES
        }
        Err(error) => return Err(error.into()),
    })
}

#[cfg(all(feature = "mlx", feature = "chat"))]
impl PromptCache {
    fn capture(
        conversation: &str,
        tokens: &[u32],
        model: &NativeChatModel,
        logits: &mlxl3_native::array::Array,
        dflash: Option<&DFlashChat>,
    ) -> Result<Option<Self>> {
        let NativeChatModel::Qwen(target) = model else {
            return Ok(None);
        };
        anyhow::ensure!(
            usize::try_from(target.offset()).ok() == Some(tokens.len()),
            "prefix cache position differs from its token history"
        );
        if prompt_cache_budget()? == 0 {
            return Ok(None);
        }
        let state = target.snapshot()?.compact_for_cache()?;
        let saved = Self {
            conversation: conversation.to_owned(),
            tokens: tokens.to_vec(),
            state,
            logits: logits.compact_for_cache()?,
            draft: dflash
                .map(|session| session.cache.try_clone()?.compact_for_cache())
                .transpose()?,
            mtp: None,
        };
        saved.within_budget()
    }

    fn within_budget(self) -> Result<Option<Self>> {
        let budget = prompt_cache_budget()?;
        let fits = mlxl3_native::memory_policy::cache_fits(
            [
                self.state.retained_bytes()?,
                self.logits.retained_bytes()?,
                self.draft
                    .as_ref()
                    .map(|cache| cache.retained_bytes())
                    .transpose()?
                    .unwrap_or(0),
                self.mtp
                    .as_ref()
                    .map(|cache| cache.retained_bytes())
                    .transpose()?
                    .unwrap_or(0),
                self.tokens
                    .len()
                    .checked_mul(4)
                    .context("token cache size overflow")?,
                self.conversation.len(),
            ],
            budget,
        );
        Ok(fits.then_some(self))
    }
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn prefill_round(
    model: &mut NativeChatModel,
    tokens: &[u32],
    draft: Option<&mlxl3_native::dflash::DFlashWeights>,
    cache: &mut Option<PromptCache>,
    conversation: &str,
    reuse: bool,
    cancelled: &AtomicBool,
) -> Result<(mlxl3_native::array::Array, Option<DFlashChat>, usize)> {
    if cancelled.load(Ordering::Relaxed) {
        model.reset();
        bail!("generation cancelled");
    }
    if let NativeChatModel::Flash(target) = model
        && target.dflash2_active()
    {
        *cache = None;
        return Ok((target.prefill_dflash2(tokens, cancelled)?, None, 0));
    }
    let chunk_size = if draft.is_some() {
        mlxl3_native::dflash::PREFILL_CHUNK
    } else {
        model.prefill_chunk_size()
    };
    // Preserve cold-prefill chunk boundaries: changing shapes can change floating
    // point rounding even when the mathematical prefix is the same.
    let checkpoint_offset = tokens.len() / chunk_size * chunk_size;
    let previous = cache.take().filter(|saved| {
        reuse
            && saved.conversation == conversation
            && saved.mtp.is_none()
            && saved.draft.is_some() == draft.is_some()
            && mlxl3_native::reusable_prefix_len(&saved.tokens, tokens, chunk_size) > 0
    });
    model.reset();
    let mut cached = 0;
    let mut logits = None;
    let mut dflash = draft.map(|_| DFlashChat::new());
    if let Some(saved) = previous {
        let NativeChatModel::Qwen(target) = &mut *model else {
            bail!("invalid prefix cache model")
        };
        target.restore(saved.state)?;
        cached = saved.tokens.len();
        logits = Some(saved.logits);
        if let Some(session) = &mut dflash {
            session.cache = saved.draft.context("missing draft prefix state")?;
        }
        if checkpoint_offset == cached {
            *cache = PromptCache::capture(
                conversation,
                &tokens[..cached],
                model,
                logits.as_ref().unwrap(),
                dflash.as_ref(),
            )?;
        }
    }
    for (index, chunk) in tokens[cached..].chunks(chunk_size).enumerate() {
        if cancelled.load(Ordering::Relaxed) {
            model.reset();
            bail!("generation cancelled");
        }
        logits = Some(
            if let Some((session, weights)) = dflash.as_mut().zip(draft) {
                let NativeChatModel::Qwen(target) = &mut *model else {
                    bail!("DFlash2 requires a supported Qwen target")
                };
                if usize::try_from(target.offset())?
                    < mlxl3_native::dflash::prefill_capture_start(tokens.len())
                {
                    // The target still reads every token. Only features that
                    // would be discarded before the first draft are skipped.
                    target.forward_tokens(chunk)?
                } else {
                    session.prefill(target, weights, chunk)?
                }
            } else {
                model.forward_many(chunk)?
            },
        );
        model.eval_state()?;
        let position = cached + index * chunk_size + chunk.len();
        if reuse && position == checkpoint_offset {
            *cache = PromptCache::capture(
                conversation,
                &tokens[..position],
                model,
                logits.as_ref().unwrap(),
                dflash.as_ref(),
            )?;
        }
    }
    let logits = logits.context("no prefill output")?;
    logits.eval()?;
    Ok((logits, dflash, cached))
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn prefill_mtp(
    model: &mut NativeChatModel,
    head: &mut mlxl3_native::mtp::Head,
    tokens: &[u32],
    cache: &mut Option<PromptCache>,
    conversation: &str,
    reuse: bool,
    cancelled: &AtomicBool,
) -> Result<(mlxl3_native::array::Array, Option<DFlashChat>, usize)> {
    const CHUNK: usize = 256;
    let checkpoint = tokens.len() / CHUNK * CHUNK;
    let previous = cache.take().filter(|saved| {
        reuse
            && saved.conversation == conversation
            && saved.mtp.is_some()
            && mlxl3_native::reusable_prefix_len(&saved.tokens, tokens, CHUNK) > 0
    });
    model.reset();
    head.reset()?;
    let mut cached = 0;
    let mut logits = None;
    if let Some(saved) = previous {
        let NativeChatModel::Qwen(target) = &mut *model else {
            bail!("MTP requires Qwen");
        };
        target.restore(saved.state)?;
        head.restore(saved.mtp.context("missing MTP prefix state")?)?;
        cached = saved.tokens.len();
        logits = Some(saved.logits);
    }
    if reuse && cached > 0 && checkpoint == cached {
        let mut saved = PromptCache::capture(
            conversation,
            &tokens[..cached],
            model,
            logits.as_ref().unwrap(),
            None,
        )?;
        if let Some(saved) = &mut saved {
            saved.mtp = Some(head.snapshot()?.compact_for_cache()?);
        }
        *cache = saved.map(PromptCache::within_budget).transpose()?.flatten();
    }
    // At every checkpoint the last trunk hidden is deliberately unpaired.
    // The next prompt token is supplied only after prefix eligibility is known.
    for start in (cached..tokens.len()).step_by(CHUNK) {
        if cancelled.load(Ordering::Relaxed) {
            model.reset();
            head.reset()?;
            bail!("generation cancelled");
        }
        let NativeChatModel::Qwen(target) = &mut *model else {
            bail!("MTP requires Qwen");
        };
        if start > 0 {
            let last = target.mtp_hidden()?.try_clone()?;
            head.extend_cache(target, &last, &tokens[start..start + 1])?;
        }
        let end = start.saturating_add(CHUNK).min(tokens.len());
        let (output, raw) = target.forward_mtp(&tokens[start..end])?;
        let paired = end - start - 1;
        if paired > 0 {
            head.extend_cache(
                target,
                &raw.slice(1, 0, paired as i32)?,
                &tokens[start + 1..end],
            )?;
        }
        model.eval_state()?;
        logits = Some(output);
        if reuse && end == checkpoint {
            let mut saved = PromptCache::capture(
                conversation,
                &tokens[..end],
                model,
                logits.as_ref().unwrap(),
                None,
            )?;
            if let Some(saved) = &mut saved {
                saved.mtp = Some(head.snapshot()?.compact_for_cache()?);
            }
            *cache = saved.map(PromptCache::within_budget).transpose()?.flatten();
        }
    }
    let logits = logits.context("empty MTP prefill")?;
    logits.eval()?;
    Ok((logits, None, cached))
}

#[cfg(all(feature = "mlx", feature = "chat"))]
impl DFlashChat {
    fn new() -> Self {
        Self {
            cache: Default::default(),
            pending: VecDeque::new(),
            recent: VecDeque::new(),
            proposed: 0,
            accepted: 0,
            blocks: 0,
            block_seconds: 0.,
            mode: 1,
            copy: None,
            lookup_blocks: 0,
        }
    }

    fn configure(&mut self, mode: usize, family: mlxl3_native::dflash::Family, prompt: &[u32]) {
        self.mode = mode;
        self.copy = (mode == 1 && dflash_context_copy_enabled(Some(family)))
            .then(|| mlxl3_native::speculative::DFlashCopy::new(prompt));
    }

    fn proposals_count(&self, context_remaining: usize, output_remaining: usize) -> Option<usize> {
        let (accepted, proposed) = self
            .recent
            .iter()
            .fold((0, 0), |(accepted, proposed), &(a, p)| {
                (accepted + a, proposed + p)
            });
        mlxl3_native::speculative::dflash_proposals(
            self.mode,
            context_remaining,
            output_remaining,
            self.recent.len(),
            accepted,
            proposed,
        )
    }

    fn prefill(
        &mut self,
        target: &mut mlxl3_native::qwen35::Qwen35Moe,
        draft: &mlxl3_native::dflash::DFlashWeights,
        tokens: &[u32],
    ) -> Result<mlxl3_native::array::Array> {
        let position = target.offset();
        let (logits, captured) = if tokens.len() < 24 {
            target.prefill_serial_with_dflash_capture(tokens)?
        } else {
            target.forward_tokens_with_dflash_capture(tokens)?
        };
        self.cache.append_captured(draft, &captured, position)?;
        self.cache.eval()?;
        Ok(logits)
    }

    fn advance(
        &mut self,
        target: &mut mlxl3_native::qwen35::Qwen35Moe,
        draft: &mlxl3_native::dflash::DFlashWeights,
        anchor: u32,
        context_limit: usize,
        output_remaining: usize,
    ) -> Result<u32> {
        anyhow::ensure!(output_remaining > 0, "DFlash reached the output limit");
        if let Some(token) = self.pending.pop_front() {
            return Ok(token);
        }
        let remaining = context_limit.saturating_sub(usize::try_from(target.offset())?);
        let proposals_count = self
            .proposals_count(remaining, output_remaining)
            .context("DFlash reached the context limit")?;
        if proposals_count == 0 {
            // This is the last deliverable token. No later draft needs captures.
            return target
                .forward(anchor)?
                .chat_greedy_ids()?
                .into_iter()
                .next()
                .context("model returned no logits");
        }
        let block_started = Instant::now();
        let copied = self
            .copy
            .as_ref()
            .and_then(|copy| copy.propose(anchor, proposals_count));
        let is_copy = copied.is_some();
        let proposals = if let Some(tokens) = copied {
            tokens.to_vec()
        } else {
            let input = target.dflash_input(anchor, draft.family.mask())?;
            let output = draft.forward_hidden(&input, &self.cache, target.offset())?;
            let draft_logits = target.dflash_logits(&output.hidden, proposals_count)?;
            draft.select_greedy(&draft_logits, &output.selector, anchor)?
        };
        let verify = std::iter::once(anchor)
            .chain(proposals.iter().copied())
            .collect::<Vec<_>>();
        let position = target.offset();
        let (target_logits, captured) = target.verify_tokens_exact_with_dflash_capture(&verify)?;
        let target_tokens = target_logits.chat_greedy_ids()?;
        let acceptance = mlxl3_native::speculative::greedy_accept(&proposals, &target_tokens)
            .context("invalid DFlash target verification")?;
        let accepted = acceptance.accepted_draft_tokens;
        self.proposed += proposals.len();
        self.accepted += accepted;
        self.blocks += 1;
        self.recent.push_back((accepted, proposals.len()));
        if self.recent.len() > 8 {
            self.recent.pop_front();
        }
        let retained = accepted + 1;
        target.commit_dflash_verification(retained, verify.len())?;
        self.cache.append_captured(
            draft,
            &captured.slice(0, 0, i32::try_from(retained)?)?,
            position,
        )?;
        if let Some(copy) = &mut self.copy {
            copy.record(anchor, &proposals[..accepted], is_copy);
        }
        self.lookup_blocks += usize::from(is_copy);
        self.pending.extend(proposals[..accepted].iter().copied());
        self.pending.push_back(acceptance.target_token);
        // Wall time through materialized token selection, without extra GPU
        // barriers. Deferred cache/commit work may be paid by the next block.
        self.block_seconds += block_started.elapsed().as_secs_f64();
        self.pending
            .pop_front()
            .context("DFlash produced no target token")
    }
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn dflash_context_copy_enabled(family: Option<mlxl3_native::dflash::Family>) -> bool {
    family == Some(mlxl3_native::dflash::Family::Qwen36Moe)
        && std::env::var("MLXL3_DFLASH_CONTEXT_COPY").as_deref() == Ok("1")
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn dflash_runtime_key(base: &str, copy: bool) -> String {
    format!("{base}:dflash-v4:copy={}", u8::from(copy))
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn unlimited_tokens() -> i64 {
    -1
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn unit_penalty() -> f32 {
    1.0
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
#[derive(Clone, Default, Serialize)]
struct NativeStats {
    ttft_seconds: f64,
    prefill_tps: f64,
    decode_tps: f64,
    prompt_tokens: usize,
    generated_tokens: usize,
    model_size_gb: f64,
    cached_prompt_tokens: usize,
    evaluated_prompt_tokens: usize,
    context_used: usize,
    context_limit: usize,
    elapsed_seconds: f64,
    prepare_seconds: f64,
    prefill_seconds: f64,
    decode_seconds: f64,
    decode_tokens: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    native_gpu_greedy_selections: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    native_gpu_greedy_heads: Option<u64>,
    end_to_end_ttft_seconds: Option<f64>,
    tool_seconds: f64,
    draft_load_seconds: f64,
    tool_rounds: usize,
    round_count: usize,
    memory: Option<mlxl3_native::runtime_stats::MemoryStats>,
    dflash_proposed_tokens: Option<usize>,
    dflash_accepted_tokens: Option<usize>,
    dflash_blocks: Option<usize>,
    dflash_lookup_blocks: Option<usize>,
    dflash_block_seconds: f64,
    dflash_profile: Option<mlxl3_native::runtime_stats::FlashDraftProfile>,
    mtp_proposed_tokens: Option<usize>,
    mtp_accepted_tokens: Option<usize>,
    mtp_blocks: Option<usize>,
    mtp_lookup_blocks: Option<usize>,
    mtp_depth_blocks: Option<[usize; 4]>,
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
impl NativeStats {
    fn accumulate(&mut self, round: &Self) {
        if let Some(value) = round.native_gpu_greedy_selections {
            *self.native_gpu_greedy_selections.get_or_insert(0) += value;
        }
        if let Some(value) = round.native_gpu_greedy_heads {
            *self.native_gpu_greedy_heads.get_or_insert(0) += value;
        }
        self.prompt_tokens += round.prompt_tokens;
        self.generated_tokens += round.generated_tokens;
        self.cached_prompt_tokens += round.cached_prompt_tokens;
        self.evaluated_prompt_tokens += round.evaluated_prompt_tokens;
        self.prepare_seconds += round.prepare_seconds;
        self.prefill_seconds += round.prefill_seconds;
        self.decode_seconds += round.decode_seconds;
        self.decode_tokens += round.decode_tokens;
        self.prefill_tps = self.evaluated_prompt_tokens as f64 / self.prefill_seconds.max(1e-9);
        self.decode_tps = self.decode_tokens as f64 / self.decode_seconds.max(1e-9);
        self.context_used = round.context_used;
        self.context_limit = round.context_limit;
        self.round_count += round.round_count;
        self.dflash_block_seconds += round.dflash_block_seconds;
        if let Some(profile) = round.dflash_profile {
            let sum = self.dflash_profile.get_or_insert_with(Default::default);
            sum.draft_seconds += profile.draft_seconds;
            sum.verification_seconds += profile.verification_seconds;
            sum.commit_cache_seconds += profile.commit_cache_seconds;
            sum.verified_rows += profile.verified_rows;
            sum.drafted_rows += profile.drafted_rows;
            for (sum, value) in sum.drafted_widths.iter_mut().zip(profile.drafted_widths) {
                *sum += value;
            }
            for (sum, value) in sum.verified_widths.iter_mut().zip(profile.verified_widths) {
                *sum += value;
            }
            sum.expert_demand_bytes += profile.expert_demand_bytes;
            for (sum, value) in sum.ssd_prefetch.iter_mut().zip(profile.ssd_prefetch) {
                *sum = sum.saturating_add(value);
            }
        }
        self.memory = round.memory;
        if let Some(counts) = round.mtp_depth_blocks {
            let sum = self.mtp_depth_blocks.get_or_insert([0; 4]);
            for (total, count) in sum.iter_mut().zip(counts) {
                *total += count;
            }
        }
        for (sum, value) in [
            (
                &mut self.dflash_proposed_tokens,
                round.dflash_proposed_tokens,
            ),
            (
                &mut self.dflash_accepted_tokens,
                round.dflash_accepted_tokens,
            ),
            (&mut self.dflash_blocks, round.dflash_blocks),
            (&mut self.dflash_lookup_blocks, round.dflash_lookup_blocks),
            (&mut self.mtp_proposed_tokens, round.mtp_proposed_tokens),
            (&mut self.mtp_accepted_tokens, round.mtp_accepted_tokens),
            (&mut self.mtp_blocks, round.mtp_blocks),
            (&mut self.mtp_lookup_blocks, round.mtp_lookup_blocks),
        ] {
            if let Some(value) = value {
                *sum = Some(sum.unwrap_or(0) + value);
            }
        }
    }
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
struct RoundOutput {
    stop_reason: mlxl3_native::GenerationStopReason,
    raw: String,
    answer: String,
    stats: NativeStats,
    first_text_seconds: Option<f64>,
    token_hash: String,
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn token_hash(tokens: &[u32]) -> String {
    let mut hash = 0xcbf29ce484222325u64;
    for token in tokens {
        for byte in token.to_le_bytes() {
            hash = (hash ^ u64::from(byte)).wrapping_mul(0x100000001b3);
        }
    }
    format!("{hash:016x}")
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn emit_event(value: Value) -> Result<()> {
    let mut stdout = io::stdout().lock();
    serde_json::to_writer(&mut stdout, &value)?;
    writeln!(stdout)?;
    stdout.flush()?;
    Ok(())
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn select_token(
    logits: &mlxl3_native::array::Array,
    generated: &[u32],
    temperature: f32,
    top_k: usize,
    repetition_penalty: f32,
    random: &mut u64,
) -> Result<u32> {
    anyhow::ensure!(
        temperature.is_finite() && temperature >= 0.,
        "temperature must be non-negative"
    );
    anyhow::ensure!(
        repetition_penalty.is_finite() && repetition_penalty > 0.,
        "repetition_penalty must be positive"
    );
    if (temperature == 0. || top_k == 1) && repetition_penalty == 1. {
        return logits
            .chat_greedy_ids()?
            .into_iter()
            .next()
            .context("model returned no logits");
    }
    sample_values(
        logits.log_probs()?.to_f32()?,
        generated,
        temperature,
        top_k,
        repetition_penalty,
        random,
    )
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn sample_values(
    mut values: Vec<f32>,
    generated: &[u32],
    temperature: f32,
    top_k: usize,
    repetition_penalty: f32,
    random: &mut u64,
) -> Result<u32> {
    if repetition_penalty != 1. {
        for &token in generated.iter().rev().take(20) {
            if let Some(value) = values.get_mut(token as usize) {
                *value = if *value < 0. {
                    *value * repetition_penalty
                } else {
                    *value / repetition_penalty
                };
            }
        }
    }
    if temperature == 0. || top_k == 1 {
        return values
            .iter()
            .enumerate()
            .filter(|(_, value)| value.is_finite())
            .max_by(|left, right| left.1.total_cmp(right.1))
            .map(|(index, _)| index as u32)
            .context("model returned no finite logits");
    }
    let keep = if top_k == 0 {
        values.len()
    } else {
        top_k.min(values.len())
    };
    let mut candidates: Vec<_> = values.into_iter().enumerate().collect();
    if keep < candidates.len() {
        candidates.select_nth_unstable_by(keep, |left, right| right.1.total_cmp(&left.1));
        candidates.truncate(keep);
    }
    candidates.retain(|(_, value)| value.is_finite());
    let maximum = candidates
        .iter()
        .map(|(_, value)| *value)
        .max_by(f32::total_cmp)
        .context("model returned no finite logits")?;
    let mut total = 0f64;
    let weights: Vec<_> = candidates
        .iter()
        .map(|(_, value)| {
            let weight = (((*value - maximum) / temperature) as f64).exp();
            total += weight;
            weight
        })
        .collect();
    anyhow::ensure!(
        total.is_finite() && total > 0.,
        "invalid sampling distribution"
    );
    *random ^= *random << 13;
    *random ^= *random >> 7;
    *random ^= *random << 17;
    let mut target = (*random as f64 / u64::MAX as f64) * total;
    for ((index, _), weight) in candidates.iter().zip(weights) {
        if target <= weight {
            return Ok(*index as u32);
        }
        target -= weight;
    }
    Ok(candidates.last().expect("nonempty candidates").0 as u32)
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn bridge_emit_delta(
    request_id: &str,
    phase: &str,
    text: &str,
    buffered: bool,
    answer: &mut String,
) -> Result<()> {
    if phase == "answer" {
        answer.push_str(text);
    }
    if !buffered {
        emit_event(json!({"type":"delta", "request_id":request_id, "phase":phase, "text":text}))?;
    }
    Ok(())
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
impl BridgeRequest {
    fn greedy_unpenalized(&self) -> bool {
        (self.temperature == 0. || self.top_k == 1) && self.repetition_penalty == 1.
    }
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn emit_generation_mode(
    request: &BridgeRequest,
    mtp: bool,
    dflash: bool,
    proposals: usize,
    path: Option<String>,
) -> Result<()> {
    emit_event(json!({
        "type":"generation_mode", "request_id":request.request_id,
        "dflash_requested":request.dflash2,"dflash_active":dflash,
        "mtp_requested":request.mtp, "mtp_active":mtp, "mtp_depth":if mtp { request.mtp_depth } else { 0 },
        "mtp_reason":if request.mtp && !mtp { Some("MTP uses greedy sampling and repetition penalty 1; ordinary sampling remains active") } else { None },
        "dflash_proposals":proposals, "dflash_mode":if dflash { request.dflash_mode } else { 0 },
        "dflash_draft_path":path
    }))
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
#[allow(clippy::too_many_arguments)]
fn bridge_generate_round(
    model: &mut NativeChatModel,
    tokenizer: &mlxl3_native::tokenizer::ChatTokenizer,
    request_id: &str,
    messages: &[Value],
    tools: &[Value],
    max_tokens: i64,
    temperature: f32,
    top_k: usize,
    repetition_penalty: f32,
    context_limit: usize,
    resident_gb: f64,
    cancelled: &AtomicBool,
    random: &mut u64,
    draft: Option<&RoundDraft>,
    mut mtp: Option<&mut ChatMtpHead>,
    mtp_depth: usize,
    dflash_mode: usize,
    cache: &mut Option<PromptCache>,
    conversation: &str,
    reuse: bool,
    buffer_output: bool,
) -> Result<RoundOutput> {
    use mlxl3_native::{streaming::Channel, tool_call::StreamFilter};
    let started = Instant::now();
    #[cfg(not(feature = "mlx"))]
    let device_greedy = tools.is_empty()
        && model.device_greedy_eligible(
            temperature,
            top_k,
            repetition_penalty,
            mtp.is_some() || draft.is_some(),
        );
    #[cfg(not(feature = "mlx"))]
    let device_greedy_before = model.device_greedy_counts();
    anyhow::ensure!(!messages.is_empty(), "messages cannot be empty");
    anyhow::ensure!(
        max_tokens == -1 || max_tokens > 0,
        "max_tokens must be positive, or -1"
    );
    let rendered = tokenizer.render_values(&Value::Array(messages.to_vec()), Some(tools))?;
    let tokens = tokenizer.encode(&rendered)?;
    anyhow::ensure!(!tokens.is_empty(), "chat template produced no tokens");
    anyhow::ensure!(
        tokens.len() < context_limit,
        "conversation exceeds model context"
    );
    emit_event(json!({
        "type":"context_usage", "request_id":request_id,
        "used_tokens":tokens.len(), "context_limit":context_limit
    }))?;
    let available = context_limit - tokens.len();
    let budget = if max_tokens == -1 {
        available
    } else {
        usize::try_from(max_tokens)?.min(available)
    };
    #[cfg(feature = "mlx")]
    if let NativeChatModel::Flash(target) = &mut *model
        && let Some(plan) = target.admit_request(tokens.len() + budget)?
    {
        emit_event(
            json!({"type":"flash_memory_plan", "request_id":request_id, "ar":plan,
            "memory":target.memory_ledger(None)?}),
        )?;
    }
    #[cfg(not(feature = "mlx"))]
    if let Some(plan) = direct_bridge::admit_request(model, tokens.len() + budget, cache, reuse)? {
        emit_event(
            json!({"type":"flash_memory_plan","request_id":request_id,"ar":plan,"memory":model.memory_ledger(None)?}),
        )?;
    }
    let prepare_seconds = started.elapsed().as_secs_f64();
    let prefill_started = Instant::now();
    #[cfg(feature = "mlx")]
    let (mut logits, mut dflash, cached, mut mtp_session) = {
        let (logits, mut dflash, cached) = if let Some(head) = mtp.as_deref_mut() {
            match head {
                ChatMtpHead::Qwen(head) => {
                    prefill_mtp(model, head, &tokens, cache, conversation, reuse, cancelled)?
                }
                ChatMtpHead::Flash(head) => {
                    prefill_flash_mtp(model, head, &tokens, cache, cancelled)?
                }
            }
        } else {
            prefill_round(model, &tokens, draft, cache, conversation, reuse, cancelled)?
        };
        if let Some((session, weights)) = dflash.as_mut().zip(draft) {
            session.configure(dflash_mode, weights.family, &tokens);
        }
        let mut mtp_session = mtp
            .as_ref()
            .map(|head| ChatMtpSession::new(head, mtp_depth))
            .transpose()?;
        if std::env::var("MLXL3_MTP_ADAPTIVE").as_deref() == Ok("1")
            && let Some(session) = &mut mtp_session
        {
            session.enable_adaptive();
        }
        if std::env::var("MLXL3_MTP_LOOKUP").as_deref() == Ok("1")
            && let Some(session) = &mut mtp_session
        {
            session.enable_prompt_lookup(&tokens);
        }
        (logits, dflash, cached, mtp_session)
    };
    #[cfg(not(feature = "mlx"))]
    let (mut logits, cached, mut mtp_session) = {
        let _ = dflash_mode;
        direct_bridge::prefill(
            model,
            mtp.as_deref_mut(),
            draft,
            &tokens,
            mtp_depth,
            cache,
            conversation,
            reuse,
            cancelled,
        )?
    };
    let prefill_seconds = prefill_started.elapsed().as_secs_f64();
    #[cfg(feature = "mlx")]
    let gpu_capture = mlxl3_native::array::capture_for_request(request_id)?;
    let mut decoder = tokenizer.tokenizer().decode_stream(false);
    let mut splitter = ThinkingSplitter::new(&rendered);
    let mut filter = (!tools.is_empty()).then(StreamFilter::new);
    let mut last_tool_progress: Option<Instant> = None;
    let mut decoded = String::new();
    let mut answer = String::new();
    let mut generated = Vec::new();
    let mut first_token = None;
    let mut first_visible_text = None;
    let mut dflash_next = None;
    #[cfg(not(feature = "mlx"))]
    let mut device_greedy_next = None;
    let mut eos_observed = false;
    for _ in 0..budget {
        if cancelled.load(Ordering::Relaxed) {
            model.reset();
            bail!("generation cancelled");
        }
        let next = if let Some(token) = dflash_next.take() {
            token
        } else {
            #[cfg(feature = "mlx")]
            let sampled = select_token(
                &logits,
                &generated,
                temperature,
                top_k,
                repetition_penalty,
                random,
            )?;
            #[cfg(not(feature = "mlx"))]
            let sampled = if device_greedy {
                match device_greedy_next.take() {
                    Some(token) => token,
                    None => model.greedy_from_logits(&logits)?,
                }
            } else {
                direct_bridge::select(
                    model,
                    &logits,
                    &generated,
                    temperature,
                    top_k,
                    repetition_penalty,
                    random,
                )?
            };
            sampled
        };
        if tokenizer.eos_ids().contains(&next) {
            eos_observed = true;
            break;
        }
        first_token.get_or_insert_with(|| started.elapsed().as_secs_f64());
        generated.push(next);
        if let Some(text) = decoder
            .step(next)
            .map_err(|error| anyhow::anyhow!("token decode failed: {error}"))?
        {
            decoded.push_str(&text);
            for fragment in splitter.feed(&text) {
                let visible = if fragment.channel == Channel::Thinking {
                    vec![fragment.text]
                } else if let Some(filter) = &mut filter {
                    filter.feed(&fragment.text)
                } else {
                    vec![fragment.text]
                };
                for text in visible {
                    if !text.is_empty() {
                        first_visible_text.get_or_insert_with(|| started.elapsed().as_secs_f64());
                    }
                    bridge_emit_delta(
                        request_id,
                        if fragment.channel == Channel::Thinking {
                            "thinking"
                        } else {
                            "answer"
                        },
                        &text,
                        buffer_output,
                        &mut answer,
                    )?;
                }
            }
        }
        if filter.as_ref().is_some_and(StreamFilter::is_preparing_tool)
            && last_tool_progress
                .is_none_or(|last| last.elapsed() >= std::time::Duration::from_millis(500))
        {
            emit_event(json!({
                "type":"generation_status", "request_id":request_id, "phase":"tool_preparation",
                "text":format!("Preparing tool call · {} tokens", generated.len())
            }))?;
            last_tool_progress = Some(Instant::now());
        }
        if generated.len() < budget {
            #[cfg(feature = "mlx")]
            {
                if let Some((session, head)) = mtp_session.as_mut().zip(mtp.as_deref_mut()) {
                    dflash_next = Some(session.advance(
                        model,
                        head,
                        next,
                        context_limit,
                        budget - generated.len(),
                        |ids| {
                            tokenizer
                                .tokenizer()
                                .decode(ids, false)
                                .is_ok_and(|s| s.contains('\n'))
                        },
                    )?);
                } else if let Some((session, weights)) = dflash.as_mut().zip(draft) {
                    let NativeChatModel::Qwen(target) = &mut *model else {
                        bail!("DFlash2 requires a supported Qwen target")
                    };
                    dflash_next = Some(session.advance(
                        target,
                        weights,
                        next,
                        context_limit,
                        budget - generated.len(),
                    )?);
                } else if let NativeChatModel::Flash(target) = &mut *model
                    && target.dflash2_active()
                {
                    dflash_next = Some(target.advance_dflash2(next, budget - generated.len())?);
                } else {
                    logits = model.forward(next)?;
                }
            }
            #[cfg(not(feature = "mlx"))]
            if let Some((session, head)) = mtp_session.as_mut().zip(mtp.as_deref_mut()) {
                dflash_next = Some(session.advance(
                    model,
                    head,
                    next,
                    u32::try_from(context_limit)?,
                    budget - generated.len(),
                )?);
            } else if let Some(draft) = draft {
                dflash_next =
                    Some(draft.advance(model, next, context_limit, budget - generated.len())?);
            } else if device_greedy {
                device_greedy_next = Some(model.forward_greedy(next)?);
            } else {
                logits = model.forward(next)?;
            }
        }
    }
    let complete = tokenizer.decode(&generated)?;
    let tail = complete
        .strip_prefix(&decoded)
        .context("incremental tokenizer output differs from full decoding")?;
    for fragment in splitter.feed(tail).into_iter().chain(splitter.finish()) {
        let visible = if fragment.channel == Channel::Thinking {
            vec![fragment.text]
        } else if let Some(filter) = &mut filter {
            filter.feed(&fragment.text)
        } else {
            vec![fragment.text]
        };
        for text in visible {
            if !text.is_empty() {
                first_visible_text.get_or_insert_with(|| started.elapsed().as_secs_f64());
            }
            bridge_emit_delta(
                request_id,
                if fragment.channel == Channel::Thinking {
                    "thinking"
                } else {
                    "answer"
                },
                &text,
                buffer_output,
                &mut answer,
            )?;
        }
    }
    if let Some(filter) = &mut filter {
        for text in filter.finish() {
            if !text.is_empty() {
                first_visible_text.get_or_insert_with(|| started.elapsed().as_secs_f64());
            }
            bridge_emit_delta(request_id, "answer", &text, buffer_output, &mut answer)?;
        }
    }
    #[cfg(feature = "mlx")]
    if let Some(capture) = gpu_capture {
        capture.finish()?;
    }
    let elapsed = started.elapsed().as_secs_f64();
    #[cfg(feature = "mlx")]
    if let NativeChatModel::Flash(target) = &*model
        && target.request_memory_limit().is_some()
    {
        emit_event(json!({"type":"flash_memory_end","request_id":request_id,
            "positions":target.offset(),"ledger":target.memory_ledger(None)?}))?;
    }
    let ttft = first_token.unwrap_or(elapsed);
    let stats = NativeStats {
        ttft_seconds: ttft,
        #[cfg(not(feature = "mlx"))]
        native_gpu_greedy_selections: device_greedy
            .then(|| model.device_greedy_counts()[0] - device_greedy_before[0]),
        #[cfg(not(feature = "mlx"))]
        native_gpu_greedy_heads: device_greedy
            .then(|| model.device_greedy_counts()[1] - device_greedy_before[1]),
        prefill_tps: (tokens.len() - cached) as f64 / prefill_seconds.max(1e-9),
        decode_tps: generated.len().saturating_sub(1) as f64 / (elapsed - ttft).max(1e-9),
        prompt_tokens: tokens.len(),
        generated_tokens: generated.len(),
        model_size_gb: resident_gb,
        cached_prompt_tokens: cached,
        evaluated_prompt_tokens: tokens.len() - cached,
        context_used: tokens.len() + generated.len(),
        context_limit,
        elapsed_seconds: elapsed,
        prepare_seconds,
        prefill_seconds,
        decode_seconds: elapsed - ttft,
        decode_tokens: generated.len().saturating_sub(1),
        round_count: 1,
        #[cfg(feature = "mlx")]
        memory: mlxl3_native::array::memory_stats(false).ok(),
        #[cfg(feature = "mlx")]
        dflash_proposed_tokens: dflash.as_ref().map(|session| session.proposed),
        #[cfg(feature = "mlx")]
        dflash_accepted_tokens: dflash.as_ref().map(|session| session.accepted),
        #[cfg(feature = "mlx")]
        dflash_blocks: dflash.as_ref().map(|session| session.blocks),
        #[cfg(feature = "mlx")]
        dflash_lookup_blocks: dflash.as_ref().map(|session| session.lookup_blocks),
        #[cfg(feature = "mlx")]
        dflash_block_seconds: dflash.as_ref().map_or(0., |session| session.block_seconds),
        #[cfg(feature = "mlx")]
        mtp_proposed_tokens: mtp_session.as_ref().map(|s| s.stats().0),
        #[cfg(feature = "mlx")]
        mtp_accepted_tokens: mtp_session.as_ref().map(|s| s.stats().1),
        #[cfg(feature = "mlx")]
        mtp_blocks: mtp_session.as_ref().map(|s| s.stats().2),
        #[cfg(feature = "mlx")]
        mtp_lookup_blocks: mtp_session.as_ref().map(|s| s.stats().3),
        #[cfg(feature = "mlx")]
        mtp_depth_blocks: mtp_session.as_ref().map(|s| s.stats().4),
        #[cfg(not(feature = "mlx"))]
        memory: model.memory_stats().ok(),
        #[cfg(not(feature = "mlx"))]
        mtp_proposed_tokens: mtp_session.as_ref().map(|s| s.proposed),
        #[cfg(not(feature = "mlx"))]
        mtp_accepted_tokens: mtp_session.as_ref().map(|s| s.accepted),
        #[cfg(not(feature = "mlx"))]
        mtp_blocks: mtp_session.as_ref().map(|s| s.proposed),
        #[cfg(not(feature = "mlx"))]
        dflash_proposed_tokens: draft.map(|s| s.stats().0),
        #[cfg(not(feature = "mlx"))]
        dflash_accepted_tokens: draft.map(|s| s.stats().1),
        #[cfg(not(feature = "mlx"))]
        dflash_blocks: draft.map(|s| s.stats().2),
        #[cfg(not(feature = "mlx"))]
        dflash_profile: draft.map(|s| s.profile()),
        #[cfg(not(feature = "mlx"))]
        dflash_lookup_blocks: draft.map(|_| 0),
        #[cfg(not(feature = "mlx"))]
        dflash_block_seconds: draft.map_or(0., |d| {
            let p = d.profile();
            p.draft_seconds + p.verification_seconds + p.commit_cache_seconds
        }),

        ..Default::default()
    };
    #[cfg(feature = "mlx")]
    let mut stats = stats;
    #[cfg(feature = "mlx")]
    if let NativeChatModel::Flash(target) = &*model
        && let Some((proposed, accepted, blocks, seconds)) = target.dflash2_stats()
    {
        stats.dflash_proposed_tokens = Some(proposed);
        stats.dflash_accepted_tokens = Some(accepted);
        stats.dflash_blocks = Some(blocks);
        stats.dflash_lookup_blocks = Some(0);
        stats.dflash_block_seconds = seconds;
        stats.dflash_profile = target.dflash2_profile();
    }
    Ok(RoundOutput {
        stop_reason: mlxl3_native::GenerationStopReason::from_round(
            eos_observed,
            tokens.len() + generated.len() >= context_limit,
        ),
        raw: complete,
        answer,
        stats,
        first_text_seconds: first_visible_text,
        token_hash: token_hash(&generated),
    })
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn validated_bridge_messages(messages: Vec<Value>) -> Result<Vec<Value>> {
    let mut output = Vec::new();
    for mut message in messages {
        let object = message
            .as_object_mut()
            .context("each message must be an object")?;
        let role = object
            .get("role")
            .and_then(Value::as_str)
            .context("message requires a role")?
            .to_owned();
        anyhow::ensure!(
            matches!(role.as_str(), "system" | "user" | "assistant" | "tool"),
            "invalid message role"
        );
        anyhow::ensure!(
            object.get("content").is_some_and(Value::is_string),
            "message requires string content"
        );
        if let Some(turn) = object.remove("turn_context") {
            anyhow::ensure!(
                role == "assistant",
                "only assistant messages can contain tool history"
            );
            let encoded = turn.as_str().context("turn_context must be a string")?;
            let expanded: Vec<Value> =
                serde_json::from_str(encoded).context("invalid tool history")?;
            let expanded = validated_bridge_messages(expanded)?;
            anyhow::ensure!(
                expanded
                    .iter()
                    .all(|value| matches!(value["role"].as_str(), Some("assistant" | "tool"))),
                "tool history contains an invalid role"
            );
            output.extend(expanded);
        } else {
            output.push(message);
        }
    }
    anyhow::ensure!(!output.is_empty(), "messages cannot be empty");
    Ok(output)
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
#[allow(clippy::too_many_arguments)]
fn bridge_generate(
    model: &mut NativeChatModel,
    tokenizer: &mlxl3_native::tokenizer::ChatTokenizer,
    request_id: &str,
    messages: Vec<Value>,
    max_tokens: i64,
    temperature: f32,
    top_k: usize,
    repetition_penalty: f32,
    context_limit: usize,
    resident_gb: f64,
    cancelled: &AtomicBool,
    random: &mut u64,
    mcp: &mut mlxl3_native::mcp::Manager,
    draft: Option<&RoundDraft>,
    mut mtp: Option<&mut ChatMtpHead>,
    mtp_depth: usize,
    dflash_mode: usize,
    started: Instant,
    draft_load_seconds: f64,
    cache: &mut Option<PromptCache>,
    conversation: &str,
    reuse: bool,
    allowed_tools: Option<&[String]>,
    response_schema: Option<&str>,
) -> Result<()> {
    let schema = response_schema
        .map(mlxl3_native::structured::Schema::parse)
        .transpose()?;
    let mut dialogue = validated_bridge_messages(messages)?;
    if let Some(schema) = &schema {
        anyhow::ensure!(
            mcp.chat_tools().is_empty(),
            "JSON output and MCP must be used separately"
        );
        let instruction = schema.instruction();
        if dialogue
            .first()
            .is_some_and(|message| message["role"] == "system")
        {
            let existing = dialogue[0]["content"].as_str().unwrap_or("");
            dialogue[0]["content"] = json!(format!("{existing}\n\n{instruction}"));
        } else {
            dialogue.insert(0, json!({"role":"system", "content":instruction}));
        }
    }
    let original_length = dialogue.len();
    let tools: Vec<_> = mcp
        .chat_tools()
        .into_iter()
        .filter(|tool| {
            tool["function"]["name"]
                .as_str()
                .is_some_and(|name| mlxl3_native::structured::tool_allowed(name, allowed_tools))
        })
        .collect();
    let mut first_text = None;
    let mut summary: Option<NativeStats> = None;
    let mut round_stats = Vec::new();
    let mut tool_seconds = 0.;
    for round in 0..5 {
        emit_event(json!({
            "type":"generation_status", "request_id":request_id,
            "phase":"prefill", "text":if round == 0 { "Preparing context" } else { "Reading MCP results" }
        }))?;
        let round_start = started.elapsed().as_secs_f64();
        let round_max_tokens = mlxl3_native::structured::remaining_tokens(
            max_tokens,
            summary.as_ref().map_or(0, |stats| stats.generated_tokens),
        )
        .context(if schema.is_some() {
            "JSON token budget exhausted"
        } else {
            "Generation token budget exhausted"
        })?;
        let output = bridge_generate_round(
            model,
            tokenizer,
            request_id,
            &dialogue,
            &tools,
            round_max_tokens,
            temperature,
            top_k,
            repetition_penalty,
            context_limit,
            resident_gb,
            cancelled,
            random,
            draft,
            mtp.as_deref_mut(),
            mtp_depth,
            dflash_mode,
            cache,
            conversation,
            reuse,
            schema.is_some(),
        )?;
        if first_text.is_none() {
            first_text = output
                .first_text_seconds
                .map(|seconds| round_start + seconds);
        }
        if let Some(summary) = &mut summary {
            summary.accumulate(&output.stats);
        } else {
            let mut first = output.stats.clone();
            first.ttft_seconds += round_start;
            summary = Some(first);
        }
        round_stats.push(output.stats.clone());
        let validated_json = if let Some(schema) = &schema {
            match schema.validate(&output.answer) {
                Ok(answer) => Some(answer),
                Err(error) if round < 2 => {
                    dialogue.push(json!({"role":"assistant", "content":output.raw}));
                    dialogue.push(json!({"role":"user", "content":format!("The previous response failed JSON validation: {error}. Return only valid JSON conforming to the schema.")}));
                    *cache = None;
                    continue;
                }
                Err(error) => return Err(error.context("JSON validation failed after 3 attempts")),
            }
        } else {
            None
        };
        let calls = if tools.is_empty() {
            Vec::new()
        } else {
            mlxl3_native::tool_call::parse(&output.raw)?
        };
        let context_full = output.stats.context_used >= context_limit;
        if calls.is_empty() || context_full {
            let assistant = validated_json
                .clone()
                .unwrap_or_else(|| mlxl3_native::tool_call::without_calls(&output.raw));
            if let Some(answer) = &validated_json {
                first_text = Some(started.elapsed().as_secs_f64());
                emit_event(
                    json!({"type":"delta", "request_id":request_id,"phase":"answer","text":answer}),
                )?;
            }
            let turn_context = if round == 0 {
                None
            } else {
                let mut transcript = dialogue[original_length..].to_vec();
                transcript.push(json!({"role":"assistant", "content":output.raw}));
                Some(serde_json::to_string(&transcript)?)
            };
            let mut stats = summary.context("missing generation statistics")?;
            stats.elapsed_seconds = started.elapsed().as_secs_f64();
            stats.end_to_end_ttft_seconds = first_text;
            stats.tool_seconds = tool_seconds;
            stats.draft_load_seconds = draft_load_seconds;
            stats.tool_rounds = if schema.is_some() { 0 } else { round };
            return emit_event(json!({
                "type":"complete", "request_id":request_id,
                "assistant_context":assistant, "cache_context":output.raw,
                "token_hash":output.token_hash,
                "stats":stats, "round_stats":round_stats, "context_full":context_full,
                "stop_reason":output.stop_reason.as_str(),
                "turn_context":turn_context,
                "elapsed_seconds":started.elapsed().as_secs_f64(),
                "first_text_seconds":first_text,
                "tool_rounds":round
            }));
        }
        let tool_calls: Vec<_> = calls
            .iter()
            .map(|call| json!({"type":"function", "function":{"name":call.name, "arguments":call.arguments}}))
            .collect();
        dialogue.push(json!({
            "role":"assistant",
            "content":mlxl3_native::tool_call::without_calls(&output.raw),
            "tool_calls":tool_calls
        }));
        for call in calls {
            if cancelled.load(Ordering::Relaxed) {
                model.reset();
                bail!("generation cancelled");
            }
            let tool = mcp.tools.get(&call.name);
            let server = tool.map(|tool| tool.server.clone());
            let call_id = format!("mcp-{round}-{}-{}", dialogue.len(), call.name);
            emit_event(json!({
                "type":"tool_start", "request_id":request_id,
                "tool_call_id":call_id, "tool_name":call.name,
                "server_name":server
            }))?;
            let tool_started = Instant::now();
            anyhow::ensure!(
                mlxl3_native::structured::tool_allowed(&call.name, allowed_tools),
                "MCP tool is not allowed in this project: {}",
                call.name
            );
            let mut result = mcp.call(&call.name, call.arguments);
            tool_seconds += tool_started.elapsed().as_secs_f64();
            let budget = 8192usize.min((context_limit / 8).max(256));
            let result_tokens = tokenizer.encode(&result.text)?;
            if result_tokens.len() > budget {
                result.text = format!(
                    "{}\n[Tool output truncated to fit context]",
                    tokenizer.decode(&result_tokens[..budget])?
                );
            }
            emit_event(json!({
                "type":"tool_result", "request_id":request_id,
                "tool_call_id":call_id, "tool_name":call.name,
                "server_name":server, "text":result.text,
                "is_error":result.is_error
            }))?;
            dialogue.push(json!({
                "role":"tool", "name":call.name, "content":result.text
            }));
        }
    }
    bail!("the model exceeded the limit of 5 consecutive MCP tool rounds")
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn load_dflash_weights(
    slot: &mut Option<(PathBuf, String, mlxl3_native::dflash::DFlashWeights)>,
    cache: &mut Option<PromptCache>,
    path: &str,
    family: mlxl3_native::dflash::Family,
) -> Result<bool> {
    anyhow::ensure!(
        !path.trim().is_empty(),
        "DFlash2 draft folder is not configured"
    );
    let path = registry::expand_home(&PathBuf::from(path))?.canonicalize()?;
    let revision = mtp_tune::artifact_key(&path.join("draft"))?;
    if slot
        .as_ref()
        .is_some_and(|(previous, fingerprint, _)| previous == &path && fingerprint == &revision)
    {
        return Ok(false);
    }
    *slot = None;
    *cache = None;
    mlxl3_native::array::synchronize()?;
    mlxl3_native::array::clear_cache()?;
    let package = mlxl3_native::dflash::inspect(&path)?;
    anyhow::ensure!(
        package.family == family,
        "DFlash draft does not match this target"
    );
    *slot = Some((
        path,
        revision,
        mlxl3_native::dflash::DFlashWeights::load(&package)?,
    ));
    Ok(true)
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn load_mtp_head(
    head: &mut Option<(PathBuf, ChatMtpHead)>,
    revision: &mut Option<String>,
    prompt_cache: &mut Option<PromptCache>,
    requested: &str,
    model: &mut NativeChatModel,
    dflash_weights: &mut Option<(PathBuf, String, mlxl3_native::dflash::DFlashWeights)>,
) -> Result<bool> {
    // A direct generate request can switch modes without a preceding set_mtp.
    // Release both possible DFlash owners before validating or allocating MTP,
    // including the failed-load and already-loaded-head paths.
    let flash_dflash = matches!(&*model, NativeChatModel::Flash(target) if target.dflash2_active());
    if flash_dflash || dflash_weights.is_some() {
        *prompt_cache = None;
    }
    *dflash_weights = None;
    if let NativeChatModel::Flash(target) = &mut *model {
        target.configure_dflash2(None, 1)?;
    }
    anyhow::ensure!(
        !requested.trim().is_empty(),
        "MTP head folder is not configured"
    );
    let path = registry::expand_home(&PathBuf::from(requested))?.canonicalize()?;
    let next_revision = mtp_tune::artifact_key(&path)?;
    if head.as_ref().map(|(p, _)| p) == Some(&path) && revision.as_ref() == Some(&next_revision) {
        return Ok(false);
    }
    // Drop the previous head and its cached state before allocating a replacement.
    *prompt_cache = None;
    *head = None;
    *revision = None;
    mlxl3_native::array::synchronize()?;
    mlxl3_native::array::clear_cache()?;
    *head = Some((path.clone(), ChatMtpHead::load(&path, model)?));
    *revision = Some(next_revision);
    Ok(true)
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn release_bridge_idle_state(
    model: &mut NativeChatModel,
    head: Option<&mut ChatMtpHead>,
    memory_saver: bool,
) -> Result<()> {
    // Both prefill paths reset or restore their separate PromptCache on the next
    // request. The final decode state is not a continuation checkpoint.
    model.reset();
    let reset = head.map_or(Ok(()), ChatMtpHead::reset);
    let released = mlxl3_native::array::release_idle_cache_with_policy(memory_saver);
    reset?;
    released?;
    if memory_saver && let NativeChatModel::Flash(target) = model {
        target.clear_idle_program_cache()?;
    }
    Ok(())
}

#[cfg(all(feature = "mlx", feature = "chat"))]
fn native_bridge(
    registry_path: Option<&std::path::Path>,
    name: &str,
    requested: i32,
) -> Result<()> {
    use mlxl3_native::tokenizer::ChatTokenizer;
    let registry_path = registry_path
        .map(PathBuf::from)
        .map(Ok)
        .unwrap_or_else(registry::default_path)?;
    let path = resolve_model_path(Some(&registry_path), name)?;
    let checkpoint = checkpoint::inspect(&path)?;
    emit_event(json!({"type":"loading", "model":name}))?;
    let started = Instant::now();
    let tokenizer = ChatTokenizer::load(&path)?;
    let mut model = NativeChatModel::from_checkpoint(&checkpoint)?;
    let converted_embedding = checkpoint.tensors.iter().any(|(name, tensor)| {
        name.ends_with("embed_tokens.weight")
            && tensor.dtype != "F16"
            && tensor.data_offsets[1] - tensor.data_offsets[0] >= 64 * 1024 * 1024
    });
    if converted_embedding && std::env::var("MLXL3_RETAIN_LOAD_CACHE").as_deref() != Ok("1") {
        mlxl3_native::array::clear_cache()?;
    }
    let model_limit = model.context_limit();
    anyhow::ensure!(
        requested >= 0 && requested <= model_limit,
        "context length must be between 1 and {model_limit}, or 0 for automatic"
    );
    let context_limit = if requested == 0 {
        model_limit
    } else {
        requested
    } as usize;
    let resident_gb = checkpoint.size_bytes as f64 / 1e9;
    let dflash_family = match &model {
        NativeChatModel::Qwen(target) => target.dflash_family(),
        _ => None,
    };
    let flash_speculative =
        matches!(&model, NativeChatModel::Flash(target) if target.request_memory_limit().is_none());
    let dflash_supported = (dflash_family.is_some()
        && mlxl3_native::array::supports_packed_dflash_q4()?)
        || flash_speculative;
    let mtp_auto_download_supported = matches!(&model, NativeChatModel::Qwen(_))
        && mlxl3_native::mtp::target_layout(&path)
            .is_ok_and(|(layout, layers)| layout.managed_head(layers).is_some());
    let executable = std::env::current_exe()?.display().to_string();
    let tuning_key = mtp_tune::runtime_key(&path, context_limit)?;
    let dflash_tuning_key =
        dflash_runtime_key(&tuning_key, dflash_context_copy_enabled(dflash_family));
    let memory = mlxl3_native::array::memory_stats(false)?;
    emit_event(json!({
        "flash":match &model { NativeChatModel::Flash(target) => Some(target.runtime_manifest()?), _ => None },
        "type":"ready", "model":name, "modules":checkpoint.modules.len(),
        "load_seconds":started.elapsed().as_secs_f64(), "resident_gb":resident_gb,
        "memory":memory,
        "runtime_commit":env!("MLXL3_BUILD_REVISION"),
        "runtime_profile":env!("MLXL3_BUILD_PROFILE"),
        "mlx_version":env!("MLXL3_MLX_VERSION"),
        "runtime_executable":executable,
        "dflash_supported":dflash_supported, "dflash_family":dflash_family,
        "dflash_tune_supported":dflash_family.is_some() && dflash_supported, "dflash_configure_supported":true,
        "dflash_tuning_key":dflash_tuning_key,
        "mtp_supported":matches!(&model, NativeChatModel::Qwen(_)) || flash_speculative,
        "mtp_auto_download_supported":mtp_auto_download_supported,
        "mtp_configure_supported":true,
        "mtp_max_depth":if matches!(&model, NativeChatModel::Flash(_)) { 1 } else { 3 }, "mtp_tune_supported":matches!(&model, NativeChatModel::Qwen(_)),
        "memory_saver_supported":true,
        "context_memory":match &model {
            NativeChatModel::Qwen(target) => Some(target.context_memory_profile()?),
            NativeChatModel::Lfm2(target) => Some(target.context_memory_profile()?),
            _ => None
        },
        "mtp_tuning_key":tuning_key,
        "runtime_version":env!("CARGO_PKG_VERSION"), "bridge_protocol":1,
        "mcp_servers":0, "mcp_tools":0, "mcp_errors":{}, "workspace_features":true,
        "context_limit":context_limit, "model_context_limit":model_limit
    }))?;
    let cancelled = Arc::new(AtomicBool::new(false));
    signal_hook::flag::register(signal_hook::consts::SIGUSR1, Arc::clone(&cancelled))?;
    let mut random = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos() as u64
        | 1;
    let mut mcp = mlxl3_native::mcp::Manager::disabled();
    let mut dflash_weights: Option<(PathBuf, String, mlxl3_native::dflash::DFlashWeights)> = None;
    let mut mtp_head: Option<(PathBuf, ChatMtpHead)> = None;
    let mut mtp_head_revision = None;
    let mut prompt_cache: Option<PromptCache> = None;
    for line in io::stdin().lock().lines() {
        let line = line?;
        if line.trim().is_empty() {
            continue;
        }
        let parsed: Result<BridgeRequest> =
            serde_json::from_str(&line).context("invalid bridge request");
        let request = match parsed {
            Ok(request) => request,
            Err(error) => {
                emit_event(json!({"type":"error", "request_id":"", "message":error.to_string()}))?;
                continue;
            }
        };
        match request.kind.as_str() {
            "shutdown" => break,
            "flash_memory" => {
                let result = match &model {
                    NativeChatModel::Flash(target) => target.memory_ledger(match mtp_head.as_ref() {
                        Some((_, ChatMtpHead::Flash(head))) => Some(head),
                        _ => None,
                    }).map(|ledger|
                        json!({"type":"flash_memory","request_id":request.request_id,"ledger":ledger})),
                    _ => Err(anyhow::anyhow!("flash_memory requires Flash Next")),
                };
                emit_event(result.unwrap_or_else(|e| {
                    json!({"type":"error",
                    "request_id":request.request_id,"message":e.to_string()})
                }))?;
            }
            "ping" => emit_event(json!({"type":"pong", "request_id":request.request_id,
                "memory":mlxl3_native::array::memory_stats(false)?}))?,
            "set_mcp" => {
                mcp.set_enabled(&registry_path, request.enabled, true);
                emit_event(json!({
                    "type":"mcp_status", "mcp_servers":mcp.server_count(),
                    "mcp_tools":mcp.tools.len(), "mcp_errors":mcp.errors, "mcp_tool_catalog":mcp.chat_tools()
                }))?;
            }
            "set_mtp" => {
                prompt_cache = None;
                model.reset();
                let result = (|| -> Result<()> {
                    if request.enabled {
                        anyhow::ensure!(
                            matches!(&model, NativeChatModel::Qwen(_) | NativeChatModel::Flash(_)),
                            "MTP requires a supported Qwen target"
                        );
                        load_mtp_head(
                            &mut mtp_head,
                            &mut mtp_head_revision,
                            &mut prompt_cache,
                            &request.mtp_head_path,
                            &mut model,
                            &mut dflash_weights,
                        )?;
                    } else {
                        mtp_head = None;
                        mtp_head_revision = None;
                    }
                    mlxl3_native::array::synchronize()?;
                    mlxl3_native::array::clear_cache()?;
                    emit_event(json!({"type":"mtp_status", "request_id":request.request_id,
                        "mtp_active":mtp_head.is_some(),
                        "mtp_head_path":mtp_head.as_ref().map(|(path, _)| path),
                        "memory":mlxl3_native::array::memory_stats(false)?}))
                })();
                if let Err(error) = result {
                    mtp_head = None;
                    mtp_head_revision = None;
                    mlxl3_native::array::synchronize()?;
                    mlxl3_native::array::clear_cache()?;
                    emit_event(json!({"type":"error", "request_id":request.request_id,
                        "message":error.to_string(), "mtp_active":false,
                        "memory":mlxl3_native::array::memory_stats(false)?}))?;
                }
            }
            "set_dflash" | "tune_dflash" => {
                cancelled.store(false, Ordering::Relaxed);
                prompt_cache = None;
                model.reset();
                let result = (|| -> Result<()> {
                    if let NativeChatModel::Flash(target) = &mut model {
                        anyhow::ensure!(
                            request.kind != "tune_dflash",
                            "Flash DFlash2 learns its verify budget online; Tune is not supported"
                        );
                        if request.enabled {
                            mtp_head = None;
                            mtp_head_revision = None;
                        }
                        dflash_weights = None;
                        let path =
                            registry::expand_home(&PathBuf::from(&request.dflash_draft_path))?;
                        target.configure_dflash2(
                            request.enabled.then_some(path.as_path()),
                            request.dflash_mode,
                        )?;
                        return emit_event(
                            json!({"type":"dflash_status", "request_id":request.request_id,
                            "dflash_active":target.dflash2_active(), "memory":mlxl3_native::array::memory_stats(false)?}),
                        );
                    }
                    if request.enabled || request.kind == "tune_dflash" {
                        let family = dflash_family.context("Unsupported DFlash target")?;
                        mtp_head = None;
                        mtp_head_revision = None;
                        mlxl3_native::array::synchronize()?;
                        mlxl3_native::array::clear_cache()?;
                        load_dflash_weights(
                            &mut dflash_weights,
                            &mut prompt_cache,
                            &request.dflash_draft_path,
                            family,
                        )?;
                    } else {
                        dflash_weights = None;
                    }
                    if request.kind == "tune_dflash" {
                        mtp_tune::run_dflash(
                            &mut model,
                            &dflash_weights.as_ref().context("missing DFlash draft")?.2,
                            &tokenizer,
                            &request.request_id,
                            &dflash_tuning_key,
                            context_limit,
                            &cancelled,
                        )
                    } else {
                        mlxl3_native::array::synchronize()?;
                        mlxl3_native::array::clear_cache()?;
                        emit_event(
                            json!({"type":"dflash_status", "request_id":request.request_id,
                            "dflash_active":dflash_weights.is_some(), "memory":mlxl3_native::array::memory_stats(false)?}),
                        )
                    }
                })();
                if let Err(error) = release_bridge_idle_state(
                    &mut model,
                    mtp_head.as_mut().map(|(_, head)| head),
                    request.memory_saver,
                ) {
                    eprintln!("Idle memory cleanup failed: {error:#}");
                }
                if let Err(error) = result {
                    dflash_weights = None;
                    if let NativeChatModel::Flash(target) = &mut model {
                        target.configure_dflash2(None, 1)?;
                    }
                    mlxl3_native::array::synchronize()?;
                    mlxl3_native::array::clear_cache()?;
                    if cancelled.swap(false, Ordering::Relaxed) {
                        emit_event(json!({"type":"cancelled","request_id":request.request_id}))?;
                    } else {
                        emit_event(
                            json!({"type":"error","request_id":request.request_id,"message":error.to_string(),"dflash_active":false}),
                        )?;
                    }
                }
            }
            "tune_mtp" => {
                cancelled.store(false, Ordering::Relaxed);
                prompt_cache = None;
                dflash_weights = None;
                let result = (|| -> Result<()> {
                    let NativeChatModel::Qwen(_) = &model else {
                        bail!("Tune MTP supports Qwen3.5/3.6/3.8 targets");
                    };
                    emit_event(
                        json!({"type":"mtp_tune_progress","request_id":request.request_id,
                        "phase":"loading_head","completed":0,"total":12}),
                    )?;
                    load_mtp_head(
                        &mut mtp_head,
                        &mut mtp_head_revision,
                        &mut prompt_cache,
                        &request.mtp_head_path,
                        &mut model,
                        &mut dflash_weights,
                    )?;
                    let ChatMtpHead::Qwen(head) =
                        &mut mtp_head.as_mut().context("missing MTP head")?.1
                    else {
                        bail!("Tune MTP requires a Qwen target");
                    };
                    mtp_tune::run(
                        &mut model,
                        head,
                        &tokenizer,
                        &request.request_id,
                        &tuning_key,
                        context_limit,
                        &cancelled,
                    )
                })();
                if let Err(error) = release_bridge_idle_state(
                    &mut model,
                    mtp_head.as_mut().map(|(_, head)| head),
                    request.memory_saver,
                ) {
                    eprintln!("Idle memory cleanup failed: {error:#}");
                }
                if let Err(error) = result {
                    if cancelled.swap(false, Ordering::Relaxed) {
                        emit_event(json!({"type":"cancelled","request_id":request.request_id}))?;
                    } else {
                        emit_event(
                            json!({"type":"error","request_id":request.request_id,"message":error.to_string()}),
                        )?;
                    }
                }
            }
            "generate" => {
                if request.memory_saver {
                    prompt_cache = None;
                }
                let started = Instant::now();
                let _ = mlxl3_native::array::memory_stats(true);
                cancelled.store(false, Ordering::Relaxed);
                let schema_valid = request
                    .response_schema
                    .as_deref()
                    .map(mlxl3_native::structured::Schema::parse)
                    .transpose();
                if let Err(error) = schema_valid {
                    emit_event(
                        json!({"type":"error", "request_id":request.request_id, "message":error.to_string()}),
                    )?;
                    continue;
                }
                if request.response_schema.is_some() && request.mcp_enabled {
                    emit_event(
                        json!({"type":"error", "request_id":request.request_id, "message":"JSON output and MCP must be used separately"}),
                    )?;
                    continue;
                }
                mcp.set_enabled(&registry_path, request.mcp_enabled, false);
                let request_id = request.request_id.clone();
                let memory_saver = request.memory_saver;
                let result = (|| -> Result<()> {
                    let mut draft_load_seconds = 0.;
                    anyhow::ensure!(
                        !(request.mtp && request.dflash2),
                        "Choose either MTP or DFlash2"
                    );
                    let mtp_active = request.mtp && request.greedy_unpenalized();
                    if mtp_active {
                        anyhow::ensure!(
                            (1..=3).contains(&request.mtp_depth),
                            "MTP depth must be 1, 2 or 3"
                        );
                        anyhow::ensure!(
                            matches!(&model, NativeChatModel::Qwen(_) | NativeChatModel::Flash(_)),
                            "MTP requires a supported Qwen target"
                        );
                        anyhow::ensure!(
                            !matches!(&model, NativeChatModel::Flash(_)) || request.mtp_depth == 1,
                            "Flash MTP supports depth 1"
                        );
                        let started = Instant::now();
                        if load_mtp_head(
                            &mut mtp_head,
                            &mut mtp_head_revision,
                            &mut prompt_cache,
                            &request.mtp_head_path,
                            &mut model,
                            &mut dflash_weights,
                        )? {
                            prompt_cache = None;
                            draft_load_seconds += started.elapsed().as_secs_f64();
                        }
                    } else {
                        mtp_head = None;
                        mtp_head_revision = None;
                    }
                    if request.dflash2 {
                        anyhow::ensure!(
                            (1..=3).contains(&request.dflash_mode),
                            "DFlash mode must be 1, 2 or 3"
                        );
                        anyhow::ensure!(
                            request.greedy_unpenalized(),
                            "DFlash2 requires greedy sampling and repetition penalty 1.0"
                        );
                        let draft_started = Instant::now();
                        if let NativeChatModel::Flash(target) = &mut model {
                            dflash_weights = None;
                            prompt_cache = None;
                            let path =
                                registry::expand_home(&PathBuf::from(&request.dflash_draft_path))?;
                            target.configure_dflash2(Some(&path), request.dflash_mode)?;
                            draft_load_seconds += draft_started.elapsed().as_secs_f64();
                        } else if load_dflash_weights(
                            &mut dflash_weights,
                            &mut prompt_cache,
                            &request.dflash_draft_path,
                            dflash_family.context("Unsupported DFlash2 target")?,
                        )? {
                            draft_load_seconds += draft_started.elapsed().as_secs_f64();
                        }
                    } else {
                        if let NativeChatModel::Flash(target) = &mut model {
                            target.configure_dflash2(None, 1)?;
                        }
                        if dflash_weights.is_some() {
                            prompt_cache = None;
                        }
                        dflash_weights = None;
                    }
                    let flash_dflash =
                        matches!(&model, NativeChatModel::Flash(target) if target.dflash2_active());
                    let dflash_active = dflash_weights.is_some() || flash_dflash;
                    let proposals = if let NativeChatModel::Flash(target) = &model {
                        target.dflash2_proposals().unwrap_or(0)
                    } else if dflash_active {
                        match request.dflash_mode {
                            3 => 7,
                            2 => 2,
                            _ => 5,
                        }
                    } else {
                        0
                    };
                    let draft_path = if flash_dflash {
                        Some(request.dflash_draft_path.clone())
                    } else {
                        dflash_weights
                            .as_ref()
                            .map(|(path, _, _)| path.display().to_string())
                    };
                    emit_generation_mode(
                        &request,
                        mtp_active,
                        dflash_active,
                        proposals,
                        draft_path,
                    )?;
                    bridge_generate(
                        &mut model,
                        &tokenizer,
                        &request.request_id,
                        request.messages,
                        request.max_tokens,
                        request.temperature,
                        request.top_k,
                        request.repetition_penalty,
                        context_limit,
                        resident_gb,
                        &cancelled,
                        &mut random,
                        &mut mcp,
                        dflash_weights.as_ref().map(|(_, _, weights)| weights),
                        mtp_head.as_mut().map(|(_, head)| head),
                        request.mtp_depth,
                        request.dflash_mode,
                        started,
                        draft_load_seconds,
                        &mut prompt_cache,
                        if request.conversation_id.is_empty() {
                            &request.request_id
                        } else {
                            &request.conversation_id
                        },
                        request.reuse_prompt_cache && !request.memory_saver,
                        request.allowed_tools.as_deref(),
                        request.response_schema.as_deref(),
                    )
                })();
                // Runs after the whole turn (including tools), not between decode
                // tokens. Also release temporary state after cancellation/error.
                if let Err(error) = release_bridge_idle_state(
                    &mut model,
                    mtp_head.as_mut().map(|(_, head)| head),
                    memory_saver,
                ) {
                    eprintln!("Idle memory cleanup failed: {error:#}");
                }
                if let Err(error) = result {
                    model.reset();
                    prompt_cache = None;
                    mtp_head = None;
                    mtp_head_revision = None;
                    if cancelled.swap(false, Ordering::Relaxed) {
                        emit_event(json!({"type":"cancelled", "request_id":request_id}))?;
                    } else {
                        emit_event(
                            json!({"type":"error", "request_id":request_id, "message":error.to_string()}),
                        )?;
                    }
                }
            }
            other => emit_event(json!({
                "type":"error", "request_id":request.request_id,
                "message":format!("unsupported request type: {other}")
            }))?,
        }
    }
    Ok(())
}

#[cfg(all(
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
fn native_chat(path: &std::path::Path, prompt: Option<String>, max_tokens: usize) -> Result<()> {
    use mlxl3_native::{
        streaming::Channel,
        tokenizer::{ChatTokenizer, Message},
    };
    let tokenizer = ChatTokenizer::load(path)?;
    #[cfg(feature = "mlx")]
    let mut model = NativeChatModel::load(path)?;
    #[cfg(not(feature = "mlx"))]
    let gpu = mlxl3_native::gpu::Metal::new()?;
    #[cfg(not(feature = "mlx"))]
    let mut model = mlxl3_native::gpu::FlashNext::load(&gpu, &checkpoint::inspect(path)?, 0)?;
    #[cfg(feature = "mlx")]
    let name = model.name();
    #[cfg(not(feature = "mlx"))]
    let name = "Flash Next / direct Metal";
    eprintln!(
        "Loaded native {} engine (experimental, greedy sampling)",
        name
    );
    let mut messages = Vec::new();
    let interactive = prompt.is_none();
    let mut one_prompt = prompt;
    let mut stdout = io::stdout().lock();
    loop {
        let user = if interactive {
            write!(stdout, "\n>>> ")?;
            stdout.flush()?;
            let mut line = String::new();
            if io::stdin().read_line(&mut line)? == 0 {
                break;
            }
            let text = line.trim_end().to_owned();
            if matches!(text.as_str(), "/exit" | "/quit") {
                break;
            }
            if text == "/clear" {
                messages.clear();
                model.reset();
                continue;
            }
            if text.is_empty() {
                continue;
            }
            text
        } else {
            one_prompt.take().context("missing prompt")?
        };
        messages.push(Message {
            role: "user".into(),
            content: user,
        });
        let rendered = tokenizer.render(&messages)?;
        let tokens = tokenizer.encode(&rendered)?;
        anyhow::ensure!(!tokens.is_empty(), "chat template produced no tokens");
        let available = (model.context_limit() as usize).saturating_sub(tokens.len());
        anyhow::ensure!(
            available > 0,
            "conversation exceeds model context; use /clear"
        );
        let budget = if max_tokens == 0 {
            available
        } else {
            max_tokens.min(available)
        };
        #[cfg(feature = "mlx")]
        if let NativeChatModel::Flash(target) = &mut model {
            target.admit_request(tokens.len() + budget)?;
        }
        // Replay keeps conversation contents exact. Qwen uses bounded QMM chunks;
        // other architectures retain their established token path.
        #[cfg(not(feature = "mlx"))]
        model.admit_request(tokens.len() + budget)?;
        model.reset();
        let started = std::time::Instant::now();
        #[cfg(feature = "mlx")]
        let mut logits = {
            let mut last = None;
            for chunk in tokens.chunks(model.prefill_chunk_size()) {
                last = Some(model.forward_many(chunk)?);
                model.eval_state()?;
            }
            let logits = last.context("no prefill output")?;
            logits.eval()?;
            logits
        };
        #[cfg(not(feature = "mlx"))]
        let device_greedy = model.device_greedy_eligible(0., 1, 1., false);
        #[cfg(not(feature = "mlx"))]
        let mut device_greedy_next = None;
        #[cfg(not(feature = "mlx"))]
        let mut logits = model.prefill(&tokens)?;
        let prefill = started.elapsed();
        let mut decoder = tokenizer.tokenizer().decode_stream(false);
        let mut split = ThinkingSplitter::new(&rendered);
        let mut raw_text = String::new();
        let mut generated = Vec::new();
        let mut count = 0usize;
        let mut ttft = None;
        let mut current_channel = None;
        let mut emit = |fragments: Vec<mlxl3_native::streaming::Fragment>| -> Result<()> {
            for fragment in fragments {
                if current_channel != Some(fragment.channel) {
                    write!(
                        stdout,
                        "\n{}\n",
                        if fragment.channel == Channel::Thinking {
                            "— Thinking —"
                        } else {
                            "— Answer —"
                        }
                    )?;
                    current_channel = Some(fragment.channel);
                }
                write!(stdout, "{}", fragment.text)?;
            }
            stdout.flush()?;
            Ok(())
        };
        for _ in 0..budget {
            // Preserve MLX-LM's normalization before greedy selection. A raw
            // logits argmax could choose differently at FP16 rounding ties.
            #[cfg(feature = "mlx")]
            let next =
                mlxl3_native::speculative::greedy_log_prob_id(&logits.log_probs()?.to_f32()?)
                    .context("model returned invalid log probabilities or no finite token")?;
            #[cfg(not(feature = "mlx"))]
            let next = if device_greedy {
                match device_greedy_next.take() {
                    Some(token) => token,
                    None => model.greedy_from_logits(&logits)?,
                }
            } else {
                mlxl3_native::speculative::greedy_log_prob_id(&gpu.flash_log_probs(&logits)?)
                    .context("model returned invalid log probabilities or no finite token")?
            };
            if tokenizer.eos_ids().contains(&next) {
                break;
            }
            ttft.get_or_insert_with(|| started.elapsed());
            count += 1;
            generated.push(next);
            if let Some(text) = decoder
                .step(next)
                .map_err(|e| anyhow::anyhow!("token decode failed: {e}"))?
            {
                raw_text.push_str(&text);
                emit(split.feed(&text))?;
            }
            if count < budget {
                #[cfg(feature = "mlx")]
                {
                    logits = model.forward(next)?;
                }
                #[cfg(not(feature = "mlx"))]
                if device_greedy {
                    device_greedy_next = Some(model.forward_greedy(next)?);
                } else {
                    logits = model.forward(next)?;
                }
            }
        }
        // A token limit can cut a byte-fallback character. Flush the tokenizer's
        // final representation instead of silently dropping buffered bytes.
        let complete = tokenizer.decode(&generated)?;
        let tail = complete
            .strip_prefix(&raw_text)
            .context("incremental tokenizer output differs from full decoding")?;
        emit(split.feed(tail))?;
        raw_text = complete;
        emit(split.finish())?;
        let elapsed = started.elapsed();
        let decode = elapsed
            .saturating_sub(ttft.unwrap_or(elapsed))
            .as_secs_f64();
        writeln!(
            stdout,
            "\n[prefill {:.1} tok/s · decode {:.1} tok/s · TTFT {:.0} ms · {} tokens]",
            tokens.len() as f64 / prefill.as_secs_f64().max(1e-9),
            count.saturating_sub(1) as f64 / decode.max(1e-9),
            ttft.unwrap_or(elapsed).as_secs_f64() * 1000.0,
            count
        )?;
        stdout.flush()?;
        messages.push(Message {
            role: "assistant".into(),
            content: raw_text,
        });
        if !interactive {
            break;
        }
    }
    Ok(())
}

#[cfg(all(test, feature = "mlx", feature = "chat"))]
mod tests {
    use super::*;

    #[test]
    #[ignore = "requires local Flash target/DFlash checkpoints and Apple GPU; run alone"]
    fn mtp_preparation_retires_flash_draft_before_invalid_head_is_read() -> Result<()> {
        let path = PathBuf::from(std::env::var("MLXL3_FLASH_MODEL")?);
        let draft = PathBuf::from(std::env::var("MLXL3_FLASH_DRAFT_MODEL")?);
        let mut model = NativeChatModel::load(&path)?;
        anyhow::ensure!(
            matches!(&model, NativeChatModel::Flash(_)),
            "requires a Flash Next target"
        );
        let baseline = model.forward(0)?.to_f32()?;
        anyhow::ensure!(
            baseline.len() == 248_320 && baseline.iter().all(|x| x.is_finite()),
            "invalid reference logits"
        );
        model.reset();
        let directory = tempfile::tempdir()?;
        let missing = directory.path().join("absent-mtp-head");
        let missing = missing.to_str().context("non-UTF8 temporary path")?;
        let mut head = None;
        let mut revision = None;
        let mut cache = None;
        let mut packed_draft = None;
        for requested in ["", missing] {
            let NativeChatModel::Flash(target) = &mut model else {
                unreachable!();
            };
            target.configure_dflash2(Some(&draft), 1)?;
            assert!(target.dflash2_active(), "fixture must own a live draft");
            // This exact preparer is used by generate and set_mtp. Rejection of
            // an invalid MTP path must happen after retiring the previous mode.
            assert!(
                load_mtp_head(
                    &mut head,
                    &mut revision,
                    &mut cache,
                    requested,
                    &mut model,
                    &mut packed_draft,
                )
                .is_err()
            );
            assert!(matches!(&model, NativeChatModel::Flash(target) if !target.dflash2_active()));
            assert!(head.is_none() && revision.is_none() && cache.is_none());
            assert!(packed_draft.is_none());
            model.reset();
            let actual = model.forward(0)?.to_f32()?;
            assert_eq!(actual.len(), baseline.len());
            assert!(actual.iter().all(|x| x.is_finite()));
            assert!(
                actual
                    .iter()
                    .zip(&baseline)
                    .all(|(a, b)| a.to_bits() == b.to_bits()),
                "ordinary target logits changed after a failed mode switch"
            );
            model.reset();
        }
        mlxl3_native::array::synchronize()?;
        Ok(())
    }

    #[test]
    fn dflash_width_tracks_recent_acceptance() {
        let mut session = DFlashChat::new();
        session.blocks = 16;
        session.accepted = 48;
        session.proposed = 80;
        session.recent = std::iter::repeat_n((1, 5), 8).collect();
        assert_eq!(session.proposals_count(128, 128), Some(2));
        session.recent = std::iter::repeat_n((4, 5), 7).collect();
        assert_eq!(session.proposals_count(128, 128), Some(5));
        session.recent.push_back((4, 5));
        assert_eq!(session.proposals_count(128, 128), Some(5));
        assert_eq!(session.proposals_count(2, 128), Some(1));
        session.mode = 2;
        assert_eq!(session.proposals_count(128, 128), Some(2));
    }

    #[test]
    fn native_sampler_respects_greedy_argmax() {
        let logits = mlxl3_native::array::Array::from_f32(&[1., 4., 2.], &[1, 3]).unwrap();
        let mut random = 1;
        assert_eq!(
            select_token(&logits, &[], 0., 0, 1., &mut random).unwrap(),
            1
        );
    }

    #[test]
    fn bridge_token_hash_uses_ordered_token_ids() {
        assert_eq!(token_hash(&[]), "cbf29ce484222325");
        assert_ne!(token_hash(&[1, 2]), token_hash(&[2, 1]));
    }

    #[test]
    fn dflash_runtime_key_distinguishes_copy_policy() {
        assert_eq!(
            dflash_runtime_key("model:runtime", false),
            "model:runtime:dflash-v4:copy=0"
        );
        assert_eq!(
            dflash_runtime_key("model:runtime", true),
            "model:runtime:dflash-v4:copy=1"
        );
        assert!(!dflash_context_copy_enabled(None));
        assert!(!dflash_context_copy_enabled(Some(
            mlxl3_native::dflash::Family::Qwen38Dense
        )));
    }

    #[test]
    fn bridge_stats_aggregate_work_not_rates_and_keep_latest_context() {
        let mut first = NativeStats {
            ttft_seconds: 0.5,
            prompt_tokens: 100,
            evaluated_prompt_tokens: 100,
            generated_tokens: 11,
            prefill_seconds: 0.25,
            decode_seconds: 1.,
            decode_tokens: 10,
            round_count: 1,
            dflash_profile: Some(mlxl3_native::qwen4::FlashDraftProfile {
                draft_seconds: 0.25,
                verification_seconds: 0.5,
                commit_cache_seconds: 0.125,
                verified_rows: 12,
                drafted_rows: 16,
                drafted_widths: [1, 2, 3, 4, 5, 6, 7, 8],
                verified_widths: [1, 2, 3, 4, 5, 6, 7, 8],
                expert_demand_bytes: 1_248_012,
                ssd_prefetch: [1, 2, 3, 4, 5, 6, 7, 8],
            }),
            dflash_proposed_tokens: Some(10),
            dflash_accepted_tokens: Some(6),
            dflash_blocks: Some(2),
            dflash_lookup_blocks: Some(1),
            mtp_lookup_blocks: Some(3),
            ..Default::default()
        };
        first.accumulate(&NativeStats {
            ttft_seconds: 2.,
            prompt_tokens: 200,
            evaluated_prompt_tokens: 200,
            generated_tokens: 31,
            prefill_seconds: 0.75,
            decode_seconds: 1.5,
            decode_tokens: 30,
            context_used: 231,
            context_limit: 4096,
            round_count: 1,
            dflash_profile: Some(mlxl3_native::qwen4::FlashDraftProfile {
                draft_seconds: 0.125,
                verification_seconds: 1.,
                commit_cache_seconds: 0.125,
                verified_rows: 48,
                drafted_rows: 64,
                drafted_widths: [8, 7, 6, 5, 4, 3, 2, 1],
                verified_widths: [8, 7, 6, 5, 4, 3, 2, 1],
                expert_demand_bytes: 2_496_024,
                ssd_prefetch: [8, 7, 6, 5, 4, 3, 2, 1],
            }),
            dflash_proposed_tokens: Some(40),
            dflash_accepted_tokens: Some(22),
            dflash_blocks: Some(8),
            dflash_lookup_blocks: Some(3),
            mtp_lookup_blocks: Some(4),
            ..Default::default()
        });
        assert_eq!(
            (
                first.prompt_tokens,
                first.generated_tokens,
                first.round_count
            ),
            (300, 42, 2)
        );
        assert_eq!(
            (first.prefill_tps, first.decode_tps, first.ttft_seconds),
            (300., 16., 0.5)
        );
        assert_eq!((first.context_used, first.context_limit), (231, 4096));
        assert_eq!(first.mtp_lookup_blocks, Some(7));
        assert_eq!(first.dflash_lookup_blocks, Some(4));
        let profile = first.dflash_profile.unwrap();
        assert_eq!(
            (
                profile.draft_seconds,
                profile.verification_seconds,
                profile.commit_cache_seconds
            ),
            (0.375, 1.5, 0.25)
        );
        assert_eq!(
            (profile.verified_rows, profile.expert_demand_bytes),
            (60, 3_744_036)
        );
        let encoded = serde_json::to_value(&first).unwrap();
        assert_eq!(encoded["dflash_profile"]["verified_rows"], 60);
        assert_eq!(encoded["dflash_profile"]["verification_seconds"], 1.5);
        assert_eq!(profile.ssd_prefetch, [9; 8]);
        assert_eq!(profile.drafted_rows, 80);
        assert_eq!(profile.drafted_widths, [9; 8]);
        assert_eq!(profile.verified_widths, [9; 8]);
        assert_eq!(
            encoded["dflash_profile"]["ssd_prefetch"],
            serde_json::to_value([9; 8]).unwrap()
        );
        assert_eq!(
            (
                first.dflash_proposed_tokens,
                first.dflash_accepted_tokens,
                first.dflash_blocks
            ),
            (Some(50), Some(28), Some(10))
        );
    }

    #[test]
    #[ignore = "requires local Qwen/MTP checkpoints, MLXL3_MTP_LOOKUP=1 and Apple GPU"]
    fn bridge_lookup_seeds_prompt_and_preserves_budget_and_prefix() -> Result<()> {
        use mlxl3_native::{mtp::Head, tokenizer::ChatTokenizer};
        anyhow::ensure!(
            std::env::var("MLXL3_MTP_LOOKUP").as_deref() == Ok("1"),
            "run this test with MLXL3_MTP_LOOKUP=1"
        );
        let path = std::path::PathBuf::from(
            std::env::var("MLXL3_MTP_TEST_MODEL")
                .unwrap_or_else(|_| "models/Qwen3.6-35B-A3B-EXL3-2.49bpw".into()),
        );
        let mut model = NativeChatModel::load(&path)?;
        let tokenizer = ChatTokenizer::load(&path)?;
        let NativeChatModel::Qwen(target) = &model else {
            bail!("requires Qwen target")
        };
        let mut head = ChatMtpHead::Qwen(Box::new(Head::load(
            std::path::Path::new(
                &std::env::var("MLXL3_MTP_TEST_HEAD")
                    .unwrap_or_else(|_| "models/Qwen3.6-35B-A3B-MTP-4bit".into()),
            ),
            target,
        )?));
        let code = "def normalize_name(value):\n    return value.strip().casefold()\n\ndef average(values):\n    return sum(values) / len(values) if values else 0\n\n";
        let messages = vec![json!({"role":"user", "content":format!(
            "Recopie exactement le code suivant, sans commentaire ni changement :\n```python\n{}```", code.repeat(8))})];
        let cancelled = AtomicBool::new(false);
        let mut cache = None;
        let mut random = 7;
        let mut lookup_blocks = 0;
        let copy_budget = std::env::var("MLXL3_MTP_TEST_COPY_BUDGET")
            .ok()
            .map(|value| value.parse::<i64>())
            .transpose()?
            .unwrap_or(256);
        anyhow::ensure!(
            (256..=1024).contains(&copy_budget),
            "copy test budget must be 256..1024"
        );
        for budget in [1, 2, 3, 17, copy_budget] {
            let baseline = bridge_generate_round(
                &mut model,
                &tokenizer,
                "lookup-reference",
                &messages,
                &[],
                budget,
                0.,
                1,
                1.,
                4096,
                0.,
                &cancelled,
                &mut random,
                None,
                None,
                1,
                1,
                &mut cache,
                "lookup",
                false,
                false,
            )?;
            assert!(!baseline.raw.is_empty());
            assert!(
                baseline.stats.generated_tokens > 0
                    && baseline.stats.generated_tokens <= budget as usize
            );
            for depth in 1..=3 {
                for pass in 0..2 {
                    let actual = bridge_generate_round(
                        &mut model,
                        &tokenizer,
                        "lookup-candidate",
                        &messages,
                        &[],
                        budget,
                        0.,
                        1,
                        1.,
                        4096,
                        0.,
                        &cancelled,
                        &mut random,
                        None,
                        Some(&mut head),
                        depth,
                        1,
                        &mut cache,
                        "lookup",
                        true,
                        false,
                    )?;
                    assert_eq!(actual.raw, baseline.raw);
                    assert_eq!(actual.token_hash, baseline.token_hash);
                    assert_eq!(
                        actual.stats.generated_tokens,
                        baseline.stats.generated_tokens
                    );
                    lookup_blocks += actual.stats.mtp_lookup_blocks.unwrap();
                    // The second request at each depth can reuse the exact prefix.
                    if pass == 1 {
                        assert!(actual.stats.cached_prompt_tokens >= 256);
                    }
                }
            }
        }
        assert!(
            lookup_blocks > 0,
            "the production prompt must exercise lookup drafting"
        );
        let messages = vec![json!({"role":"user", "content":
            "Write complete Python code for a strict JSON Lines reader. Reject malformed records with the line number, bound record sizes, and include a small example. Explain the failure cases."})];
        let mut run = |mtp| {
            bridge_generate_round(
                &mut model,
                &tokenizer,
                "lookup-no-break",
                &messages,
                &[],
                128,
                0.,
                1,
                1.,
                4096,
                0.,
                &cancelled,
                &mut random,
                None,
                mtp,
                2,
                1,
                &mut cache,
                "lookup",
                false,
                false,
            )
        };
        let baseline = run(None)?;
        let actual = run(Some(&mut head))?;
        assert!(!actual.raw.is_empty());
        assert_eq!(actual.raw, baseline.raw);
        assert_eq!(actual.token_hash, baseline.token_hash);
        assert_eq!(actual.stats.generated_tokens, 128);
        assert_eq!(
            actual.stats.mtp_lookup_blocks,
            Some(0),
            "do not draft an in-line reformulation"
        );
        eprintln!(
            "production lookup: 37 nonempty completions, {lookup_blocks} copy lookup blocks; in-line echo skipped"
        );
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen/DFlash checkpoints and Apple GPU"]
    fn dflash_copy_accepts_rejects_and_preserves_draft_cache() -> Result<()> {
        use mlxl3_native::{dflash::DFlashWeights, speculative::DFlashCopy};
        let path = std::path::Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw");
        let mut target = mlxl3_native::qwen35::Qwen35Moe::load(path)?;
        let weights = DFlashWeights::load(&mlxl3_native::dflash::inspect(
            "models/Qwen3.6-35B-A3B-DFlash2",
        )?)?;
        let prompt = (1..=24).collect::<Vec<u32>>();
        let finite_bytes = |array: &mlxl3_native::array::Array| -> Result<Vec<u8>> {
            let values = array.to_f32()?;
            let count = array.shape().iter().try_fold(1usize, |count, &dim| {
                count.checked_mul(usize::try_from(dim).ok()?)
            });
            anyhow::ensure!(
                count == Some(values.len())
                    && !values.is_empty()
                    && values.iter().all(|v| v.is_finite()),
                "invalid copy oracle array"
            );
            array.to_bytes()
        };
        let mut cases = 0;
        for width in 1..=3 {
            for accepted in 0..=width {
                target.reset();
                let mut session = DFlashChat::new();
                let anchor = session
                    .prefill(&mut target, &weights, &prompt)?
                    .chat_greedy_ids()?[0];
                let before = target.snapshot()?;
                let mut reference_cache = session.cache.try_clone()?;
                let mut caches = Vec::new();
                let mut expected = Vec::new();
                let mut token = anchor;
                for _ in 0..width + 2 {
                    let position = target.offset();
                    let (logits, captures) = target.prefill_serial_with_dflash_capture(&[token])?;
                    reference_cache.append_captured(&weights, &captures, position)?;
                    reference_cache.eval()?;
                    token = logits.chat_greedy_ids()?[0];
                    expected.push(token);
                    caches.push(reference_cache.try_clone()?);
                }
                target.restore(before)?;
                let mut proposals = expected[..width].to_vec();
                if accepted < width {
                    proposals[accepted] = (proposals[accepted] + 1) % 248_320;
                }
                let history = (1..=7)
                    .chain([anchor])
                    .chain(proposals.iter().copied())
                    .chain(1..=7)
                    .collect::<Vec<_>>();
                session.copy = Some(DFlashCopy::new(&history));
                assert_eq!(
                    session.copy.as_ref().unwrap().propose(anchor, width),
                    Some(proposals.as_slice())
                );
                let mut delivered = Vec::new();
                for i in 0..=accepted {
                    delivered.push(session.advance(
                        &mut target,
                        &weights,
                        if i == 0 { anchor } else { delivered[i - 1] },
                        4096,
                        width + 1 - i,
                    )?);
                }
                assert_eq!(delivered, expected[..=accepted]);
                assert_eq!(session.lookup_blocks, 1);
                assert!(session.pending.is_empty());
                assert_eq!(target.offset(), 24 + accepted as i32 + 1);
                let input =
                    target.dflash_input(*delivered.last().unwrap(), weights.family.mask())?;
                let actual = weights.forward_hidden(&input, &session.cache, target.offset())?;
                let oracle = weights.forward_hidden(&input, &caches[accepted], target.offset())?;
                assert_eq!(finite_bytes(&actual.hidden)?, finite_bytes(&oracle.hidden)?);
                assert_eq!(
                    finite_bytes(&actual.selector)?,
                    finite_bytes(&oracle.selector)?
                );
                let next =
                    session.advance(&mut target, &weights, *delivered.last().unwrap(), 4096, 4)?;
                assert_eq!(
                    next,
                    expected[accepted + 1],
                    "neural continuation after copy"
                );
                cases += 1;
            }
        }
        assert_eq!(cases, 9);
        eprintln!(
            "9 production copy blocks, all accept0..N/N1..3, finite hidden/selector and draft cache bit exact; neural continuation exact"
        );
        Ok(())
    }

    #[test]
    #[ignore = "requires Qwen/DFlash checkpoints, MLXL3_DFLASH_CONTEXT_COPY=1 and Apple GPU"]
    fn bridge_dflash_copy_seeds_prompt_and_preserves_budget_and_prefix() -> Result<()> {
        anyhow::ensure!(
            dflash_context_copy_enabled(Some(mlxl3_native::dflash::Family::Qwen36Moe)),
            "run with MLXL3_DFLASH_CONTEXT_COPY=1"
        );
        let path = std::path::Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw");
        let mut model = NativeChatModel::load(path)?;
        let tokenizer = mlxl3_native::tokenizer::ChatTokenizer::load(path)?;
        let weights = mlxl3_native::dflash::DFlashWeights::load(&mlxl3_native::dflash::inspect(
            "models/Qwen3.6-35B-A3B-DFlash2",
        )?)?;
        let code = "def normalize_name(value):\n    return value.strip().casefold()\n\ndef average(values):\n    return sum(values) / len(values) if values else 0\n\n";
        let messages = vec![
            json!({"role":"user", "content":format!("Recopie exactement le code suivant, sans commentaire ni changement :\n```python\n{}```", code.repeat(8))}),
        ];
        let cancelled = AtomicBool::new(false);
        let mut cache = None;
        let mut random = 7;
        let mut copies = 0;
        let mut completions = 0;
        for budget in [1, 2, 3, 17, 256] {
            let reference = bridge_generate_round(
                &mut model,
                &tokenizer,
                "copy-reference",
                &messages,
                &[],
                budget,
                0.,
                1,
                1.,
                4096,
                0.,
                &cancelled,
                &mut random,
                None,
                None,
                1,
                1,
                &mut cache,
                "dflash-copy",
                false,
                false,
            )?;
            assert!(
                !reference.raw.is_empty()
                    && reference.stats.generated_tokens > 0
                    && reference.stats.generated_tokens <= budget as usize
            );
            for mode in 1..=3 {
                for pass in 0..2 {
                    let actual = bridge_generate_round(
                        &mut model,
                        &tokenizer,
                        "copy-candidate",
                        &messages,
                        &[],
                        budget,
                        0.,
                        1,
                        1.,
                        4096,
                        0.,
                        &cancelled,
                        &mut random,
                        Some(&weights),
                        None,
                        1,
                        mode,
                        &mut cache,
                        "dflash-copy",
                        true,
                        false,
                    )?;
                    assert_eq!(actual.raw, reference.raw);
                    assert_eq!(actual.token_hash, reference.token_hash);
                    assert_eq!(
                        actual.stats.generated_tokens,
                        reference.stats.generated_tokens
                    );
                    if pass == 1 {
                        assert!(actual.stats.cached_prompt_tokens >= 256);
                    }
                    let count = actual.stats.dflash_lookup_blocks.unwrap();
                    if mode != 1 {
                        assert_eq!(count, 0, "fixed modes keep their neural proposals");
                    }
                    copies += count;
                    completions += 1;
                }
            }
            completions += 1;
        }
        assert_eq!(completions, 35);
        assert!(copies > 0, "the production bridge must actually copy");
        eprintln!(
            "35 nonempty completions with budgets/cache/Auto/fixed modes exact; {copies} verified copy blocks"
        );
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen and DFlash checkpoints and Apple GPU"]
    fn bridge_draft_suffix_keeps_full_prefill_and_replay() -> Result<()> {
        use mlxl3_native::{array::memory_stats, dflash::PREFILL_CHUNK, tokenizer::ChatTokenizer};
        let path = std::path::Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw");
        let mut model = NativeChatModel::load(path)?;
        let tokenizer = ChatTokenizer::load(path)?;
        let package = mlxl3_native::dflash::inspect("models/Qwen3.6-35B-A3B-DFlash2")?;
        let weights = mlxl3_native::dflash::DFlashWeights::load(&package)?;
        let cancelled = AtomicBool::new(false);
        let suffix = tokenizer.encode(&tokenizer.render_values(
            &json!([{"role":"user", "content":"Explain how a KV cache reduces latency."}]),
            None,
        )?)?;
        let mut run = |tokens: &[u32], optimized: bool| -> Result<_> {
            model.reset();
            let _ = memory_stats(true)?;
            let started = Instant::now();
            let (logits, mut session) = if optimized {
                let (logits, session, cached) = prefill_round(
                    &mut model,
                    tokens,
                    Some(&weights),
                    &mut None,
                    "long",
                    false,
                    &cancelled,
                )?;
                assert_eq!(cached, 0);
                (logits, session.unwrap())
            } else {
                // Original prefill: every target chunk is captured/projected,
                // including the draft KV subsequently thrown away by its window.
                let mut session = DFlashChat::new();
                let mut logits = None;
                for chunk in tokens.chunks(PREFILL_CHUNK) {
                    let NativeChatModel::Qwen(target) = &mut model else {
                        unreachable!()
                    };
                    logits = Some(session.prefill(target, &weights, chunk)?);
                    model.eval_state()?;
                }
                (logits.unwrap(), session)
            };
            logits.eval()?;
            let seconds = started.elapsed().as_secs_f64();
            let memory = memory_stats(false)?;
            let first_logits = logits.to_f16_bits()?;
            let mut generated = vec![logits.chat_greedy_ids()?[0]];
            let NativeChatModel::Qwen(target) = &mut model else {
                unreachable!()
            };
            assert_eq!(
                usize::try_from(target.offset())?,
                tokens.len(),
                "target must read the whole prompt"
            );
            let draft = weights.forward_hidden(
                &target.dflash_input(generated[0], 248_077)?,
                &session.cache,
                target.offset(),
            )?;
            let features = (draft.hidden.to_bytes()?, draft.selector.to_bytes()?);
            while generated.len() < 32 {
                let next = session.advance(
                    target,
                    &weights,
                    *generated.last().unwrap(),
                    16_384,
                    32 - generated.len(),
                )?;
                generated.push(next);
            }
            Ok((
                first_logits,
                features,
                generated,
                session.proposed,
                session.accepted,
                seconds,
                memory,
            ))
        };
        for length in [2047, 2048, 2049, 4096, 4097, 8192] {
            let tokens: Vec<u32> = (0..length - suffix.len())
                .map(|i| (i % 97 + 1) as u32)
                .chain(suffix.iter().copied())
                .collect();
            let baseline = run(&tokens, false)?;
            let candidate = run(&tokens, true)?;
            assert_eq!(candidate.0, baseline.0, "prefill logits at {length}");
            assert_eq!(candidate.1, baseline.1, "draft features at {length}");
            assert_eq!(candidate.2, baseline.2, "generation at {length}");
            assert_eq!(
                (candidate.3, candidate.4),
                (baseline.3, baseline.4),
                "acceptance at {length}"
            );
            eprintln!(
                "suffix bridge parity {length}: 32 IDs, logits, draft features and acceptance exact"
            );
            if length == 4096 || length == 8192 {
                let mut times = [Vec::new(), Vec::new()];
                for optimized in [false, true, true, false] {
                    let sample = run(&tokens, optimized)?;
                    assert_eq!(sample.2, baseline.2);
                    eprintln!(
                        "suffix prefill {length}, optimized={optimized}: {:.3} s, memory {}",
                        sample.5,
                        serde_json::to_string(&sample.6)?
                    );
                    times[usize::from(optimized)].push(sample.5);
                }
                eprintln!(
                    "suffix prefill {length} median: {:.3} -> {:.3} s",
                    (times[0][0] + times[0][1]) / 2.,
                    (times[1][0] + times[1][1]) / 2.
                );
            }
        }
        // A partial final chunk must not leave the saved checkpoint with an
        // incomplete draft window. Extend that checkpoint after live decode.
        let tokens: Vec<u32> = (0..4097).map(|i| (i % 97 + 1) as u32).collect();
        let mut saved = None;
        prefill_round(
            &mut model,
            &tokens,
            Some(&weights),
            &mut saved,
            "replay",
            true,
            &cancelled,
        )?;
        assert!(
            saved.is_some(),
            "fixture must exercise an actual saved prefix"
        );
        model.forward(37)?.eval()?;
        let extended: Vec<_> = tokens
            .iter()
            .copied()
            .chain(suffix.iter().copied())
            .collect();
        let (warm, mut session, cached) = prefill_round(
            &mut model,
            &extended,
            Some(&weights),
            &mut saved,
            "replay",
            true,
            &cancelled,
        )?;
        assert_eq!(cached, 4096);
        let mut actual = vec![warm.chat_greedy_ids()?[0]];
        let NativeChatModel::Qwen(target) = &mut model else {
            unreachable!()
        };
        while actual.len() < 32 {
            actual.push(session.as_mut().unwrap().advance(
                target,
                &weights,
                *actual.last().unwrap(),
                16_384,
                32 - actual.len(),
            )?);
        }
        // Compare to the independent full-capture baseline above, not a second
        // call to the new suffix-only policy.
        let NativeChatModel::Qwen(target) = &mut model else {
            unreachable!()
        };
        target.reset();
        let mut reference = DFlashChat::new();
        let mut logits = None;
        for chunk in extended.chunks(PREFILL_CHUNK) {
            logits = Some(reference.prefill(target, &weights, chunk)?);
        }
        let mut expected = vec![logits.unwrap().chat_greedy_ids()?[0]];
        while expected.len() < 32 {
            expected.push(reference.advance(
                target,
                &weights,
                *expected.last().unwrap(),
                16_384,
                32 - expected.len(),
            )?);
        }
        assert_eq!(actual, expected, "long prefix replay changed tokens");
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen and DFlash checkpoints and Apple GPU"]
    fn long_prompt_dflash_blocks_match_target() -> Result<()> {
        use mlxl3_native::tokenizer::ChatTokenizer;
        let path = std::path::Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw");
        let mut model = NativeChatModel::load(path)?;
        let tokenizer = ChatTokenizer::load(path)?;
        let prompt = std::fs::read_to_string("docs/audit-runtime-2026-09-04.md")?;
        let rendered =
            tokenizer.render_values(&json!([{"role":"user", "content":prompt}]), None)?;
        let tokens = tokenizer.encode(&rendered)?;
        assert_eq!(tokens.len(), 2825);
        let package = mlxl3_native::dflash::inspect("models/Qwen3.6-35B-A3B-DFlash2")?;
        let weights = mlxl3_native::dflash::DFlashWeights::load(&package)?;
        let cancelled = AtomicBool::new(false);
        let (mut logits, _, _) = prefill_round(
            &mut model, &tokens, None, &mut None, "normal", false, &cancelled,
        )?;
        let normal_prefill = logits.to_f16_bits()?;
        let NativeChatModel::Qwen(target) = &mut model else {
            unreachable!()
        };
        let mut reference = target.snapshot()?;
        let mut expected = Vec::new();
        while expected.len() < 128 {
            let next = logits.chat_greedy_ids()?[0];
            expected.push(next);
            if expected.len() < 128 {
                logits = target.forward(next)?;
            }
        }
        let (logits, session, _) = prefill_round(
            &mut model,
            &tokens,
            Some(&weights),
            &mut None,
            "dflash",
            false,
            &cancelled,
        )?;
        assert_eq!(logits.to_f16_bits()?, normal_prefill);
        let mut session = session.context("missing DFlash session")?;
        let mut generated = vec![logits.chat_greedy_ids()?[0]];
        assert_eq!(generated[0], expected[0]);
        let NativeChatModel::Qwen(target) = &mut model else {
            unreachable!()
        };
        let mut block = 0;
        while generated.len() < expected.len() {
            let anchor = *generated.last().unwrap();
            let before = target.offset();
            let accepted_before = session.accepted;
            let next = session.advance(
                target,
                &weights,
                anchor,
                8192,
                expected.len() - generated.len(),
            )?;
            if target.offset() > before {
                block += 1;
                let accepted = session.accepted - accepted_before;
                let mut committed = vec![anchor];
                if accepted > 0 {
                    committed.push(next);
                    committed.extend(session.pending.iter().take(accepted - 1).copied());
                }
                assert_eq!(target.offset() - before, committed.len() as i32);
                let speculative = target.snapshot()?;
                target.restore(reference)?;
                for token in committed {
                    target.forward(token)?;
                }
                reference = target.snapshot()?;
                target.restore(speculative.clone())?;
                let actual = target.forward(42)?.to_f16_bits()?;
                target.restore(reference.clone())?;
                let expected_logits = target.forward(42)?.to_f16_bits()?;
                target.restore(speculative)?;
                anyhow::ensure!(
                    actual == expected_logits,
                    "DFlash target state differs after block {block}, offset {}",
                    target.offset()
                );
            }
            anyhow::ensure!(
                next == expected[generated.len()],
                "DFlash token differs at index {}, block {block}",
                generated.len()
            );
            generated.push(next);
        }
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen and DFlash checkpoints and Apple GPU"]
    fn dflash_output_budget_matches_target_and_skips_unused_work() -> Result<()> {
        use mlxl3_native::{qwen35::Qwen35Moe, tokenizer::ChatTokenizer};
        let path = std::path::Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw");
        let mut model = Qwen35Moe::load(path)?;
        let tokenizer = ChatTokenizer::load(path)?;
        let package = mlxl3_native::dflash::inspect("models/Qwen3.6-35B-A3B-DFlash2")?;
        let weights = mlxl3_native::dflash::DFlashWeights::load(&package)?;
        for prompt in [
            "Explain lossless speculative decoding in one paragraph.",
            "Write a Rust function to add two integers.",
        ] {
            let rendered =
                tokenizer.render_values(&json!([{"role":"user", "content":prompt}]), None)?;
            let tokens = tokenizer.encode(&rendered)?;
            model.reset();
            let mut logits = model.forward_tokens(&tokens)?;
            // Independent, non-speculative target sequence. Deliberately don't
            // stop at EOS: stopping at every prefix also exercises early stops.
            let mut expected = Vec::new();
            for _ in 0..16 {
                let token = logits.chat_greedy_ids()?[0];
                expected.push(token);
                logits = model.forward(token)?;
            }
            let mut run = |budget: usize, bounded: bool, tight_context: bool| -> Result<f64> {
                model.reset();
                let mut session = DFlashChat::new();
                let first = session
                    .prefill(&mut model, &weights, &tokens)?
                    .chat_greedy_ids()?[0];
                let mut actual = vec![first];
                let context = if tight_context {
                    tokens.len() + budget
                } else {
                    4096
                };
                let started = Instant::now();
                while actual.len() < budget {
                    let remaining = if bounded {
                        budget - actual.len()
                    } else {
                        usize::MAX
                    };
                    let token = session.advance(
                        &mut model,
                        &weights,
                        *actual.last().unwrap(),
                        context,
                        remaining,
                    )?;
                    actual.push(token);
                }
                let elapsed = started.elapsed().as_secs_f64();
                assert_eq!(
                    actual,
                    expected[..budget],
                    "budget {budget}, bounded {bounded}"
                );
                if bounded {
                    assert!(
                        session.pending.is_empty(),
                        "no computed tokens may be left past the output limit"
                    );
                    assert_eq!(usize::try_from(model.offset())?, tokens.len() + budget - 1);
                }
                let position = model.offset();
                let pending = session.pending.clone();
                assert!(
                    session
                        .advance(&mut model, &weights, first, context, 0)
                        .is_err()
                );
                assert_eq!(
                    model.offset(),
                    position,
                    "invalid budget must not mutate state"
                );
                assert_eq!(session.pending, pending);
                Ok(elapsed)
            };
            // All prefixes, including abandoned pending from the old algorithm,
            // start the next request from a fresh prefill in the same model.
            for budget in 1..=16 {
                run(budget, false, false)?;
                run(budget, true, false)?;
                run(budget, true, true)?;
            }
            for budget in [2, 4, 6, 16] {
                let mut times = [Vec::new(), Vec::new()];
                for bounded in [false, true, true, false, false, true, true, false] {
                    times[usize::from(bounded)].push(run(budget, bounded, false)? * 1000.);
                }
                for samples in &mut times {
                    samples.sort_by(f64::total_cmp);
                }
                eprintln!(
                    "output budget {budget} ({prompt}): unbounded {:.3} -> bounded {:.3} ms",
                    (times[0][1] + times[0][2]) / 2.,
                    (times[1][1] + times[1][2]) / 2.
                );
            }
        }
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen and DFlash checkpoints and Apple GPU"]
    fn bridge_prefix_cache_replays_cold_logits_exactly() -> Result<()> {
        let mut model =
            NativeChatModel::load(std::path::Path::new("models/Qwen3.6-35B-A3B-EXL3-2.49bpw"))?;
        let package = mlxl3_native::dflash::inspect("models/Qwen3.6-35B-A3B-DFlash2")?;
        let weights = mlxl3_native::dflash::DFlashWeights::load(&package)?;
        let cancelled = AtomicBool::new(false);
        let mut cache = None;
        for draft in [None, Some(&weights)] {
            let block = if draft.is_some() { 128 } else { 256 };
            let original: Vec<u32> = (0..block + 17)
                .map(|index| (index % 97 + 1) as u32)
                .collect();
            let (cold, _, count) = prefill_round(
                &mut model, &original, draft, &mut cache, "a", true, &cancelled,
            )?;
            assert_eq!(count, 0, "mode switch must miss");
            let cold = cold.to_f16_bits()?;
            model.forward(51)?.eval()?; // Live decode may be ahead of the saved prefix.
            let (replay, _, count) = prefill_round(
                &mut model, &original, draft, &mut cache, "a", true, &cancelled,
            )?;
            assert_eq!(count, block);
            assert_eq!(replay.to_f16_bits()?, cold);
            for suffix in [0, 1, 23, 24, 25] {
                let extended: Vec<_> = original[..block]
                    .iter()
                    .copied()
                    .chain(std::iter::repeat_n(42, suffix))
                    .collect();
                let (expected, _, _) = prefill_round(
                    &mut model, &extended, draft, &mut None, "a", false, &cancelled,
                )?;
                let expected = expected.to_f16_bits()?;
                let (actual, _, count) = prefill_round(
                    &mut model, &extended, draft, &mut cache, "a", true, &cancelled,
                )?;
                assert_eq!(count, block);
                assert_eq!(
                    actual.to_f16_bits()?,
                    expected,
                    "prefill suffix {suffix}, DFlash {}",
                    draft.is_some()
                );
            }
            let mut edited = original.clone();
            edited[0] += 1;
            let (_, _, count) = prefill_round(
                &mut model, &edited, draft, &mut cache, "a", true, &cancelled,
            )?;
            assert_eq!(count, 0, "edited history must miss");
            let (_, _, count) = prefill_round(
                &mut model, &edited, draft, &mut cache, "b", true, &cancelled,
            )?;
            assert_eq!(count, 0, "conversation switch must miss");
            cancelled.store(true, Ordering::Relaxed);
            assert!(
                prefill_round(
                    &mut model, &edited, draft, &mut cache, "b", true, &cancelled
                )
                .is_err()
            );
            cancelled.store(false, Ordering::Relaxed);
            let (_, _, count) = prefill_round(
                &mut model, &edited, draft, &mut cache, "b", false, &cancelled,
            )?;
            assert_eq!(count, 0);
            assert!(cache.is_none(), "cache OFF must release the saved state");
        }
        Ok(())
    }
}

#[cfg(all(
    test,
    feature = "chat",
    any(feature = "mlx", all(target_os = "macos", feature = "direct-metal"))
))]
mod device_greedy_stats_tests {
    use super::*;
    #[test]
    fn scalar_selector_stats_are_optional_and_accumulate_actual_work() {
        let mut stats = NativeStats::default();
        assert!(
            serde_json::to_value(&stats)
                .unwrap()
                .get("native_gpu_greedy_selections")
                .is_none()
        );
        stats.accumulate(&NativeStats {
            native_gpu_greedy_selections: Some(2),
            native_gpu_greedy_heads: Some(1),
            ..Default::default()
        });
        stats.accumulate(&NativeStats::default());
        stats.accumulate(&NativeStats {
            native_gpu_greedy_selections: Some(3),
            native_gpu_greedy_heads: Some(2),
            ..Default::default()
        });
        assert_eq!(stats.native_gpu_greedy_selections, Some(5));
        assert_eq!(stats.native_gpu_greedy_heads, Some(3));
        let encoded = serde_json::to_value(&stats).unwrap();
        assert_eq!(encoded["native_gpu_greedy_selections"], 5);
        assert_eq!(encoded["native_gpu_greedy_heads"], 3);
    }
}
