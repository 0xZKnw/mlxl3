    pub fn append_captured(
        &mut self,
        weights: &DFlashWeights,
        captured: &crate::array::Array,
        start_position: i32,
    ) -> Result<()> {
        use crate::array::{Array, Dtype};

        ensure!(
            captured.shape().len() == 2
                && captured.shape()[0] > 0
                && captured.shape()[1] == weights.family.target_hidden() as i32
                && captured.dtype() == Dtype::BFloat16
                && start_position >= 0,
            "invalid DFlash captured context"
        );
        if self.layers.is_empty() {
            self.layers = std::iter::repeat_with(|| None)
                .take(weights.layers.len())
                .collect();
        }
        ensure!(
            self.layers.len() == weights.layers.len(),
            "DFlash cache belongs to another draft"
        );
        ensure!(
            start_position.checked_add(captured.shape()[0]).is_some(),
            "DFlash capture position overflow"
        );
        let rows = captured.shape()[0];
        for begin in (0..rows).step_by(8) {
            let count = (rows - begin).min(8);
            let block = captured.slice(0, begin, begin + count)?;
            let block = if count == 8 {
                block
            } else {
                Array::concatenate(
                    &[
                        &block,
                        &Array::zeros_dtype(
                            &[8 - count, weights.family.target_hidden() as i32],
                            Dtype::BFloat16,
                        )?,
                    ],
                    0,
                )?
            };
            let hidden = weights
                .context_projection
                .forward(&block, Q4Kernel::N128Pipelined, 16)?
                .rms_norm(&weights.hidden_norm, 1e-6)?;
            for (index, layer) in weights.layers.iter().enumerate() {
                let kv =
                    layer
                        .qkv
                        .forward_range(&hidden, Q4Kernel::N128Pipelined, 16, 4096, 6144)?;
                let keys = kv
                    .slice(1, 0, 1024)?
                    .reshape(&[1, 8, 8, 128])?
                    .rms_norm(&layer.key_norm, 1e-6)?
                    .transpose(&[0, 2, 1, 3])?
                    .rope(128, 10_000_000.0, start_position + begin)?
                    .slice(2, 0, count)?;
                let values = kv
                    .slice(1, 1024, 2048)?
                    .reshape(&[1, 8, 8, 128])?
                    .transpose(&[0, 2, 1, 3])?
                    .slice(2, 0, count)?;
                let (keys, values) = match &self.layers[index] {
                    Some(previous) => (
                        Array::concatenate(&[&previous.keys, &keys], 2)?,
                        Array::concatenate(&[&previous.values, &values], 2)?,
                    ),
                    None => (keys, values),
                };
                let length = keys.shape()[2];
                let first = (length - CONTEXT_WINDOW as i32).max(0);
                self.layers[index] = Some(DFlashCacheLayer {
                    keys: keys.slice(2, first, length)?,
                    values: values.slice(2, first, length)?,
                });
            }
        }
        Ok(())
    }

