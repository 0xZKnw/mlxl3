# Q27-19 — patch préparé, pas appliqué ni exécuté par cet agent

Sept fichiers Rust/MSL. Aucun poids modifié. Aucun gain global annoncé.
Manifest : manifest.json. Les copies candidate ne valident pas un moteur construit.

## Application après retrait18

Ne pas remplacer contracts.rs par la copie candidate : sa baseline contient encore le garde18.

1. Vérifier les before_sha256 des six autres fichiers.
2. Appliquer les hunks de without-contracts.patch.
3. Ajouter exactement une fois contracts-addition.rs à la fin du contracts.rs courant, en préservant tous ses autres changements.
4. Lire le diff et exécuter format/checks avant toute inférence.

Le patch complet prototype.patch fonctionne seulement sur la baseline correspondante. Il ne faut pas restaurer la copie complète contracts.rs lors de cette application.

## Portée

- Flag MLXL3_EXL3_LANE_ORDER=1 uniquement ; absent/0/invalide -> off.
- Garde des16géométries de l'inventaire Q27-16 : M5/Mul1/M1-M2, entrées5120/6144/17408. Groupes aux largeurs [10240,6144] ou [17408,17408]. Les12cellules sans filtre de vitesse qualifié restent explicitement incluses dans l'hypothèse globale à falsifier ; pas de sélection des seuls20gagnants.
- Exl3Linear::new et Exl3Group::new sont les seuls constructeurs littéraux trouvés dans tout le dépôt. Les autres callers passent par new/from_checkpoint.
- Option<Array> d'indices i32 préparé et matérialisé au chargement. Aucun index Array CPU créé par pas.
- lane_order_input prend l'axe2 après reshape [M,groups,H], après le Hadamard existant, puis restaure la forme d'origine. Le coût take est inclus à chaque projection.
- Quatre chemins QMV touchés : Linear M1/batch et Group M1/batch. M≥3 et autres formes gardent les graphes stock.
- Les deux shaders gardent le bloc half2+shuffles sous #else. Aucune FMA, réduction, géométrie, fenêtre trellis ni codebook changé.
- Le header0/1 sépare le cache Metal : KernelCacheKey contient header et source.
- Tune ajoute lanelayout-v1=0|1 avant smallm-v2 ; huit combinaisons de flags dans son test existant.
- TLS d'override imbriqué, restauration après panique, isolation par thread. Charger sous true pour préparer les indices ; basculer ensuite0/1 sur le même modèle. Une instance chargée sous false ne prépare pas d'indices et reste stock.
- Aucun défaut activé, profil Tune sauvé, release ou installation.

## Commandes CPU proposées — non exécutées

Depuis le worktree après application :

~~~sh
export PATH=/Users/justin/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:$PATH
export MLXL3_MLX_ROOT=/Users/justin/Documents/mix-stq1_0/.venv/lib/python3.12/site-packages/mlx
cargo fmt
cargo fmt --check
cargo clippy --locked --all-targets --features mlx,chat -- -D warnings
cargo test --locked --features mlx,chat
cargo build --locked --release --features mlx,chat
cargo test --locked --release --features mlx,chat --lib --no-run
cargo kani --lib --no-default-features --harness exl3_lane_layout_key_distinguishes_options
cargo kani --lib --no-default-features --harness exl3_lane_permutation_is_bijective_and_preserves_tile_bounds
cargo kani --lib --no-default-features --harness exl3_lane_order_preserves_shape_and_large_m_fallback
cargo kani --lib --features mlx,chat --tests --harness lane_order_real_array_api
~~~

Kani scalaire : bool/i32/u32/usize complets, aucune assume ni boucle ; key injective, permutation bijective et blocs16 conservés, garde avec fallback et bornes. L'API Array est réellement appelée ; ICE/FFI éventuelle doit rester non vérifiée. Ne pas confondre ces preuves CPU avec une preuve Metal.

Les trois tests de contrats, le test TLS et le test Tune8combinaisons sont CPU. Aucun test n'a encore passé sur ce patch. La CI existante PR/push couvre fmt/Clippy/build/tests CPU et libKani ; les tests physiques restent ignorés en CI.

MSL : tenter le vérificateur source disponible sur les deux vrais shaders et le contexte Metal réel ; CBMC ne prenait pas MSL en charge précédemment. Garder le diagnostic, ne pas traduire en C++ pour revendiquer une preuve du shader.

## Commandes physiques proposées — après CPU, un seul GPU

Le parent supervise chaque processus, délais300s/test/900sbridge adaptés et stop+join. Utiliser le binaire de test release déjà construit, pas une compilation pendant les mesures.

~~~sh
export MLXL3_QWEN_TEST_MODEL='/Users/justin/Library/Application Support/io.mlxl3.desktop/Models/Qwen3.8-27B-exl3-6a9ca9d0'
export MLXL3_MTP_TEST_MODEL="$MLXL3_QWEN_TEST_MODEL"
export MLXL3_MTP_TEST_HEAD='/Users/justin/Library/Application Support/io.mlxl3.desktop/Drafts/Qwen3.8-27B-MTP-4bit'
export MLXL3_ALLOCATOR_CACHE_MIB=256
TESTBIN='remplacer-par-le-chemin-exact-du-binaire-de-tests-lib-release'
"$TESTBIN" linear::tests::lane_order_real_projections_match_stock_and_reject_mutated_index --exact --ignored --nocapture --test-threads=1
"$TESTBIN" qwen35::tests::dense_mlp_batch_matches_serial_layers --exact --ignored --nocapture --test-threads=1
"$TESTBIN" qwen35::tests::dense_lane_order_matches_stock_prefixes --exact --ignored --nocapture --test-threads=1
~~~

- Premier test : trois vraies projections et deux vrais groupes, M1/2/3/4,20 comparaisons positives/non vides/finies ; mutation de deux indices de tête, divergence finie exigée puis restauration/parité.
- MLP existant :384cas, maintenant oracle explicitement lane0/candidat1, indices préparés avant chargement.
- Nouveau test modèle : réutilise check_dense_smallm_prefixes. Préfixes24/257 stock0 ; M1/2/3/4, commits partiels, logits248320/hidden5120/128états. Candidat1 et replay de référence/continuations explicitement stock0. Les deux anciens tests gardent leur mode false.
- Ensuite : Session récursive existante, tête originale, D1..3/adaptatif ; bridge check-mtp-depths sous flag1, budgets/cancel/préfixes.
- Pour la vitesse réelle, retirer MLXL3_ALLOCATOR_CACHE_MIB et garder le protocole Q27-19 exact, même binaire A0/B1, acceptation et outputs égaux, ABBA puis BAAB seulement si utile.

## État de vérification

Préparation texte uniquement : aucun format, build, test, Kani, JIT Metal, inférence ou benchmark exécuté par cet agent. Le parent examine et construit la source réellement appliquée, enregistre ses SHA et vérifie la qualité avant la vitesse. App installée inchangée.
