//! Qwen Gated DeltaNet state transition through the production MSL kernel.
use crate::array::{self, Array, Dtype};
use anyhow::{Context, Result, ensure};

#[allow(clippy::too_many_arguments)]
pub fn prepare_qkv(
    qkv: &Array,
    conv_state: &Array,
    conv_weight: &Array,
    q_scale: &Array,
    k_scale: &Array,
    key_heads: i32,
    value_heads: i32,
    key_dim: i32,
    value_dim: i32,
    conv_length: i32,
) -> Result<(Array, Array, Array, Array)> {
    let [batch, time, conv_dims]: [i32; 3] = qkv
        .shape()
        .try_into()
        .map_err(|_| anyhow::anyhow!("Gated DeltaNet QKV input must have rank 3"))?;
    let keys = key_heads
        .checked_mul(key_dim)
        .context("Gated DeltaNet key width overflow")?;
    let values = value_heads
        .checked_mul(value_dim)
        .context("Gated DeltaNet value width overflow")?;
    ensure!(
        batch == 1
            && (1..=8).contains(&time)
            && key_heads > 0
            && value_heads > 0
            && key_dim == 128
            && value_dim > 0
            && value_dim % 8 == 0
            && conv_length > 1
            && conv_dims == 2 * keys + values,
        "invalid fused Gated DeltaNet preparation dimensions"
    );
    ensure!(
        qkv.dtype() == Dtype::Float16
            && conv_state.dtype() == Dtype::Float16
            && conv_weight.dtype() == Dtype::Float16
            && q_scale.dtype() == Dtype::Float16
            && k_scale.dtype() == Dtype::Float16
            && conv_state.shape() == [1, conv_length - 1, conv_dims]
            && conv_weight.shape() == [conv_dims, conv_length, 1]
            && q_scale.shape().is_empty()
            && k_scale.shape().is_empty(),
        "invalid fused Gated DeltaNet preparation tensors"
    );
    let header = prepare_header(
        time,
        key_heads,
        value_heads,
        key_dim,
        value_dim,
        conv_length,
        keys,
        conv_dims,
    );
    let mut outputs = array::metal_kernel(
        &format!(
            "mlxl3_rs_gdn_prepare_t{time}_kh{key_heads}_vh{value_heads}_vd{value_dim}_c{conv_length}"
        ),
        &["qkv", "conv_state", "conv_weight", "q_scale", "k_scale"],
        &["q", "k", "v", "state_out"],
        &header,
        include_str!("../shaders/gated_delta_prepare.metal"),
        &[qkv, conv_state, conv_weight, q_scale, k_scale],
        &[
            vec![1, time, key_heads, key_dim],
            vec![1, time, key_heads, key_dim],
            vec![1, time, value_heads, value_dim],
            conv_state.shape().to_vec(),
        ],
        &[
            Dtype::Float16,
            Dtype::Float16,
            Dtype::Float16,
            Dtype::Float16,
        ],
        [32, key_heads.max(value_heads), time],
        [32, 1, 1],
    )?;
    ensure!(
        outputs.len() == 4,
        "Gated DeltaNet preparation returned wrong outputs"
    );
    let state = outputs
        .pop()
        .context("missing Gated DeltaNet convolution state")?;
    let v = outputs.pop().context("missing Gated DeltaNet V")?;
    let k = outputs.pop().context("missing Gated DeltaNet K")?;
    let q = outputs.pop().context("missing Gated DeltaNet Q")?;
    Ok((q, k, v, state))
}

#[allow(clippy::too_many_arguments)]
fn prepare_header(
    time: i32,
    key_heads: i32,
    value_heads: i32,
    key_dim: i32,
    value_dim: i32,
    conv_length: i32,
    keys: i32,
    conv_dims: i32,
) -> String {
    format!(
        r#"
#define TIME {time}
#define KEY_HEADS {key_heads}
#define VALUE_HEADS {value_heads}
#define KEY_DIM {key_dim}
#define VALUE_DIM {value_dim}
#define KEYS {keys}
#define CONV_LENGTH {conv_length}
#define CONV_HISTORY {history}
#define CONV_DIMS {conv_dims}

inline half mlxl3_gdn_input(
    const device half* qkv,
    const device half* conv_state,
    uint position,
    uint channel
) {{
    if (position < uint(CONV_HISTORY)) {{
        return conv_state[position * uint(CONV_DIMS) + channel];
    }}
    return qkv[(position - uint(CONV_HISTORY)) * uint(CONV_DIMS) + channel];
}}

inline half mlxl3_gdn_conv_silu(
    const device half* qkv,
    const device half* conv_state,
    const device half* conv_weight,
    uint time,
    uint channel
) {{
    float acc = 0.0f;
    for (uint index = 0u; index < uint(CONV_LENGTH); ++index) {{
        acc += float(mlxl3_gdn_input(qkv, conv_state, time + index, channel))
            * conv_weight[channel * uint(CONV_LENGTH) + index];
    }}
    half value = half(acc);
    half tail = half(1.0h) / (half(1.0h) + metal::exp(metal::abs(value)));
    half sigmoid = value < half(0.0h) ? tail : half(1.0h) - tail;
    return value * sigmoid;
}}
"#,
        history = conv_length - 1,
    )
}

#[allow(clippy::too_many_arguments)]
pub fn prepare_and_step_with_gates(
    qkv: &Array,
    conv: &Array,
    weight: &Array,
    q_scale: &Array,
    k_scale: &Array,
    a: &Array,
    b: &Array,
    a_log: &Array,
    bias: &Array,
    state: &Array,
    retain: bool,
) -> Result<(Array, Array, Array, Option<RecurrentTape>)> {
    let time = qkv.shape().get(1).copied().unwrap_or(0);
    let value_heads = state.shape().get(1).copied().unwrap_or(0);
    ensure!(
        crate::contracts::fused_gdn_prepare_recurrence(time, 16, value_heads, 128, 128, 4),
        "unqualified fused GDN time"
    );
    let conv_dims = 4096 + value_heads * 128;
    ensure!(
        qkv.shape() == [1, time, conv_dims]
            && conv.shape() == [1, 3, conv_dims]
            && weight.shape() == [conv_dims, 4, 1]
            && q_scale.shape().is_empty()
            && k_scale.shape().is_empty()
            && a.shape() == [1, time, value_heads]
            && b.shape() == a.shape()
            && a_log.shape() == [value_heads]
            && bias.shape() == [value_heads]
            && state.shape() == [1, value_heads, 128, 128],
        "invalid fused GDN shapes"
    );
    ensure!(
        [qkv, conv, weight, q_scale, k_scale, a, b, bias]
            .iter()
            .all(|x| x.dtype() == Dtype::Float16)
            && a_log.dtype() == Dtype::Float32
            && state.dtype() == Dtype::Float32,
        "invalid fused GDN dtypes"
    );
    let header = format!(
        "{}\n#define MLXL3_GDN_FUSED_PREP 1\n#define MLXL3_GDN_FUSED_GATES 1\n#define MLXL3_GDN_SAVE_HISTORY 0\n#define MLXL3_GDN_SAVE_TAPE {}\n#define InT half\n#define StT float\n#define B 1\n#define T {time}\n#define Dk 128\n#define Dv 128\n#define Hk 16\n#define Hv {value_heads}\n",
        prepare_header(time, 16, value_heads, 128, 128, 4, 2048, conv_dims),
        u8::from(retain)
    );
    let names: &[&str] = if retain {
        &[
            "y",
            "state_out",
            "conv_out",
            "keys_out",
            "delta_tape",
            "decay_tape",
        ]
    } else {
        &["y", "state_out", "conv_out", "keys_out"]
    };
    let mut shapes = vec![
        vec![1, time, value_heads, 128],
        state.shape().to_vec(),
        conv.shape().to_vec(),
        vec![1, time, 16, 128],
    ];
    let mut dtypes = vec![
        Dtype::Float16,
        Dtype::Float32,
        Dtype::Float16,
        Dtype::Float16,
    ];
    if retain {
        shapes.extend([vec![1, time, value_heads, 128], vec![1, time, value_heads]]);
        dtypes.extend([Dtype::Float32, Dtype::Float32]);
    }
    let mut outputs = array::metal_kernel(
        &format!(
            "mlxl3_rs_gdn_prepare_recurrence_hv{value_heads}_t{time}_tape{}",
            u8::from(retain)
        ),
        &[
            "qkv",
            "conv_state",
            "conv_weight",
            "q_scale",
            "k_scale",
            "a",
            "b",
            "a_log",
            "dt_bias",
            "state_in",
        ],
        names,
        &header,
        include_str!("../shaders/gated_delta_packed.metal"),
        &[
            qkv, conv, weight, q_scale, k_scale, a, b, a_log, bias, state,
        ],
        &shapes,
        &dtypes,
        [32, 16, value_heads],
        [32, 16, 1],
    )?;
    ensure!(
        outputs.len() == names.len(),
        "fused GDN returned wrong output count"
    );
    let tape_parts = outputs.split_off(4);
    let keys = outputs.pop().context("missing fused GDN keys")?;
    let conv = outputs.pop().context("missing fused GDN conv")?;
    let next = outputs.pop().context("missing fused GDN state")?;
    let out = outputs.pop().context("missing fused GDN output")?;
    let tape = if retain {
        let mut parts = tape_parts;
        let decay = parts.pop().context("missing fused GDN decay")?;
        let delta = parts.pop().context("missing fused GDN delta")?;
        Some(RecurrentTape {
            initial: state.try_clone()?,
            keys,
            delta,
            decay,
            time,
        })
    } else {
        None
    };
    Ok((out, next, conv, tape))
}

pub fn step(
    q: &Array,
    k: &Array,
    v: &Array,
    g: &Array,
    beta: &Array,
    state: &Array,
) -> Result<(Array, Array)> {
    let [batch, time, key_heads, key_dim]: [i32; 4] = q
        .shape()
        .try_into()
        .map_err(|_| anyhow::anyhow!("Gated DeltaNet q must have rank 4"))?;
    let [v_batch, v_time, value_heads, value_dim]: [i32; 4] = v
        .shape()
        .try_into()
        .map_err(|_| anyhow::anyhow!("Gated DeltaNet v must have rank 4"))?;
    ensure!(
        batch > 0 && batch == v_batch && time > 0 && v_time == time,
        "invalid Gated DeltaNet batch/time dimensions"
    );
    ensure!(
        key_dim == 128 && value_dim > 0 && value_dim % 8 == 0,
        "packed Gated DeltaNet requires key dim 128 and value dim divisible by 8"
    );
    ensure!(
        key_heads > 0 && value_heads > 0 && value_heads % key_heads == 0,
        "invalid Gated DeltaNet head counts"
    );
    ensure!(k.shape() == q.shape(), "Gated DeltaNet q/k shapes differ");
    ensure!(
        q.dtype() == Dtype::Float16
            && k.dtype() == Dtype::Float16
            && v.dtype() == Dtype::Float16
            && beta.dtype() == Dtype::Float16,
        "native packed Gated DeltaNet expects FP16 q/k/v/beta"
    );
    ensure!(
        g.shape() == [batch, time, value_heads] && g.dtype() == Dtype::Float32,
        "Gated DeltaNet decay must be FP32 [batch,time,value_heads]"
    );
    ensure!(
        beta.shape() == [batch, time, value_heads],
        "invalid Gated DeltaNet beta shape"
    );
    ensure!(
        state.shape() == [batch, value_heads, value_dim, key_dim]
            && state.dtype() == Dtype::Float32,
        "Gated DeltaNet state must be FP32 [batch,value_heads,value_dim,128]"
    );
    let header = format!(
        "#define InT half\n#define StT float\n#define T {time}\n#define Dk {key_dim}\n#define Dv {value_dim}\n#define Hk {key_heads}\n#define Hv {value_heads}\n"
    );
    let mut outputs = array::metal_kernel(
        &format!(
            "mlxl3_rs_gdn_packed_b{batch}_t{time}_hk{key_heads}_hv{value_heads}_dv{value_dim}"
        ),
        &["q", "k", "v", "g", "beta", "state_in"],
        &["y", "state_out"],
        &header,
        include_str!("../shaders/gated_delta_packed.metal"),
        &[q, k, v, g, beta, state],
        &[
            vec![batch, time, value_heads, value_dim],
            state.shape().to_vec(),
        ],
        &[Dtype::Float16, Dtype::Float32],
        [
            32,
            value_dim / 8,
            batch
                .checked_mul(value_heads)
                .context("GDN grid overflow")?,
        ],
        [32, 2, 1],
    )?;
    ensure!(
        outputs.len() == 2,
        "Gated DeltaNet kernel returned wrong output count"
    );
    let state = outputs.pop().context("missing Gated DeltaNet state")?;
    let output = outputs.pop().context("missing Gated DeltaNet output")?;
    Ok((output, state))
}

#[allow(clippy::too_many_arguments)]
pub fn step_with_gates(
    q: &Array,
    k: &Array,
    v: &Array,
    a: &Array,
    b: &Array,
    a_log: &Array,
    dt_bias: &Array,
    state: &Array,
) -> Result<(Array, Array)> {
    let (output, state, _) =
        step_with_gates_impl(q, k, v, a, b, a_log, dt_bias, state, Retention::None)?;
    Ok((output, state))
}

#[allow(clippy::too_many_arguments)]
/// History contains partial-commit states (T-1 rows), or the legacy one row at T=1.
pub fn step_with_gates_history(
    q: &Array,
    k: &Array,
    v: &Array,
    a: &Array,
    b: &Array,
    a_log: &Array,
    dt_bias: &Array,
    state: &Array,
) -> Result<(Array, Array, Array)> {
    let (output, state, mut extra) =
        step_with_gates_impl(q, k, v, a, b, a_log, dt_bias, state, Retention::History)?;
    Ok((
        output,
        state,
        extra
            .pop()
            .context("missing fused Gated DeltaNet history")?,
    ))
}

#[derive(Clone, Copy)]
enum Retention {
    None,
    History,
    Tape,
}

pub struct RecurrentTape {
    initial: Array,
    keys: Array,
    delta: Array,
    decay: Array,
    time: i32,
}

impl RecurrentTape {
    pub fn replay(&self, retained: i32) -> Result<Array> {
        let retained = crate::contracts::gdn_tape_prefix(self.time, retained)
            .context("invalid GDN tape commit prefix")?;
        let value_heads = self.initial.shape()[1];
        let value_dim = self.initial.shape()[2];
        let key_heads = self.keys.shape()[2];
        let header = format!(
            "#define RETAINED {retained}\n#define Dk 128\n#define Dv {value_dim}\n#define Hk {key_heads}\n#define Hv {value_heads}\n"
        );
        let mut outputs = array::metal_kernel(
            &format!("mlxl3_rs_gdn_replay_r{retained}_hk{key_heads}_hv{value_heads}_dv{value_dim}"),
            &["k", "delta_tape", "decay_tape", "state_in"],
            &["state_out"],
            &header,
            include_str!("../shaders/gated_delta_replay.metal"),
            &[&self.keys, &self.delta, &self.decay, &self.initial],
            &[self.initial.shape().to_vec()],
            &[Dtype::Float32],
            [32, value_dim / 8, value_heads],
            [32, 2, 1],
        )?;
        outputs.pop().context("missing GDN replay state")
    }
}

#[allow(clippy::too_many_arguments)]
pub fn step_with_gates_tape(
    q: &Array,
    k: &Array,
    v: &Array,
    a: &Array,
    b: &Array,
    a_log: &Array,
    dt_bias: &Array,
    state: &Array,
) -> Result<(Array, Array, RecurrentTape)> {
    let (out, next, mut extra) =
        step_with_gates_impl(q, k, v, a, b, a_log, dt_bias, state, Retention::Tape)?;
    let decay = extra.pop().context("missing GDN decay tape")?;
    let delta = extra.pop().context("missing GDN delta tape")?;
    Ok((
        out,
        next,
        RecurrentTape {
            initial: state.try_clone()?,
            keys: k.try_clone()?,
            delta,
            decay,
            time: q.shape()[1],
        },
    ))
}

#[allow(clippy::too_many_arguments)]
fn step_with_gates_impl(
    q: &Array,
    k: &Array,
    v: &Array,
    a: &Array,
    b: &Array,
    a_log: &Array,
    dt_bias: &Array,
    state: &Array,
    retention: Retention,
) -> Result<(Array, Array, Vec<Array>)> {
    let save_history = matches!(retention, Retention::History);
    let save_tape = matches!(retention, Retention::Tape);
    let [batch, time, key_heads, key_dim]: [i32; 4] = q
        .shape()
        .try_into()
        .map_err(|_| anyhow::anyhow!("Gated DeltaNet q must have rank 4"))?;
    let [v_batch, v_time, value_heads, value_dim]: [i32; 4] = v
        .shape()
        .try_into()
        .map_err(|_| anyhow::anyhow!("Gated DeltaNet v must have rank 4"))?;
    let history_rows = crate::contracts::gdn_history_rows(time)
        .context("fused Gated DeltaNet gates require 1 to 8 tokens")?;
    ensure!(
        batch == 1 && v_batch == batch && v_time == time,
        "fused Gated DeltaNet gates require 1 to 8 tokens"
    );
    ensure!(
        key_dim == 128
            && value_dim > 0
            && value_dim % 8 == 0
            && key_heads > 0
            && value_heads > 0
            && value_heads % key_heads == 0,
        "invalid fused Gated DeltaNet head dimensions"
    );
    ensure!(
        k.shape() == q.shape()
            && a.shape() == [batch, time, value_heads]
            && b.shape() == a.shape()
            && a_log.shape() == [value_heads]
            && dt_bias.shape() == [value_heads]
            && state.shape() == [batch, value_heads, value_dim, key_dim],
        "invalid fused Gated DeltaNet gate shapes"
    );
    ensure!(
        q.dtype() == Dtype::Float16
            && k.dtype() == Dtype::Float16
            && v.dtype() == Dtype::Float16
            && a.dtype() == Dtype::Float16
            && b.dtype() == Dtype::Float16
            && a_log.dtype() == Dtype::Float32
            && dt_bias.dtype() == Dtype::Float16
            && state.dtype() == Dtype::Float32,
        "invalid fused Gated DeltaNet gate dtypes"
    );
    let header = format!(
        "#define MLXL3_GDN_FUSED_GATES 1\n#define MLXL3_GDN_SAVE_HISTORY {}\n#define MLXL3_GDN_SAVE_TAPE {}\n#define InT half\n#define StT float\n#define B {batch}\n#define T {time}\n#define Dk {key_dim}\n#define Dv {value_dim}\n#define Hk {key_heads}\n#define Hv {value_heads}\n",
        u8::from(save_history),
        u8::from(save_tape),
    );
    let output_names: &[&str] = if save_tape {
        &["y", "state_out", "delta_tape", "decay_tape"]
    } else if save_history {
        &["y", "state_out", "state_history"]
    } else {
        &["y", "state_out"]
    };
    let mut output_shapes = vec![
        vec![batch, time, value_heads, value_dim],
        state.shape().to_vec(),
    ];
    let mut output_dtypes = vec![Dtype::Float16, Dtype::Float32];
    if save_history {
        output_shapes.push(vec![history_rows, batch, value_heads, value_dim, key_dim]);
        output_dtypes.push(Dtype::Float32);
    }
    if save_tape {
        output_shapes.push(vec![batch, time, value_heads, value_dim]);
        output_shapes.push(vec![batch, time, value_heads]);
        output_dtypes.extend([Dtype::Float32, Dtype::Float32]);
    }
    let mut outputs = array::metal_kernel(
        &format!(
            "mlxl3_rs_gdn_packed_gates_h{}_tape{}_t{time}_hk{key_heads}_hv{value_heads}_dv{value_dim}",
            u8::from(save_history),
            u8::from(save_tape)
        ),
        &["q", "k", "v", "a", "b", "a_log", "dt_bias", "state_in"],
        output_names,
        &header,
        include_str!("../shaders/gated_delta_packed.metal"),
        &[q, k, v, a, b, a_log, dt_bias, state],
        &output_shapes,
        &output_dtypes,
        [32, value_dim / 8, value_heads],
        [32, 2, 1],
    )?;
    ensure!(
        outputs.len() == output_names.len(),
        "fused Gated DeltaNet gates returned wrong output count"
    );
    let extra = outputs.split_off(2);
    let state = outputs
        .pop()
        .context("missing fused Gated DeltaNet state")?;
    let output = outputs
        .pop()
        .context("missing fused Gated DeltaNet output")?;
    Ok((output, state, extra))
}

pub fn step_vector(
    q: &Array,
    k: &Array,
    v: &Array,
    g: &Array,
    beta: &Array,
    state: &Array,
) -> Result<(Array, Array)> {
    step_vector_impl(q, k, v, g, beta, state, false)
}

pub fn step_vector_with_beta(
    q: &Array,
    k: &Array,
    v: &Array,
    g: &Array,
    beta_raw: &Array,
    state: &Array,
) -> Result<(Array, Array)> {
    ensure!(
        q.shape().get(1) == Some(&1),
        "fused vector beta requires one decode token"
    );
    step_vector_impl(q, k, v, g, beta_raw, state, true)
}

fn step_vector_impl(
    q: &Array,
    k: &Array,
    v: &Array,
    g: &Array,
    beta: &Array,
    state: &Array,
    beta_is_raw: bool,
) -> Result<(Array, Array)> {
    let [batch, time, heads, dim]: [i32; 4] = q
        .shape()
        .try_into()
        .map_err(|_| anyhow::anyhow!("vector Gated DeltaNet q must have rank 4"))?;
    ensure!(
        batch > 0
            && time > 0
            && heads > 0
            && dim == 128
            && k.shape() == q.shape()
            && v.shape() == q.shape()
            && g.shape() == q.shape()
            && beta.shape() == [batch, time, heads]
            && state.shape() == [batch, heads, dim, dim],
        "invalid vector Gated DeltaNet dimensions"
    );
    ensure!(
        q.dtype() == Dtype::Float16
            && k.dtype() == Dtype::Float16
            && v.dtype() == Dtype::Float16
            && g.dtype() == Dtype::Float32
            && beta.dtype()
                == if beta_is_raw {
                    Dtype::Float32
                } else {
                    Dtype::Float16
                }
            && state.dtype() == Dtype::Float32,
        "invalid vector Gated DeltaNet dtypes"
    );
    let source = r#"
        uint packed = thread_position_in_grid.z;
        uint batch = packed / HEADS;
        uint head = packed - batch * HEADS;
        uint lane = thread_position_in_threadgroup.x;
        uint value_index = thread_position_in_grid.y;
        uint base = lane * 4u;
        ulong state_base = (ulong(batch) * HEADS * 128u + head * 128u + value_index) * 128u;
        float local[4];
        for (uint i = 0u; i < 4u; ++i) {
            local[i] = state_in[state_base + base + i];
        }
        for (uint t = 0u; t < TIME; ++t) {
            ulong vector_base = ((ulong(batch) * TIME + t) * HEADS + head) * 128u;
            float memory = 0.0f;
            for (uint i = 0u; i < 4u; ++i) {
                uint key_index = base + i;
                local[i] *= g[vector_base + key_index];
                memory += local[i] * float(k[vector_base + key_index]);
            }
            memory += simd_shuffle_xor(memory, 1);
            memory += simd_shuffle_xor(memory, 2);
            memory += simd_shuffle_xor(memory, 4);
            memory += simd_shuffle_xor(memory, 8);
            memory += simd_shuffle_xor(memory, 16);
#if MLXL3_GDN_VECTOR_FUSED_BETA
            float beta_value = beta_raw[(ulong(batch) * TIME + t) * HEADS + head];
            float beta_tail = 1.0f / (1.0f + metal::exp(metal::abs(beta_value)));
            half beta_t = half(beta_value < 0.0f ? beta_tail : 1.0f - beta_tail);
#else
            half beta_t = beta[(ulong(batch) * TIME + t) * HEADS + head];
#endif
            float delta = (float(v[vector_base + value_index]) - memory)
                * float(beta_t);
            float output = 0.0f;
            for (uint i = 0u; i < 4u; ++i) {
                uint key_index = base + i;
                local[i] += float(k[vector_base + key_index]) * delta;
                output += local[i] * float(q[vector_base + key_index]);
            }
            output += simd_shuffle_xor(output, 1);
            output += simd_shuffle_xor(output, 2);
            output += simd_shuffle_xor(output, 4);
            output += simd_shuffle_xor(output, 8);
            output += simd_shuffle_xor(output, 16);
            if (lane == 0u) y[vector_base + value_index] = half(output);
        }
        for (uint i = 0u; i < 4u; ++i) {
            state_out[state_base + base + i] = local[i];
        }
    "#;
    let fused_header = if beta_is_raw {
        "#define MLXL3_GDN_VECTOR_FUSED_BETA 1\n"
    } else {
        ""
    };
    let beta_name = if beta_is_raw { "beta_raw" } else { "beta" };
    let mut outputs = array::metal_kernel(
        &format!(
            "mlxl3_rs_gdn_vector{}_b{batch}_t{time}_h{heads}_d{dim}_v2",
            if beta_is_raw { "_raw_beta" } else { "" }
        ),
        &["q", "k", "v", "g", beta_name, "state_in"],
        &["y", "state_out"],
        &format!("{fused_header}#define TIME {time}u\n#define HEADS {heads}u\n"),
        source,
        &[q, k, v, g, beta, state],
        &[q.shape().to_vec(), state.shape().to_vec()],
        &[Dtype::Float16, Dtype::Float32],
        [
            32,
            dim,
            batch.checked_mul(heads).context("GDN grid overflow")?,
        ],
        [32, 4, 1],
    )?;
    let state = outputs
        .pop()
        .context("missing vector Gated DeltaNet state")?;
    let output = outputs
        .pop()
        .context("missing vector Gated DeltaNet output")?;
    Ok((output, state))
}

#[cfg(test)]
mod tests {
    use super::*;

    struct GdnPreparationFixture {
        value_heads: i32,
        qkv: Array,
        conv: Array,
        weights: Array,
        qs: Array,
        ks: Array,
        a: Array,
        b: Array,
        a_log: Array,
        bias: Array,
        state: Array,
    }

    impl GdnPreparationFixture {
        fn split(&self, retain: bool) -> Result<(Array, Array, Array, Option<RecurrentTape>)> {
            let (q, k, v, conv) = prepare_qkv(
                &self.qkv, &self.conv, &self.weights, &self.qs, &self.ks,
                16, self.value_heads, 128, 128, 4,
            )?;
            let (out, next, tape) = if retain {
                let (out, next, tape) = step_with_gates_tape(
                    &q, &k, &v, &self.a, &self.b, &self.a_log, &self.bias, &self.state,
                )?;
                (out, next, Some(tape))
            } else {
                let (out, next) = step_with_gates(
                    &q, &k, &v, &self.a, &self.b, &self.a_log, &self.bias, &self.state,
                )?;
                (out, next, None)
            };
            Ok((out, next, conv, tape))
        }

        fn fused(&self, retain: bool) -> Result<(Array, Array, Array, Option<RecurrentTape>)> {
            prepare_and_step_with_gates(
                &self.qkv, &self.conv, &self.weights, &self.qs, &self.ks,
                &self.a, &self.b, &self.a_log, &self.bias, &self.state, retain,
            )
        }

        fn evaluate(&self, fused: bool, retain: bool) -> Result<()> {
            let (out, next, conv, tape) = if fused { self.fused(retain)? } else { self.split(retain)? };
            out.eval()?;
            next.eval()?;
            conv.eval()?;
            if let Some(tape) = tape {
                tape.keys.eval()?;
                tape.delta.eval()?;
                tape.decay.eval()?;
            }
            array::synchronize()
        }
    }

    fn gdn_preparation_fixture(shape: &[i32], seed: usize) -> Result<Array> {
        let count = shape.iter().map(|&d| d as usize).product();
        Array::from_f16_bits(
            &(0..count)
                .map(|i| {
                    half::f16::from_f32(if seed == 0 {
                        0.
                    } else {
                        ((i * 7 + seed) % 61) as f32 / 64. - 0.5
                    }).to_bits()
                })
                .collect::<Vec<_>>(),
            shape,
        )
    }

    fn check_gdn_preparation_arrays(actual: &Array, expected: &Array, name: &str) -> Result<()> {
        assert_eq!(actual.shape(), expected.shape(), "{name} shape");
        assert_eq!(actual.dtype(), expected.dtype(), "{name} dtype");
        let count = expected.shape().iter().map(|&d| d as usize).product::<usize>();
        assert!(count > 0, "{name} empty");
        for array in [actual, expected] {
            let values = array.to_f32()?;
            assert_eq!(values.len(), count, "{name} size");
            assert!(values.iter().all(|value| value.is_finite()), "{name} non-finite");
        }
        let actual = actual.to_bytes()?;
        let expected = expected.to_bytes()?;
        assert!(
            actual == expected,
            "{name} bits differ at byte {:?}",
            actual.iter().zip(&expected).position(|(a, b)| a != b),
        );
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen27B checkpoint and physical Apple GPU; run alone"]
    fn fused_preparation_recurrence_matches_split_and_all_prefixes() -> Result<()> {
        let model_path = std::env::var("MLXL3_MTP_TEST_MODEL")
            .context("set MLXL3_MTP_TEST_MODEL to the Qwen27B checkpoint")?;
        let checkpoint = crate::checkpoint::inspect(std::path::Path::new(&model_path))?;
        let prefix = "model.language_model.layers.0.linear_attn";
        let mut comparisons = 0;
        let mut replay_comparisons = 0;
        let mut micro_cases = Vec::new();
        for value_heads in [32, 48] {
            let conv_dims = 4096 + value_heads * 128;
            let (weights, a_log, bias) = if value_heads == 48 {
                (
                    crate::lfm2::half_weight(
                        &checkpoint, &format!("{prefix}.conv1d.weight"), Some(&[conv_dims, 1, 4]),
                    )?.transpose(&[0, 2, 1])?,
                    crate::linear::checkpoint_array(&checkpoint, &format!("{prefix}.A_log"))?
                        .astype(Dtype::Float32)?,
                    crate::lfm2::half_weight(
                        &checkpoint, &format!("{prefix}.dt_bias"), Some(&[value_heads]),
                    )?,
                )
            } else {
                (
                    gdn_preparation_fixture(&[conv_dims, 4, 1], 11)?,
                    Array::from_f32(
                        &(0..value_heads).map(|i| -4. + i as f32 / 32.).collect::<Vec<_>>(),
                        &[value_heads],
                    )?,
                    gdn_preparation_fixture(&[value_heads], 5)?,
                )
            };
            assert_eq!(a_log.shape(), [value_heads]);
            for seed in [0, 7] {
                for time in 0..=5 {
                    let fixture = GdnPreparationFixture {
                        value_heads,
                        qkv: gdn_preparation_fixture(&[1, time, conv_dims], seed)?,
                        conv: gdn_preparation_fixture(&[1, 3, conv_dims], seed)?,
                        weights: weights.try_clone()?,
                        qs: Array::from_f16_bits(&[half::f16::from_f32(1. / 128.).to_bits()], &[])?,
                        ks: Array::from_f16_bits(&[half::f16::from_f32(1. / 128_f32.sqrt()).to_bits()], &[])?,
                        a: gdn_preparation_fixture(&[1, time, value_heads], seed)?,
                        b: gdn_preparation_fixture(&[1, time, value_heads], seed + 1)?,
                        a_log: a_log.try_clone()?,
                        bias: bias.try_clone()?,
                        state: gdn_preparation_fixture(&[1, value_heads, 128, 128], seed)?
                            .astype(Dtype::Float32)?,
                    };
                    if time == 0 || time == 5 {
                        assert!(fixture.fused(true).is_err());
                        continue;
                    }
                    let (q, k, v, _) = prepare_qkv(
                        &fixture.qkv, &fixture.conv, &fixture.weights, &fixture.qs, &fixture.ks,
                        16, value_heads, 128, 128, 4,
                    )?;
                    let (expected, state, next_conv, expected_tape) = fixture.split(true)?;
                    let expected_tape = expected_tape.context("missing reference tape")?;
                    let mut serial_state = fixture.state.try_clone()?;
                    let mut serial_rows = Vec::new();
                    let mut prefixes = Vec::new();
                    for row in 0..time {
                        let (out, next) = step_with_gates(
                            &q.slice(1, row, row + 1)?, &k.slice(1, row, row + 1)?,
                            &v.slice(1, row, row + 1)?, &fixture.a.slice(1, row, row + 1)?,
                            &fixture.b.slice(1, row, row + 1)?, &fixture.a_log, &fixture.bias,
                            &serial_state,
                        )?;
                        serial_rows.push(out);
                        serial_state = next;
                        prefixes.push(serial_state.try_clone()?);
                    }
                    check_gdn_preparation_arrays(
                        &expected, &Array::concatenate(&serial_rows.iter().collect::<Vec<_>>(), 1)?,
                        "split vs serial output",
                    )?;
                    check_gdn_preparation_arrays(&state, &serial_state, "split vs serial state")?;
                    for retain in [false, true] {
                        let (out, next, conv, tape) = fixture.fused(retain)?;
                        check_gdn_preparation_arrays(&out, &expected, "output")?;
                        check_gdn_preparation_arrays(&next, &state, "state")?;
                        check_gdn_preparation_arrays(&conv, &next_conv, "conv")?;
                        if let Some(tape) = tape {
                            assert!(retain);
                            check_gdn_preparation_arrays(&tape.keys, &k, "keys")?;
                            check_gdn_preparation_arrays(&tape.delta, &expected_tape.delta, "delta")?;
                            check_gdn_preparation_arrays(&tape.decay, &expected_tape.decay, "decay")?;
                            for invalid in [i32::MIN, 0, time + 1, i32::MAX] {
                                assert!(tape.replay(invalid).is_err());
                            }
                            for retained in 1..=time {
                                check_gdn_preparation_arrays(
                                    &tape.replay(retained)?, &prefixes[(retained - 1) as usize],
                                    "replay vs serial prefix",
                                )?;
                                let (_, _, _, serial_conv) = prepare_qkv(
                                    &fixture.qkv.slice(1, 0, retained)?, &fixture.conv,
                                    &fixture.weights, &fixture.qs, &fixture.ks,
                                    16, value_heads, 128, 128, 4,
                                )?;
                                let committed_conv = Array::concatenate(&[&fixture.conv, &fixture.qkv], 1)?
                                    .slice(1, retained, retained + 3)?;
                                check_gdn_preparation_arrays(
                                    &committed_conv, &serial_conv, "committed conv prefix",
                                )?;
                                replay_comparisons += 1;
                            }
                        } else {
                            assert!(!retain);
                        }
                        comparisons += 1;
                    }
                    for (bad_qkv, bad_conv, bad_qs, bad_state) in [
                        (fixture.qkv.astype(Dtype::Float32)?, fixture.conv.try_clone()?,
                         fixture.qs.try_clone()?, fixture.state.try_clone()?),
                        (fixture.qkv.try_clone()?, fixture.conv.slice(1, 0, 2)?,
                         fixture.qs.try_clone()?, fixture.state.try_clone()?),
                        (fixture.qkv.try_clone()?, fixture.conv.try_clone()?,
                         fixture.qs.reshape(&[1])?, fixture.state.try_clone()?),
                        (fixture.qkv.try_clone()?, fixture.conv.try_clone()?,
                         fixture.qs.try_clone()?, fixture.state.astype(Dtype::Float16)?),
                    ] {
                        assert!(prepare_and_step_with_gates(
                            &bad_qkv, &bad_conv, &fixture.weights, &bad_qs, &fixture.ks,
                            &fixture.a, &fixture.b, &fixture.a_log, &fixture.bias, &bad_state, true,
                        ).is_err());
                    }
                    let short_log = fixture.a_log.slice(0, 0, value_heads - 1)?;
                    assert!(prepare_and_step_with_gates(
                        &fixture.qkv, &fixture.conv, &fixture.weights, &fixture.qs, &fixture.ks,
                        &fixture.a, &fixture.b, &short_log, &fixture.bias, &fixture.state, true,
                    ).is_err());
                    if seed == 7 && time <= 2 {
                        micro_cases.push(fixture);
                    }
                }
            }
        }
        assert_eq!(comparisons, 32);
        assert_eq!(replay_comparisons, 40);
        eprintln!(
            "GDN18 quality: 32 split comparisons, 40 serial rollback prefixes; Hv32 synthetic/Hv48 checkpoint; finite bitexact output/state/conv/keys/tapes"
        );
        if std::env::var("MLXL3_GDN_FUSED_MICRO").as_deref() == Ok("1") {
            assert_eq!(micro_cases.len(), 4);
            for fixture in micro_cases {
                let time = fixture.qkv.shape()[1];
                let retain = time > 1;
                for _ in 0..3 {
                    fixture.evaluate(false, retain)?;
                    fixture.evaluate(true, retain)?;
                }
                let mut samples = [Vec::with_capacity(40), Vec::with_capacity(40)];
                for repeat in 0..40 {
                    for fused in if repeat % 2 == 0 { [false, true] } else { [true, false] } {
                        let start = std::time::Instant::now();
                        fixture.evaluate(fused, retain)?;
                        let millis = start.elapsed().as_secs_f64() * 1000.;
                        assert!(millis.is_finite() && millis > 0.);
                        samples[usize::from(fused)].push(millis);
                    }
                }
                println!("{}", serde_json::json!({
                    "gdn18_micro": {
                        "value_heads": fixture.value_heads, "time": time, "retain": retain,
                        "quality_complete": true, "warmups": 3, "pairs": 40,
                        "boundary": "prepare+recurrence+outputs host/MLX/GPU sync; no generation speed",
                        "samples_ms": samples,
                    }
                }));
            }
        }
        Ok(())
    }

    #[test]
    #[ignore = "requires Apple GPU"]
    fn tape_replay_matches_every_serial_prefix() -> Result<()> {
        let half_array = |shape: &[i32], seed: usize| -> Result<Array> {
            let len = shape.iter().map(|&d| d as usize).product::<usize>();
            let bits = (0..len)
                .map(|i| half::f16::from_f32(((i * 7 + seed) % 31) as f32 / 64.0 - 0.25).to_bits())
                .collect::<Vec<_>>();
            Array::from_f16_bits(&bits, shape)
        };
        for (kh, hv, dv) in [(2, 4, 16), (16, 32, 128)] {
            let a_log = Array::from_f32(
                &(0..hv).map(|i| -4.0 + i as f32 / 32.).collect::<Vec<_>>(),
                &[hv],
            )?;
            let bias = half_array(&[hv], 5)?;
            let initial = Array::from_f32(
                &(0..hv * dv * 128)
                    .map(|i| (i % 23) as f32 / 128. - 0.125)
                    .collect::<Vec<_>>(),
                &[1, hv, dv, 128],
            )?;
            for time in 0..=9 {
                let q = half_array(&[1, time, kh, 128], 1)?;
                let k = half_array(&[1, time, kh, 128], 3)?;
                let v = half_array(&[1, time, hv, dv], 9)?;
                let a = half_array(&[1, time, hv], 11)?;
                let b = half_array(&[1, time, hv], 17)?;
                let actual = step_with_gates_tape(&q, &k, &v, &a, &b, &a_log, &bias, &initial);
                if time == 0 || time == 9 {
                    assert!(actual.is_err());
                    continue;
                }
                let (out, final_state, tape) = actual?;
                assert_eq!(tape.delta.shape(), [1, time, hv, dv]);
                assert_eq!(tape.decay.shape(), [1, time, hv]);
                let mut state = initial.try_clone()?;
                let mut rows = Vec::new();
                for row in 0..time {
                    let (expected, next) = step_with_gates(
                        &q.slice(1, row, row + 1)?,
                        &k.slice(1, row, row + 1)?,
                        &v.slice(1, row, row + 1)?,
                        &a.slice(1, row, row + 1)?,
                        &b.slice(1, row, row + 1)?,
                        &a_log,
                        &bias,
                        &state,
                    )?;
                    state = next;
                    rows.push(expected);
                    assert_eq!(
                        tape.replay(row + 1)?.to_bytes()?,
                        state.to_bytes()?,
                        "replay hv={hv} T={time} retained={}",
                        row + 1
                    );
                }
                assert_eq!(
                    out.to_bytes()?,
                    Array::concatenate(&rows.iter().collect::<Vec<_>>(), 1)?.to_bytes()?,
                    "output hv={hv} T={time}"
                );
                assert_eq!(
                    final_state.to_bytes()?,
                    state.to_bytes()?,
                    "final state hv={hv} T={time}"
                );
                for retained in [i32::MIN, 0, time + 1, i32::MAX] {
                    assert!(tape.replay(retained).is_err());
                }
            }
        }
        Ok(())
    }

    #[test]
    #[ignore = "requires Apple GPU"]
    fn compact_gate_history_matches_every_serial_prefix() -> Result<()> {
        let half_array = |shape: &[i32], seed: usize| -> Result<Array> {
            let count = shape.iter().product::<i32>() as usize;
            let bits: Vec<_> = (0..count)
                .map(|i| half::f16::from_f32(((i * 7 + seed) % 31) as f32 / 64.0 - 0.25).to_bits())
                .collect();
            Array::from_f16_bits(&bits, shape)
        };
        let a_log = Array::from_f32(&[-4.0, -3.0, -2.0, -1.0], &[4])?;
        let bias = half_array(&[4], 5)?;
        let initial = Array::from_f32(
            &(0..4 * 16 * 128)
                .map(|i| (i % 23) as f32 / 128.0 - 0.125)
                .collect::<Vec<_>>(),
            &[1, 4, 16, 128],
        )?;
        for time in 0..=9 {
            let q = half_array(&[1, time, 2, 128], 1)?;
            let k = half_array(&[1, time, 2, 128], 3)?;
            let v = half_array(&[1, time, 4, 16], 9)?;
            let a = half_array(&[1, time, 4], 11)?;
            let b = half_array(&[1, time, 4], 17)?;
            let result = step_with_gates_history(&q, &k, &v, &a, &b, &a_log, &bias, &initial);
            if time == 0 || time == 9 {
                assert!(result.is_err(), "invalid history length {time}");
                continue;
            }
            let (actual, final_state, history) = result?;
            let expected_rows = if time == 1 { 1 } else { time - 1 };
            assert_eq!(history.shape(), [expected_rows, 1, 4, 16, 128]);
            let mut state = initial.clone();
            let mut expected_outputs = Vec::new();
            for row in 0..time {
                let (output, next) = step_with_gates(
                    &q.slice(1, row, row + 1)?,
                    &k.slice(1, row, row + 1)?,
                    &v.slice(1, row, row + 1)?,
                    &a.slice(1, row, row + 1)?,
                    &b.slice(1, row, row + 1)?,
                    &a_log,
                    &bias,
                    &state,
                )?;
                expected_outputs.push(output);
                state = next;
                if row < expected_rows {
                    assert_eq!(
                        history.slice(0, row, row + 1)?.to_bytes()?,
                        state.to_bytes()?,
                        "history T={time}, row={row}"
                    );
                }
            }
            assert_eq!(final_state.to_bytes()?, state.to_bytes()?, "state T={time}");
            assert_eq!(
                actual.to_bytes()?,
                Array::concatenate(&expected_outputs.iter().collect::<Vec<_>>(), 1)?.to_bytes()?,
                "output T={time}"
            );
        }
        Ok(())
    }

    #[test]
    #[ignore = "requires Apple GPU"]
    fn packed_step_with_gates_matches_graph() -> Result<()> {
        let mut qkv = vec![0u16; 128];
        qkv[0] = half::f16::ONE.to_bits();
        let q = Array::from_f16_bits(&qkv, &[1, 1, 1, 128])?;
        let values = Array::from_f16_bits(&[half::f16::ONE.to_bits(); 8], &[1, 1, 1, 8])?;
        let a = Array::from_f16_bits(&[half::f16::from_f32(-0.75).to_bits()], &[1, 1, 1])?;
        let b = Array::from_f16_bits(&[half::f16::from_f32(0.625).to_bits()], &[1, 1, 1])?;
        let a_log = Array::from_f32(&[-4.25], &[1])?;
        let dt_bias = Array::from_f16_bits(&[half::f16::from_f32(0.125).to_bits()], &[1])?;
        let state = Array::zeros_dtype(&[1, 1, 8, 128], Dtype::Float32)?;
        let zero = Array::from_f16_bits(&[0], &[])?;
        let beta = b.sigmoid()?;
        let softplus = a.add(&dt_bias)?.logaddexp(&zero)?;
        let decay = a_log.exp()?.mul(&softplus)?.negative()?.exp()?;
        let (expected, expected_state) = step(&q, &q, &values, &decay, &beta, &state)?;
        let (actual, actual_state) =
            step_with_gates(&q, &q, &values, &a, &b, &a_log, &dt_bias, &state)?;
        assert_eq!(actual.to_f16_bits()?, expected.to_f16_bits()?);
        assert_eq!(actual_state.to_f32()?, expected_state.to_f32()?);
        Ok(())
    }

    #[test]
    #[ignore = "requires Apple GPU"]
    fn vector_step_with_beta_matches_graph() -> Result<()> {
        let mut qkv = vec![0u16; 128];
        qkv[0] = half::f16::ONE.to_bits();
        let q = Array::from_f16_bits(&qkv, &[1, 1, 1, 128])?;
        let g = Array::from_f32(&[1.0; 128], &[1, 1, 1, 128])?;
        let beta_raw = Array::from_f32(&[0.625], &[1, 1, 1])?;
        let beta = beta_raw.sigmoid()?.astype(Dtype::Float16)?;
        let state = Array::from_f32(&[0.25; 128 * 128], &[1, 1, 128, 128])?;
        let (expected, expected_state) = step_vector(&q, &q, &q, &g, &beta, &state)?;
        let (actual, actual_state) = step_vector_with_beta(&q, &q, &q, &g, &beta_raw, &state)?;
        assert_eq!(actual.to_f16_bits()?, expected.to_f16_bits()?);
        assert_eq!(actual_state.to_f32()?, expected_state.to_f32()?);
        Ok(())
    }

    #[test]
    #[ignore = "requires Apple GPU"]
    fn vector_step_matches_one_hot_update() -> Result<()> {
        let mut qkv = vec![0u16; 128];
        qkv[0] = half::f16::ONE.to_bits();
        let ones = vec![half::f16::ONE.to_bits(); 128];
        let (output, state) = step_vector(
            &Array::from_f16_bits(&qkv, &[1, 1, 1, 128])?,
            &Array::from_f16_bits(&qkv, &[1, 1, 1, 128])?,
            &Array::from_f16_bits(&ones, &[1, 1, 1, 128])?,
            &Array::from_f32(&vec![1.; 128], &[1, 1, 1, 128])?,
            &Array::from_f16_bits(&[half::f16::ONE.to_bits()], &[1, 1, 1])?,
            &Array::zeros_dtype(&[1, 1, 128, 128], Dtype::Float32)?,
        )?;
        assert!(output.to_f32()?.iter().all(|&value| value == 1.));
        let state = state.to_f32()?;
        assert!((0..128).all(|row| state[row * 128] == 1.));
        Ok(())
    }

    #[test]
    #[ignore = "requires Apple GPU"]
    fn vector_batch_matches_serial_steps() -> Result<()> {
        let mut qkv = vec![0u16; 256];
        qkv[0] = half::f16::ONE.to_bits();
        qkv[128] = half::f16::ONE.to_bits();
        let qkv = Array::from_f16_bits(&qkv, &[1, 2, 1, 128])?;
        let values = Array::from_f16_bits(&vec![half::f16::ONE.to_bits(); 256], &[1, 2, 1, 128])?;
        let decay = Array::from_f32(&[vec![0.8; 128], vec![0.9; 128]].concat(), &[1, 2, 1, 128])?;
        let beta = Array::from_f16_bits(&[half::f16::ONE.to_bits(); 2], &[1, 2, 1])?;
        let initial = Array::zeros_dtype(&[1, 1, 128, 128], Dtype::Float32)?;
        let (batched, batched_state) = step_vector(&qkv, &qkv, &values, &decay, &beta, &initial)?;
        let mut state = initial;
        let mut serial = Vec::new();
        for time in 0..2 {
            let (output, next) = step_vector(
                &qkv.slice(1, time, time + 1)?,
                &qkv.slice(1, time, time + 1)?,
                &values.slice(1, time, time + 1)?,
                &decay.slice(1, time, time + 1)?,
                &beta.slice(1, time, time + 1)?,
                &state,
            )?;
            serial.push(output);
            state = next;
        }
        let serial = Array::concatenate(&serial.iter().collect::<Vec<_>>(), 1)?;
        assert_eq!(batched.to_f16_bits()?, serial.to_f16_bits()?);
        assert_eq!(batched_state.to_f32()?, state.to_f32()?);
        Ok(())
    }
}


#[cfg(kani)]
#[kani::proof]
fn fused_gdn_real_array_api_preserves_output_shapes() {
    let time = 1 + i32::from(kani::any::<u8>() % 4);
    let value_heads = if kani::any::<bool>() { 48 } else { 32 };
    let conv_dims = 4096 + value_heads * 128;
    let qkv = Array::zeros_dtype(&[1, time, conv_dims], Dtype::Float16).unwrap();
    let conv = Array::zeros_dtype(&[1, 3, conv_dims], Dtype::Float16).unwrap();
    let weights = Array::zeros_dtype(&[conv_dims, 4, 1], Dtype::Float16).unwrap();
    let qs = Array::from_f16_bits(&[half::f16::from_f32(1. / 128.).to_bits()], &[]).unwrap();
    let ks = Array::from_f16_bits(&[half::f16::from_f32(1. / 128_f32.sqrt()).to_bits()], &[]).unwrap();
    let gates = Array::zeros_dtype(&[1, time, value_heads], Dtype::Float16).unwrap();
    let a_log = Array::zeros_dtype(&[value_heads], Dtype::Float32).unwrap();
    let bias = Array::zeros_dtype(&[value_heads], Dtype::Float16).unwrap();
    let state = Array::zeros_dtype(&[1, value_heads, 128, 128], Dtype::Float32).unwrap();
    let (out, next, conv_out, tape) = prepare_and_step_with_gates(
        &qkv, &conv, &weights, &qs, &ks, &gates, &gates, &a_log, &bias, &state, true,
    ).unwrap();
    assert_eq!(out.shape(), [1, time, value_heads, 128]);
    assert_eq!(next.shape(), state.shape());
    assert_eq!(conv_out.shape(), conv.shape());
    assert!(tape.is_some());
}
