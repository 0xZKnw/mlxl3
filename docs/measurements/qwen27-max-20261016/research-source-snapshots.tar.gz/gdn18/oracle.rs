    struct GdnPreparationFixture {
        value_heads: i32,
        qkv: Array,
        conv: Array,
        weights: Array,
        qs: Array,
        ks: Array,
        a: Array,
        b: Array,
        a_log: Array,
        bias: Array,
        state: Array,
    }

    impl GdnPreparationFixture {
        fn split(&self, retain: bool) -> Result<(Array, Array, Array, Option<RecurrentTape>)> {
            let (q, k, v, conv) = prepare_qkv(
                &self.qkv, &self.conv, &self.weights, &self.qs, &self.ks,
                16, self.value_heads, 128, 128, 4,
            )?;
            let (out, next, tape) = if retain {
                let (out, next, tape) = step_with_gates_tape(
                    &q, &k, &v, &self.a, &self.b, &self.a_log, &self.bias, &self.state,
                )?;
                (out, next, Some(tape))
            } else {
                let (out, next) = step_with_gates(
                    &q, &k, &v, &self.a, &self.b, &self.a_log, &self.bias, &self.state,
                )?;
                (out, next, None)
            };
            Ok((out, next, conv, tape))
        }

        fn fused(&self, retain: bool) -> Result<(Array, Array, Array, Option<RecurrentTape>)> {
            prepare_and_step_with_gates(
                &self.qkv, &self.conv, &self.weights, &self.qs, &self.ks,
                &self.a, &self.b, &self.a_log, &self.bias, &self.state, retain,
            )
        }

        fn evaluate(&self, fused: bool, retain: bool) -> Result<()> {
            let (out, next, conv, tape) = if fused { self.fused(retain)? } else { self.split(retain)? };
            out.eval()?;
            next.eval()?;
            conv.eval()?;
            if let Some(tape) = tape {
                tape.keys.eval()?;
                tape.delta.eval()?;
                tape.decay.eval()?;
            }
            array::synchronize()
        }
    }

    fn gdn_preparation_fixture(shape: &[i32], seed: usize) -> Result<Array> {
        let count = shape.iter().map(|&d| d as usize).product();
        Array::from_f16_bits(
            &(0..count)
                .map(|i| {
                    half::f16::from_f32(if seed == 0 {
                        0.
                    } else {
                        ((i * 7 + seed) % 61) as f32 / 64. - 0.5
                    }).to_bits()
                })
                .collect::<Vec<_>>(),
            shape,
        )
    }

    fn check_gdn_preparation_arrays(actual: &Array, expected: &Array, name: &str) -> Result<()> {
        assert_eq!(actual.shape(), expected.shape(), "{name} shape");
        assert_eq!(actual.dtype(), expected.dtype(), "{name} dtype");
        let count = expected.shape().iter().map(|&d| d as usize).product::<usize>();
        assert!(count > 0, "{name} empty");
        for array in [actual, expected] {
            let values = array.to_f32()?;
            assert_eq!(values.len(), count, "{name} size");
            assert!(values.iter().all(|value| value.is_finite()), "{name} non-finite");
        }
        let actual = actual.to_bytes()?;
        let expected = expected.to_bytes()?;
        assert!(
            actual == expected,
            "{name} bits differ at byte {:?}",
            actual.iter().zip(&expected).position(|(a, b)| a != b),
        );
        Ok(())
    }

    #[test]
    #[ignore = "requires local Qwen27B checkpoint and physical Apple GPU; run alone"]
    fn fused_preparation_recurrence_matches_split_and_all_prefixes() -> Result<()> {
        let model_path = std::env::var("MLXL3_MTP_TEST_MODEL")
            .context("set MLXL3_MTP_TEST_MODEL to the Qwen27B checkpoint")?;
        let checkpoint = crate::checkpoint::inspect(std::path::Path::new(&model_path))?;
        let prefix = "model.language_model.layers.0.linear_attn";
        let mut comparisons = 0;
        let mut replay_comparisons = 0;
        let mut micro_cases = Vec::new();
        for value_heads in [32, 48] {
            let conv_dims = 4096 + value_heads * 128;
            let (weights, a_log, bias) = if value_heads == 48 {
                (
                    crate::lfm2::half_weight(
                        &checkpoint, &format!("{prefix}.conv1d.weight"), Some(&[conv_dims, 1, 4]),
                    )?.transpose(&[0, 2, 1])?,
                    crate::linear::checkpoint_array(&checkpoint, &format!("{prefix}.A_log"))?
                        .astype(Dtype::Float32)?,
                    crate::lfm2::half_weight(
                        &checkpoint, &format!("{prefix}.dt_bias"), Some(&[value_heads]),
                    )?,
                )
            } else {
                (
                    gdn_preparation_fixture(&[conv_dims, 4, 1], 11)?,
                    Array::from_f32(
                        &(0..value_heads).map(|i| -4. + i as f32 / 32.).collect::<Vec<_>>(),
                        &[value_heads],
                    )?,
                    gdn_preparation_fixture(&[value_heads], 5)?,
                )
            };
            assert_eq!(a_log.shape(), [value_heads]);
            for seed in [0, 7] {
                for time in 0..=5 {
                    let fixture = GdnPreparationFixture {
                        value_heads,
                        qkv: gdn_preparation_fixture(&[1, time, conv_dims], seed)?,
                        conv: gdn_preparation_fixture(&[1, 3, conv_dims], seed)?,
                        weights: weights.try_clone()?,
                        qs: Array::from_f16_bits(&[half::f16::from_f32(1. / 128.).to_bits()], &[])?,
                        ks: Array::from_f16_bits(&[half::f16::from_f32(1. / 128_f32.sqrt()).to_bits()], &[])?,
                        a: gdn_preparation_fixture(&[1, time, value_heads], seed)?,
                        b: gdn_preparation_fixture(&[1, time, value_heads], seed + 1)?,
                        a_log: a_log.try_clone()?,
                        bias: bias.try_clone()?,
                        state: gdn_preparation_fixture(&[1, value_heads, 128, 128], seed)?
                            .astype(Dtype::Float32)?,
                    };
                    if time == 0 || time == 5 {
                        assert!(fixture.fused(true).is_err());
                        continue;
                    }
                    let (q, k, v, _) = prepare_qkv(
                        &fixture.qkv, &fixture.conv, &fixture.weights, &fixture.qs, &fixture.ks,
                        16, value_heads, 128, 128, 4,
                    )?;
                    let (expected, state, next_conv, expected_tape) = fixture.split(true)?;
                    let expected_tape = expected_tape.context("missing reference tape")?;
                    let mut serial_state = fixture.state.try_clone()?;
                    let mut serial_rows = Vec::new();
                    let mut prefixes = Vec::new();
                    for row in 0..time {
                        let (out, next) = step_with_gates(
                            &q.slice(1, row, row + 1)?, &k.slice(1, row, row + 1)?,
                            &v.slice(1, row, row + 1)?, &fixture.a.slice(1, row, row + 1)?,
                            &fixture.b.slice(1, row, row + 1)?, &fixture.a_log, &fixture.bias,
                            &serial_state,
                        )?;
                        serial_rows.push(out);
                        serial_state = next;
                        prefixes.push(serial_state.try_clone()?);
                    }
                    check_gdn_preparation_arrays(
                        &expected, &Array::concatenate(&serial_rows.iter().collect::<Vec<_>>(), 1)?,
                        "split vs serial output",
                    )?;
                    check_gdn_preparation_arrays(&state, &serial_state, "split vs serial state")?;
                    for retain in [false, true] {
                        let (out, next, conv, tape) = fixture.fused(retain)?;
                        check_gdn_preparation_arrays(&out, &expected, "output")?;
                        check_gdn_preparation_arrays(&next, &state, "state")?;
                        check_gdn_preparation_arrays(&conv, &next_conv, "conv")?;
                        if let Some(tape) = tape {
                            assert!(retain);
                            check_gdn_preparation_arrays(&tape.keys, &k, "keys")?;
                            check_gdn_preparation_arrays(&tape.delta, &expected_tape.delta, "delta")?;
                            check_gdn_preparation_arrays(&tape.decay, &expected_tape.decay, "decay")?;
                            for invalid in [i32::MIN, 0, time + 1, i32::MAX] {
                                assert!(tape.replay(invalid).is_err());
                            }
                            for retained in 1..=time {
                                check_gdn_preparation_arrays(
                                    &tape.replay(retained)?, &prefixes[(retained - 1) as usize],
                                    "replay vs serial prefix",
                                )?;
                                let (_, _, _, serial_conv) = prepare_qkv(
                                    &fixture.qkv.slice(1, 0, retained)?, &fixture.conv,
                                    &fixture.weights, &fixture.qs, &fixture.ks,
                                    16, value_heads, 128, 128, 4,
                                )?;
                                let committed_conv = Array::concatenate(&[&fixture.conv, &fixture.qkv], 1)?
                                    .slice(1, retained, retained + 3)?;
                                check_gdn_preparation_arrays(
                                    &committed_conv, &serial_conv, "committed conv prefix",
                                )?;
                                replay_comparisons += 1;
                            }
                        } else {
                            assert!(!retain);
                        }
                        comparisons += 1;
                    }
                    for (bad_qkv, bad_conv, bad_qs, bad_state) in [
                        (fixture.qkv.astype(Dtype::Float32)?, fixture.conv.try_clone()?,
                         fixture.qs.try_clone()?, fixture.state.try_clone()?),
                        (fixture.qkv.try_clone()?, fixture.conv.slice(1, 0, 2)?,
                         fixture.qs.try_clone()?, fixture.state.try_clone()?),
                        (fixture.qkv.try_clone()?, fixture.conv.try_clone()?,
                         fixture.qs.reshape(&[1])?, fixture.state.try_clone()?),
                        (fixture.qkv.try_clone()?, fixture.conv.try_clone()?,
                         fixture.qs.try_clone()?, fixture.state.astype(Dtype::Float16)?),
                    ] {
                        assert!(prepare_and_step_with_gates(
                            &bad_qkv, &bad_conv, &fixture.weights, &bad_qs, &fixture.ks,
                            &fixture.a, &fixture.b, &fixture.a_log, &fixture.bias, &bad_state, true,
                        ).is_err());
                    }
                    if seed == 7 && time <= 2 {
                        micro_cases.push(fixture);
                    }
                }
            }
        }
        assert_eq!(comparisons, 32);
        assert_eq!(replay_comparisons, 40);
        eprintln!(
            "GDN18 quality: 32 split comparisons, 40 serial rollback prefixes; Hv32 synthetic/Hv48 checkpoint; finite bitexact output/state/conv/keys/tapes"
        );
        if std::env::var("MLXL3_GDN_FUSED_MICRO").as_deref() == Ok("1") {
            assert_eq!(micro_cases.len(), 4);
            for fixture in micro_cases {
                let time = fixture.qkv.shape()[1];
                let retain = time > 1;
                for _ in 0..3 {
                    fixture.evaluate(false, retain)?;
                    fixture.evaluate(true, retain)?;
                }
                let mut samples = [Vec::with_capacity(40), Vec::with_capacity(40)];
                for repeat in 0..40 {
                    for fused in if repeat % 2 == 0 { [false, true] } else { [true, false] } {
                        let start = std::time::Instant::now();
                        fixture.evaluate(fused, retain)?;
                        let millis = start.elapsed().as_secs_f64() * 1000.;
                        assert!(millis.is_finite() && millis > 0.);
                        samples[usize::from(fused)].push(millis);
                    }
                }
                println!("{}", serde_json::json!({
                    "gdn18_micro": {
                        "value_heads": fixture.value_heads, "time": time, "retain": retain,
                        "quality_complete": true, "warmups": 3, "pairs": 40,
                        "boundary": "prepare+recurrence+outputs host/MLX/GPU sync; no generation speed",
                        "samples_ms": samples,
                    }
                }));
            }
        }
        Ok(())
    }
