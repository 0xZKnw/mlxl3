import AppKit
import SwiftUI

@main struct SettingsCheck {
    @MainActor static func main() throws {
        let app = NSApplication.shared
        app.setActivationPolicy(.prohibited)
        let suite = "io.mlxl3.mlx-policy." + UUID().uuidString
        let prefs = UserDefaults(suiteName: suite)!
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(suite)
        defer { prefs.removePersistentDomain(forName: suite); try? FileManager.default.removeItem(at: root) }
        let model = StudioModel(conversationFileURL: root.appendingPathComponent("history.json"), preferences: prefs)
        precondition(!EngineRuntimeStore.nativeEngineEnabled)
        for (width, height) in [(960, 720), (1280, 900)] {
            let view = NSHostingView(rootView: AppSettingsView().environmentObject(model))
            let window = NSWindow(contentRect: NSRect(x: -20000, y: -20000, width: width, height: height), styleMask: [.borderless], backing: .buffered, defer: false)
            window.isReleasedWhenClosed = false
            window.contentView = view
            view.frame = NSRect(x: 0, y: 0, width: width, height: height)
            view.layoutSubtreeIfNeeded()
            RunLoop.main.run(until: Date().addingTimeInterval(0.2))
            let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds)!
            view.cacheDisplay(in: view.bounds, to: bitmap)
            let data = bitmap.representation(using: .png, properties: [:])!
            precondition(data.count > 1000)
            try data.write(to: URL(fileURLWithPath: "build/v2-mlx/settings-\(width).png"))
            window.close()
        }
        print("Settings rendered offscreen at 960×720 and 1280×900")
    }
}
