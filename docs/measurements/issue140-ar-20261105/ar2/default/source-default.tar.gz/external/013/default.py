"""Qualify the retained AR2 default without rerunning its controlled screen."""

import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
D = runpy.run_path(str(ROOT / "build/issue140/ar2.py"))
R = D["R"]
BASE_CHECK = D["check_marker"]
SPECS = tuple(spec for spec in D["SPECS"] if spec[0] == "model")


def environment(enabled=1):
    assert type(enabled) is int and enabled == 1
    env = D["environment"](enabled)
    del env[D["FLAG"]]
    return env


def check_marker(text, spec):
    evidence = BASE_CHECK(text, spec)
    assert evidence["qsa_append_default_environment_unset"] is True
    return evidence


def journal(message):
    with (ROOT / "opti.md").open("a") as stream:
        stream.write("\nAR36 DEFAULT " + message + "\n")


def main():
    R["main"].__globals__.update(
        __file__=__file__,
        HERE=ROOT / "docs/measurements/issue140-ar-20261105/ar2/default",
        SPECS=SPECS,
        NEW=(D["FLAG"],),
        ARMS=(("default", 1),),
        TOKEN_CHOICES=(128,),
        DEFAULT_TOKENS=128,
        EXTRA_REQUIRED=D["EXTRA_REQUIRED"],
        environment=environment,
        check_marker=check_marker,
        journal=journal,
    )
    R["main"]()


if __name__ == "__main__":
    main()
