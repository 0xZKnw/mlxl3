"""AR2 only: reuse the audited supervisor, golden and cleanup contracts."""

import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "docs/measurements/issue140-ar-20261105/ar2"
R = runpy.run_path(str(ROOT / "build/issue140/run.py"))
FLAG = "MLXL3_NATIVE_QSA_APPEND_CHAIN"
REFERENCE = Path("/Users/justin/Documents/mix-stq1_0/build/flash-attention-oracle-06")
EXTRA_REQUIRED = (
    REFERENCE / "reference.json",
    *(REFERENCE / f"a15-s{i}-{kind}.f32" for i in range(5) for kind in ("input", "out")),
)
REFERENCE_SHA256 = "40c57a914159b81a14d95324188799c3f503ee2ca992f4bc46ccbc60aaed74ec"
BASE_ENV = R["environment"]
BASE_MARKER = R["check_marker"]
SPECS = (
    (
        "qsa",
        "gpu::qsa::ar36_tests::physical_ar36_qsa_append_chain_preserves_canonical_states_and_rollbacks",
        "AR36_QSA_APPEND_CHAIN",
    ),
    next(spec for spec in R["SPECS"] if spec[0] == "model"),
)
CONTEXTS = [3, 4, 32, 33, 1023, 1024, 2047, 2048, 2049, 2050, 2051, 2052]


def environment(enabled=1):
    assert type(enabled) is int and enabled in (0, 1)
    env = BASE_ENV(enabled)
    env.pop("MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE", None)
    env.pop("MLXL3_NATIVE_READY_STAGES", None)
    env.update(
        {
            FLAG: str(enabled),
            "MLXL3_NATIVE_QSA_HC_CHAIN": "0",
            "MLXL3_NATIVE_FINAL_HEAD_CHAIN": "0",
            "MLXL3_QSA_MODEL": R["D"]["MODEL"],
            "MLXL3_FLASH_ATTENTION_REFERENCE": str(REFERENCE),
        }
    )
    return env


def checked_counts(value):
    assert type(value) is list and len(value) == 3
    assert all(type(n) is int and n >= 0 for n in value)
    assert value[0] >= value[1]
    return value


def checked_delta(before, after):
    a, b = checked_counts(before), checked_counts(after)
    assert [y - x for x, y in zip(a, b, strict=True)] == [12, 12, 0]


def check_marker(text, spec):
    if spec[0] == "model":
        evidence = BASE_MARKER(text, spec)
        total = checked_counts(evidence["qsa_append_chain_counts"])
        assert total[1] >= 24
        for row in evidence["actual_paths"]:
            checked_delta(
                row["before"]["qsa_append_chain_counts"],
                row["after"]["qsa_append_chain_counts"],
            )
        return evidence
    R["D"]["test_log"](text)
    evidence = R["D"]["marker"](text, spec[2])
    R["D"]["OLD"]["exact_fields"](
        evidence,
        {
            "parity": True,
            "boundary_cases": 27,
            "contexts": CONTEXTS,
            "independent_output_words": 12800,
            "trace_fallback": True,
            "unindexed_fallback": True,
            "sparse_2052_fallback": True,
            "grow": True,
            "fork": True,
            "retained_snapshot": True,
            "stale_prepared_rejected": True,
            "encode_failure": True,
            "post_append_publication_failure": True,
            "retry": True,
            "unsubmitted_abandon": True,
            "submitted_abandon": True,
            "all_commands_joined": True,
        },
    )
    words = evidence["synthetic_state_half_words"]
    assert type(words) is int and words > 1_000_000
    counts = checked_counts(evidence["actual_counts"])
    assert counts[0] > 0 and counts[1] > 0 and counts[2] >= 2
    return evidence


def journal(message):
    with (ROOT / "opti.md").open("a") as stream:
        stream.write("\nAR36 AR2 " + message + "\n")


def main():
    R["main"].__globals__.update(
        __file__=__file__,
        HERE=HERE,
        SPECS=SPECS,
        NEW=(FLAG,),
        ARMS=(("control-start", 0), ("qsa-append", 1), ("control-end", 0)),
        TOKEN_CHOICES=(128,),
        DEFAULT_TOKENS=128,
        EXTRA_REQUIRED=EXTRA_REQUIRED,
        environment=environment,
        check_marker=check_marker,
        journal=journal,
    )
    R["main"]()


if __name__ == "__main__":
    main()
