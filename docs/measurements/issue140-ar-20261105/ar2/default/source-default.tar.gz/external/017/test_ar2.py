"""Prepared CPU marker/flag mutations; no model or child process is launched."""

import json
import runpy
import unittest
from pathlib import Path

R = runpy.run_path(str(Path(__file__).with_name("ar2.py")))


def log(evidence):
    return (
        "dyld[123]: /System/Library/Frameworks/Metal.framework/Metal\nrunning 1 test\n"
        + "AR36_QSA_APPEND_CHAIN "
        + json.dumps(evidence)
        + "\ntest result: ok. 1 passed; 0 failed; 0 ignored;\n"
    )


class AR2(unittest.TestCase):
    def setUp(self):
        self.evidence = {
            "parity": True,
            "boundary_cases": 27,
            "contexts": R["CONTEXTS"],
            "independent_output_words": 12800,
            "synthetic_state_half_words": 1000001,
            "actual_counts": [25, 24, 2],
            **{
                key: True
                for key in (
                    "trace_fallback",
                    "unindexed_fallback",
                    "sparse_2052_fallback",
                    "grow",
                    "fork",
                    "retained_snapshot",
                    "stale_prepared_rejected",
                    "encode_failure",
                    "post_append_publication_failure",
                    "retry",
                    "unsubmitted_abandon",
                    "submitted_abandon",
                    "all_commands_joined",
                )
            },
        }

    def test_exact_component_and_every_missing_field(self):
        R["check_marker"](log(self.evidence), R["SPECS"][0])
        for key in self.evidence:
            bad = self.evidence.copy()
            del bad[key]
            with self.subTest(missing=key), self.assertRaises((AssertionError, KeyError)):
                R["check_marker"](log(bad), R["SPECS"][0])

    def test_divergent_vacuous_or_incomplete_component(self):
        for key, value in (
            ("parity", False),
            ("boundary_cases", 26),
            ("independent_output_words", 0),
            ("synthetic_state_half_words", 1000000),
            ("synthetic_state_half_words", True),
            ("actual_counts", [0, 0, 2]),
            ("actual_counts", [25, 24, 1]),
            ("actual_counts", [2, 3, 2]),
        ):
            with self.subTest(key=key, value=value), self.assertRaises(AssertionError):
                R["check_marker"](log({**self.evidence, key: value}), R["SPECS"][0])

    def test_duplicate_json_nonfinite_and_false_true_mutants(self):
        text = log(self.evidence)
        for bad in (
            text + "AR36_QSA_APPEND_CHAIN " + json.dumps(self.evidence),
            text.replace('"parity": true', '"parity": false, "parity": true'),
            log({**self.evidence, "extra": float("nan")}),
        ):
            with self.assertRaises((AssertionError, ValueError)):
                R["check_marker"](bad, R["SPECS"][0])

    def test_real_model_delta_is_twelve_without_fallback_or_abandon(self):
        R["checked_delta"]([1, 1, 0], [13, 13, 0])
        for value in ([12, 12, 0], [13, 12, 0], [13, 13, 1], [13, 13], [True, 13, 0], [-1, 13, 0]):
            with self.subTest(value=value), self.assertRaises(AssertionError):
                R["checked_delta"]([1, 1, 0], value)

    def test_retained_defaults_and_only_ar2_override(self):
        for enabled in (0, 1):
            env = R["environment"](enabled)
            self.assertEqual(env[R["FLAG"]], str(enabled))
            self.assertNotIn("MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE", env)
            self.assertNotIn("MLXL3_NATIVE_READY_STAGES", env)
            self.assertEqual(env["MLXL3_NATIVE_QSA_HC_CHAIN"], "0")
            self.assertEqual(env["MLXL3_NATIVE_FINAL_HEAD_CHAIN"], "0")
            self.assertTrue(all(env[name] == "1" for name in R["R"]["D"]["FLAGS"]))
            self.assertEqual(env["MLXL3_FLASH_ATTENTION_REFERENCE"], str(R["REFERENCE"]))
        for bad in (-1, 2, True, "1"):
            with self.assertRaises(AssertionError):
                R["environment"](bad)

    def test_reference_contract_has_exact_eleven_flat_files(self):
        paths = R["EXTRA_REQUIRED"]
        self.assertEqual(len(set(paths)), 11)
        self.assertTrue(all(path.parent == R["REFERENCE"] for path in paths))
        self.assertEqual(paths[0].name, "reference.json")
        self.assertEqual(len(R["REFERENCE_SHA256"]), 64)


if __name__ == "__main__":
    unittest.main()
