import runpy
import unittest
from pathlib import Path
from unittest.mock import patch

D = runpy.run_path(str(Path(__file__).with_name("default.py")))


class Default(unittest.TestCase):
    def test_unset_flag_preserves_qualified_baseline(self):
        env = D["environment"]()
        self.assertNotIn(D["D"]["FLAG"], env)
        self.assertNotIn("MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE", env)
        self.assertEqual(env["MLXL3_NATIVE_QSA_HC_CHAIN"], "0")
        self.assertEqual(env["MLXL3_NATIVE_FINAL_HEAD_CHAIN"], "0")
        for value in (0, True, "1", -1):
            with self.assertRaises(AssertionError):
                D["environment"](value)

    def test_default_gate_rejects_forced_missing_or_falsely_typed_evidence(self):
        function = D["check_marker"]
        for evidence in (
            {},
            {"qsa_append_default_environment_unset": False},
            {"qsa_append_default_environment_unset": 1},
        ):
            with (
                patch.dict(function.__globals__, BASE_CHECK=lambda *_, value=evidence: value),
                self.assertRaises((AssertionError, KeyError)),
            ):
                function("unused", D["SPECS"][0])
        good = {"qsa_append_default_environment_unset": True}
        with patch.dict(function.__globals__, BASE_CHECK=lambda *_: good):
            self.assertIs(function("unused", D["SPECS"][0]), good)


if __name__ == "__main__":
    unittest.main()
