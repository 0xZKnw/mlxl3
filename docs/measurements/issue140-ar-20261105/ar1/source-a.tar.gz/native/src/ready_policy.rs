//! Bounds used by the real cold-ready preparation/finish caller.
pub(crate) const OUTPUT_BYTES: u64 = 5120;

pub(crate) fn eligible(
    enabled: bool,
    n: usize,
    axis: bool,
    dual: bool,
    fused: bool,
    pending: bool,
) -> bool {
    enabled && (2..=10).contains(&n) && axis && dual && fused && !pending
}

pub(crate) fn bytes(n: usize, width: usize, element: usize) -> Option<u64> {
    if !(2..=10).contains(&n) || !matches!(width, 640 | 2560 | 5120) || !matches!(element, 2 | 4) {
        return None;
    }
    (n as u64)
        .checked_mul(width as u64)?
        .checked_mul(element as u64)
}

pub(crate) fn prefix(index: usize, n: usize, width: usize, element: usize) -> Option<(u64, u64)> {
    let total = bytes(n, width, element)?;
    if index >= n {
        return None;
    }
    let stride = (width as u64).checked_mul(element as u64)?;
    let start = (index as u64).checked_mul(stride)?;
    let end = start.checked_add(stride)?;
    (end <= total).then_some((start, end))
}

pub(crate) fn destination(offset: u64, length: u64) -> bool {
    offset.is_multiple_of(2)
        && offset
            .checked_add(OUTPUT_BYTES)
            .is_some_and(|end| end <= length)
}

pub(crate) fn disjoint(first: u64, second: u64) -> bool {
    match (
        first.checked_add(OUTPUT_BYTES),
        second.checked_add(OUTPUT_BYTES),
    ) {
        (Some(a), Some(b)) => a <= second || b <= first,
        _ => false,
    }
}

#[test]
fn ready_stage_bounds_cover_singletons_tails_aliases_and_overflow() {
    assert!(!eligible(true, 1, true, true, true, false));
    assert!(eligible(true, 2, true, true, true, false));
    assert!(eligible(true, 10, true, true, true, false));
    assert!(!eligible(true, 11, true, true, true, false));
    assert!(!eligible(true, 2, true, true, true, true));
    assert!(!eligible(false, 2, true, true, true, false));
    assert_eq!(bytes(10, 5120, 2), Some(102400));
    assert_eq!(prefix(9, 10, 2560, 2), Some((46080, 51200)));
    assert_eq!(prefix(10, 10, 640, 4), None);
    assert_eq!(bytes(usize::MAX, usize::MAX, usize::MAX), None);
    assert!(destination(2, 5122));
    assert!(!destination(1, 5121));
    assert!(!destination(u64::MAX - 1, u64::MAX));
    assert!(disjoint(0, 5120));
    assert!(!disjoint(0, 5118));
    assert!(!disjoint(u64::MAX, 0));
}

#[cfg(kani)]
#[kani::proof]
fn ready_stages_actual_cohort_prefixes_and_destinations_never_escape() {
    let n: usize = kani::any();
    let i: usize = kani::any();
    let width: usize = kani::any();
    let element: usize = kani::any();
    let enabled: bool = kani::any();
    let axis: bool = kani::any();
    let dual: bool = kani::any();
    let fused: bool = kani::any();
    let pending: bool = kani::any();
    let yes = eligible(enabled, n, axis, dual, fused, pending);
    assert_eq!(
        yes,
        enabled && n >= 2 && n <= 10 && axis && dual && fused && !pending
    );
    if let Some(total) = bytes(n, width, element) {
        assert!(total <= 204800 && total > 0);
    }
    if let Some((start, end)) = prefix(i, n, width, element) {
        assert!(start < end && end <= bytes(n, width, element).unwrap());
    }
    let a: u64 = kani::any();
    let b: u64 = kani::any();
    let length: u64 = kani::any();
    if destination(a, length) {
        assert!(a % 2 == 0 && u128::from(a) + 5120 <= u128::from(length));
    }
    if disjoint(a, b) {
        assert!(u128::from(a) + 5120 <= u128::from(b) || u128::from(b) + 5120 <= u128::from(a));
    }
    kani::cover!(yes && n == 2);
    kani::cover!(yes && n == 10);
    kani::cover!(!yes && n == 1);
    kani::cover!(prefix(i, n, width, element) == Some((46080, 51200)));
    kani::cover!(disjoint(a, b));
    kani::cover!(!destination(a, length) && a == u64::MAX);
}
