use super::super::routed_scratch_tests::{Case, input, record};
use super::*;
use std::{fs, path::PathBuf};

type CanonicalRows = Vec<Vec<u16>>;

// Uses the original prepare/finish PSOs and original ten-binding axis QMV;
// no new vector-stage helper or shader contributes to this oracle.
fn canonical(
    gpu: &Metal,
    x: &MatrixView,
    experts: &[&FlashExpert<'_>],
) -> Result<(CanonicalRows, CanonicalRows)> {
    let n = experts.len();
    let (trace, outputs) = gpu.command(|cmd| {
        let prepared = buffer(&gpu.device, (n * 10240) as u64, Storage::StorageModeShared)?;
        let gate_partial = buffer(&gpu.device, (n * 2560) as u64, Storage::StorageModeShared)?;
        let up_partial = buffer(&gpu.device, (n * 2560) as u64, Storage::StorageModeShared)?;
        let down_partial = buffer(&gpu.device, (n * 10240) as u64, Storage::StorageModeShared)?;
        let down_prepared = buffer(&gpu.device, (n * 1280) as u64, Storage::StorageModeShared)?;
        for (i, e) in experts.iter().enumerate() {
            Metal::encode_bound(
                cmd,
                gpu.expert_gu_prepare.as_ref().unwrap(),
                [
                    (&x.buffer, 0),
                    (&e.gate.suh, e.gate.offsets.suh),
                    (&e.up.suh, e.up.offsets.suh),
                    (&prepared, (i * 10240) as u64),
                ]
                .into_iter(),
                [
                    x.layout.offset,
                    x.layout.strides[1],
                    i64::from(x.dtype == FloatType::F32),
                    2560,
                ],
                MTLSize::new(20, 1, 1),
                64,
            );
        }
        FlashExpert::encode_axis_qmv(cmd, experts, 0, &prepared, 0, 5120, &gate_partial)?;
        let mut gates = Vec::new();
        for (i, e) in experts.iter().enumerate() {
            let gate = buffer(&gpu.device, 1280, Storage::StorageModeShared)?;
            e.gate
                .encode_finish(cmd, &gate_partial, (i * 2560) as u64, &gate, 0, 640, None)?;
            gates.push(gate);
        }
        FlashExpert::encode_axis_qmv(cmd, experts, 1, &prepared, 5120, 5120, &up_partial)?;
        let mut active = Vec::new();
        for (i, e) in experts.iter().enumerate() {
            let out = buffer(&gpu.device, 1280, Storage::StorageModeShared)?;
            e.up.encode_finish(
                cmd,
                &up_partial,
                (i * 2560) as u64,
                &out,
                0,
                640,
                Some(&gates[i]),
            )?;
            e.down.encode_input_into(
                cmd,
                Activation::Contiguous(&out),
                &down_prepared,
                (i * 1280) as u64,
            )?;
            active.push(out);
        }
        FlashExpert::encode_axis_qmv(cmd, experts, 2, &down_prepared, 0, 640, &down_partial)?;
        let mut outputs = Vec::new();
        for (i, e) in experts.iter().enumerate() {
            let out = buffer(&gpu.device, 5120, Storage::StorageModeShared)?;
            e.down
                .encode_finish(cmd, &down_partial, (i * 10240) as u64, &out, 0, 2560, None)?;
            outputs.push(out);
        }
        let gate_slab = buffer(&gpu.device, (n * 1280) as u64, Storage::StorageModeShared)?;
        let active_slab = buffer(&gpu.device, (n * 1280) as u64, Storage::StorageModeShared)?;
        let blit = cmd.new_blit_command_encoder();
        for i in 0..n {
            blit.copy_from_buffer(&gates[i], 0, &gate_slab, (i * 1280) as u64, 1280);
            blit.copy_from_buffer(&active[i], 0, &active_slab, (i * 1280) as u64, 1280);
        }
        blit.end_encoding();
        Ok((
            vec![
                prepared,
                gate_partial,
                gate_slab,
                up_partial,
                active_slab,
                down_prepared,
                down_partial,
            ],
            outputs,
        ))
    })?;
    Ok((
        trace
            .iter()
            .map(|b| Metal::read(b, b.length() as usize / 2))
            .collect(),
        outputs.iter().map(|b| Metal::read(b, 2560)).collect(),
    ))
}

fn check_stage(index: usize, actual: &[u16], expected: &[u16]) -> Result<()> {
    ensure!(
        !actual.is_empty() && actual == expected,
        "ready stage{index} differs"
    );
    if matches!(index, 1 | 3 | 6) {
        ensure!(
            actual.len().is_multiple_of(2)
                && actual
                    .as_chunks::<2>()
                    .0
                    .iter()
                    .all(|w| f32::from_bits(u32::from(w[0]) | (u32::from(w[1]) << 16)).is_finite())
        );
    } else {
        ensure!(actual.iter().all(|&w| f16::from_bits(w).is_finite()));
    }
    Ok(())
}

#[test]
#[ignore = "physical AR35 cold-ready stages: independent original PSOs, all intermediates, poisoned slabs/strides/alias/duplicates/precommit failure; exclusive GPU"]
fn physical_ar35_ready_stages_preserve_canonical_intermediates_and_boundaries() -> Result<()> {
    let gpu = Metal::new()?;
    ensure!(
        gpu.ready_stages_enabled(),
        "enable READY_STAGES on exact M5"
    );
    let bulk = gpu.ready_batch_bindings_enabled();
    ensure!(
        std::env::var("MLXL3_NATIVE_READY_BATCH_BINDINGS").as_deref() != Ok("1") || bulk,
        "requested ready-stage bulk bindings were not selected"
    );
    let root = PathBuf::from(
        std::env::var_os("MLXL3_ROUTED_SCRATCH_FIXTURES")
            .context("routed stock fixtures required")?,
    );
    let cases: Vec<Case> = serde_json::from_slice(&fs::read(root.join("cases.json"))?)?;
    let stock: Vec<Vec<u16>> = serde_json::from_slice(&fs::read(root.join("stock.json"))?)?;
    ensure!(cases.len() >= 5 && cases.len() == stock.len() && stock[0].len() == 2560);
    let base = [record(&gpu, &cases[0])?, record(&gpu, &cases[1])?];
    let mut owners = Vec::new();
    for i in 0..10 {
        let mut words = Metal::read(&base[i % 2], flash_support::EXPERT_BYTES as usize / 2);
        for stage in 0..3 {
            let offset = flash_support::record_offsets(stage).unwrap().suh as usize / 2;
            let width = if stage == 0 { 640 } else { 2560 };
            for word in &mut words[offset..offset + width] {
                *word = f16::from_f32(f16::from_bits(*word).to_f32() * (1. + i as f32 / 128.))
                    .to_bits();
            }
        }
        let offset = flash_support::record_offsets(0).unwrap().svh as usize / 2;
        for word in &mut words[offset..offset + 2560] {
            *word = f16::from_f32(f16::from_bits(*word).to_f32() * (1. + i as f32 / 64.)).to_bits();
        }
        owners.push(super::super::super::upload(&gpu.device, &words)?);
    }
    let experts = owners
        .iter()
        .map(|b| FlashExpert::from_backing(&gpu, b))
        .collect::<Result<Vec<_>>>()?;
    let compiled = gpu
        .ar20_library
        .get_function("ready_compiled", None)
        .map_err(anyhow::Error::msg)?;
    let compiled = gpu
        .device
        .new_compute_pipeline_state_with_function(&compiled)
        .map_err(anyhow::Error::msg)?;
    let flag = buffer(&gpu.device, 4, Storage::StorageModeShared)?;
    gpu.command(|cmd| {
        Metal::encode(cmd, &compiled, &[&flag], [0u32], MTLSize::new(1, 1, 1), 1);
        Ok(())
    })?;
    ensure!(Metal::read(&flag, 2) == [1, 0]);
    gpu.ready_stages.capture.set(true);
    let mut stage_bytes = 0usize;
    let mut output_words = 0usize;
    let mut test_cases = 0;
    let mut mutated = false;
    for n in [1usize, 2, 10] {
        for fp32 in [false, true] {
            for pattern in 0..if n == 1 { 1 } else { 3 } {
                let order = (0..n)
                    .map(|i| match pattern {
                        1 => n - 1 - i,
                        2 => i % 2,
                        _ => i,
                    })
                    .collect::<Vec<_>>();
                let cohort = order.iter().map(|&i| &experts[i]).collect::<Vec<_>>();
                let x = input(&gpu, &cases[0], fp32)?;
                let (expected_stages, expected) = canonical(&gpu, &x, &cohort)?;
                if pattern == 0 {
                    ensure!(expected[0] == stock[0]);
                }
                let poison = vec![0x7e55u16; n * 2560 + 32];
                let dest = super::super::super::upload(&gpu.device, &poison)?;
                let targets = (0..n)
                    .map(|i| Some((&dest, 16 + (i * 5120) as u64)))
                    .collect::<Vec<_>>();
                let before = gpu.ready_stage_counts.get();
                let bulk_before = gpu.ready_bulk_counts.get();
                let outputs = gpu.command(|cmd| {
                    FlashExpert::encode_ready_cohort(
                        cmd,
                        &x,
                        &cohort,
                        &targets,
                        Storage::StorageModeShared,
                    )
                })?;
                ensure!(outputs.len() == n);
                let actual = Metal::read(&dest, poison.len());
                ensure!(
                    actual[..8] == poison[..8] && actual[8 + n * 2560..] == poison[8 + n * 2560..]
                );
                for (i, row) in expected.iter().enumerate() {
                    ensure!(
                        &actual[8 + i * 2560..8 + (i + 1) * 2560] == row
                            && row.iter().all(|&w| f16::from_bits(w).is_finite())
                    );
                    output_words += row.len();
                }
                let after = gpu.ready_stage_counts.get();
                let bulk_after = gpu.ready_bulk_counts.get();
                let bulk_delta = std::array::from_fn::<_, 3, _>(|i| bulk_after[i] - bulk_before[i]);
                ensure!(bulk_delta == if bulk && n > 1 { [5, 90, 5] } else { [0; 3] });
                if n == 1 {
                    ensure!(after == before && gpu.ready_stages.captured.borrow().is_none());
                } else {
                    let trace = gpu
                        .ready_stages
                        .captured
                        .borrow_mut()
                        .take()
                        .context("missing actual vector-stage captures")?;
                    ensure!(trace.len() == expected_stages.len() && trace.len() == 7);
                    for (stage, (buffer, expected)) in
                        trace.iter().zip(&expected_stages).enumerate()
                    {
                        let actual = Metal::read(buffer, buffer.length() as usize / 2);
                        check_stage(stage, &actual, expected)?;
                        stage_bytes += actual.len() * 2;
                        if !mutated {
                            let mut wrong = actual.clone();
                            wrong[0] ^= 1;
                            ensure!(check_stage(stage, &wrong, expected).is_err());
                            mutated = true;
                        }
                    }
                    ensure!(
                        after[0] == before[0] + 1
                            && (1..=5).all(|i| after[i] == before[i] + 1)
                            && after[6] == before[6] + n as u64
                            && after[7] == before[7] + 8
                    );
                }
                test_cases += 1;
            }
        }
    }
    let valid_counts = gpu.ready_stage_counts.get();
    let valid_bulk_counts = gpu.ready_bulk_counts.get();
    ensure!(
        valid_counts == [12, 12, 12, 12, 12, 12, 72, 96]
            && valid_bulk_counts == if bulk { [60, 1080, 60] } else { [0; 3] }
            && test_cases == 14
            && stage_bytes == 2119680
            && output_words == 189440
            && mutated
    );
    if bulk {
        let before = gpu.helper_commits.get();
        ensure!(
            gpu.command(|cmd| encode_stage(
                &gpu,
                cmd,
                &gpu.ready_stages.stages.as_ref().unwrap()[0],
                std::iter::empty(),
                [0u32],
                MTLSize::new(1, 1, 1),
            ))
            .is_err()
        );
        ensure!(
            gpu.helper_commits.get() == before && gpu.ready_bulk_counts.get() == valid_bulk_counts
        );
    }
    let x = input(&gpu, &cases[0], true)?;
    let cohort = vec![&experts[0], &experts[1]];
    let (_, expected) = canonical(&gpu, &x, &cohort)?;
    gpu.ready_stages.wrong_records.set(true);
    let wrong = gpu.command(|cmd| {
        FlashExpert::encode_ready_cohort(
            cmd,
            &x,
            &cohort,
            &[None, None],
            Storage::StorageModeShared,
        )
    })?;
    gpu.ready_stages.wrong_records.set(false);
    ensure!(
        Metal::read(&wrong[0], 2560) != expected[0],
        "wrong record mutation escaped output oracle"
    );
    gpu.ready_stages.captured.borrow_mut().take();
    let before = gpu.helper_commits.get();
    gpu.ready_stages.reject_after_encode.set(true);
    ensure!(
        gpu.command(|cmd| FlashExpert::encode_ready_cohort(
            cmd,
            &x,
            &cohort,
            &[None, None],
            Storage::StorageModeShared
        ))
        .is_err()
    );
    gpu.ready_stages.reject_after_encode.set(false);
    ensure!(
        gpu.helper_commits.get() == before,
        "late rejected encode committed a command"
    );
    let invalid = buffer(&gpu.device, 5120, Storage::StorageModeShared)?;
    ensure!(
        gpu.command(|cmd| FlashExpert::encode_ready_cohort(
            cmd,
            &x,
            &cohort,
            &[Some((&invalid, u64::MAX)), None],
            Storage::StorageModeShared
        ))
        .is_err()
    );
    ensure!(gpu.helper_commits.get() == before);
    let counts = gpu.ready_stage_counts.get();
    let alias = buffer(&gpu.device, 5120, Storage::StorageModeShared)?;
    gpu.command(|cmd| {
        FlashExpert::encode_ready_cohort(
            cmd,
            &x,
            &cohort,
            &[Some((&alias, 0)), Some((&alias, 0))],
            Storage::StorageModeShared,
        )
    })?;
    ensure!(gpu.ready_stage_counts.get() == counts && Metal::read(&alias, 2560) == expected[1]);
    let alias_x = input(&gpu, &cases[0], true)?;
    gpu.command(|cmd| {
        FlashExpert::encode_ready_cohort(
            cmd,
            &alias_x,
            &cohort,
            &[Some((&alias_x.buffer, 0)), None],
            Storage::StorageModeShared,
        )
    })?;
    ensure!(
        gpu.ready_stage_counts.get() == counts && Metal::read(&alias_x.buffer, 2560) == expected[0]
    );
    eprintln!(
        "AR35_READY_STAGES {}",
        serde_json::json!({"parity":true,"compiled_ready_stages":true,"bulk_bindings_selected":bulk,"valid_bulk_counts":valid_bulk_counts,"invalid_bulk_prefix_unsubmitted":bulk,"cases":test_cases,"cohort_sizes":[1,2,10],"valid_counts":valid_counts,"compared_stage_bytes":stage_bytes,"finite_output_half_words":output_words,"independent_stock":true,"all_seven_intermediates":true,"poisoned_prefixes":true,"f16_f32_negative_strides":true,"permuted_duplicate_experts":true,"n1_fallback":true,"overlap_fallback":true,"input_alias_fallback":true,"wrong_record_mutant_detected":true,"stage_bit_mutant_detected":true,"late_failure_unsubmitted":true,"invalid_destination_unsubmitted":true})
    );
    Ok(())
}
