import runpy,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
d=runpy.run_path(str(root/"build/issue140/c.py"))
d["main"].__globals__["ARMS"] = (("control-start",(0,0,0)),("split",(1,1,1)),("control-end",(0,0,0)))
assert len(d["main"].__globals__["ARMS"]) == 3
d["main"]()
