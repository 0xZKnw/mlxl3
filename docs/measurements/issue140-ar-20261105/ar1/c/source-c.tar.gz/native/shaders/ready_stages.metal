#if MLXL3_READY_STAGES
#define READY_RECORDS const device uchar* r0 [[buffer(1)]], const device uchar* r1 [[buffer(2)]], \
    const device uchar* r2 [[buffer(3)]], const device uchar* r3 [[buffer(4)]], \
    const device uchar* r4 [[buffer(5)]], const device uchar* r5 [[buffer(6)]], \
    const device uchar* r6 [[buffer(7)]], const device uchar* r7 [[buffer(8)]], \
    const device uchar* r8 [[buffer(9)]], const device uchar* r9 [[buffer(10)]]
#define READY_RECORD const device uchar* records[10]={r0,r1,r2,r3,r4,r5,r6,r7,r8,r9}; \
    const device uchar* record=records[group.y];
kernel void ready_gu_prepare(const device uchar* input [[buffer(0)]], READY_RECORDS,
    device half* output [[buffer(11)]],constant long* p [[buffer(12)]],
    uint lane [[thread_index_in_threadgroup]],uint2 group [[threadgroup_position_in_grid]]) {
    READY_RECORD
    const device half* gs=reinterpret_cast<const device half*>(record+p[3]);
    const device half* us=reinterpret_cast<const device half*>(record+p[4]);
    threadgroup float gate[128],up[128];
    uint start=group.x*128,base=group.y*5120;
    for(uint i=lane;i<128;i+=64) {
        long xi=p[0]+long(start+i)*p[1];
        half x=p[2]?half(reinterpret_cast<const device float*>(input)[xi]):reinterpret_cast<const device half*>(input)[xi];
        gate[i]=float(x*gs[start+i]);up[i]=float(x*us[start+i]);
    }
    hadamard128(gate,lane);hadamard128(up,lane);
    for(uint i=lane;i<128;i+=64) {
        output[base+start+i]=half(gate[i]*as_type<float>(0x3db504f3u));
        output[base+2560+start+i]=half(up[i]*as_type<float>(0x3db504f3u));
    }
}
#define READY_OUTPUTS device half* o0 [[buffer(11)]],device half* o1 [[buffer(12)]], \
    device half* o2 [[buffer(13)]],device half* o3 [[buffer(14)]], \
    device half* o4 [[buffer(15)]],device half* o5 [[buffer(16)]], \
    device half* o6 [[buffer(17)]],device half* o7 [[buffer(18)]], \
    device half* o8 [[buffer(19)]],device half* o9 [[buffer(20)]]
kernel void ready_finish(const device float* partial [[buffer(0)]],READY_RECORDS,READY_OUTPUTS,
    const device half* gate [[buffer(21)]],constant uint4& p [[buffer(22)]],
    uint lane [[thread_index_in_threadgroup]],uint2 group [[threadgroup_position_in_grid]]) {
    READY_RECORD
    device half* outputs[10]={o0,o1,o2,o3,o4,o5,o6,o7,o8,o9};
    device half* output=outputs[group.y];
    const device half* svh=reinterpret_cast<const device half*>(record+p.y);
    uint base=group.x*128,width=p.x;
    threadgroup float values[128];
    for(uint i=lane;i<128;i+=64) values[i]=float(half(partial[group.y*width+base+i]));
    hadamard128(values,lane);
    for(uint i=lane;i<128;i+=64) {
        half y=half(values[i]*as_type<float>(0x3db504f3u))*svh[base+i];
        if(p.z) {
            half g=gate[group.y*width+base+i];
            half tail=half(1)/(half(1)+metal::exp(metal::abs(g)));
            half sigmoid=g<half(0)?tail:half(1)-tail;
            y=(g*sigmoid)*y;
        }
        output[base+i]=y;
    }
}
// Same ABI and dynamic width; separate the stock plain/SwiGLU bodies.
kernel void ready_finish_plain(const device float* partial [[buffer(0)]],READY_RECORDS,READY_OUTPUTS,
    const device half* gate [[buffer(21)]],constant uint4& p [[buffer(22)]],
    uint lane [[thread_index_in_threadgroup]],uint2 group [[threadgroup_position_in_grid]]) {
    READY_RECORD
    device half* outputs[10]={o0,o1,o2,o3,o4,o5,o6,o7,o8,o9};
    device half* output=outputs[group.y];
    const device half* svh=reinterpret_cast<const device half*>(record+p.y);
    uint base=group.x*128,width=p.x;
    threadgroup float values[128];
    for(uint i=lane;i<128;i+=64) values[i]=float(half(partial[group.y*width+base+i]));
    hadamard128(values,lane);
    for(uint i=lane;i<128;i+=64) {
        half y=half(values[i]*as_type<float>(0x3db504f3u))*svh[base+i];
        output[base+i]=y;
    }
}
kernel void ready_finish_up(const device float* partial [[buffer(0)]],READY_RECORDS,READY_OUTPUTS,
    const device half* gate [[buffer(21)]],constant uint4& p [[buffer(22)]],
    uint lane [[thread_index_in_threadgroup]],uint2 group [[threadgroup_position_in_grid]]) {
    READY_RECORD
    device half* outputs[10]={o0,o1,o2,o3,o4,o5,o6,o7,o8,o9};
    device half* output=outputs[group.y];
    const device half* svh=reinterpret_cast<const device half*>(record+p.y);
    uint base=group.x*128,width=p.x;
    threadgroup float values[128];
    for(uint i=lane;i<128;i+=64) values[i]=float(half(partial[group.y*width+base+i]));
    hadamard128(values,lane);
    for(uint i=lane;i<128;i+=64) {
        half y=half(values[i]*as_type<float>(0x3db504f3u))*svh[base+i];
        half g=gate[group.y*width+base+i];
        half tail=half(1)/(half(1)+metal::exp(metal::abs(g)));
        half sigmoid=g<half(0)?tail:half(1)-tail;
        y=(g*sigmoid)*y;
        output[base+i]=y;
    }
}
kernel void ready_down_prepare(const device half* input [[buffer(0)]],READY_RECORDS,
    device half* output [[buffer(11)]],constant ulong& offset [[buffer(12)]],
    uint lane [[thread_index_in_threadgroup]],uint2 group [[threadgroup_position_in_grid]]) {
    READY_RECORD
    const device half* suh=reinterpret_cast<const device half*>(record+offset);
    uint start=group.x*128,base=group.y*640;
    threadgroup float values[128];
    for(uint i=lane;i<128;i+=64) values[i]=float(half(input[base+start+i]*suh[start+i]));
    hadamard128(values,lane);
    for(uint i=lane;i<128;i+=64) output[base+start+i]=half(values[i]*as_type<float>(0x3db504f3u));
}
#undef READY_RECORDS
#undef READY_RECORD
#undef READY_OUTPUTS
#if MLXL3_AR20_TESTS
kernel void ready_compiled(device uint* out [[buffer(0)]],uint tid [[thread_position_in_grid]]) {
    if(tid==0)out[0]=MLXL3_READY_STAGES;
}
#endif
#endif
