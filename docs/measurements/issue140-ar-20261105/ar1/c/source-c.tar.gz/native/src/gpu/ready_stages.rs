//! Batch only the five preparation/finish stages; existing three axis-QMV calls remain.
use super::super::view::FloatType;
use super::*;
use crate::ready_policy as policy;
use metal::ComputePipelineState;

pub(in crate::gpu) struct Pipelines {
    enabled: std::cell::Cell<bool>,
    batch_bindings: bool,
    stages: Option<[ComputePipelineState; 3]>,
    split_finish: Option<[ComputePipelineState; 2]>,
    #[cfg(test)]
    capture: std::cell::Cell<bool>,
    #[cfg(test)]
    reject_after_encode: std::cell::Cell<bool>,
    #[cfg(test)]
    captured: std::cell::RefCell<Option<Vec<Buffer>>>,
    #[cfg(test)]
    wrong_records: std::cell::Cell<bool>,
}

impl Pipelines {
    pub(in crate::gpu) fn load(
        p: &impl Fn(&str) -> Result<ComputePipelineState>,
        enabled: bool,
        batch_bindings: bool,
        split_finish: bool,
    ) -> Result<Self> {
        let stages = enabled
            .then(|| {
                Ok::<_, anyhow::Error>([
                    p("ready_gu_prepare")?,
                    p("ready_finish")?,
                    p("ready_down_prepare")?,
                ])
            })
            .transpose()?;
        let enabled = stages.as_ref().is_some_and(|ps| {
            ps.iter().all(|p| {
                p.thread_execution_width() == 32 && p.max_total_threads_per_threadgroup() >= 64
            })
        });
        let split_finish = (enabled && split_finish)
            .then(|| Ok::<_, anyhow::Error>([p("ready_finish_plain")?, p("ready_finish_up")?]))
            .transpose()?;
        if let Some(ps) = &split_finish {
            ensure!(
                ps.iter().all(|p| p.thread_execution_width() == 32
                    && p.max_total_threads_per_threadgroup() >= 64),
                "unsupported split ready-finish geometry"
            );
        }
        Ok(Self {
            enabled: std::cell::Cell::new(enabled),
            batch_bindings,
            stages,
            split_finish,
            #[cfg(test)]
            capture: std::cell::Cell::new(false),
            #[cfg(test)]
            reject_after_encode: std::cell::Cell::new(false),
            #[cfg(test)]
            captured: std::cell::RefCell::new(None),
            #[cfg(test)]
            wrong_records: std::cell::Cell::new(false),
        })
    }
}

impl Metal {
    pub(in crate::gpu) fn ready_stages_enabled(&self) -> bool {
        self.ready_stages.enabled.get() && self.ready_stages.stages.is_some()
    }
    pub(in crate::gpu) fn ready_batch_bindings_enabled(&self) -> bool {
        self.ready_stages_enabled() && self.ready_stages.batch_bindings
    }
    #[cfg(test)]
    pub(in crate::gpu) fn ready_split_finish_enabled(&self) -> bool {
        self.ready_stages_enabled() && self.ready_stages.split_finish.is_some()
    }
}

fn encode_stage<'a, T: Copy, const N: usize>(
    gpu: &Metal,
    command: &CommandBufferRef,
    pipeline: &ComputePipelineState,
    buffers: impl ExactSizeIterator<Item = (&'a Buffer, u64)>,
    params: [T; N],
    groups: MTLSize,
) -> Result<()> {
    if !gpu.ready_batch_bindings_enabled() {
        Metal::encode_bound(command, pipeline, buffers, params, groups, 64);
        return Ok(());
    }
    let mut refs: [Option<&metal::BufferRef>; 22] = [None; 22];
    let mut offsets = [0u64; 22];
    let count = policy::binding_prefix(buffers.len(), refs.len(), offsets.len())
        .context("invalid ready-stage bulk binding prefix")?;
    for (i, (buffer, offset)) in buffers.enumerate() {
        refs[i] = Some(buffer.as_ref());
        offsets[i] = offset;
    }
    let encoder = command.new_compute_command_encoder();
    encoder.set_compute_pipeline_state(pipeline);
    encoder.set_buffers(0, &refs[..count], &offsets[..count]);
    encoder.set_bytes(
        count as u64,
        std::mem::size_of_val(&params) as u64,
        params.as_ptr().cast(),
    );
    encoder.dispatch_thread_groups(groups, MTLSize::new(64, 1, 1));
    encoder.end_encoding();
    #[cfg(test)]
    {
        let [calls, bound, parameter_calls] = gpu.ready_bulk_counts.get();
        gpu.ready_bulk_counts
            .set([calls + 1, bound + count as u64, parameter_calls + 1]);
    }
    Ok(())
}

fn same(a: &Buffer, b: &Buffer) -> bool {
    std::ptr::eq::<metal::BufferRef>(a.as_ref(), b.as_ref())
}
fn record_bindings<'a>(
    input: &'a Buffer,
    offset: u64,
    records: &'a [Buffer],
) -> Vec<(&'a Buffer, u64)> {
    let mut bindings = Vec::with_capacity(11);
    bindings.push((input, offset));
    bindings.extend((0..10).map(|i| (&records[i.min(records.len() - 1)], 0)));
    bindings
}

fn slab(gpu: &Metal, n: usize, width: usize, element: usize) -> Result<Buffer> {
    let bytes = policy::bytes(n, width, element).context("invalid ready-stage slab")?;
    #[cfg(test)]
    if gpu.ready_stages.capture.get() {
        return super::super::upload(&gpu.device, &vec![0x7e55u16; bytes as usize / 2]);
    }
    buffer(&gpu.device, bytes, Storage::StorageModePrivate)
}

#[cfg(test)]
fn snapshot(gpu: &Metal, cmd: &CommandBufferRef, source: &Buffer, bytes: u64) -> Result<Buffer> {
    let out = buffer(&gpu.device, bytes, Storage::StorageModeShared)?;
    let copy = cmd.new_blit_command_encoder();
    copy.copy_from_buffer(source, 0, &out, 0, bytes);
    copy.end_encoding();
    Ok(out)
}

pub(super) fn encode(
    cmd: &CommandBufferRef,
    x: &MatrixView,
    experts: &[&FlashExpert<'_>],
    destinations: &[Option<(&Buffer, u64)>],
    storage: Storage,
    pending: bool,
) -> Result<Option<Vec<Buffer>>> {
    let Some(first) = experts.first() else {
        return Ok(None);
    };
    let gpu = first.gate.metal;
    let n = experts.len();
    if !policy::eligible(
        gpu.ready_stages_enabled(),
        n,
        gpu.expert_ar_enabled[3].get(),
        gpu.expert_ar_enabled[1].get(),
        gpu.expert_ar_enabled[0].get(),
        pending,
    ) {
        return Ok(None);
    }
    if !gpu.owns_command_queue(cmd) {
        return Ok(None);
    }
    ensure!(
        destinations.len() == n,
        "invalid vector-ready destination count"
    );
    ensure!(
        x.shape() == [1, 2560] && x.buffer.device().registry_id() == gpu.device.registry_id(),
        "invalid vector-ready input"
    );
    let mut records = Vec::with_capacity(n);
    for expert in experts {
        ensure!(
            std::ptr::eq(gpu, expert.gate.metal),
            "foreign vector-ready Metal instance"
        );
        crate::expert_ar_policy::eligible(
            expert.routed,
            expert.expert_extents(expert.gate.view_extents(x)?)?,
        )
        .then_some(())
        .context("invalid vector-ready extents")?;
        records.push(expert.record_backing()?);
        for (index, p) in [(0, &expert.down), (1, &expert.gate), (2, &expert.up)] {
            let canonical = flash_support::record_offsets(index)
                .context("missing vector-ready record geometry")?;
            let expected = if index == 0 { [640, 2560] } else { [2560, 640] };
            ensure!(
                p.k == 2
                    && p.cb == Codebook::Mul1
                    && p.splits == 1
                    && p.bias.is_none()
                    && same(&p.suh, records.last().unwrap())
                    && same(&p.svh, records.last().unwrap())
                    && [p.input, p.output] == expected
                    && (p.offsets.suh, p.offsets.svh, p.offsets.trellis)
                        == (canonical.suh, canonical.svh, canonical.trellis)
                    && FlashExpert::axis_nt(p)
                        == FlashExpert::axis_nt(first.axis_projection(if index == 0 {
                            2
                        } else {
                            index - 1
                        })),
                "incompatible vector-ready record"
            );
        }
    }
    for (i, target) in destinations.iter().enumerate() {
        if let Some((dest, offset)) = target {
            ensure!(
                dest.device().registry_id() == gpu.device.registry_id()
                    && policy::destination(*offset, dest.length()),
                "invalid vector-ready destination prefix"
            );
            if same(dest, &x.buffer) || records.iter().any(|r| same(r, dest)) {
                return Ok(None);
            }
            for other in destinations[..i].iter().flatten() {
                if same(dest, other.0) && !policy::disjoint(*offset, other.1) {
                    return Ok(None);
                }
            }
        }
    }
    let prepared = slab(gpu, n, 5120, 2)?;
    let partial = slab(gpu, n, 2560, 4)?;
    let gates = slab(gpu, n, 640, 2)?;
    let active = slab(gpu, n, 640, 2)?;
    let outputs = destinations
        .iter()
        .map(|d| match d {
            Some((b, _)) => Ok((*b).clone()),
            None => buffer(&gpu.device, 5120, storage),
        })
        .collect::<Result<Vec<_>>>()?;
    let stages = gpu
        .ready_stages
        .stages
        .as_ref()
        .context("vector-ready pipelines missing")?;
    #[cfg(test)]
    if gpu.ready_stages.wrong_records.get() {
        records.rotate_left(1);
    }
    #[cfg(test)]
    let mut captures = Vec::new();
    let mut bindings = record_bindings(&x.buffer, 0, &records);
    bindings.push((&prepared, 0));
    encode_stage(
        gpu,
        cmd,
        &stages[0],
        bindings.into_iter(),
        [
            x.layout.offset,
            x.layout.strides[1],
            i64::from(x.dtype == FloatType::F32),
            i64::try_from(first.gate.offsets.suh)?,
            i64::try_from(first.up.offsets.suh)?,
        ],
        MTLSize::new(20, n as u64, 1),
    )?;
    #[cfg(test)]
    if gpu.ready_stages.capture.get() {
        captures.push(snapshot(
            gpu,
            cmd,
            &prepared,
            policy::bytes(n, 5120, 2).unwrap(),
        )?);
    }
    for (stage, p) in [(0, &first.gate), (1, &first.up), (2, &first.down)] {
        if stage == 2 {
            let mut bindings = record_bindings(&active, 0, &records);
            bindings.push((&prepared, 0));
            encode_stage(
                gpu,
                cmd,
                &stages[2],
                bindings.into_iter(),
                [p.offsets.suh],
                MTLSize::new(5, n as u64, 1),
            )?;
            #[cfg(test)]
            if gpu.ready_stages.capture.get() {
                captures.push(snapshot(
                    gpu,
                    cmd,
                    &prepared,
                    policy::bytes(n, 640, 2).unwrap(),
                )?);
            }
        }
        FlashExpert::encode_axis_qmv(
            cmd,
            experts,
            stage,
            &prepared,
            if stage == 1 { 5120 } else { 0 },
            if stage == 2 { 640 } else { 5120 },
            &partial,
        )?;
        #[cfg(test)]
        if gpu.ready_stages.capture.get() {
            captures.push(snapshot(
                gpu,
                cmd,
                &partial,
                policy::bytes(n, p.output as usize, 4).unwrap(),
            )?);
        }
        let mut bindings = record_bindings(&partial, 0, &records);
        for i in 0..10 {
            let route = i.min(n - 1);
            let target = match stage {
                0 => (&gates, policy::prefix(route, n, 640, 2).unwrap().0),
                1 => (&active, policy::prefix(route, n, 640, 2).unwrap().0),
                _ => (
                    &outputs[route],
                    destinations[route].map_or(0, |(_, offset)| offset),
                ),
            };
            bindings.push(target);
        }
        bindings.push((&gates, 0));
        ensure!(bindings.len() == 22, "invalid vector-ready binding arity");
        encode_stage(
            gpu,
            cmd,
            if let Some(ps) = &gpu.ready_stages.split_finish {
                &ps[usize::from(stage == 1)]
            } else {
                &stages[1]
            },
            bindings.into_iter(),
            [
                p.output,
                u32::try_from(p.offsets.svh)?,
                u32::from(stage == 1),
                0,
            ],
            MTLSize::new(u64::from(p.output / 128), n as u64, 1),
        )?;
        #[cfg(test)]
        {
            let mut counts = gpu.ready_finish_counts.get();
            let role = if gpu.ready_split_finish_enabled() {
                1 + usize::from(stage == 1)
            } else {
                0
            };
            counts[role] += 1;
            gpu.ready_finish_counts.set(counts);
        }
        #[cfg(test)]
        if gpu.ready_stages.capture.get() && stage < 2 {
            captures.push(snapshot(
                gpu,
                cmd,
                if stage == 0 { &gates } else { &active },
                policy::bytes(n, 640, 2).unwrap(),
            )?);
        }
    }
    #[cfg(test)]
    {
        ensure!(
            !gpu.ready_stages.reject_after_encode.get(),
            "injected vector-ready precommit failure"
        );
        if gpu.ready_stages.capture.get() {
            *gpu.ready_stages.captured.borrow_mut() = Some(captures);
        }
        let mut counts = gpu.ready_stage_counts.get();
        for value in &mut counts[..6] {
            *value += 1;
        }
        counts[6] += n as u64;
        counts[7] += 8;
        gpu.ready_stage_counts.set(counts);
    }
    Ok(Some(outputs))
}

#[cfg(test)]
#[path = "ar35_ready_stages_tests.rs"]
mod tests;
