//! Exact routed EXL3 experts, read directly into reusable slot-major banks.
use crate::{
    array::{Array, Dtype},
    checkpoint::{Checkpoint, TensorInfo},
    codec::Codebook,
    flash_support::{EXPERT_BYTES, ExpertCache, ExpertFill, expert_slot_destinations},
    lfm2::Projection,
    linear, router,
    ssd_prefetch::{PREDICTION_RANKS, ReaderPool, order_predictions},
};
use anyhow::{Context, Result, ensure};
use std::{cell::RefCell, collections::BTreeSet, rc::Rc};

const H: i32 = 2560;
const I: i32 = 640;

struct ResidentHot {
    input: Array,
    output: Array,
    map: [u32; 512],
    complete: bool,
}

struct PreparedRows {
    selected: Array,
    weights: Array,
    ids: Vec<u32>,
    hot: Option<ResidentHot>,
}

// On failure, both independent consumers must finish before slot reuse.
#[derive(Default)]
struct ColdConsumers(Vec<Array>);
struct ColdWaves {
    first: Array,
    rest: Option<Array>,
}
impl Drop for ColdConsumers {
    fn drop(&mut self) {
        let mut failed = false;
        for value in &self.0 {
            if let Err(error) = value.eval() {
                failed = true;
                eprintln!("Cold consumer cleanup failed: {error}");
            }
        }
        if failed && let Err(error) = crate::array::synchronize() {
            eprintln!("Cold consumer synchronization failed: {error}");
        }
    }
}

mod policy;
pub(crate) use policy::ResolvedPolicy;

struct ExpertStore {
    records: Vec<TensorInfo>,
    banks: Vec<Array>,
    cache: Rc<RefCell<ExpertCache>>,
    last: Option<Array>,
}

impl ExpertStore {
    fn drain(&mut self) -> Result<()> {
        if let Some(last) = &self.last {
            last.eval()?;
            self.last = None;
        }
        Ok(())
    }
}

pub struct SsdMoe {
    gate: Projection,
    resident_gate: Option<Array>,
    shared_gate: Projection,
    shared_up: Projection,
    shared_down: Projection,
    multiplier: Projection,
    store: ExpertStore,
    pub(crate) policy: ResolvedPolicy,
    pub hits: u64,
    pub misses: u64,
    pub read_bytes: u64,
    routed_indices: [Option<Array>; 8],
    #[cfg(test)]
    routed_index_builds: usize,
    #[cfg(test)]
    routed_index_hits: usize,
    #[cfg(test)]
    cold_shared_submissions: usize,
    #[cfg(test)]
    pub(crate) cold_ready_waves: Vec<usize>,
    #[cfg(test)]
    cold_ready_verify_overlap: bool,
    #[cfg(test)]
    cold_ready_verified_overlap: usize,
    #[cfg(test)]
    cold_ready_fail_after_wave: bool,
    #[cfg(test)]
    cold_ready_fail_after_prepare: bool,
    #[cfg(test)]
    cold_ready_complete_before_submit: bool,
    #[cfg(test)]
    cold_ready_prepared_rest: usize,
    #[cfg(test)]
    cold_priority_batches: usize,
    #[cfg(test)]
    cohort_sizes: Vec<usize>,
    #[cfg(test)]
    route_readbacks: usize,
    #[cfg(test)]
    window_hot_before_readback: Vec<bool>,
    #[cfg(test)]
    hybrid_submissions: u64,
    #[cfg(test)]
    slow_hot_for_test: bool,
    #[cfg(test)]
    hot_ready_at_routes: Option<bool>,
    #[cfg(test)]
    hot_ready_at_demand: Option<bool>,
    pub(crate) prefetcher: Option<(usize, Rc<RefCell<ReaderPool>>)>,
    #[cfg(test)]
    pub(crate) route_ids: Vec<u32>,
    #[cfg(test)]
    pub(crate) profile_seconds: [f64; 2],
    #[cfg(test)]
    pub(crate) prefetched: u64,
    #[cfg(test)]
    pub(crate) prefetch_profile: [u64; 4],
    #[cfg(test)]
    pub(crate) overlap_hot_rows: u64,
    #[cfg(test)]
    pub(crate) import_seconds: f64,
    #[cfg(test)]
    schedule_events: Vec<(&'static str, f64)>,
    #[cfg(test)]
    prediction_ready_at_demand: Option<bool>,
    #[cfg(test)]
    slow_prediction_for_test: bool,
}

impl SsdMoe {
    fn allocate_banks(slots: usize) -> Result<Vec<Array>> {
        let s = i32::try_from(slots)?;
        [
            (vec![s, 2, 160, 40, 32], Dtype::UInt16), // gate/up trellises
            (vec![s, 1, 40, 160, 32], Dtype::UInt16), // down trellis
            (vec![s, 2, H], Dtype::Float16),
            (vec![s, 2, I], Dtype::Float16),
            (vec![s, 1, I], Dtype::Float16),
            (vec![s, 1, H], Dtype::Float16),
            (vec![s, 3], Dtype::Int32),
        ]
        .into_iter()
        // Only fully filled, published slots enter the map; masked kernels skip all others.
        .map(|(shape, dtype)| unsafe { Array::uninitialized(&shape, dtype) })
        .collect::<Result<Vec<_>>>()
    }

    pub(crate) fn capacity(&self) -> usize {
        self.store.cache.borrow().capacity()
    }

    pub(crate) fn collect_weights<'a>(&'a self, out: &mut Vec<&'a Array>) {
        for p in [
            &self.gate,
            &self.shared_gate,
            &self.shared_up,
            &self.shared_down,
            &self.multiplier,
        ] {
            p.collect_weights(out);
        }
        out.extend(&self.resident_gate);
    }

    pub(crate) fn bank_backing_bytes(&self) -> Result<u64> {
        self.store.banks.iter().try_fold(0u64, |total, bank| {
            total
                .checked_add(bank.retained_bytes()? as u64)
                .context("Flash bank size overflow")
        })
    }

    // Replace one complete bank set atomically, after its readers and consumers drain.
    pub(crate) fn shrink(&mut self, slots: usize) -> Result<()> {
        self.shrink_with(slots, Self::allocate_banks)
    }
    fn shrink_with(
        &mut self,
        slots: usize,
        allocate: impl FnOnce(usize) -> Result<Vec<Array>>,
    ) -> Result<()> {
        ensure!(
            (10..=self.capacity()).contains(&slots),
            "invalid Flash cache shrink"
        );
        if slots == self.capacity() {
            return Ok(());
        }
        if let Some((_, pool)) = &self.prefetcher {
            pool.borrow_mut().wait_for_idle()?;
        }
        self.drain()?;
        let mut cache = ExpertCache::new(slots)?;
        if self.policy.force_lru || self.prefetcher.is_some() {
            cache.enable_predictive_lru();
        }
        let banks = allocate(slots)?;
        self.store.banks = banks;
        self.store.cache = Rc::new(RefCell::new(cache));
        Ok(())
    }

    pub fn load(c: &Checkpoint, prefix: &str, slots: usize, overlap: bool) -> Result<Self> {
        Self::load_resolved(
            c,
            prefix,
            slots,
            ResolvedPolicy::resolve(prefix.starts_with("model.language_model.layers."), overlap)?,
        )
    }

    pub(crate) fn load_resolved(
        c: &Checkpoint,
        prefix: &str,
        slots: usize,
        policy: ResolvedPolicy,
    ) -> Result<Self> {
        let records = crate::checkpoint::flash_expert_records(c, prefix)?;
        let cache = Rc::new(RefCell::new(ExpertCache::new(slots)?));
        if policy.force_lru {
            cache.borrow_mut().enable_predictive_lru();
        }
        let banks = Self::allocate_banks(slots)?;
        let projection = |suffix: &str, input, output| {
            Projection::load(c, &format!("{prefix}.{suffix}"), input, output, false)
        };
        let resident_gate =
            if policy.resident_gates && prefix.starts_with("model.language_model.layers.") {
                let name = format!("{prefix}.gate.weight");
                let info = c.tensors.get(&name).context("missing dense Flash gate")?;
                ensure!(
                    info.shape == [512, H as usize]
                        && matches!(info.dtype.as_str(), "F16" | "BF16" | "F32")
                        && !c.tensors.contains_key(&format!("{prefix}.gate.bias")),
                    "resident Flash gate must be dense 512x2560 without bias"
                );
                // Match MLX matmul's transpose-then-promote order, once at load.
                let weight = linear::checkpoint_array(c, &name)?
                    .astype(Dtype::Float16)?
                    .transpose(&[1, 0])?
                    .astype(Dtype::Float32)?;
                weight.eval()?;
                Some(weight)
            } else {
                None
            };
        Ok(Self {
            routed_indices: std::array::from_fn(|_| None),
            #[cfg(test)]
            routed_index_builds: 0,
            #[cfg(test)]
            routed_index_hits: 0,
            #[cfg(test)]
            cold_shared_submissions: 0,
            #[cfg(test)]
            cold_ready_waves: Vec::new(),
            #[cfg(test)]
            cold_ready_verify_overlap: false,
            #[cfg(test)]
            cold_ready_verified_overlap: 0,
            #[cfg(test)]
            cold_ready_fail_after_wave: false,
            #[cfg(test)]
            cold_ready_fail_after_prepare: false,
            #[cfg(test)]
            cold_ready_complete_before_submit: false,
            #[cfg(test)]
            cold_ready_prepared_rest: 0,
            #[cfg(test)]
            cold_priority_batches: 0,
            #[cfg(test)]
            cohort_sizes: Vec::new(),
            #[cfg(test)]
            route_readbacks: 0,
            #[cfg(test)]
            window_hot_before_readback: Vec::new(),
            #[cfg(test)]
            hybrid_submissions: 0,
            #[cfg(test)]
            slow_hot_for_test: false,
            #[cfg(test)]
            hot_ready_at_routes: None,
            #[cfg(test)]
            hot_ready_at_demand: None,
            gate: projection("gate", H, 512)?,
            resident_gate,
            shared_gate: projection("shared_expert.gate_proj", H, I)?,
            shared_up: projection("shared_expert.up_proj", H, I)?,
            shared_down: projection("shared_expert.down_proj", I, H)?,
            multiplier: projection("shared_expert_gate", H, 1)?,
            store: ExpertStore {
                records,
                banks,
                cache,
                last: None,
            },
            policy,
            hits: 0,
            misses: 0,
            read_bytes: 0,
            prefetcher: None,
            #[cfg(test)]
            route_ids: Vec::new(),
            #[cfg(test)]
            profile_seconds: [0.0; 2],
            #[cfg(test)]
            prefetched: 0,
            #[cfg(test)]
            prefetch_profile: [0; 4],
            #[cfg(test)]
            overlap_hot_rows: 0,
            #[cfg(test)]
            import_seconds: 0.0,
            #[cfg(test)]
            schedule_events: Vec::with_capacity(8),
            #[cfg(test)]
            prediction_ready_at_demand: None,
            #[cfg(test)]
            slow_prediction_for_test: false,
        })
    }

    fn fill_many(&mut self, jobs: &[(u32, usize)]) -> Result<()> {
        if jobs.is_empty() {
            return Ok(());
        }
        #[cfg(test)]
        let _profile = crate::flash_profile::span("fill_prepare_and_read");
        let sources = jobs
            .iter()
            .map(|&(expert, _)| {
                self.store
                    .records
                    .get(expert as usize)
                    .context("invalid expert")?
                    .source()
            })
            .collect::<Result<Vec<_>>>()?;
        let destinations = jobs
            .iter()
            .map(|&(_, slot)| expert_slot_destinations(slot))
            .collect::<Vec<_>>();
        let views = destinations
            .iter()
            .map(|ranges| ranges.as_slice())
            .collect::<Vec<_>>();
        let bytes = EXPERT_BYTES
            .checked_mul(jobs.len() as u64)
            .and_then(|n| self.read_bytes.checked_add(n))
            .context("SSD byte counter exhausted")?;
        #[cfg(test)]
        let read_profile = crate::flash_profile::span("disk_read_batch");
        #[cfg(test)]
        if read_profile.is_some() {
            crate::array::disk_profile_enable(true);
        }
        let result =
            Array::read_records(&sources, &mut self.store.banks, &views, self.policy.readers);
        #[cfg(test)]
        if let Some(profile) = &read_profile {
            profile.data(serde_json::json!({"jobs":jobs,"workers":self.policy.readers,"schedule":crate::array::disk_profile_schedule(),"timings_job_worker_start_end_bytes_failed":crate::array::disk_profile()?,"ok":result.is_ok()}));
        }
        result?;
        self.read_bytes = bytes;
        Ok(())
    }

    fn calculate_cold(&self, routed_x: &Array, cold: &[(usize, u32)]) -> Result<Array> {
        self.calculate(
            &routed_x.take(
                &Array::from_u32(
                    &cold.iter().map(|p| p.0 as u32).collect::<Vec<_>>(),
                    &[cold.len() as i32],
                )?,
                0,
            )?,
            &cold.iter().map(|p| p.1).collect::<Vec<_>>(),
        )
    }

    fn fill_ready(
        &mut self,
        jobs: &[(u32, usize)],
        routed_x: &Array,
        cold: &mut Vec<(usize, u32)>,
        consumers: &mut ColdConsumers,
        shared: Option<(&Array, &mut Option<Array>)>,
        route_rows: i32,
    ) -> Result<Option<ColdWaves>> {
        ensure!(
            (1..=self.policy.cold_ready_rows).contains(&route_rows)
                && routed_x.shape() == [route_rows * 10, H]
                && cold
                    .iter()
                    .all(|&(index, _)| index < route_rows as usize * 10),
            "invalid Cold wave route domain"
        );
        #[cfg(test)]
        let priority_active = route_rows == 2 && self.policy.cold_priority;
        #[cfg(test)]
        let cold_occurrences = cold.clone();
        #[cfg(test)]
        let diagnostic = crate::flash_profile::span("cold_ready_batch");
        #[cfg(test)]
        if let Some(event) = &diagnostic {
            event.data(
                serde_json::json!({"status":"incomplete","jobs":jobs.len(),"cold_rows":cold.len()}),
            );
        }
        #[cfg(test)]
        let prepare = crate::flash_profile::span("cold_ready_begin");
        let bytes = EXPERT_BYTES
            .checked_mul(jobs.len() as u64)
            .and_then(|n| self.read_bytes.checked_add(n))
            .context("SSD byte counter exhausted")?;
        let sources = jobs
            .iter()
            .map(|&(expert, _)| {
                self.store
                    .records
                    .get(expert as usize)
                    .context("invalid expert")?
                    .source()
            })
            .collect::<Result<Vec<_>>>()?;
        let destinations = jobs
            .iter()
            .map(|&(_, slot)| expert_slot_destinations(slot))
            .collect::<Vec<_>>();
        let views = destinations
            .iter()
            .map(|ranges| ranges.as_slice())
            .collect::<Vec<_>>();
        // Reservations exclude Hot; only published slots enter W1. Drop joins all readers.
        let mut batch = unsafe {
            Array::begin_read_records(&sources, &mut self.store.banks, &views, self.policy.readers)?
        };
        let shared = match shared {
            Some((x, output)) => {
                // Start disk work before building the independent resident expert.
                *output = Some(self.shared(x)?);
                output.as_ref()
            }
            None => None,
        };
        #[cfg(test)]
        drop(prepare);
        #[cfg(test)]
        let waiting = crate::flash_profile::span("cold_ready_wait");
        let ready = batch.wait_ready(2)?;
        #[cfg(test)]
        drop(waiting);
        let first = if ready.iter().all(|&done| done) {
            None
        } else {
            #[cfg(test)]
            let building = crate::flash_profile::span("cold_ready_first_build");
            let slots = jobs
                .iter()
                .zip(&ready)
                .filter_map(|(&(_, slot), &done)| done.then_some(slot as u32))
                .collect::<Vec<_>>();
            let (first, rest) = crate::cold_ready::partition(cold, &slots);
            ensure!(
                !first.is_empty() && !rest.is_empty(),
                "invalid Cold partition"
            );
            let value = self.calculate_cold(routed_x, &first)?;
            consumers.0.push(value.try_clone()?);
            #[cfg(test)]
            drop(building);
            #[cfg(test)]
            if self.cold_ready_complete_before_submit {
                batch.finish()?;
            }
            #[cfg(test)]
            let snapshot = crate::flash_profile::span("cold_ready_snapshot_before_submit");
            #[cfg(test)]
            if let Some(event) = &snapshot {
                let mask = batch.ready()?;
                event.data(serde_json::json!({"status":"ok","ready":mask.iter().filter(|&&done|done).count(),"jobs":mask.len()}));
            }
            #[cfg(test)]
            drop(snapshot);
            {
                #[cfg(test)]
                let _submitting = crate::flash_profile::span("cold_ready_first_submit");
                // W1 can overlap subsequent CPU work even when all reads have completed.
                if let Some(shared) = shared {
                    consumers.0.push(shared.try_clone()?);
                    Array::async_eval_all(&[&value, shared])?;
                    #[cfg(test)]
                    {
                        self.cold_shared_submissions += 1;
                    }
                } else {
                    value.async_eval()?;
                }
            }
            #[cfg(test)]
            if let Some(event) = crate::flash_profile::span("cold_ready_snapshot_after_submit") {
                event.data(match batch.ready() {
                    Ok(mask) => serde_json::json!({"status":"ok","ready":mask.iter().filter(|&&done|done).count(),"jobs":mask.len()}),
                    Err(error) => serde_json::json!({"status":"diagnostic_error","error":error.to_string()}),
                });
            }
            #[cfg(test)]
            {
                self.cold_ready_waves.push(first.len());
                if self.cold_ready_verify_overlap {
                    value.eval()?;
                    ensure!(batch.ready()?.iter().any(|&done| !done));
                    self.cold_ready_verified_overlap += 1;
                }
                ensure!(
                    !self.cold_ready_fail_after_wave,
                    "injected Cold wave failure"
                );
            }
            #[cfg(test)]
            let prepare_rest = !crate::flash_profile::fenced();
            #[cfg(not(test))]
            let prepare_rest = true;
            // Fenced profiling evaluates intermediate stages; only a lazy graph is safe here.
            let rest_output = if prepare_rest {
                #[cfg(test)]
                let _building = crate::flash_profile::span("cold_ready_rest_build");
                let rest_output = self.calculate_cold(routed_x, &rest)?;
                #[cfg(test)]
                {
                    self.cold_ready_prepared_rest += 1;
                    ensure!(!rest_output.is_available()?, "W2 evaluated before join");
                    if self.cold_ready_verify_overlap {
                        ensure!(batch.ready()?.iter().any(|&done| !done));
                    }
                    ensure!(
                        !self.cold_ready_fail_after_prepare,
                        "injected Cold preparation failure"
                    );
                }
                Some(rest_output)
            } else {
                None
            };
            *cold = first.into_iter().chain(rest).collect();
            Some(ColdWaves {
                first: value,
                rest: rest_output,
            })
        };
        #[cfg(test)]
        let finishing = crate::flash_profile::span("cold_ready_finish");
        let finished = batch.finish();
        #[cfg(test)]
        drop(finishing);
        #[cfg(test)]
        if let Some(event) = &diagnostic {
            let first_rows = first
                .as_ref()
                .map_or(0, |wave| wave.first.shape()[0] as usize);
            event.data(serde_json::json!({
                "status":if finished.is_ok(){"finished"}else{"failed_finish"},
                "jobs":jobs.len(),"cold_rows":cold.len(),
                "ready_initial":ready.iter().filter(|&&done|done).count(),
                "ready_job_indices":ready.iter().enumerate().filter_map(|(i,&done)|done.then_some(i)).collect::<Vec<_>>(),
                "w1_rows":first_rows,"w2_rows":cold.len()-first_rows,
                "split":first.is_some(),"io_ok":finished.is_ok(),
                "jobs_mapping":jobs,"workers":self.policy.readers,
                "route_rows":route_rows,"priority":priority_active,
                "cold_occurrences":cold_occurrences,
                "multiplicities":crate::cold_ready::job_multiplicities(jobs, &cold_occurrences),
                "schedule":crate::array::disk_profile_schedule(),
                "timings_job_worker_start_end_bytes_failed":crate::array::disk_profile()?,
            }));
        }
        finished?;
        self.read_bytes = bytes;
        Ok(first)
    }

    fn calculate(&self, x: &Array, slots: &[u32]) -> Result<Array> {
        let capacity = self.store.banks[0].shape()[0];
        let slots = if self.policy.shared_exl3 {
            linear::ExpertSlots::grouped(slots, capacity)?
        } else {
            linear::ExpertSlots::new(slots, capacity)?
        };
        self.calculate_slots(x, &slots)
    }

    fn calculate_slots(&self, x: &Array, slots: &linear::ExpertSlots) -> Result<Array> {
        let n = slots.indices().shape()[0];
        #[cfg(test)]
        let profile = crate::flash_profile::span("expert_calculate_build");
        #[cfg(test)]
        if let Some(profile) = &profile {
            profile.data(serde_json::json!({"rows":n}));
        }
        ensure!(n > 0 && x.shape() == [n, H], "invalid expert slot mapping");
        let expanded = x
            .reshape(&[n, 1, H])?
            .broadcast_to(&[n, 2, H])?
            .reshape(&[n * 2, H])?;
        let suh = slots
            .gather_scales(&self.store.banks[2])?
            .reshape(&[n * 2, H])?;
        let svh = slots
            .gather_scales(&self.store.banks[3])?
            .reshape(&[n * 2, I])?;
        #[cfg(test)]
        let gu_build = crate::flash_profile::span("expert_gate_up_build");
        let gu = linear::expert_slots(
            &expanded,
            &self.store.banks[0],
            &suh,
            &svh,
            slots,
            I,
            2,
            2,
            Codebook::Mul1,
            self.policy.stable_expert_kernels,
            self.policy.native_prepare,
        )?
        .reshape(&[n, 2, I])?;
        #[cfg(test)]
        drop(gu_build);
        #[cfg(test)]
        crate::flash_profile::stage("expert_gate_up_completion", &gu)?;
        #[cfg(test)]
        let activation_build = crate::flash_profile::span("expert_swiglu_build");
        let activated = gu
            .slice(1, 0, 1)?
            .reshape(&[n, I])?
            .swiglu(&gu.slice(1, 1, 2)?.reshape(&[n, I])?)?;
        #[cfg(test)]
        drop(activation_build);
        #[cfg(test)]
        crate::flash_profile::stage("expert_swiglu_completion", &activated)?;
        #[cfg(test)]
        let down_build = crate::flash_profile::span("expert_down_build");
        let down = linear::expert_slots(
            &activated,
            &self.store.banks[1],
            &slots
                .gather_scales(&self.store.banks[4])?
                .reshape(&[n, I])?,
            &slots
                .gather_scales(&self.store.banks[5])?
                .reshape(&[n, H])?,
            slots,
            H,
            1,
            2,
            Codebook::Mul1,
            self.policy.stable_expert_kernels,
            self.policy.native_prepare,
        )?;
        #[cfg(test)]
        drop(down_build);
        #[cfg(test)]
        crate::flash_profile::stage("expert_down_completion", &down)?;
        Ok(down)
    }

    fn gate_logits(&self, x: &Array) -> Result<Array> {
        match &self.resident_gate {
            Some(weight) if x.dtype() == Dtype::Float32 => x.matmul(weight),
            _ => self.gate.forward(x),
        }
    }

    pub(crate) fn route(&self, x: &Array) -> Result<(Array, Array)> {
        #[cfg(test)]
        let _profile = crate::flash_profile::span("router_projection_and_topk_build");
        ensure!(
            x.shape() == [1, H] && matches!(x.dtype(), Dtype::Float16 | Dtype::Float32),
            "streamed MoE expects one exact route row"
        );
        let probabilities = self.gate_logits(x)?.softmax_precise()?;
        if x.dtype() == Dtype::Float16 {
            let (indices, scores) = router::topk(&probabilities, 10, false)?;
            Ok((indices, scores.div(&scores.sum(1, true)?)?))
        } else {
            router::topk(&probabilities, 10, true)
        }
    }
    fn predict(&self, x: &Array) -> Result<Array> {
        let x = if self.policy.predictor_half {
            x.astype(Dtype::Float16)?
        } else {
            x.try_clone()?
        };
        let scores = self.gate.forward(&x)?;
        #[cfg(test)]
        let scores = if self.slow_prediction_for_test {
            crate::array::metal_kernel(
                "mlxl3_test_slow_prediction",
                &["scores"], &["out"], "",
                "uint i=thread_position_in_grid.x; float v=float(scores[i]); for(uint j=0;j<1000000u;++j) v=fma(v,0.99999f,0.0001f); out[i]=v;",
                &[&scores], &[scores.shape().to_vec()], &[Dtype::Float32],
                [512, 1, 1], [128, 1, 1],
            )?.remove(0)
        } else {
            scores
        };
        scores
            .argsort()?
            .slice(1, 512 - PREDICTION_RANKS as i32, 512)
    }
    pub fn forward(&mut self, x: &Array) -> Result<Array> {
        self.forward_many(x)
    }

    pub(crate) fn warm_all(&mut self) -> Result<()> {
        self.drain()?;
        ensure!(
            self.store.cache.borrow().capacity() == 512,
            "resident draft requires all expert slots"
        );
        let ids = (0..512u32).collect::<Vec<_>>();
        let routes = self.store.cache.borrow_mut().reserve(&ids)?;
        let jobs = ids
            .iter()
            .zip(&routes)
            .filter_map(|(&id, &(slot, hit))| (!hit).then_some((id, slot)))
            .collect::<Vec<_>>();
        if let Err(error) = self.fill_many(&jobs) {
            self.store.cache.borrow_mut().invalidate();
            return Err(error);
        }
        Ok(())
    }

    pub(crate) fn forward_many(&mut self, x: &Array) -> Result<Array> {
        self.forward_lookahead(x, None, 0)
    }

    pub(crate) fn forward_lookahead(
        &mut self,
        x: &Array,
        next: Option<&mut Self>,
        depth: usize,
    ) -> Result<Array> {
        self.forward_rows(x, next, depth, 2)
    }

    #[cfg(any(feature = "chat", test))]
    pub(crate) fn forward_draft_rows(&mut self, x: &Array) -> Result<Array> {
        self.forward_rows(x, None, 0, 8)
    }

    #[cfg(any(feature = "chat", test))]
    pub(crate) fn forward_draft_lookahead(
        &mut self,
        x: &Array,
        next: Option<&mut Self>,
        depth: usize,
    ) -> Result<Array> {
        if !self.policy.prefetch_pipeline || depth == 0 {
            return self.forward_draft_rows(x);
        }
        ensure!(
            depth <= 10 && x.shape().len() == 2,
            "invalid draft lookahead"
        );
        let rows = crate::ssd_prefetch::prediction_rows(usize::try_from(x.shape()[0])?)
            .context("invalid draft prediction rows")?;
        let prediction = next
            .as_ref()
            .map(|next| next.predict(&x.slice(0, 0, rows as i32)?))
            .transpose()?;
        if let Some(prediction) = &prediction {
            prediction.async_eval()?;
        }
        let output = self.forward_draft_rows(x)?;
        if let (Some(next), Some(prediction)) = (next, prediction) {
            output.async_eval()?;
            let mut ids = prediction.to_u32()?;
            ensure!(
                order_predictions(&mut ids, rows),
                "invalid draft predictions"
            );
            next.prefetch(&ids, depth)?;
        }
        Ok(output)
    }

    fn forward_rows(
        &mut self,
        x: &Array,
        next: Option<&mut Self>,
        depth: usize,
        row_limit: i32,
    ) -> Result<Array> {
        self.forward_rows_prepared(x, next, depth, row_limit, None)
    }

    fn routed_input(&mut self, x: &Array) -> Result<Array> {
        let rows = *x
            .shape()
            .first()
            .context("routed input needs a row dimension")?;
        let routed_rows = rows
            .checked_mul(10)
            .context("routed input row count overflow")?;
        let cache_slot =
            (self.policy.routed_index_cache && (1..=8).contains(&rows)).then(|| rows as usize - 1);
        if let Some(indices) = cache_slot.and_then(|slot| self.routed_indices[slot].as_ref()) {
            #[cfg(test)]
            {
                self.routed_index_hits += 1;
            }
            return x.take(indices, 0)?.astype(Dtype::Float16);
        }
        let indices = (0..rows as u32)
            .flat_map(|row| std::iter::repeat_n(row, 10))
            .collect::<Vec<_>>();
        let indices = Array::from_u32(&indices, &[routed_rows])?;
        #[cfg(test)]
        {
            self.routed_index_builds += 1;
        }
        if let Some(slot) = cache_slot {
            self.routed_indices[slot] = Some(indices.try_clone()?);
        }
        x.take(&indices, 0)?.astype(Dtype::Float16)
    }

    fn prepare_resident_hot(&mut self, x: &Array, selected: &Array) -> Result<Option<ResidentHot>> {
        if self.store.last.is_some() {
            #[cfg(test)]
            let _profile = crate::flash_profile::span("hot_previous_bank_users_wait");
            self.store.drain()?;
        }
        let map = self.store.cache.borrow().resident_slot_map()?;
        if map.iter().all(|&slot| slot == u32::MAX) {
            return Ok(None);
        }
        let input = self.routed_input(x)?;
        #[cfg(test)]
        let _prepare = crate::flash_profile::span("gpu_resident_hot_prepare");
        let slots = linear::ExpertSlots::residents(selected, &map, self.store.banks[0].shape()[0])?;
        slots.indices().async_eval()?;
        let output = self.calculate_slots(&input, &slots)?;
        #[cfg(test)]
        let output = if self.slow_hot_for_test {
            hybrid_tests::delay(&output)?
        } else {
            output
        };
        self.store.last = Some(output.try_clone()?);
        output.async_eval()?;
        #[cfg(test)]
        {
            self.hybrid_submissions += 1;
        }
        Ok(Some(ResidentHot {
            input,
            output,
            map,
            complete: false,
        }))
    }

    fn forward_unique_rows(&mut self, x: &Array, row_limit: i32) -> Result<Array> {
        #[cfg(test)]
        let _cohorts = crate::flash_profile::span("moe_unique_cohorts");
        #[cfg(test)]
        let planning = crate::flash_profile::span("route_window_build_and_wait_inclusive");
        #[cfg(test)]
        let started = std::time::Instant::now();
        #[cfg(test)]
        let submissions_before = self.hybrid_submissions;
        let rows = x.shape()[0];
        let pairs = (0..rows)
            .map(|row| self.route(&x.slice(0, row, row + 1)?))
            .collect::<Result<Vec<_>>>()?;
        let selected = Array::concatenate(&pairs.iter().map(|p| &p.0).collect::<Vec<_>>(), 0)?;
        let weights = Array::concatenate(&pairs.iter().map(|p| &p.1).collect::<Vec<_>>(), 0)?;
        let mut hot = self.prepare_resident_hot(x, &selected)?;
        #[cfg(test)]
        self.window_hot_before_readback
            .push(self.hybrid_submissions > submissions_before);
        let ids = selected.to_u32()?;
        ensure!(ids.len() == rows as usize * 10, "incomplete route window");
        #[cfg(test)]
        {
            self.route_readbacks += 1;
            self.profile_seconds[0] += started.elapsed().as_secs_f64();
            drop(planning);
        }
        let available = self.store.cache.borrow().available_slots();
        if crate::flash_support::largest_expert_prefix(&ids, available) == Some(rows as usize) {
            return self.forward_rows_prepared(
                x,
                None,
                0,
                row_limit,
                Some(PreparedRows {
                    selected,
                    weights,
                    ids,
                    hot,
                }),
            );
        }
        // A split may evict future Hot experts: finish their captured results first.
        if let Some(hot) = &mut hot {
            let hot_ids = ids
                .iter()
                .copied()
                .filter(|&id| {
                    hot.map
                        .get(id as usize)
                        .is_some_and(|&slot| slot != u32::MAX)
                })
                .collect::<Vec<_>>();
            // Reused Hot values still count as demand before Cold chooses its victims.
            if !hot_ids.is_empty() {
                let before = self.store.cache.borrow().prefetch_hits;
                ensure!(
                    self.store
                        .cache
                        .borrow_mut()
                        .reserve(&hot_ids)?
                        .iter()
                        .all(|p| p.1),
                    "resident Hot snapshot changed before reservation"
                );
                self.count_prefetch_hits(before);
            }
            hot.output.eval()?;
            hot.complete = true;
            self.store.last = None;
        }
        let mut output = Vec::new();
        let mut begin = 0;
        while begin < rows {
            let available = self.store.cache.borrow().available_slots();
            let count =
                crate::flash_support::largest_expert_prefix(&ids[begin as usize * 10..], available)
                    .filter(|&count| count > 0)
                    .context("route window has no reservable expert prefix")?
                    as i32;
            let end = begin + count;
            self.store.drain()?;
            output.push(
                self.forward_rows_prepared(
                    &x.slice(0, begin, end)?,
                    None,
                    0,
                    row_limit,
                    Some(PreparedRows {
                        selected: selected.slice(0, begin, end)?,
                        weights: weights.slice(0, begin, end)?,
                        ids: ids[begin as usize * 10..end as usize * 10].to_vec(),
                        hot: hot
                            .as_ref()
                            .map(|hot| {
                                Ok::<_, anyhow::Error>(ResidentHot {
                                    input: hot.input.slice(0, begin * 10, end * 10)?,
                                    output: hot.output.slice(0, begin * 10, end * 10)?,
                                    map: hot.map,
                                    complete: true,
                                })
                            })
                            .transpose()?,
                    }),
                )?,
            );
            begin = end;
        }
        Array::concatenate(&output.iter().collect::<Vec<_>>(), 0)
    }

    fn forward_rows_prepared(
        &mut self,
        x: &Array,
        next: Option<&mut Self>,
        depth: usize,
        row_limit: i32,
        prepared: Option<PreparedRows>,
    ) -> Result<Array> {
        ensure!(depth <= 10, "lookahead depth must be in 0..=10");
        ensure!(
            x.shape().len() == 2
                && (1..=row_limit).contains(&x.shape()[0])
                && x.shape()[1] == H
                && matches!(x.dtype(), Dtype::Float16 | Dtype::Float32),
            "invalid streamed MoE route shape or dtype"
        );
        let rows = x.shape()[0];
        if let Some((_, pool)) = &self.prefetcher {
            pool.borrow_mut().poll();
        }
        let available = self.store.cache.borrow().available_slots();
        if prepared.is_none() && available < rows as usize * 10 {
            if self.policy.unique_cohorts
                && self.policy.gpu_hot
                && self.policy.gpu_hot_wide
                && self.policy.overlap
                && depth == 0
                && (self.prefetcher.is_none() || self.policy.prefetch_pipeline)
            {
                return self.forward_unique_rows(x, row_limit);
            }
            #[cfg(test)]
            let _cohorts = crate::flash_profile::span("moe_cohorts");
            let cohort = crate::flash_support::expert_cohort_rows(available)
                .context("invalid streamed MoE cache capacity")? as i32;
            let mut output = Vec::new();
            for begin in (0..rows).step_by(cohort as usize) {
                output.push(self.forward_rows(
                    &x.slice(0, begin, (begin + cohort).min(rows))?,
                    None,
                    0,
                    row_limit,
                )?);
            }
            return Array::concatenate(&output.iter().collect::<Vec<_>>(), 0);
        }
        #[cfg(test)]
        self.cohort_sizes.push(rows as usize);
        #[cfg(test)]
        let profile = crate::flash_profile::span("moe_forward_rows");
        #[cfg(test)]
        let route_start = std::time::Instant::now();
        #[cfg(test)]
        {
            self.schedule_events.clear();
            self.prediction_ready_at_demand = None;
            self.hot_ready_at_routes = None;
            self.hot_ready_at_demand = None;
        }
        #[cfg(test)]
        let routing = crate::flash_profile::span("router_build_and_wait_inclusive");
        let hybrid = self.policy.gpu_hot
            && self.policy.overlap
            && (rows <= 2 || self.policy.gpu_hot_wide)
            && depth == 0
            && (self.prefetcher.is_none() || self.policy.prefetch_pipeline);
        let (selected, weights, host_ids, hot) = match prepared {
            Some(prepared) => (
                prepared.selected,
                prepared.weights,
                Some(prepared.ids),
                prepared.hot,
            ),
            None => {
                let pairs = (0..rows)
                    .map(|row| self.route(&x.slice(0, row, row + 1)?))
                    .collect::<Result<Vec<_>>>()?;
                let selected =
                    Array::concatenate(&pairs.iter().map(|p| &p.0).collect::<Vec<_>>(), 0)?;
                let weights =
                    Array::concatenate(&pairs.iter().map(|p| &p.1).collect::<Vec<_>>(), 0)?;
                let hot = if hybrid {
                    self.prepare_resident_hot(x, &selected)?
                } else {
                    None
                };
                (selected, weights, None, hot)
            }
        };
        let (early_input, gpu_hot, snapshot, completed_hot) = match hot {
            Some(hot) => (
                Some(hot.input),
                Some(hot.output),
                Some(hot.map),
                hot.complete,
            ),
            None => (None, None, None, false),
        };
        let early_hot = gpu_hot.is_some();
        #[cfg(test)]
        let readback = crate::flash_profile::span("route_readback_inclusive");
        let ids = match host_ids {
            Some(ids) => ids,
            None => {
                #[cfg(test)]
                {
                    self.route_readbacks += 1;
                }
                selected.to_u32()?
            }
        };
        #[cfg(test)]
        {
            drop(readback);
            drop(routing);
        }
        #[cfg(test)]
        {
            self.profile_seconds[0] += route_start.elapsed().as_secs_f64();
            self.schedule_events
                .push(("routes_cpu", route_start.elapsed().as_secs_f64()));
        }
        #[cfg(test)]
        {
            self.route_ids.clone_from(&ids);
            self.hot_ready_at_routes = gpu_hot.as_ref().map(Array::is_available).transpose()?;
        }
        let routed_x = match early_input {
            Some(value) => value,
            None => self.routed_input(x)?,
        };
        if !early_hot && self.store.last.is_some() {
            #[cfg(test)]
            let _profile = crate::flash_profile::span("previous_bank_users_wait");
            self.store.drain()?;
        }
        #[cfg(test)]
        let import_start = std::time::Instant::now();
        if let Some((layer, pool)) = &self.prefetcher {
            self.store.cache.borrow_mut().enable_predictive_lru();
            let mut pool = pool.borrow_mut();
            pool.poll();
            pool.note_late(*layer, &ids);
            if self.policy.prefetch_pipeline {
                pool.wait_demand(*layer, &self.store.cache, &ids);
            }
        }
        let before = self.store.cache.borrow().prefetch_hits;
        let fill = ExpertFill::new(&self.store.cache);
        let snapshot_hot = |id: u32| {
            snapshot
                .as_ref()
                .and_then(|map| map.get(id as usize))
                .is_some_and(|&slot| slot != u32::MAX)
        };
        let routes = if completed_hot {
            // Completed Hot values survive eviction; reserve only the original Cold IDs.
            let cold_ids = ids
                .iter()
                .copied()
                .filter(|&id| !snapshot_hot(id))
                .collect::<Vec<_>>();
            let reserved = if cold_ids.is_empty() {
                Vec::new()
            } else {
                self.store.cache.borrow_mut().reserve(&cold_ids)?
            };
            let mut reserved = reserved.into_iter();
            ids.iter()
                .map(|&id| {
                    if snapshot_hot(id) {
                        (
                            snapshot.as_ref().expect("Hot snapshot")[id as usize] as usize,
                            true,
                        )
                    } else {
                        reserved.next().expect("reserved Cold occurrence")
                    }
                })
                .collect::<Vec<_>>()
        } else {
            self.store.cache.borrow_mut().reserve(&ids)?
        };
        self.count_prefetch_hits(before);
        #[cfg(test)]
        {
            self.import_seconds += import_start.elapsed().as_secs_f64();
        }
        let mut hot = Vec::new();
        let mut cold = Vec::new();
        let mut order = Vec::new();
        for (i, &(slot, hit)) in routes.iter().enumerate() {
            if hit {
                self.hits = self.hits.saturating_add(1);
            } else {
                self.misses = self.misses.saturating_add(1);
            }
            if if early_hot { snapshot_hot(ids[i]) } else { hit } {
                hot.push((i, slot as u32));
            } else {
                cold.push((i, slot as u32));
            }
        }
        #[cfg(test)]
        if let Some(profile) = &profile {
            let hits = routes.iter().filter(|p| p.1).count();
            profile.data(serde_json::json!({"rows":rows,"ids":ids,"slots_hit":routes,"hot_rows":hits,"cold_rows":ids.len()-hits,"resident_gpu_rows":hot.len(),"completed_hot":completed_hot,"capacity":self.store.cache.borrow().capacity()}));
        }
        let hot_output = if early_hot {
            #[cfg(test)]
            {
                self.overlap_hot_rows += hot.len() as u64;
            }
            gpu_hot
        } else if self.policy.overlap && !hot.is_empty() && !cold.is_empty() {
            let value = self.calculate(
                &routed_x.take(
                    &Array::from_u32(
                        &hot.iter().map(|p| p.0 as u32).collect::<Vec<_>>(),
                        &[hot.len() as i32],
                    )?,
                    0,
                )?,
                &hot.iter().map(|p| p.1).collect::<Vec<_>>(),
            )?;
            // Retain submitted reads of the banks even if a later operation fails.
            self.store.last = Some(value.try_clone()?);
            value.async_eval()?;
            #[cfg(test)]
            {
                self.overlap_hot_rows += hot.len() as u64;
            }
            Some(value)
        } else {
            None
        };
        let prediction = (|| -> Result<Option<Array>> {
            let prediction = if depth > 0 {
                next.as_ref().map(|next| next.predict(x)).transpose()?
            } else {
                None
            };
            if let Some(prediction) = &prediction {
                prediction.async_eval()?;
                #[cfg(test)]
                self.schedule_events
                    .push(("prediction_submitted", route_start.elapsed().as_secs_f64()));
            }
            Ok(prediction)
        })();
        let prediction = match prediction {
            Ok(prediction) => prediction,
            Err(error) => {
                if let Some(hot) = &hot_output {
                    hot.eval()?;
                }
                return Err(error.context("preparing optional expert prediction"));
            }
        };
        let mut filled = BTreeSet::new();
        #[cfg(test)]
        let read_start = std::time::Instant::now();
        let mut jobs = cold
            .iter()
            .filter(|&&(i, _)| !routes[i].1)
            .filter_map(|&(i, slot)| filled.insert(slot).then_some((ids[i], slot as usize)))
            .collect::<Vec<_>>();
        #[cfg(test)]
        if !jobs.is_empty() {
            self.hot_ready_at_demand = hot_output.as_ref().map(Array::is_available).transpose()?;
            self.prediction_ready_at_demand =
                prediction.as_ref().map(Array::is_available).transpose()?;
            self.schedule_events
                .push(("demand_begin", route_start.elapsed().as_secs_f64()));
        }
        let mut consumers = ColdConsumers::default();
        let mut shared = None;
        // Wider Cold waves are opt-in; grouped and prefetched paths retain their fallback.
        let split_cold = self.policy.cold_ready
            && (1..=self.policy.cold_ready_rows).contains(&rows)
            && depth == 0
            && self.prefetcher.is_none()
            && !self.policy.shared_exl3
            && !self.policy.weighted_epilogue
            && jobs.len() > 2
            && hot_output.is_some();
        let priority_active = split_cold && rows == 2 && self.policy.cold_priority;
        if priority_active {
            crate::cold_ready::prioritize_jobs(&mut jobs, &cold);
            #[cfg(test)]
            {
                self.cold_priority_batches += 1;
            }
        }
        let read = if split_cold {
            let hot = hot_output.as_ref().expect("Hot checked");
            let lease = match hot.try_clone() {
                Ok(lease) => lease,
                Err(error) => {
                    hot.eval().or_else(|_| crate::array::synchronize())?;
                    return Err(error.context("retaining Hot during Cold reads"));
                }
            };
            consumers.0.push(lease);
            self.fill_ready(
                &jobs,
                &routed_x,
                &mut cold,
                &mut consumers,
                self.policy.cold_shared.then_some((x, &mut shared)),
                rows,
            )
        } else {
            self.fill_many(&jobs).map(|()| None)
        };
        let (first_cold, prepared_rest) = match read {
            Ok(Some(waves)) => (Some(waves.first), waves.rest),
            Ok(None) => (None, None),
            Err(error) => {
                if consumers.0.is_empty()
                    && let Some(hot) = &hot_output
                {
                    hot.eval()?;
                }
                return Err(error.context("loading cold EXL3 experts"));
            }
        };
        fill.commit();
        #[cfg(test)]
        if !jobs.is_empty()
            && let Some(probe) = crate::flash_profile::span("cold_io_return")
        {
            probe.data(serde_json::json!({
                "jobs": jobs.len(),
                "hot_ready_at_begin": self.hot_ready_at_demand,
                "hot_ready_at_return": hot_output.as_ref()
                    .map(Array::is_available).transpose()?,
            }));
        }
        #[cfg(test)]
        {
            self.profile_seconds[1] += read_start.elapsed().as_secs_f64();
            if !jobs.is_empty() {
                self.schedule_events
                    .push(("demand_end", route_start.elapsed().as_secs_f64()));
            }
        }
        let (values, already_weighted) = if let Some(hot_output) = hot_output {
            if cold.is_empty() {
                (hot_output, false)
            } else {
                let first_rows = first_cold.as_ref().map_or(0, |a| a.shape()[0] as usize);
                let cold_output = match prepared_rest {
                    Some(rest) => rest,
                    None => self.calculate_cold(&routed_x, &cold[first_rows..])?,
                };
                let combined = if let Some(first) = &first_cold {
                    Some(Array::concatenate(&[&hot_output, first, &cold_output], 0)?)
                } else if self.policy.weighted_epilogue {
                    None
                } else {
                    Some(Array::concatenate(&[&hot_output, &cold_output], 0)?)
                };
                for (i, &(_, hit)) in routes.iter().enumerate() {
                    let index = if early_hot && snapshot_hot(ids[i]) {
                        i
                    } else if !early_hot && hit {
                        hot.iter().position(|p| p.0 == i).expect("hot route")
                    } else {
                        (if early_hot { ids.len() } else { hot.len() })
                            + cold.iter().position(|p| p.0 == i).expect("cold route")
                    };
                    order.push(index as u32);
                }
                if self.policy.weighted_epilogue {
                    (
                        crate::weighted_epilogue::apply(
                            &hot_output,
                            &cold_output,
                            &order,
                            &weights,
                            x.dtype(),
                        )?,
                        true,
                    )
                } else {
                    (
                        combined
                            .expect("stock merge prepared")
                            .take(&Array::from_u32(&order, &[order.len() as i32])?, 0)?,
                        false,
                    )
                }
            }
        } else {
            (
                self.calculate(
                    &routed_x,
                    &routes.iter().map(|p| p.0 as u32).collect::<Vec<_>>(),
                )?,
                false,
            )
        };
        let weighted = if already_weighted {
            values
        } else {
            values
                .astype(x.dtype())?
                .mul(&weights.reshape(&[rows * 10, 1])?)?
        };
        let routed = weighted.reshape(&[rows, 10, H])?.sum(1, false)?;
        #[cfg(test)]
        crate::flash_profile::stage("routed_reduction_completion", &routed)?;
        let shared = match shared {
            Some(value) => value,
            None => self.shared(x)?,
        };
        let output = routed.add(&shared)?;
        #[cfg(test)]
        crate::flash_profile::stage("moe_add_completion", &output)?;
        self.store.last = Some(output.try_clone()?);
        let predicted_ids = prediction
            .map(|p| -> Result<Vec<u32>> {
                let mut ids = p.to_u32()?;
                ensure!(
                    order_predictions(&mut ids, rows as usize),
                    "invalid lookahead prediction shape or IDs"
                );
                #[cfg(test)]
                self.schedule_events
                    .push(("prediction_cpu", route_start.elapsed().as_secs_f64()));
                Ok(ids)
            })
            .transpose()?;
        if let (Some(next), Some(ids)) = (next, predicted_ids) {
            if ids
                .iter()
                .any(|&id| !next.store.cache.borrow().contains(id))
            {
                output.async_eval()?;
            }
            next.prefetch(&ids, depth)?;
        }
        // The final output/last now retains every submitted bank consumer.
        consumers.0.clear();
        Ok(output)
    }

    fn shared_projection(&self, x: &Array) -> Result<Array> {
        #[cfg(test)]
        let _profile = crate::flash_profile::span("shared_projection_build");
        let gate = self.shared_gate.forward(x)?.astype(Dtype::Float16)?;
        #[cfg(test)]
        crate::flash_profile::stage("shared_gate_projection", &gate)?;
        let up = self.shared_up.forward(x)?.astype(Dtype::Float16)?;
        #[cfg(test)]
        crate::flash_profile::stage("shared_up_projection", &up)?;
        let activated = gate.swiglu(&up)?;
        #[cfg(test)]
        crate::flash_profile::stage("shared_swiglu", &activated)?;
        let shared = self.shared_down.forward(&activated)?.astype(x.dtype())?;
        #[cfg(test)]
        crate::flash_profile::stage("shared_down_projection", &shared)?;
        Ok(shared)
    }

    fn shared(&self, x: &Array) -> Result<Array> {
        #[cfg(test)]
        let _profile = crate::flash_profile::span("shared_expert_build");
        ensure!(
            x.shape().len() == 2
                && (1..=8).contains(&x.shape()[0])
                && x.shape()[1] == H
                && matches!(x.dtype(), Dtype::Float16 | Dtype::Float32),
            "invalid shared expert shape or dtype"
        );
        let rows = x.shape()[0];
        let batched = (self.policy.shared_batch
            && rows > 1
            && self.shared_gate.is_exl3()
            && self.shared_up.is_exl3()
            && self.shared_down.is_exl3())
        .then(|| self.shared_projection(x))
        .transpose()?;
        let mut output = Vec::new();
        for row in 0..rows {
            let x = x.slice(0, row, row + 1)?;
            let shared = match &batched {
                Some(values) => values.slice(0, row, row + 1)?,
                None => self.shared_projection(&x)?,
            };
            // Keep the dense scalar GEMV's single-row reduction order.
            let shared = shared.mul(&self.multiplier.forward(&x)?.sigmoid()?)?;
            #[cfg(test)]
            crate::flash_profile::stage("shared_expert_completion", &shared)?;
            output.push(shared);
        }
        Array::concatenate(&output.iter().collect::<Vec<_>>(), 0)
    }

    fn count_prefetch_hits(&mut self, before: u64) {
        let used = self.store.cache.borrow().prefetch_hits - before;
        if let Some((_, pool)) = &self.prefetcher {
            pool.borrow()
                .counters
                .used
                .fetch_add(used, std::sync::atomic::Ordering::Relaxed);
        }
        #[cfg(test)]
        {
            self.prefetched += used;
        }
    }

    fn prefetch(&mut self, ids: &[u32], budget: usize) -> Result<()> {
        ensure!(
            !ids.is_empty() && ids.len() <= 2 * PREDICTION_RANKS && ids.iter().all(|&id| id < 512),
            "invalid predicted experts"
        );
        let Some((layer, pool)) = self.prefetcher.as_ref().map(|(l, p)| (*l, Rc::clone(p))) else {
            return Ok(());
        };
        let mut pool = pool.borrow_mut();
        pool.poll();
        self.store.cache.borrow_mut().protect_predictions(ids)?;
        let mut cold = Vec::new();
        #[cfg(test)]
        {
            self.prefetch_profile[0] += ids.len() as u64;
        }
        for &id in ids {
            #[cfg(test)]
            {
                self.prefetch_profile[1] += 1;
            }
            if self.store.cache.borrow().contains(id) {
                #[cfg(test)]
                {
                    self.prefetch_profile[2] += 1;
                }
            } else if !cold.contains(&id) {
                cold.push(id);
            }
        }
        if cold.is_empty() || budget == 0 || !pool.has_room() {
            return Ok(());
        }
        self.drain()?;
        let mut admitted = 0;
        for id in cold {
            if admitted == budget.min(4) || !pool.has_room() {
                break;
            }
            let Some(lease) = self.store.cache.borrow_mut().claim_lease(id)? else {
                continue;
            };
            let read = self.store.records[id as usize]
                .source()
                .and_then(|(file, offset)| {
                    Array::prepare_read(
                        file,
                        offset,
                        &mut self.store.banks,
                        &expert_slot_destinations(lease.slot),
                    )
                });
            let read = match read {
                Ok(read) => read,
                Err(_) => {
                    self.store.cache.borrow_mut().finish_lease(lease, false);
                    pool.counters
                        .failed
                        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                    continue;
                }
            };
            if pool.submit(layer, lease, Rc::clone(&self.store.cache), read) {
                admitted += 1;
                #[cfg(test)]
                {
                    self.prefetch_profile[3] += 1;
                }
            }
        }
        Ok(())
    }

    pub fn drain(&mut self) -> Result<()> {
        self.store.drain()
    }

    #[cfg(test)]
    pub(crate) fn cache_for_test_invalidate(&mut self) {
        self.store.cache.borrow_mut().invalidate();
    }

    #[cfg(test)]
    pub(crate) fn slots_for_test(&self) -> usize {
        let slots = self.store.cache.borrow().capacity();
        assert!(
            self.store
                .banks
                .iter()
                .all(|b| b.shape()[0] == slots as i32)
        );
        slots
    }

    #[cfg(test)]
    pub(crate) fn gate_for_test(&self) -> &Projection {
        &self.gate
    }
}

#[test]
#[ignore = "physical Apple GPU and Flash checkpoint; fail bank replacement after partial allocation"]
fn failed_shrink_keeps_the_old_cache_and_banks() -> Result<()> {
    let c = crate::checkpoint::inspect(std::path::Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
    let mut moe = SsdMoe::load(&c, "model.language_model.layers.0.mlp", 20, true)?;
    let identity = Rc::as_ptr(&moe.store.cache);
    let before = moe.bank_backing_bytes()?;
    let error = moe
        .shrink_with(10, |_| {
            let _partial = Array::zeros_dtype(&[10, 640], Dtype::Float16)?;
            anyhow::bail!("injected allocation failure")
        })
        .unwrap_err();
    assert!(error.to_string().contains("injected allocation"));
    assert_eq!(Rc::as_ptr(&moe.store.cache), identity);
    assert_eq!(moe.slots_for_test(), 20);
    assert_eq!(moe.bank_backing_bytes()?, before);
    let x = Array::from_f32(&vec![0.03125; H as usize], &[1, H])?;
    let expected = moe.forward(&x)?.to_bytes()?;
    moe.shrink(10)?;
    assert_eq!(moe.slots_for_test(), 10);
    assert!(moe.bank_backing_bytes()? < before);
    assert!(!expected.is_empty());
    assert_eq!(moe.forward(&x)?.to_bytes()?, expected);
    Ok(())
}

#[cfg(test)]
#[path = "ssd_moe/hybrid_tests.rs"]
mod hybrid_tests;

#[cfg(test)]
#[path = "ssd_moe/routed_index_tests.rs"]
mod routed_index_tests;

#[cfg(test)]
#[path = "ssd_moe/shared_tests.rs"]
mod shared_tests;

#[cfg(test)]
#[path = "ssd_moe/prefetch_tests.rs"]
mod prefetch_tests;

#[cfg(test)]
#[path = "ssd_moe/cold_ready_tests.rs"]
mod cold_ready_tests;

#[cfg(test)]
mod tests {
    fn resident_gate_fixture() -> anyhow::Result<Vec<(super::SsdMoe, [crate::array::Array; 2])>> {
        use super::*;
        use serde_json::Value;
        use std::{fs::File, path::Path};
        ensure!(std::env::var("MLXL3_SSD_RESIDENT_GATES")? == "1");
        let root = std::env::var("MLXL3_FLASH_REFERENCE")?;
        let root = Path::new(&root);
        let reference: Value = serde_json::from_reader(File::open(root.join("reference.json"))?)?;
        ensure!(reference["status"] == "complete" && reference["mode"] == "eval");
        let checkpoint =
            crate::checkpoint::inspect(Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
        crate::array::set_default_cache_limit(512 << 20)?;
        (0..48)
            .map(|layer| {
                let mut inputs = Vec::new();
                for step in [0, 1] {
                    let components = reference["steps"][step]["components"]
                        .as_array()
                        .context("missing components")?;
                    ensure!(components.len() == 48);
                    let entry = &components[layer]["mlp"]["input"];
                    ensure!(entry["count"] == H);
                    let bytes = std::fs::read(
                        root.join(entry["file"].as_str().context("missing fixture")?),
                    )?;
                    ensure!(
                        bytes.len() == H as usize * 4
                            && bytes
                                .as_chunks::<4>()
                                .0
                                .iter()
                                .all(|&b| f32::from_le_bytes(b).is_finite())
                    );
                    let x = Array::from_bytes(&bytes, &[1, H], Dtype::Float32)?;
                    x.eval()?;
                    inputs.push(x);
                }
                let moe = SsdMoe::load(
                    &checkpoint,
                    &format!("model.language_model.layers.{layer}.mlp"),
                    20,
                    true,
                )?;
                let weight = moe
                    .resident_gate
                    .as_ref()
                    .context("missing resident gate")?;
                ensure!(weight.shape() == [H, 512] && weight.dtype() == Dtype::Float32);
                ensure!(weight.retained_bytes()? == H as usize * 512 * 4);
                Ok((
                    moe,
                    inputs
                        .try_into()
                        .map_err(|_| anyhow::anyhow!("invalid fixture count"))?,
                ))
            })
            .collect()
    }

    #[test]
    #[ignore = "physical Apple GPU; experiment49 all dense gates, strides and fallback"]
    fn resident_gate_logits_probabilities_and_routes_match_original() -> anyhow::Result<()> {
        use super::*;
        let mut cases = 0;
        for (layer, (mut moe, inputs)) in resident_gate_fixture()?.into_iter().enumerate() {
            for input in inputs {
                for dtype in [Dtype::Float32, Dtype::Float16] {
                    for strided in [false, true] {
                        let x = if strided {
                            let values = input
                                .to_f32()?
                                .into_iter()
                                .flat_map(|v| [v, v * 0.5 + 0.125])
                                .collect::<Vec<_>>();
                            Array::from_f32(&values, &[H, 2])?
                                .astype(dtype)?
                                .transpose(&[1, 0])?
                                .slice(0, 0, 1)?
                        } else {
                            input.astype(dtype)?
                        };
                        let original = moe.gate.forward(&x)?;
                        let cached = moe.gate_logits(&x)?;
                        ensure!(original.shape() == [1, 512] && cached.shape() == [1, 512]);
                        let values = cached.to_f32()?;
                        ensure!(values.len() == 512 && values.iter().all(|v| v.is_finite()));
                        ensure!(
                            cached.to_bytes()? == original.to_bytes()?,
                            "resident gate logits differ at layer{layer}, dtype{dtype:?}, stride{strided}"
                        );
                        let original_p = original.softmax_precise()?;
                        let cached_p = cached.softmax_precise()?;
                        ensure!(original_p.to_bytes()? == cached_p.to_bytes()?);
                        let probabilities = original_p.to_f32()?;
                        ensure!(
                            probabilities.len() == 512
                                && probabilities.iter().all(|v| v.is_finite())
                        );
                        let actual = moe.route(&x)?;
                        let weight = moe.resident_gate.take().context("missing weight")?;
                        let expected = moe.route(&x)?;
                        moe.resident_gate = Some(weight);
                        ensure!(actual.0.shape() == [1, 10] && actual.1.shape() == [1, 10]);
                        ensure!(
                            actual.0.to_bytes()? == expected.0.to_bytes()?
                                && actual.1.to_bytes()? == expected.1.to_bytes()?
                        );
                        let ids = actual.0.to_u32()?;
                        let mut sorted = (0..512u32).collect::<Vec<_>>();
                        sorted.sort_by(|&a, &b| {
                            probabilities[a as usize]
                                .total_cmp(&probabilities[b as usize])
                                .then(a.cmp(&b))
                        });
                        ensure!(ids == sorted[502..], "independent route order differs");
                        let scores = actual.1.to_f32()?;
                        ensure!(
                            scores.len() == 10
                                && scores.iter().all(|v| v.is_finite())
                                && (scores.iter().sum::<f32>() - 1.).abs() < 0.002
                        );
                        if layer == 0 && dtype == Dtype::Float32 && !strided {
                            let weight = moe.resident_gate.take().context("missing weight")?;
                            moe.resident_gate = Some(weight.scalar_mul(0.5)?);
                            ensure!(
                                moe.gate_logits(&x)?.to_bytes()? != original.to_bytes()?,
                                "bad gate mutation escaped oracle"
                            );
                            moe.resident_gate = Some(weight);
                            ensure!(moe.gate_logits(&x)?.to_bytes()? == original.to_bytes()?);
                        }
                        cases += 1;
                    }
                }
            }
        }
        ensure!(cases == 384);
        println!(
            "FLASH_RESIDENT_GATE cases=384 logits=196608 routes=3840 mutation=detected_restored parity=byte_exact"
        );
        Ok(())
    }

    #[cfg(kani)]
    #[kani::proof]
    fn actual_resident_gate_preserves_original_routes() {
        resident_gate_logits_probabilities_and_routes_match_original().unwrap();
    }

    #[test]
    #[ignore = "physical Apple GPU; experiment49 resident gate component timing only"]
    fn resident_gate_component_microbench() -> anyhow::Result<()> {
        use super::*;
        use std::{fs::File, time::Instant};
        fn select(
            models: &mut [(SsdMoe, [Array; 2])],
            saved: &mut [Option<Array>],
            candidate: bool,
        ) {
            for ((moe, _), cache) in models.iter_mut().zip(saved) {
                if candidate != moe.resident_gate.is_some() {
                    std::mem::swap(&mut moe.resident_gate, cache);
                }
                assert_eq!(moe.resident_gate.is_some(), candidate);
                assert_ne!(moe.resident_gate.is_some(), cache.is_some());
            }
        }
        fn sweep(models: &[(SsdMoe, [Array; 2])]) -> Result<Vec<u32>> {
            let mut ids = Vec::with_capacity(960);
            for (moe, inputs) in models {
                let a = moe.route(&inputs[0])?;
                let b = moe.route(&inputs[1])?;
                ids.extend(Array::concatenate(&[&a.0, &b.0], 0)?.to_u32()?);
            }
            ensure!(ids.len() == 960);
            Ok(ids)
        }
        let output = std::env::var("MLXL3_FLASH_GATE_MICRO")?;
        serde_json::to_writer(
            File::create_new(&output)?,
            &serde_json::json!({"status":"incomplete"}),
        )?;
        let mut models = resident_gate_fixture()?;
        let mut saved = (0..48).map(|_| None).collect::<Vec<_>>();
        select(&mut models, &mut saved, false);
        let oracle = sweep(&models)?;
        select(&mut models, &mut saved, true);
        ensure!(sweep(&models)? == oracle);
        let warmup = Instant::now();
        let mut warmup_sweeps = 0;
        while warmup.elapsed().as_secs_f64() < 2. {
            for candidate in [false, true] {
                select(&mut models, &mut saved, candidate);
                ensure!(sweep(&models)? == oracle);
                warmup_sweeps += 1;
            }
        }
        let warmup_seconds = warmup.elapsed().as_secs_f64();
        let mut samples = Vec::new();
        for pair in 0..5 {
            for candidate in if pair % 2 == 0 {
                [false, true]
            } else {
                [true, false]
            } {
                select(&mut models, &mut saved, candidate);
                let start = Instant::now();
                let mut last = Vec::new();
                for _ in 0..32 {
                    last = sweep(&models)?;
                }
                let seconds = start.elapsed().as_secs_f64() / 32.;
                ensure!(seconds.is_finite() && seconds > 0. && last == oracle);
                samples
                    .push(serde_json::json!({"pair":pair,"candidate":candidate,"seconds":seconds}));
            }
        }
        ensure!(models.iter().all(|(moe, _)| moe.read_bytes == 0));
        std::fs::write(
            output,
            serde_json::to_vec_pretty(&serde_json::json!({
                "status":"complete","layers":48,"route_rows":2,"route_count":960,
                "resident_gate_bytes":48usize*512*H as usize*4,"warmup_sweeps":warmup_sweeps,
                "warmup_seconds":warmup_seconds,"sweeps_per_sample":32,"parity":"exact_route_ids",
                "no_expert_io":true,"samples":samples
            }))?,
        )?;
        println!(
            "FLASH_GATE_MICRO layers=48 rows=2 samples=10 sweeps=32 parity=exact_route_ids no_expert_io=true"
        );
        Ok(())
    }

    pub(super) fn admission_fixture()
    -> anyhow::Result<(crate::checkpoint::Checkpoint, crate::array::Array, Vec<u8>)> {
        use crate::array::{Array, Dtype};
        use anyhow::{Context, ensure};
        use std::path::Path;
        let root = std::env::var("MLXL3_FLASH_REFERENCE")?;
        let root = Path::new(&root);
        let reference: serde_json::Value =
            serde_json::from_reader(std::fs::File::open(root.join("reference.json"))?)?;
        let fixture = &reference["steps"][0]["components"][0]["mlp"];
        let input =
            std::fs::read(root.join(fixture["input"]["file"].as_str().context("missing input")?))?;
        let expected = std::fs::read(
            root.join(
                fixture["output"]["file"]
                    .as_str()
                    .context("missing output")?,
            ),
        )?;
        ensure!(input.len() == super::H as usize * 4 && expected.len() == input.len());
        let checkpoint =
            crate::checkpoint::inspect(Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
        Ok((
            checkpoint,
            Array::from_bytes(&input, &[1, super::H], Dtype::Float32)?,
            expected,
        ))
    }

    #[test]
    #[ignore = "physical Apple GPU; demanded reads must not wait for a slow predictor"]
    fn demanded_reads_start_before_the_optional_prediction_finishes() -> anyhow::Result<()> {
        use super::*;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut current = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 24, true)?;
        let mut next = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 24, true)?;
        next.slow_prediction_for_test = true;
        let pool = Rc::new(RefCell::new(ReaderPool::new()?));
        next.prefetcher = Some((1, Rc::clone(&pool)));
        let actual = current.forward_lookahead(&input, Some(&mut next), 4)?;
        println!(
            "SSD_SCHEDULE_TRACE {}",
            serde_json::json!({
                "clock_domain":"cpu_monotonic_seconds", "events":current.schedule_events,
                "prediction_ready_at_first_demand":current.prediction_ready_at_demand,
                "demand_records":current.read_bytes / EXPERT_BYTES,
                "test_only_slow_prediction":true,
            })
        );
        ensure!(actual.shape() == [1, H] && actual.to_bytes()? == expected);
        ensure!(current.read_bytes == 10 * EXPERT_BYTES);
        ensure!(
            current.prediction_ready_at_demand == Some(false),
            "demand waited for optional prediction"
        );
        let names = current
            .schedule_events
            .iter()
            .map(|e| e.0)
            .collect::<Vec<_>>();
        ensure!(
            names
                == [
                    "routes_cpu",
                    "prediction_submitted",
                    "demand_begin",
                    "demand_end",
                    "prediction_cpu"
                ]
        );
        ensure!(
            current
                .schedule_events
                .windows(2)
                .all(|p| p[0].1.is_finite() && p[0].1 <= p[1].1)
        );
        pool.borrow_mut().wait_for_idle()?;
        next.slow_prediction_for_test = false;
        ensure!(next.forward(&input)?.to_bytes()? == expected);
        Ok(())
    }

    #[test]
    #[ignore = "physical Apple GPU; failed prediction must invalidate unfilled routes and recover"]
    fn failed_prediction_invalidates_reserved_routes_and_recovers() -> anyhow::Result<()> {
        use super::*;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut current = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 24, true)?;
        let mut next = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 24, true)?;
        let ids = current.route(&input)?.0.to_u32()?;
        ensure!(ids.len() == 10 && ids.iter().copied().collect::<BTreeSet<_>>().len() == 10);
        let warm = current.store.cache.borrow_mut().reserve(&ids[..5])?;
        let jobs = ids[..5]
            .iter()
            .zip(warm)
            .map(|(&id, (slot, _))| (id, slot))
            .collect::<Vec<_>>();
        current.fill_many(&jobs)?;
        std::mem::swap(&mut next.gate, &mut next.shared_down);
        let error = current
            .forward_lookahead(&input, Some(&mut next), 4)
            .err()
            .context("invalid prediction unexpectedly succeeded")?;
        ensure!(error.chain().any(|error| {
            error
                .to_string()
                .contains("projection expects 640 logical inputs")
        }));
        ensure!(
            current.read_bytes == 5 * EXPERT_BYTES,
            "prediction did not fail before cold reads"
        );
        ensure!(current.overlap_hot_rows == 5 && current.misses == 5);
        ensure!(
            ids.iter()
                .all(|&id| !current.store.cache.borrow().contains(id)),
            "failed prediction left unfilled routes cached"
        );
        std::mem::swap(&mut next.gate, &mut next.shared_down);
        let pool = Rc::new(RefCell::new(ReaderPool::new()?));
        next.prefetcher = Some((1, Rc::clone(&pool)));
        let actual = current.forward_lookahead(&input, Some(&mut next), 4)?;
        ensure!(actual.shape() == [1, H] && actual.to_bytes()? == expected);
        pool.borrow_mut().wait_for_idle()?;
        ensure!(next.forward(&input)?.to_bytes()? == expected);
        Ok(())
    }

    #[cfg(kani)]
    #[kani::proof]
    fn actual_slot_dispatch_and_optional_prediction_schedule() {
        demanded_reads_start_before_the_optional_prediction_finishes().unwrap();
        failed_prediction_invalidates_reserved_routes_and_recovers().unwrap();
    }

    #[test]
    #[ignore = "physical Apple GPU; hot failure must invalidate unfilled routes before retry"]
    fn failed_hot_compute_invalidates_reserved_routes_and_recovers() -> anyhow::Result<()> {
        use super::*;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut moe = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 24, true)?;
        // Exercise the existing transaction after CPU reservation; the hybrid early failure has its own check.
        moe.policy.gpu_hot = false;
        let ids = moe.route(&input)?.0.to_u32()?;
        ensure!(ids.len() == 10 && ids.iter().copied().collect::<BTreeSet<_>>().len() == 10);
        let warm = moe.store.cache.borrow_mut().reserve(&ids[..5])?;
        let jobs = ids[..5]
            .iter()
            .zip(warm)
            .map(|(&id, (slot, _))| (id, slot))
            .collect::<Vec<_>>();
        moe.fill_many(&jobs)?;
        // Same storage, invalid layout: fail the real hot calculation before any cold read.
        let invalid = moe.store.banks[0].reshape(&[24, -1])?;
        let bank = std::mem::replace(&mut moe.store.banks[0], invalid);
        let error = moe
            .forward(&input)
            .err()
            .context("invalid hot bank unexpectedly succeeded")?;
        moe.store.banks[0] = bank;
        ensure!(
            error
                .to_string()
                .contains("expert slots were validated for a different bank capacity"),
            "{error:#}"
        );
        ensure!(moe.read_bytes == 5 * EXPERT_BYTES && moe.misses == 5);
        ensure!(
            ids.iter().all(|&id| !moe.store.cache.borrow().contains(id)),
            "unfilled routes cached after hot failure"
        );
        let actual = moe.forward(&input)?;
        ensure!(actual.shape() == [1, H] && actual.to_bytes()? == expected);
        ensure!(
            moe.read_bytes == 15 * EXPERT_BYTES,
            "retry did not reload every route"
        );
        moe.drain()?;
        Ok(())
    }

    #[cfg(kani)]
    #[kani::proof]
    fn actual_hot_failure_recovers_reserved_routes() {
        failed_hot_compute_invalidates_reserved_routes_and_recovers().unwrap();
    }

    #[test]
    #[ignore = "physical Apple GPU; first-layer LES must use LRU without incoming predictions"]
    fn attached_pool_enables_lru_without_an_incoming_prediction() -> anyhow::Result<()> {
        use super::*;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut moe = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 89, true)?;
        let selected = moe.route(&input)?.0.to_u32()?;
        ensure!(
            selected.len() == 10 && selected.iter().copied().collect::<BTreeSet<_>>().len() == 10
        );
        ensure!(selected.iter().any(|&id| id >= 89));
        let marker = (0..89u32)
            .find(|id| !selected.contains(id))
            .context("fixture needs an unrouted old expert")?;
        let ids = (0..89u32).collect::<Vec<_>>();
        let routes = moe.store.cache.borrow_mut().reserve(&ids)?;
        let jobs = ids
            .iter()
            .zip(routes)
            .map(|(&id, (slot, _))| (id, slot))
            .collect::<Vec<_>>();
        moe.fill_many(&jobs)?;
        for _ in 0..3 {
            moe.store.cache.borrow_mut().reserve(&[marker])?;
        }
        let others = ids
            .into_iter()
            .filter(|&id| id != marker)
            .collect::<Vec<_>>();
        for offset in (0..90).step_by(10) {
            let cohort = (offset..offset + 10)
                .map(|i| others[i % others.len()])
                .collect::<Vec<_>>();
            moe.store.cache.borrow_mut().reserve(&cohort)?;
        }
        ensure!(moe.store.cache.borrow().contains(marker));
        moe.prefetcher = Some((0, Rc::new(RefCell::new(ReaderPool::new()?))));
        ensure!(
            moe.forward(&input)?.to_bytes()? == expected,
            "independent MoE oracle differs"
        );
        ensure!(
            !moe.store.cache.borrow().contains(marker),
            "attached first-layer LES pool retained the old LFU policy"
        );
        Ok(())
    }

    #[test]
    #[ignore = "physical Apple GPU; persistent routed experts must overlap remaining SSD reads"]
    fn completed_prefetches_compute_while_other_experts_are_read() -> anyhow::Result<()> {
        use super::*;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut moe = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 89, true)?;
        let selected = moe.route(&input)?.0.to_u32()?;
        ensure!(
            selected.len() == 10 && selected.iter().copied().collect::<BTreeSet<_>>().len() == 10
        );
        let pool = Rc::new(RefCell::new(ReaderPool::new()?));
        moe.prefetcher = Some((0, Rc::clone(&pool)));
        moe.prefetch(&selected, 4)?;
        pool.borrow_mut().wait_for_idle()?;
        ensure!(
            moe.forward(&input)?.to_bytes()? == expected,
            "independent MoE oracle differs"
        );
        ensure!(moe.hits == 4 && moe.misses == 6 && moe.prefetched == 4);
        ensure!(moe.read_bytes == 6 * EXPERT_BYTES);
        ensure!(
            moe.overlap_hot_rows == 4,
            "completed prefetches still wait for cold SSD reads"
        );
        Ok(())
    }

    #[cfg(kani)]
    #[kani::proof]
    fn ready_experts_overlap_real_ssd_path() {
        completed_prefetches_compute_while_other_experts_are_read().unwrap();
    }

    #[test]
    #[ignore = "physical Apple GPU; completed late results must release admission capacity"]
    fn completed_previous_layer_reads_do_not_block_next_prefetch_cohort() -> anyhow::Result<()> {
        use super::*;
        use std::sync::atomic::Ordering;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut next = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 89, true)?;
        let pool = Rc::new(RefCell::new(ReaderPool::new()?));
        next.prefetcher = Some((1, Rc::clone(&pool)));
        let mut previous =
            SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 24, true)?;
        previous.prefetcher = Some((0, Rc::clone(&pool)));
        previous.prefetch(&[0, 1, 2, 3], 4)?;
        pool.borrow_mut().wait_for_idle()?;
        ensure!(pool.borrow().counters.completed.load(Ordering::Relaxed) == 4);
        let before = pool.borrow().counters.submitted.load(Ordering::Relaxed);
        next.prefetch(&[511], 4)?;
        ensure!(
            pool.borrow().counters.submitted.load(Ordering::Relaxed) == before + 1,
            "completed previous-layer results still block the next cohort"
        );
        pool.borrow_mut().wait_for_idle()?;
        ensure!(next.forward(&input)?.to_bytes()? == expected);
        Ok(())
    }

    #[test]
    #[ignore = "physical Apple GPU; cached strongest predictions must not consume the read budget"]
    fn cached_top_four_predictions_do_not_starve_useful_cold_prefetches() -> anyhow::Result<()> {
        use super::*;
        use std::sync::atomic::Ordering;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut current = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 89, true)?;
        let mut next = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 89, true)?;
        let hot = router::topk(&next.gate.forward(&input)?, 4, false)?
            .0
            .to_u32()?;
        ensure!(hot.len() == 4);
        let sorted_hot = next
            .gate
            .forward(&input)?
            .argsort()?
            .slice(1, 508, 512)?
            .to_u32()?;
        ensure!(
            hot.iter().copied().collect::<BTreeSet<_>>()
                == sorted_hot.into_iter().collect::<BTreeSet<_>>(),
            "fixture must warm the strongest four under both selectors"
        );
        let routes = next.store.cache.borrow_mut().reserve(&hot)?;
        let jobs = hot
            .iter()
            .zip(routes)
            .map(|(&id, (slot, _))| (id, slot))
            .collect::<Vec<_>>();
        next.fill_many(&jobs)?;
        ensure!(hot.iter().all(|&id| next.store.cache.borrow().contains(id)));
        let pool = Rc::new(RefCell::new(ReaderPool::new()?));
        next.prefetcher = Some((1, Rc::clone(&pool)));
        let before = pool.borrow().counters.submitted.load(Ordering::Relaxed);
        ensure!(
            current
                .forward_lookahead(&input, Some(&mut next), 4)?
                .to_bytes()?
                == expected
        );
        ensure!(
            pool.borrow().counters.submitted.load(Ordering::Relaxed) > before,
            "cached top four starve lower-ranked cold experts"
        );
        pool.borrow_mut().wait_for_idle()?;
        ensure!(next.forward(&input)?.to_bytes()? == expected && next.prefetched > 0);
        Ok(())
    }

    #[test]
    #[ignore = "physical Apple GPU; independent CPU sort oracle for one/two prediction rows"]
    fn batched_prediction_selects_top_sixteen_values_without_changing_real_routing()
    -> anyhow::Result<()> {
        use super::*;
        let (checkpoint, input, expected) = admission_fixture()?;
        let mut moe = SsdMoe::load(&checkpoint, "model.language_model.layers.0.mlp", 89, true)?;
        for half in [false, true] {
            moe.policy.predictor_half = half;
            for dtype in [Dtype::Float16, Dtype::Float32] {
                for rows in [1, 2] {
                    let x = if rows == 1 {
                        input.try_clone()?
                    } else {
                        Array::concatenate(&[&input, &input.scalar_mul(0.875)?], 0)?
                    }
                    .astype(dtype)?;
                    let gate_input = if half {
                        x.astype(Dtype::Float16)?
                    } else {
                        x.try_clone()?
                    };
                    let values = moe
                        .gate
                        .forward(&gate_input)?
                        .astype(Dtype::Float32)?
                        .to_f32()?;
                    ensure!(
                        values.len() == rows as usize * 512 && values.iter().all(|v| v.is_finite())
                    );
                    let prediction = moe.predict(&x)?;
                    ensure!(prediction.shape() == [rows, PREDICTION_RANKS as i32]);
                    let ids = prediction.to_u32()?;
                    ensure!(ids.len() == rows as usize * PREDICTION_RANKS);
                    for row in 0..rows as usize {
                        let ids = &ids[row * PREDICTION_RANKS..(row + 1) * PREDICTION_RANKS];
                        ensure!(
                            ids.iter().all(|&id| id < 512)
                                && ids.iter().copied().collect::<BTreeSet<_>>().len()
                                    == PREDICTION_RANKS
                        );
                        let mut oracle = values[row * 512..(row + 1) * 512].to_vec();
                        oracle.sort_by(f32::total_cmp);
                        let mut selected = ids
                            .iter()
                            .map(|&id| values[row * 512 + id as usize])
                            .collect::<Vec<_>>();
                        selected.sort_by(f32::total_cmp);
                        ensure!(
                            selected == oracle[512 - PREDICTION_RANKS..],
                            "prediction differs from independent CPU sort"
                        );
                    }
                    let mut ordered = ids;
                    ensure!(order_predictions(&mut ordered, rows as usize));
                }
            }
        }
        ensure!(moe.forward(&input)?.to_bytes()? == expected);
        let pool = Rc::new(RefCell::new(ReaderPool::new()?));
        moe.prefetcher = Some((0, Rc::clone(&pool)));
        moe.store.cache.borrow_mut().invalidate();
        moe.prefetch(&[0, 0, 1, 2, 511], 0)?;
        ensure!(moe.prefetch(&[0; 33], 4).is_err());
        ensure!(
            pool.borrow()
                .counters
                .submitted
                .load(std::sync::atomic::Ordering::Relaxed)
                == 0
        );
        moe.prefetch(&[0, 0, 1, 2, 511], 2)?;
        ensure!(
            pool.borrow()
                .counters
                .submitted
                .load(std::sync::atomic::Ordering::Relaxed)
                == 2
        );
        pool.borrow_mut().wait_for_idle()?;
        moe.prefetch(&[0, 0, 1, 2, 511], 4)?;
        ensure!(
            pool.borrow()
                .counters
                .submitted
                .load(std::sync::atomic::Ordering::Relaxed)
                == 4
        );
        pool.borrow_mut().wait_for_idle()?;
        ensure!(moe.forward(&input)?.to_bytes()? == expected);
        Ok(())
    }

    #[test]
    #[ignore = "physical Apple GPU and Flash fixtures; speculative fills and recovery"]
    fn lookahead_preserves_exact_routes_and_invalidates_failed_predictions() -> anyhow::Result<()> {
        use super::*;
        use std::path::Path;
        let root = std::env::var("MLXL3_FLASH_REFERENCE")?;
        let root = Path::new(&root);
        let reference: serde_json::Value =
            serde_json::from_reader(std::fs::File::open(root.join("reference.json"))?)?;
        let fixture = &reference["steps"][0]["components"][0]["mlp"];
        let bytes =
            std::fs::read(root.join(fixture["input"]["file"].as_str().context("missing input")?))?;
        let expected = std::fs::read(
            root.join(
                fixture["output"]["file"]
                    .as_str()
                    .context("missing output")?,
            ),
        )?;
        ensure!(bytes.len() == H as usize * 4 && expected.len() == bytes.len());
        let input = Array::from_bytes(&bytes, &[1, H], Dtype::Float32)?;
        let checkpoint =
            crate::checkpoint::inspect(Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
        for slots in [10, 20, 24, 89] {
            let mut current = SsdMoe::load(
                &checkpoint,
                "model.language_model.layers.0.mlp",
                slots,
                true,
            )?;
            let mut next = SsdMoe::load(
                &checkpoint,
                "model.language_model.layers.0.mlp",
                slots,
                true,
            )?;
            let pool = Rc::new(RefCell::new(ReaderPool::new()?));
            next.prefetcher = Some((1, Rc::clone(&pool)));
            for rows in [1, 2] {
                for depth in [0, 2, 4, 8, 10] {
                    pool.borrow_mut().wait_for_idle()?;
                    pool.borrow_mut().poll();
                    next.store.cache.borrow_mut().invalidate();
                    let x = if rows == 1 {
                        input.try_clone()?
                    } else {
                        Array::concatenate(&[&input, &input], 0)?
                    };
                    let before = pool
                        .borrow()
                        .counters
                        .submitted
                        .load(std::sync::atomic::Ordering::Relaxed);
                    let output = current.forward_lookahead(&x, Some(&mut next), depth)?;
                    ensure!(
                        output.shape() == [rows, H]
                            && output.to_bytes()? == expected.repeat(rows as usize),
                        "lookahead changed MoE output"
                    );
                    let after = pool
                        .borrow()
                        .counters
                        .submitted
                        .load(std::sync::atomic::Ordering::Relaxed);
                    if depth > 0 && slots > 20 {
                        ensure!(after > before, "test did not submit predictions");
                    } else {
                        ensure!(
                            after == before,
                            "minimum cache must preserve demand capacity"
                        );
                    }
                    pool.borrow_mut().wait_for_idle()?;
                    ensure!(
                        next.forward(&input)?.to_bytes()? == expected,
                        "prefetched weights differ"
                    );
                }
            }
            pool.borrow_mut().wait_for_idle()?;
            pool.borrow_mut().poll();
            next.store.cache.borrow_mut().invalidate();
            let selected = next.route(&input)?.0.to_u32()?;
            let before = next.prefetched;
            next.prefetch(&selected, 4)?;
            pool.borrow_mut().wait_for_idle()?;
            ensure!(next.forward(&input)?.to_bytes()? == expected);
            ensure!(
                if slots > 20 {
                    next.prefetched > before
                } else {
                    next.prefetched == before
                },
                "persistent admission or minimum-cache fallback was not exercised"
            );
            next.store.cache.borrow_mut().invalidate();
            let wrong = (0..512)
                .filter(|id| !selected.contains(id))
                .take(8)
                .collect::<Vec<_>>();
            ensure!(wrong.len() == 8);
            next.prefetch(&wrong, 4)?;
            let before = next.prefetched;
            pool.borrow_mut().wait_for_idle()?;
            let ready = wrong
                .iter()
                .copied()
                .filter(|&id| next.store.cache.borrow().contains(id))
                .collect::<Vec<_>>();
            ensure!(ready.len() == if slots > 20 { 4 } else { 0 });
            ensure!(
                next.forward(&input)?.to_bytes()? == expected && next.prefetched == before,
                "wrong predictions changed real routing"
            );
            ensure!(
                ready
                    .iter()
                    .all(|&id| next.store.cache.borrow().contains(id)),
                "unused records did not persist across a real forward"
            );
            let submitted = pool
                .borrow()
                .counters
                .submitted
                .load(std::sync::atomic::Ordering::Relaxed);
            if !ready.is_empty() {
                next.prefetch(&ready, 4)?;
                ensure!(
                    submitted
                        == pool
                            .borrow()
                            .counters
                            .submitted
                            .load(std::sync::atomic::Ordering::Relaxed),
                    "cached records were read twice"
                );
            }
            next.store.cache.borrow_mut().invalidate();
            next.prefetch(&[0, 511, 0], 4)?;
            let count = pool
                .borrow()
                .counters
                .submitted
                .load(std::sync::atomic::Ordering::Relaxed);
            next.prefetch(&[0, 511, 0], 4)?;
            ensure!(
                pool.borrow()
                    .counters
                    .submitted
                    .load(std::sync::atomic::Ordering::Relaxed)
                    == count,
                "duplicate speculative read"
            );
            pool.borrow_mut().wait_for_idle()?;
            pool.borrow_mut().poll();
            ensure!(next.prefetch(&[512], 4).is_err() && next.prefetch(&[], 4).is_err());
            next.store.cache.borrow_mut().invalidate();
            let saved = next.store.records[0].data_offsets;
            next.store.records[0].data_offsets[0] = u64::MAX;
            next.prefetch(&[0, 511], 4)?;
            pool.borrow_mut().wait_for_idle()?;
            ensure!(
                !next.store.cache.borrow_mut().reserve(&[0])?[0].1,
                "failed prediction left a false hit"
            );
            next.store.cache.borrow_mut().invalidate();
            next.store.records[0].data_offsets = saved;
            ensure!(
                next.forward(&input)?.to_bytes()? == expected,
                "prediction failure recovery differs"
            );
            ensure!(
                current
                    .forward_lookahead(&input, Some(&mut next), 11)
                    .is_err()
            );
            current.drain()?;
            next.drain()?;
        }
        Ok(())
    }

    #[test]
    #[ignore = "physical Apple GPU and independent Flash MoE inputs"]
    fn two_route_rows_match_oracle_with_cold_hot_small_caches_and_failed_reads()
    -> anyhow::Result<()> {
        use super::*;
        use serde_json::Value;
        use std::{fs::File, path::Path};
        let path = std::env::var("MLXL3_FLASH_REFERENCE")?;
        let root = Path::new(&path);
        let reference: Value = serde_json::from_reader(File::open(root.join("reference.json"))?)?;
        ensure!(
            reference["status"] == "complete" && reference["mode"] == "eval",
            "invalid MoE reference"
        );
        let checkpoint =
            crate::checkpoint::inspect(Path::new(&std::env::var("MLXL3_FLASH_MODEL")?))?;
        let mut inputs = Vec::new();
        let mut expected = Vec::new();
        for step in [0, 1, 4] {
            let entry = &reference["steps"][step]["components"][0]["mlp"];
            let read = |kind: &str| -> Result<Vec<u8>> {
                ensure!(entry[kind]["count"] == H, "invalid MoE fixture count");
                let bytes = std::fs::read(
                    root.join(entry[kind]["file"].as_str().context("missing fixture")?),
                )?;
                ensure!(
                    bytes.len() == H as usize * 4
                        && bytes
                            .as_chunks::<4>()
                            .0
                            .iter()
                            .all(|&b| f32::from_le_bytes(b).is_finite()),
                    "invalid MoE fixture bytes"
                );
                Ok(bytes)
            };
            inputs.push(Array::from_bytes(&read("input")?, &[1, H], Dtype::Float32)?);
            expected.push(read("output")?);
        }
        for slots in [10, 19, 20, 24, 53, 71, 80, 89, 512] {
            for (overlap, readers) in [
                (false, 1),
                (true, 1),
                (false, 2),
                (true, 2),
                (false, 4),
                (true, 4),
            ] {
                let mut moe = SsdMoe::load(
                    &checkpoint,
                    "model.language_model.layers.0.mlp",
                    slots,
                    overlap,
                )?;
                moe.policy.readers = readers;
                moe.policy.gpu_hot = true;
                moe.policy.gpu_hot_wide = true;
                for pair in [[0, 1], [0, 1], [1, 0], [0, 0], [1, 2]] {
                    let x = Array::concatenate(&[&inputs[pair[0]], &inputs[pair[1]]], 0)?;
                    let output = moe.forward_many(&x)?.to_bytes()?;
                    let mut oracle = expected[pair[0]].clone();
                    oracle.extend(&expected[pair[1]]);
                    ensure!(
                        output == oracle,
                        "two-row MoE differs, slots={slots}, overlap={overlap}, pair={pair:?}"
                    );
                }
                for rows in 1..=8 {
                    let indices = (0..rows).map(|i| i % 3).collect::<Vec<_>>();
                    let x = Array::concatenate(
                        &indices.iter().map(|&i| &inputs[i]).collect::<Vec<_>>(),
                        0,
                    )?;
                    let oracle = indices
                        .iter()
                        .flat_map(|&i| expected[i].iter().copied())
                        .collect::<Vec<_>>();
                    for _ in 0..2 {
                        ensure!(
                            moe.forward_draft_rows(&x)?.to_bytes()? == oracle,
                            "wide MoE differs, slots={slots}, overlap={overlap}, rows={rows}"
                        );
                    }
                }
                let counters = (moe.hits, moe.misses, moe.read_bytes);
                for shape in [[0, H], [3, H], [2, H - 1]] {
                    ensure!(
                        moe.forward_many(&Array::zeros(&shape)?).is_err(),
                        "invalid route shape accepted"
                    );
                }
                ensure!(
                    moe.forward_many(&Array::zeros_dtype(&[1, H], Dtype::UInt32)?)
                        .is_err(),
                    "integer route input accepted"
                );
                for shape in [[0, H], [9, H], [4, H - 1]] {
                    ensure!(
                        moe.forward_draft_rows(&Array::zeros(&shape)?).is_err(),
                        "invalid draft route shape accepted"
                    );
                }
                ensure!(
                    counters == (moe.hits, moe.misses, moe.read_bytes),
                    "invalid shape changed cache counters"
                );
                moe.drain()?;
                moe.store.cache.borrow_mut().invalidate();
                let expert = moe.route(&inputs[0])?.0.to_u32()?[0] as usize;
                let original = moe.store.records[expert].data_offsets;
                moe.store.records[expert].data_offsets[0] = u64::MAX;
                let wide =
                    Array::concatenate(&[&inputs[0], &inputs[1], &inputs[0], &inputs[2]], 0)?;
                ensure!(
                    moe.forward_draft_rows(&wide).is_err(),
                    "failed source accepted"
                );
                let ids = moe.route(&inputs[0])?.0.to_u32()?;
                ensure!(
                    moe.store
                        .cache
                        .borrow_mut()
                        .reserve(&ids)?
                        .iter()
                        .all(|p| !p.1),
                    "failed read left valid reservations"
                );
                moe.store.cache.borrow_mut().invalidate();
                moe.store.records[expert].data_offsets = original;
                ensure!(
                    moe.forward(&inputs[0])?.to_bytes()? == expected[0],
                    "retry after failed read diverged"
                );
                moe.drain()?;
                if slots == 53 && readers == 4 && overlap {
                    crate::flash_profile::start(false)?;
                    let result = (|| -> Result<()> {
                        let jobs = (0..5u32).map(|i| (i, i as usize)).collect::<Vec<_>>();
                        moe.fill_many(&jobs)?;
                        ensure!(crate::array::disk_profile()?.len() == 5);
                        let before = moe.read_bytes;
                        let bank = std::mem::replace(
                            &mut moe.store.banks[0],
                            Array::zeros_dtype(&[1], Dtype::UInt16)?,
                        );
                        let rejected = moe.fill_many(&jobs);
                        moe.store.banks[0] = bank;
                        ensure!(rejected.is_err() && moe.read_bytes == before);
                        ensure!(
                            crate::array::disk_profile()?.is_empty()
                                && crate::array::disk_profile_schedule() == "static",
                            "failed pre-FFI batch retained the previous timings"
                        );
                        Ok(())
                    })();
                    let events = crate::flash_profile::finish();
                    result?;
                    let events = serde_json::to_value(events?)?;
                    let reads = events
                        .as_array()
                        .context("missing profile")?
                        .iter()
                        .filter(|e| e["name"] == "disk_read_batch")
                        .collect::<Vec<_>>();
                    ensure!(
                        reads.len() == 2
                            && reads[0]["data"]["ok"] == true
                            && reads[1]["data"]["ok"] == false
                    );
                    ensure!(
                        reads[1]["data"]["timings_job_worker_start_end_bytes_failed"]
                            == serde_json::json!([])
                    );
                    println!("T18A_FAILED_PROFILE stale_timings_rejected=true jobs=5");
                }
            }
        }
        Ok(())
    }
    #[test]
    #[ignore = "physical Apple GPU; direct disk read into evaluated shared buffers"]
    fn disk_records_fill_only_owned_ranges_and_reject_bad_sources() -> anyhow::Result<()> {
        use crate::array::{Array, Dtype};
        use std::io::Write;
        let mut file = tempfile::tempfile()?;
        file.write_all(&(0..64u8).collect::<Vec<_>>())?;
        let mut banks = vec![
            Array::zeros_dtype(&[16], Dtype::UInt8)?,
            Array::zeros_dtype(&[16], Dtype::UInt8)?,
        ];
        Array::read_record(&file, 7, &mut banks, &[(0, 3, 5), (1, 9, 4), (0, 11, 2)])?;
        let mut a = vec![0u8; 16];
        a[3..8].copy_from_slice(&[7, 8, 9, 10, 11]);
        a[11..13].copy_from_slice(&[16, 17]);
        let mut b = vec![0u8; 16];
        b[9..13].copy_from_slice(&[12, 13, 14, 15]);
        assert_eq!(banks[0].to_bytes()?, a);
        assert_eq!(banks[1].to_bytes()?, b);
        for (offset, ranges) in [
            (0, vec![(2, 0, 1)]),
            (0, vec![(0, 16, 1)]),
            (0, vec![(0, usize::MAX, 1)]),
            (63, vec![(0, 0, 2)]),
            (u64::MAX, vec![(0, 0, 1)]),
            (0, vec![(0, 0, 0)]),
            (0, vec![]),
        ] {
            assert!(Array::read_record(&file, offset, &mut banks, &ranges).is_err());
            assert_eq!(banks[0].to_bytes()?, a);
            assert_eq!(banks[1].to_bytes()?, b);
        }
        Ok(())
    }

    #[test]
    #[ignore = "physical Apple GPU; concurrent disk reads into shared buffers"]
    fn disk_batches_reject_aliases_and_validate_every_record_before_writing() -> anyhow::Result<()>
    {
        use crate::array::{Array, Dtype};
        use std::io::Write;
        let mut file = tempfile::tempfile()?;
        file.write_all(&(0..64u8).collect::<Vec<_>>())?;
        for workers in 1..=4 {
            let mut banks = vec![Array::zeros_dtype(&[16], Dtype::UInt8)?];
            Array::read_records(
                &[(&file, 8), (&file, 20)],
                &mut banks,
                &[&[(0, 1, 4), (0, 5, 2)], &[(0, 9, 3), (0, 14, 2)]],
                workers,
            )?;
            let expected = vec![0, 8, 9, 10, 11, 12, 13, 0, 0, 20, 21, 22, 0, 0, 23, 24];
            assert_eq!(banks[0].to_bytes()?, expected);
            banks.push(banks[0].clone());
            for destinations in [
                vec![vec![(0, 0, 8)], vec![(0, 7, 2)]],
                vec![vec![(0, 0, 8)], vec![(1, 7, 2)]],
                vec![vec![(0, 0, 8)], vec![(0, 16, 2)]],
                vec![vec![(0, 0, 8)], vec![(2, 0, 2)]],
                vec![vec![(0, 0, 8)], vec![(0, 8, 2), (0, 10, 2)]],
            ] {
                let views = destinations.iter().map(Vec::as_slice).collect::<Vec<_>>();
                assert!(
                    Array::read_records(&[(&file, 0), (&file, 16)], &mut banks, &views, workers)
                        .is_err()
                );
                assert_eq!(banks[0].to_bytes()?, expected);
            }
            assert!(
                Array::read_records(
                    &[(&file, 0), (&file, 64)],
                    &mut banks,
                    &[&[(0, 0, 1)], &[(0, 1, 1)]],
                    workers
                )
                .is_err()
            );
            assert_eq!(banks[0].to_bytes()?, expected);
        }
        Ok(())
    }
}

#[cfg(test)]
#[path = "ssd_moe/grouped_micro.rs"]
mod grouped_micro;

#[cfg(test)]
mod row_oracle;
