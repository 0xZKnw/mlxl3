//! Physical diagnostic runner, separate from release throughput.
use super::*;
use crate::flash_profile as profile;
use std::path::Path;
use std::{
    io::BufWriter,
    process::{Command, Stdio},
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};
fn epoch() -> Result<f64> {
    Ok(SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs_f64())
}
fn snapshot() -> Result<Value> {
    let mut child = Command::new("/usr/bin/vm_stat")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()?;
    let deadline = Instant::now() + Duration::from_secs(2);
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) => {}
            Err(error) => {
                let _ = child.kill();
                let _ = child.wait();
                return Err(error.into());
            }
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            anyhow::bail!("vm_stat deadline exceeded");
        }
        std::thread::sleep(Duration::from_millis(2));
    }
    let output = child.wait_with_output()?;
    ensure!(output.status.success(), "vm_stat failed");
    let memory = crate::array::memory_stats(false)?;
    ensure!(
        memory
            .process_lifetime_peak_bytes
            .is_some_and(|v| v <= 12_000_000_000),
        "physical footprint limit exceeded"
    );
    Ok(
        serde_json::json!({"epoch":epoch()?,"memory":memory,"vm_stat":String::from_utf8(output.stdout)?}),
    )
}
fn counts(t: &FlashNext) -> Vec<[u64; 3]> {
    t.layers
        .iter()
        .map(|l| [l.moe.hits, l.moe.misses, l.moe.read_bytes])
        .collect()
}
fn test_stage_count(target: &FlashNext, head: Option<&FlashMtpHead>) -> usize {
    fn layer_count(layer: &Layer) -> usize {
        layer.stages.len()
            + match &layer.attention {
                Attention::Gdn(gdn) => gdn.stages.len(),
                Attention::Qsa(qsa) => qsa.stages.len(),
            }
            + layer.ple.as_ref().map_or(0, |ple| ple.stages.len())
    }
    target.layers.iter().map(layer_count).sum::<usize>()
        + head.map_or(0, |head| head.stages.len() + layer_count(&head.layer))
}
fn save(p: &Path, v: &impl serde::Serialize) -> Result<()> {
    let file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(p)?;
    let mut writer = BufWriter::new(file);
    serde_json::to_writer(&mut writer, v)?;
    std::io::Write::flush(&mut writer)?;
    Ok(())
}
#[test]
#[ignore = "physical Apple GPU, full Flash checkpoint; isolated diagnostic, not release throughput"]
fn flash_detailed_profile_preserves_full_outputs_and_states() -> Result<()> {
    let directory = PathBuf::from(std::env::var("MLXL3_PROFILE_OUTPUT")?);
    let kind = std::env::var("MLXL3_PROFILE_KIND")?;
    let (mtp, dflash) = match std::env::var("MLXL3_FLASH_PROFILE_MTP")?.as_str() {
        "0" => (false, false),
        "1" => (true, false),
        "DFLASH2" => (false, true),
        _ => anyhow::bail!("invalid mode"),
    };
    let label = std::env::var("MLXL3_FLASH_PROFILE_PROMPT")?;
    let long_prompt = if label == "LONG" {
        Some(std::fs::read_to_string(std::env::var(
            "MLXL3_PROFILE_PROMPT_FILE",
        )?)?)
    } else {
        None
    };
    let prompt = match label.as_str() {
        "MAIN" => {
            "Explique en français, avec un exemple concret, comment un cache LFU évite les lectures SSD inutiles pendant l’inférence d’un modèle MoE."
        }
        "HOLD" => {
            "Écris une fonction Python merge_intervals qui fusionne les intervalles qui se chevauchent, puis explique sa complexité et donne un exemple."
        }
        "LONG" => long_prompt.as_deref().context("missing long prompt")?,
        _ => anyhow::bail!("invalid prompt"),
    };
    let (budget, phases): (usize, &[(&str, bool, bool)]) = match kind.as_str() {
        "verifier" => (
            64,
            &[
                ("sequential_oracle", false, false),
                ("warmup", false, false),
                ("control_before", false, false),
                ("trace_1", true, false),
                ("trace_2", true, false),
                ("control_after", false, false),
            ],
        ),
        "natural" | "context" => (
            128,
            &[
                ("warmup", false, false),
                ("control_before", false, false),
                ("trace_1", true, false),
                ("trace_2", true, false),
                ("trace_3", true, false),
                ("control_after", false, false),
            ],
        ),
        "fenced" => (
            33,
            &[
                ("warmup", false, false),
                ("oracle", false, false),
                ("fenced_1", true, true),
                ("fenced_2", true, true),
            ],
        ),
        "quality" => (
            17,
            &[
                ("warmup", false, false),
                ("oracle", false, false),
                ("trace", true, false),
                ("fenced", true, true),
            ],
        ),
        _ => anyhow::bail!("invalid profile kind"),
    };
    ensure!(directory.is_dir(), "output directory required");
    save(
        &directory.join("started.json"),
        &serde_json::json!({"status":"incomplete","kind":kind,"mtp":mtp,"prompt":label,"budget":budget,"epoch":epoch()?}),
    )?;
    let path = PathBuf::from(std::env::var("MLXL3_FLASH_MODEL")?);
    let load_start = Instant::now();
    let checkpoint = crate::checkpoint::inspect(&path)?;
    let tokenizer = crate::tokenizer::ChatTokenizer::load(&path)?;
    let prompt_ids = tokenizer.encode(&tokenizer.render(&[crate::tokenizer::Message {
        role: "user".into(),
        content: prompt.into(),
    }])?)?;
    let mut target = FlashNext::from_checkpoint(&checkpoint)?;
    let mut head = if mtp {
        Some(FlashMtpHead::load(&checkpoint, &target)?)
    } else {
        None
    };
    let load_seconds = load_start.elapsed().as_secs_f64();
    ensure!(!prompt_ids.is_empty() && prompt_ids.len() + budget <= target.context_limit() as usize);
    let mut expected = None;
    let mut expected_head = None;
    let mut expected_draft = None;
    let mut summaries = Vec::new();
    for &(phase, traced, fenced) in phases {
        let natural = matches!(kind.as_str(), "natural" | "context");
        let _stage_policy = natural.then(|| profile::StageRetention::new(phase == "warmup"));
        let test_stage_retention = profile::retain_test_stages();
        target.reset();
        let use_dflash = dflash && phase != "sequential_oracle";
        let use_mtp = mtp && phase != "sequential_oracle";
        if use_dflash {
            let draft = PathBuf::from(std::env::var("MLXL3_FLASH_DRAFT")?);
            target.configure_dflash2(Some(&draft), 1)?;
        }
        if let Some(h) = &mut head {
            h.reset();
        }
        let before = snapshot()?;
        let before_counts = counts(&target);
        crate::array::disk_profile_enable(traced);
        if traced {
            profile::start(fenced)?;
        }
        let prefill_epoch = epoch()?;
        let start = Instant::now();
        let mut logits = None;
        {
            let _span = profile::span("prefill");
            if use_dflash {
                logits = Some(
                    target
                        .prefill_dflash2(&prompt_ids, &std::sync::atomic::AtomicBool::new(false))?,
                );
            } else if !use_mtp {
                for chunk in prompt_ids.chunks(crate::flash_support::PREFILL_CHUNK) {
                    let event = profile::span("prefill_chunk");
                    if let Some(event) = &event {
                        event.data(serde_json::json!({"tokens":chunk.len()}));
                    }
                    logits = Some(target.forward_tokens(chunk)?);
                }
            } else {
                logits = Some(target.prefill_mtp(
                    head.as_mut().context("missing MTP head")?,
                    &prompt_ids,
                    &std::sync::atomic::AtomicBool::new(false),
                )?);
            }
        }
        let mut anchor = logits.context("empty prefill")?.chat_greedy_ids()?[0];
        let prefill_seconds = start.elapsed().as_secs_f64();
        let prefill_events = if traced {
            profile::finish()?
        } else {
            Vec::new()
        };
        let prefill_counts = counts(&target);
        let prefill_snapshot = snapshot()?;
        let mut output = vec![anchor];
        let mut session = FlashMtpSession::default();
        let mut steps = Vec::with_capacity(budget - 1);
        if traced {
            profile::start(fenced)?;
        }
        let decode_epoch = epoch()?;
        let start = Instant::now();
        {
            let _decode = profile::span("decode");
            for step in 1..budget {
                let mark = Instant::now();
                let step_span = profile::span("output_step");
                let old = (session.proposed, session.accepted, session.blocks);
                let old_dflash = target.dflash2_stats();
                let old_profile = target.dflash2_profile();
                let old_offset = target.offset();
                anchor = if use_dflash {
                    target.advance_dflash2(anchor, budget - step)?
                } else if use_mtp {
                    let h = head.as_mut().context("missing profile MTP head")?;
                    session.advance(
                        &mut target,
                        h,
                        anchor,
                        prompt_ids.len() + budget - 1,
                        budget - step,
                    )?
                } else {
                    target.forward(anchor)?.chat_greedy_ids()?[0]
                };
                let seconds = mark.elapsed().as_secs_f64();
                let item = serde_json::json!({"step":step,"token":anchor,"offset":target.offset(),"seconds":seconds,"elapsed_seconds":start.elapsed().as_secs_f64(),"mtp_proposed":session.proposed-old.0,"mtp_accepted":session.accepted-old.1,"mtp_blocks":session.blocks-old.2});
                let mut item = item;
                item["target_rows"] = serde_json::json!(target.offset() - old_offset);
                if use_dflash {
                    let before = old_dflash.context("missing DFlash counters before step")?;
                    let after = target
                        .dflash2_stats()
                        .context("missing DFlash counters after step")?;
                    let before_profile =
                        old_profile.context("missing DFlash profile before step")?;
                    let after_profile = target
                        .dflash2_profile()
                        .context("missing DFlash profile after step")?;
                    item["dflash"] = serde_json::json!({
                        "proposed":after.0.checked_sub(before.0).context("DFlash proposed reversed")?,
                        "accepted":after.1.checked_sub(before.1).context("DFlash accepted reversed")?,
                        "blocks":after.2.checked_sub(before.2).context("DFlash blocks reversed")?,
                        "verified_rows":after_profile.verified_rows.checked_sub(before_profile.verified_rows).context("DFlash verify counter reversed")?,
                        "drafted_rows":after_profile.drafted_rows.checked_sub(before_profile.drafted_rows).context("DFlash draft counter reversed")?,
                        "expert_demand_bytes":after_profile.expert_demand_bytes.checked_sub(before_profile.expert_demand_bytes).context("DFlash byte counter reversed")?,
                    });
                }
                if let Some(s) = &step_span {
                    s.data(item.clone());
                }
                steps.push(item);
                output.push(anchor);
            }
            target.drain()?;
        }
        let decode_seconds = start.elapsed().as_secs_f64();
        let decode_events = if traced {
            profile::finish()?
        } else {
            Vec::new()
        };
        crate::array::disk_profile_enable(false);
        let after = snapshot()?;
        let final_counts = counts(&target);
        let test_stage_count = test_stage_count(&target, head.as_ref());
        if natural {
            ensure!(
                test_stage_retention == (phase == "warmup")
                    && ((test_stage_retention && test_stage_count > 0)
                        || (!test_stage_retention && test_stage_count == 0)),
                "unexpected retained diagnostic stages: {phase}"
            );
        }
        ensure!(
            output.len() == budget
                && session.pending.is_empty()
                && target.offset() as usize == prompt_ids.len() + budget - 1
        );
        if use_mtp && let Some(h) = &head {
            ensure!(h.offset() == target.offset() - 1);
        }
        let logits = target.logits(
            target
                .last_hidden
                .as_ref()
                .context("missing final hidden")?,
        )?;
        let host = logits.to_f32()?;
        ensure!(
            logits.shape() == [1, 248320]
                && host.len() == 248320
                && host.iter().all(|v| v.is_finite())
        );
        let state = super::tests::state_bytes(&target)?;
        ensure!(state.len() > 100 && state.iter().all(|s| !s.is_empty()));
        let head_state = if use_mtp && let Some(h) = &head {
            let Attention::Qsa(q) = &h.layer.attention else {
                anyhow::bail!("invalid head")
            };
            super::tests::qsa_bytes(q)?
        } else {
            Vec::new()
        };
        if use_dflash {
            let state = target.dflash2_state_for_profile()?;
            ensure!(state.len() == 11 && state.iter().all(|value| !value.is_empty()));
            if let Some(expected) = &expected_draft {
                ensure!(
                    &state == expected,
                    "draft KV/profile parity failed: {phase}"
                );
            } else {
                expected_draft = Some(state);
            }
        }
        let parity = (output.clone(), logits.to_bytes()?, state);
        if let Some(e) = &expected {
            ensure!(&parity == e, "full profile parity failed: {phase}");
        } else {
            expected = Some(parity);
        }
        if use_mtp {
            if let Some(expected) = &expected_head {
                ensure!(
                    &head_state == expected,
                    "MTP head profile parity failed: {phase}"
                );
            } else {
                expected_head = Some(head_state);
            }
        }
        ensure!(!traced || (!prefill_events.is_empty() && !decode_events.is_empty()));
        let hash = output
            .iter()
            .flat_map(|t| t.to_le_bytes())
            .fold(0xcbf29ce484222325u64, |h, b| {
                (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
            });
        let summary = serde_json::json!({"phase":phase,"traced":traced,"fenced":fenced,"mtp":mtp,"prompt":label,"prompt_ids":prompt_ids,"tokens":output,"token_hash":format!("{hash:016x}"),"text":tokenizer.decode(&output)?,"prefill_epoch":prefill_epoch,"decode_epoch":decode_epoch,"prefill_seconds":prefill_seconds,"decode_seconds":decode_seconds,"diagnostic_tps":(budget-1)as f64/decode_seconds,"before_counts":before_counts,"prefill_counts":prefill_counts,"after_counts":final_counts,"before":before,"prefill_boundary":prefill_snapshot,"after":after,"steps":steps,"mtp_proposed":session.proposed,"mtp_accepted":session.accepted,"mtp_blocks":session.blocks,"mtp_head_verify_repair_total_seconds":session.profile_seconds,"logit_count":host.len(),"full_logits_target_head_states_byte_exact":true,"prefill_event_count":prefill_events.len(),"decode_event_count":decode_events.len()});
        let mut summary = summary;
        summary["test_stage_retention"] = serde_json::json!(test_stage_retention);
        summary["test_stage_count"] = serde_json::json!(test_stage_count);
        summary["dflash"] = Value::Bool(use_dflash);
        summary["full_draft_states_byte_exact"] = if use_dflash {
            Value::Bool(true)
        } else {
            Value::Null
        };
        summary["dflash_stats"] = serde_json::json!(target.dflash2_stats());
        summary["dflash_profile"] = serde_json::json!(target.dflash2_profile());
        save(&directory.join(format!("{phase}-summary.json")), &summary)?;
        if traced {
            save(
                &directory.join(format!("{phase}-prefill.json")),
                &prefill_events,
            )?;
            save(
                &directory.join(format!("{phase}-decode.json")),
                &decode_events,
            )?;
        }
        println!(
            "FLASH_DETAILED_PHASE {}",
            serde_json::json!({"phase":phase,"diagnostic_tps":summary["diagnostic_tps"],"decode_seconds":decode_seconds,"events":prefill_events.len()+decode_events.len(),"epoch":epoch()?})
        );
        summaries.push(summary);
    }
    let final_snapshot = snapshot()?;
    save(&directory.join("final-snapshot.json"), &final_snapshot)?;
    save(
        &directory.join("complete.json"),
        &serde_json::json!({"status":"complete_diagnostic_internal_full_parity_external_golden_pending","profile_schema_version":2,"load_seconds":load_seconds,"kind":kind,"mtp":mtp,"dflash":dflash,"prompt":label,"summaries":summaries,"limits":"nested wall intervals overlap; natural route readback includes upstream work; fenced times include dispatch and waits, not exclusive GPU; VM global; serialization and snapshots outside phase clocks"}),
    )?;
    Ok(())
}
#[cfg(kani)]
#[kani::proof]
fn actual_detailed_profile_path() {
    flash_detailed_profile_preserves_full_outputs_and_states().unwrap();
}

#[test]
#[ignore = "physical Apple GPU, records or checks Flash migration fixtures in a disposable directory"]
fn ar_migration_prompt_fixtures() -> Result<()> {
    use std::io::Write;

    let directory = PathBuf::from(std::env::var("MLXL3_AR_FIXTURE_DIR")?);
    let record = match std::env::var("MLXL3_AR_FIXTURE_MODE")?.as_str() {
        "record" => true,
        "check" => false,
        _ => anyhow::bail!("expected record or check"),
    };
    let marker = directory.join("complete");
    if record {
        std::fs::create_dir(&directory)?;
    } else {
        ensure!(
            std::fs::read(&marker)? == b"flash-ar-v1\n",
            "incomplete AR fixtures"
        );
    }
    let path = PathBuf::from(std::env::var("MLXL3_FLASH_MODEL")?);
    let tokenizer = crate::tokenizer::ChatTokenizer::load(&path)?;
    let mut target = FlashNext::from_checkpoint(&crate::checkpoint::inspect(&path)?)?;
    for (label, expected_len, prompt) in [
        (
            "MAIN",
            87,
            "Explique en français, avec un exemple concret, comment un cache LFU évite les lectures SSD inutiles pendant l’inférence d’un modèle MoE.",
        ),
        (
            "HOLD",
            82,
            "Écris une fonction Python merge_intervals qui fusionne les intervalles qui se chevauchent, puis explique sa complexité et donne un exemple.",
        ),
    ] {
        target.reset();
        let ids = tokenizer.encode(&tokenizer.render(&[crate::tokenizer::Message {
            role: "user".into(),
            content: prompt.into(),
        }])?)?;
        ensure!(ids.len() == expected_len);
        let mut logits = target.forward_tokens(&ids)?;
        for step in 0..=1 {
            ensure!(logits.shape().iter().product::<i32>() == 248320);
            let mut values = super::tests::state_bytes(&target)?;
            ensure!(values.len() == 136 && target.layers.len() == 48);
            values.push(super::tests::tensor_state_bytes(&logits)?);
            for layer in &target.layers {
                let routes = &layer.moe.route_ids;
                ensure!(routes.len() == 10 && routes.iter().all(|&v| v < 512));
                values.push(routes.iter().flat_map(|v| v.to_le_bytes()).collect());
            }
            for (i, value) in values.into_iter().enumerate() {
                let path = directory.join(format!("{label}-{step}-{i}.bin"));
                if record {
                    File::create_new(&path)?.write_all(&value)?;
                } else {
                    ensure!(
                        value == std::fs::read(&path)?,
                        "AR fixture mismatch at {label}/{step}/{i}"
                    );
                }
            }
            if step == 0 {
                let next = logits.chat_greedy_ids()?;
                ensure!(next.len() == 1);
                logits = target.forward(next[0])?;
            }
        }
    }
    if record {
        File::create_new(marker)?.write_all(b"flash-ar-v1\n")?;
    }
    println!("AR_FIXTURES prompts=2 checkpoints=4 states=136 logits=248320 route_layers=48");
    Ok(())
}

#[test]
#[ignore = "physical Apple GPU; native Flash prepare layouts, lifetime and FP16 rounding"]
fn native_prepare_matches_canonical_hadamard() -> Result<()> {
    let before = array::flash_program_cache(true)?;
    ensure!(before.entries == 0);
    let mut pending = Vec::new();
    for width in [640, 2560] {
        for rows in [1, 3, 10, 20] {
            let data: Vec<_> = (0..rows * width)
                .map(|i| ((i % 113) - 56) as f32 * 0.01953125 + 0.000031)
                .collect();
            let scales = Array::from_f32(&data, &[width, rows])?
                .astype(Dtype::Float16)?
                .transpose(&[1, 0])?;
            for dtype in [Dtype::Float16, Dtype::Float32] {
                let x = Array::from_f32(&data, &[rows, width])?.astype(dtype)?;
                let broadcast = x.slice(0, 0, 1)?.broadcast_to(&[rows, width])?;
                for input in [&x, &broadcast] {
                    let expected = input
                        .astype(Dtype::Float16)?
                        .mul(&scales)?
                        .reshape(&[-1, 128])?
                        .hadamard_transform(Some(1.0 / 128f32.sqrt()))?
                        .reshape(&[-1])?;
                    pending.push((input.flash_prepare128(&scales)?, expected));
                }
            }
        }
    }
    ensure!(pending.len() == 32);
    for (candidate, expected) in pending.into_iter().rev() {
        ensure!(candidate.shape() == expected.shape() && candidate.dtype() == Dtype::Float16);
        let reference = expected.to_f32()?;
        ensure!(
            reference.len() >= 640
                && reference.iter().all(|v| v.is_finite())
                && reference.iter().any(|&v| v != 0.0)
        );
        ensure!(
            candidate.to_bytes()? == expected.to_bytes()?,
            "native EXL3 preparation diverged"
        );
    }
    for shape in [[21, 640], [1, 128], [0, 640]] {
        let x = Array::zeros_dtype(&shape, Dtype::Float16)?;
        ensure!(x.flash_prepare128(&x).is_err());
    }
    let bad = Array::zeros_dtype(&[1, 640], Dtype::UInt32)?;
    ensure!(bad.flash_prepare128(&bad).is_err());
    let used = array::flash_program_cache(false)?;
    ensure!(
        used.entries == 1
            && used.creations == before.creations + 1
            && used.hits == before.hits + 31
    );
    ensure!(used.retained_host_object_bytes > 0 && used.cached_tensor_bytes == 0);
    let empty = array::flash_program_cache(true)?;
    ensure!(
        empty.entries == 0
            && empty.evictions == used.evictions + 1
            && empty.retained_host_object_bytes == 0
    );
    let x = Array::from_f16_bits(&vec![0x3c00; 640], &[1, 640])?;
    let late = x.flash_prepare128(&x)?;
    array::flash_program_cache(true)?;
    let rebuilt = x.flash_prepare128(&x)?;
    ensure!(late.to_bytes()? == rebuilt.to_bytes()? && late.to_f32()?.iter().any(|x| *x != 0.));
    let end = array::flash_program_cache(false)?;
    ensure!(
        end.creations == empty.creations + 2
            && end.entries == 1
            && end.evictions == empty.evictions + 1
    );
    println!("FLASH_PROGRAM_CACHE {end:?}");
    println!("NATIVE_PREPARE real_layouts=32 rejected=4");
    Ok(())
}
