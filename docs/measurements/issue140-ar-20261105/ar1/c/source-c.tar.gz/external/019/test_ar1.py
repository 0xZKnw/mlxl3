"""CPU checks for the added selection/counter contract; no model launched."""

import copy
import runpy
import unittest
from pathlib import Path

R = runpy.run_path(str(Path(__file__).with_name("ar1.py")))


class AR1(unittest.TestCase):
    def test_retained_default_and_exact_override(self):
        for on in (0, 1):
            env = R["environment"](on)
            self.assertEqual(env[R["FLAG"]], str(on))
            self.assertNotIn("MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE", env)
            self.assertEqual(env["MLXL3_NATIVE_ROUTED_NT2_GU"], "1")
        with self.assertRaises(AssertionError):
            R["environment"](2)

    def test_real_counter_layout_detects_missing_work(self):
        good = [2, 2, 2, 2, 2, 2, 12, 16]
        self.assertEqual(R["checked_stage_delta"]([0] * 8, good), good)
        for index in range(8):
            bad = copy.copy(good)
            bad[index] = 0
            with self.assertRaises(AssertionError):
                R["checked_stage_delta"]([0] * 8, bad)
        with self.assertRaises(AssertionError):
            R["checked_stage_delta"](good, [0] * 8)
        with self.assertRaises(AssertionError):
            R["checked_stage_delta"]([], [])

    def test_cached_row_can_have_zero_work_but_not_partial_counters(self):
        self.assertEqual(R["checked_stage_delta"]([0] * 8, [0] * 8, allow_zero=True), [0] * 8)
        with self.assertRaises(AssertionError):
            R["checked_stage_delta"]([0] * 8, [0, 1, 0, 0, 0, 0, 0, 0], allow_zero=True)

    def test_one_expert_does_not_qualify_as_vectorization(self):
        with self.assertRaises(AssertionError):
            R["checked_stage_delta"]([0] * 8, [1, 1, 1, 1, 1, 1, 1, 8])
        with self.assertRaises(AssertionError):
            R["checked_stage_delta"]([0] * 8, [1, 1, 1, 1, 1, 1, 11, 8])


if __name__ == "__main__":
    unittest.main()
