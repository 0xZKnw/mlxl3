"""Check the controlled original/bulk matrix without starting a model."""

import json
import runpy
import unittest
from pathlib import Path

R = runpy.run_path(str(Path(__file__).with_name("b.py")))


class Bulk(unittest.TestCase):
    def test_four_exact_arms_keep_original_reproducible(self):
        self.assertEqual(
            R["ARMS"],
            (
                ("control-start", (0, 0)),
                ("original", (1, 0)),
                ("batched", (1, 1)),
                ("control-end", (0, 0)),
            ),
        )
        for _, (ready, bulk) in R["ARMS"]:
            env = R["environment"]((ready, bulk))
            self.assertEqual((env[R["FLAG"]], env[R["BATCH"]]), (str(ready), str(bulk)))
            self.assertNotIn("MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE", env)
        self.assertEqual(R["environment"]()[R["BATCH"]], "1")
        for bad in [True, 0, 2, (1,), (1, 2), (True, 1)]:
            with self.assertRaises(AssertionError):
                R["environment"](bad)

    def test_component_requires_real_bulk_calls(self):
        evidence = {
            k: True
            for k in [
                "parity",
                "bulk_bindings_selected",
                "invalid_bulk_prefix_unsubmitted",
                "compiled_ready_stages",
                "independent_stock",
                "all_seven_intermediates",
                "poisoned_prefixes",
                "f16_f32_negative_strides",
                "permuted_duplicate_experts",
                "n1_fallback",
                "overlap_fallback",
                "input_alias_fallback",
                "wrong_record_mutant_detected",
                "stage_bit_mutant_detected",
                "late_failure_unsubmitted",
                "invalid_destination_unsubmitted",
            ]
        }
        evidence.update(
            cases=14,
            cohort_sizes=[1, 2, 10],
            valid_counts=[12, 12, 12, 12, 12, 12, 72, 96],
            valid_bulk_counts=[60, 1080, 60],
            compared_stage_bytes=2119680,
            finite_output_half_words=189440,
        )

        def log(v):
            return (
                "dyld[1]: /System/Library/Frameworks/Metal.framework/Metal\nrunning 1 test\nAR35_READY_STAGES "
                + json.dumps(v)
                + "\ntest result: ok. 1 passed; 0 failed; 0 ignored;\n"
            )

        self.assertEqual(R["check_marker"](log(evidence), R["SPECS"][0]), evidence)
        for key, value in [
            ("valid_bulk_counts", [0, 0, 0]),
            ("bulk_bindings_selected", False),
            ("invalid_bulk_prefix_unsubmitted", False),
            ("cases", 0),
        ]:
            bad = dict(evidence)
            bad[key] = value
            with self.assertRaises(AssertionError):
                R["check_marker"](log(bad), R["SPECS"][0])


if __name__ == "__main__":
    unittest.main()
