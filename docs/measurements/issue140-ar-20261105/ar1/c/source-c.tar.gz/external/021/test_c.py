"""Check the single controlled bulk/split comparison; no model process."""

import json
import runpy
import unittest
from pathlib import Path

R = runpy.run_path(str(Path(__file__).with_name("c.py")))


class Split(unittest.TestCase):
    def test_exact_four_arms_keep_bulk_original(self):
        self.assertEqual(
            R["ARMS"],
            (
                ("control-start", (0, 0, 0)),
                ("bulk", (1, 1, 0)),
                ("split", (1, 1, 1)),
                ("control-end", (0, 0, 0)),
            ),
        )
        for _, v in R["ARMS"]:
            e = R["environment"](v)
            self.assertEqual(
                tuple(e[k] for k in [R["FLAG"], R["BATCH"], R["SPLIT"]]), tuple(map(str, v))
            )
            self.assertNotIn("MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE", e)
        for bad in [True, 2, (1, 1), (1, 1, 2), (1, False, 1)]:
            with self.assertRaises(AssertionError):
                R["environment"](bad)

    def test_component_requires_distinct_actual_pipelines(self):
        e = {
            k: True
            for k in [
                "parity",
                "split_finish_selected",
                "distinct_split_psos",
                "bulk_bindings_selected",
                "invalid_bulk_prefix_unsubmitted",
                "compiled_ready_stages",
                "independent_stock",
                "all_seven_intermediates",
                "poisoned_prefixes",
                "f16_f32_negative_strides",
                "permuted_duplicate_experts",
                "n1_fallback",
                "overlap_fallback",
                "input_alias_fallback",
                "wrong_record_mutant_detected",
                "stage_bit_mutant_detected",
                "late_failure_unsubmitted",
                "invalid_destination_unsubmitted",
            ]
        }
        e.update(
            cases=14,
            cohort_sizes=[1, 2, 10],
            valid_counts=[12, 12, 12, 12, 12, 12, 72, 96],
            valid_bulk_counts=[60, 1080, 60],
            valid_finish_counts=[0, 24, 12],
            compared_stage_bytes=2119680,
            finite_output_half_words=189440,
        )

        def log(v):
            return (
                "dyld[1]: /System/Library/Frameworks/Metal.framework/Metal\nrunning 1 test\nAR35_READY_STAGES "
                + json.dumps(v)
                + "\ntest result: ok. 1 passed; 0 failed; 0 ignored;\n"
            )

        self.assertEqual(R["check_marker"](log(e), R["SPECS"][0]), e)
        for key, val in [
            ("split_finish_selected", False),
            ("distinct_split_psos", False),
            ("valid_finish_counts", [36, 0, 0]),
        ]:
            bad = dict(e)
            bad[key] = val
            with self.assertRaises(AssertionError):
                R["check_marker"](log(bad), R["SPECS"][0])


if __name__ == "__main__":
    unittest.main()
