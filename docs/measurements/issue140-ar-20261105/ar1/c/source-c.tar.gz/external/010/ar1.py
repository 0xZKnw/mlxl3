"""AR1 uses the existing process supervisor and golden checks with T05 retained."""

import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "docs/measurements/issue140-ar-20261105/ar1"
R = runpy.run_path(str(ROOT / "build/issue140/run.py"))
FLAG = "MLXL3_NATIVE_READY_STAGES"
BASE_ENV = R["environment"]
BASE_MARKER = R["check_marker"]
SPECS = (
    (
        "ready",
        "gpu::projection::ready_stages::tests::physical_ar35_ready_stages_preserve_canonical_intermediates_and_boundaries",
        "AR35_READY_STAGES",
    ),
    next(spec for spec in R["SPECS"] if spec[0] == "model"),
)


def environment(enabled=1):
    assert type(enabled) is int and enabled in (0, 1)
    env = BASE_ENV(enabled)
    env.pop("MLXL3_NATIVE_DEVICE_RESIDENT_ROUTE", None)
    env[FLAG] = str(enabled)
    return env


def checked_stage_delta(before, after, allow_zero=False):
    for row in (before, after):
        assert type(row) is list and len(row) == 8
        assert all(type(v) is int and v >= 0 for v in row)
    delta = [b - a for a, b in zip(before, after, strict=True)]
    assert all(v >= 0 for v in delta)
    cohorts = delta[0]
    if allow_zero and cohorts == 0:
        assert delta == [0] * 8
        return delta
    assert cohorts > 0 and delta[1:6] == [cohorts] * 5
    assert 2 * cohorts <= delta[6] <= 10 * cohorts
    assert delta[7] == 8 * cohorts
    return delta


def check_marker(text, spec):
    if spec[0] == "model":
        evidence = BASE_MARKER(text, spec)
        for row in evidence["actual_paths"]:
            assert row["before"]["ready_stages_enabled"] is True
            assert row["after"]["ready_stages_enabled"] is True
            checked_stage_delta(
                row["before"]["ready_stage_counts"],
                row["after"]["ready_stage_counts"],
                allow_zero=True,
            )
        checked_stage_delta([0] * 8, evidence["ready_initial_delta"])
        checked_stage_delta([0] * 8, evidence["ready_stage_counts"])
        return evidence
    R["D"]["test_log"](text)
    evidence = R["D"]["marker"](text, spec[2])
    assert evidence["parity"] is True
    R["D"]["OLD"]["exact_fields"](
        evidence,
        {
            "compiled_ready_stages": True,
            "cases": 14,
            "cohort_sizes": [1, 2, 10],
            "valid_counts": [12, 12, 12, 12, 12, 12, 72, 96],
            "compared_stage_bytes": 2119680,
            "finite_output_half_words": 189440,
            "independent_stock": True,
            "all_seven_intermediates": True,
            "poisoned_prefixes": True,
            "f16_f32_negative_strides": True,
            "permuted_duplicate_experts": True,
            "n1_fallback": True,
            "overlap_fallback": True,
            "input_alias_fallback": True,
            "wrong_record_mutant_detected": True,
            "stage_bit_mutant_detected": True,
            "late_failure_unsubmitted": True,
            "invalid_destination_unsubmitted": True,
        },
    )
    checked_stage_delta([0] * 8, evidence["valid_counts"])
    return evidence


def journal(message):
    with (ROOT / "opti.md").open("a") as stream:
        stream.write("\nAR35 AR1 " + message + "\n")


def main():
    R["main"].__globals__.update(
        __file__=__file__,
        HERE=HERE,
        SPECS=SPECS,
        NEW=(FLAG,),
        ARMS=(("control-start", 0), ("ready-stages", 1), ("control-end", 0)),
        environment=environment,
        check_marker=check_marker,
        journal=journal,
    )
    R["main"]()


if __name__ == "__main__":
    main()
