"""Actual shipped default API: JSON/SSE finish and usage; opt-in cancellation is checked separately."""
import hashlib,http.client,json,os,signal,sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from native_json_process import JsonProcess
r=Path.cwd();binary=r/'dist/MLXL3 Desktop.app/Contents/Resources/runtime/mlxl3';out=r/'build/audit-api-lfm/physical/api-final-default';out.mkdir(exist_ok=False)
report={'status':'running','parity':False,'checks':[],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scope':'default selection HTTP JSON/SSE one-token finish reason and usage; no cancellation witness or numeric proof'}
def save():
 p=out/'report.tmp';p.write_text(json.dumps(report,indent=2));p.replace(out/'report.json')
start=time.monotonic();deadline=start+90;process=None
try:
 save();env={k:v for k,v in os.environ.items() if not k.startswith(('MLXL3_','DYLD_'))};env['MLXL3_HOME']=str(out/'home')
 with (out/'stderr.log').open('w') as stderr:
  process=JsonProcess([str(binary),'serve','/Users/justin/Documents/mix-stq1_0/models/LFM2.5-24B-A2B-EXL3-4bpw-v2','--host','127.0.0.1','--port','0','--api-key','mlxl3-release-fixture','--context-length','4096'],env=env,stderr=stderr)
  ready=process.receive(min(deadline,time.monotonic()+45));assert ready.get('type')=='ready' and type(ready.get('port')) is int and ready['port']>0;report['checks'].append('actual server ready')
  for stream in (False,True):
   connection=http.client.HTTPConnection('127.0.0.1',ready['port'],timeout=min(30,deadline-time.monotonic()))
   try:
    body={'model':'/Users/justin/Documents/mix-stq1_0/models/LFM2.5-24B-A2B-EXL3-4bpw-v2','messages':[{'role':'user','content':'Écris le mot bonjour.'}],'max_tokens':1,'temperature':0,'top_k':1,'repetition_penalty':1,'stream':stream,'stream_options':{'include_usage':True}}
    connection.request('POST','/v1/chat/completions',json.dumps(body),headers={'Authorization':'Bearer mlxl3-release-fixture','Content-Type':'application/json'})
    response=connection.getresponse();data=response.read(1024*1024+1);assert response.status==200 and len(data)<=1024*1024 and time.monotonic()<deadline
    if stream:
     assert b'data: [DONE]' in data
     events=[json.loads(s[5:]) for s in data.splitlines() if s.startswith(b'data:') and s[5:].strip()!=b'[DONE]'];assert events
     reasons=[c['finish_reason'] for e in events for c in e.get('choices',[]) if c.get('finish_reason') is not None];assert reasons==['length']
     usage=[e['usage'] for e in events if isinstance(e.get('usage'),dict)];assert len(usage)==1
     item=usage[0]
    else:
     result=json.loads(data);assert result['choices'][0]['finish_reason']=='length';item=result['usage']
    assert type(item['completion_tokens']) is int and item['completion_tokens']==1 and type(item['prompt_tokens']) is int and item['prompt_tokens']>0
    report['checks'].append(('SSE' if stream else 'JSON')+' length, usage1 and bounded response');save()
   finally:connection.close()
  process.process.send_signal(signal.SIGTERM);assert process.process.wait(timeout=15)==0;report['checks'].append('SIGTERM joined exit0');process.close()
 report.update(status='complete',parity=True,seconds=time.monotonic()-start)
except BaseException as error:
 report.update(status='failed',parity=False,error={'type':type(error).__name__,'message':str(error)});raise
finally:
 if process is not None:process.close()
 save()
print(json.dumps(report))
