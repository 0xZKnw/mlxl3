"""Supervised physical qualification. Self-checks use disposable CPU children only."""

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BINARY = ROOT / "build/audit-api-lfm/kv-integration/frozen/lfm-02-tests"
EXPECTED_SHA = "ca59596953050c8a8318ff0c4d03604de2b970cc4fd46e761dff7931d0b55961"
MODEL = Path("/Users/justin/Documents/mix-stq1_0/models/LFM2.5-24B-A2B-EXL3-4bpw-v2")
TESTS = {
    "k03": "lfm2::prefill_tests::lfm_moe_microblocks_match_serial_logits_routes_states",
    "passive": "lfm2::prefill_tests::lfm_moe_route_capture_is_passive",
    "k04": "lfm2::prefill_tests::lfm_capacity_cache_matches_baseline_logits_states",
}


def atomic(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def records(text):
    result = []
    for line in text.splitlines():
        begin = line.find("{")
        if begin >= 0:
            result.append(
                json.loads(
                    line[begin:],
                    parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
                )
            )
    return result


def valid_record(record: dict, case: tuple[str, int, int, int]) -> bool:
    """post: not _ or (record.get("status") == "complete" and record.get("parity") is True)"""
    if (
        not isinstance(record, dict)
        or record.get("status") != "complete"
        or record.get("parity") is not True
    ):
        return False
    kind, length, prefix, mode = case
    if record.get("tokens") != length or record.get("states") != 50:
        return False
    if kind == "passive":
        return all(
            record.get(key) == value
            for key, value in {
                "captured_calls": 4864,
                "route_rows": 4864,
                "candidate_route_rows": 4864,
                "candidate_grouped_moe_calls": 608,
            }.items()
        )
    if (
        record.get("prefix") != prefix
        or record.get("terminal_logits") != 128000
        or record.get("forced_decode_steps") != 17
    ):
        return False
    if kind == "k03":
        stats = record.get("stats")
        return (
            isinstance(stats, dict)
            and record.get("route_rows") == length * 38
            and all(
                stats.get(key) == value
                for key, value in {
                    "tokens": length,
                    "blocks": (length + 7) // 8,
                    "max_block": min(length, 8),
                    "router_rows": length * 38,
                    "grouped_moe_calls": (length // 8 + (length % 8 > 1)) * 38,
                }.items()
            )
        )
    witness = record.get("storage_witness")
    if not isinstance(witness, dict):
        return False
    counts = [
        witness.get(key)
        for key in (
            "same_capacity_reused_buffers",
            "same_capacity_copied_buffers",
            "growth_buffers",
        )
    ]
    return (
        record.get("prefill_mode") == ("moe_microblocks" if mode else "canonical_m1")
        and record.get("instances") == 1
        and record.get("kv_off_then_on") is True
        and record.get("mode_switch_reset") is True
        and all(type(value) is int and value >= 0 for value in counts)
        and sum(counts) == 340
    )


def joined_command(command, env, timeout, log_path):
    started = time.monotonic()
    process = None
    result = {"status": "failed", "command": command, "joined": False}
    try:
        with log_path.open("wb") as log:
            process = subprocess.Popen(
                command, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True
            )
            result["pid"] = process.pid
            try:
                process.wait(timeout=timeout)
                result["status"] = "complete" if process.returncode == 0 else "failed"
            except subprocess.TimeoutExpired:
                result["status"] = "timeout"
    except (OSError, KeyboardInterrupt, SystemExit) as error:
        result["error"] = f"{type(error).__name__}: {error}"
        if isinstance(error, (KeyboardInterrupt, SystemExit)):
            result["status"] = "interrupted"
    finally:
        if process is not None:
            if process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=2)
            result["returncode"] = process.returncode
            result["joined"] = process.poll() is not None
        result["seconds"] = time.monotonic() - started
        result["log"] = str(log_path)
        result["log_sha256"] = hashlib.sha256(log_path.read_bytes()).hexdigest()
    return result


def self_test():
    case = ("k04", 24, 0, 0)
    record = {
        "status": "complete",
        "parity": True,
        "tokens": 24,
        "prefix": 0,
        "states": 50,
        "terminal_logits": 128000,
        "forced_decode_steps": 17,
        "instances": 1,
        "kv_off_then_on": True,
        "mode_switch_reset": True,
        "prefill_mode": "canonical_m1",
        "storage_witness": {
            "same_capacity_reused_buffers": 340,
            "same_capacity_copied_buffers": 0,
            "growth_buffers": 0,
        },
    }
    assert valid_record(record, case)
    for key, bad in [
        ("parity", False),
        ("status", "running"),
        ("tokens", 0),
        ("states", 0),
        ("terminal_logits", 0),
        ("forced_decode_steps", 16),
        ("prefix", 17),
        ("instances", 2),
        ("kv_off_then_on", False),
        ("mode_switch_reset", False),
        ("prefill_mode", "moe_microblocks"),
        ("storage_witness", {}),
        (
            "storage_witness",
            {
                "same_capacity_reused_buffers": True,
                "same_capacity_copied_buffers": 339,
                "growth_buffers": 0,
            },
        ),
    ]:
        assert not valid_record(dict(record, **{key: bad}), case), key
    assert records("test ... " + json.dumps(record) + "\nok\n") == [record]
    for bad in ['{"parity":NaN}', '{"parity":true', "{}\n{}"]:
        try:
            value = records(bad)
            assert len(value) != 1 or not valid_record(value[0], case)
        except ValueError:
            pass
    with tempfile.TemporaryDirectory() as scratch:
        directory = Path(scratch)
        for code, expected in [
            ("print('ok')", "complete"),
            ("raise SystemExit(1)", "failed"),
            ("import time; time.sleep(10)", "timeout"),
        ]:
            outcome = joined_command(
                [sys.executable, "-c", code], os.environ.copy(), 2, directory / "child.log"
            )
            assert outcome["status"] == expected and outcome["joined"], outcome
    print(
        "self-check: 13 rejected record mutations, strict JSON, three supervised disposable child outcomes passed",
        flush=True,
    )


def conditions():
    result = {}
    for name, command in [
        ("power", ["pmset", "-g", "batt"]),
        ("thermal", ["pmset", "-g", "therm"]),
        ("processes", ["ps", "-axo", "pid=,ppid=,etime=,comm="]),
        ("swap", ["sysctl", "vm.swapusage"]),
    ]:
        try:
            value = subprocess.run(command, capture_output=True, text=True, timeout=10, check=False)
            result[name] = {
                "returncode": value.returncode,
                "stdout": value.stdout,
                "stderr": value.stderr,
            }
        except (OSError, subprocess.TimeoutExpired) as error:
            result[name] = {"error": str(error)}
    return result


def campaign(phase):
    if hashlib.sha256(BINARY.read_bytes()).hexdigest() != EXPECTED_SHA:
        raise RuntimeError("frozen binary hash mismatch")
    directory = ROOT / "build/audit-api-lfm/physical" / ("final-" + phase)
    directory.mkdir(parents=True, exist_ok=False)
    report = {
        "schema_version": 1,
        "status": "running",
        "parity": False,
        "phase": phase,
        "started_utc": datetime.now(UTC).isoformat(),
        "binary": str(BINARY),
        "binary_sha256": EXPECTED_SHA,
        "model": str(MODEL),
        "cases": [],
        "scope": "K03 prefill/continuation routes; K04 routes only during17forced continuations, not during prefill; storage identities after materialization, not bridge donation; no speed measured",
    }
    report_path = directory / "report.json"
    atomic(report_path, report)
    env = {key: value for key, value in os.environ.items() if not key.startswith("MLXL3_")}
    env["MLXL3_LFM_TEST_MODEL"] = str(MODEL)
    report["environment"] = {
        "MLXL3_LFM_TEST_MODEL": str(MODEL),
        "all_other_inherited_MLXL3_removed": True,
    }
    cases = (
        [
            ("k03", 8, 0, 0),
            ("k03", 266, 17, 0),
            ("passive", 128, 0, 0),
            ("k03", 600, 0, 0),
            ("k03", 600, 17, 0),
        ]
        if phase == "k03"
        else [("k04", 24, 0, 0), ("k04", 24, 0, 1)]
        + [
            ("k04", n, p, m)
            for m in [0, 1]
            for p in [0, 17]
            for n in [23, 24, 255, 256, 257]
            if (n, p) != (24, 0)
        ]
    )
    report["expected_cases"] = len(cases)
    deadline = None if phase == "k03" else time.monotonic() + 900
    long_deadline = None
    try:
        report["conditions_before"] = conditions()
        report["model_metadata"] = {
            name: {
                "sha256": hashlib.sha256((MODEL / name).read_bytes()).hexdigest(),
                "bytes": (MODEL / name).stat().st_size,
            }
            for name in [
                "config.json",
                "model.safetensors.index.json",
                "quantization_config.json",
                "v2-manifest.json",
            ]
        }
        atomic(report_path, report)
        for case in cases:
            kind, length, prefix, mode = case
            if length == 600 and long_deadline is None:
                long_deadline = time.monotonic() + 300
            remaining = long_deadline if length == 600 else deadline
            timeout = (
                min(120 if length == 600 else 60, remaining - time.monotonic())
                if remaining is not None
                else 60
            )
            if timeout <= 0:
                raise TimeoutError("campaign deadline before next case")
            case_env = dict(
                env,
                MLXL3_LFM_TEST_LENGTH=str(length),
                MLXL3_LFM_TEST_PREFIX=str(prefix),
                MLXL3_LFM_MOE_PREFILL=str(mode),
            )
            label = f"{kind}-t{length:03}-p{prefix:02}-m{mode}"
            command = [
                str(BINARY),
                "--ignored",
                "--exact",
                TESTS[kind],
                "--nocapture",
                "--test-threads=1",
            ]
            outcome = joined_command(command, case_env, timeout, directory / (label + ".log"))
            outcome.update(
                label=label, tokens=length, prefix=prefix, mode=mode, timeout_seconds=timeout
            )
            report["cases"].append(outcome)
            try:
                payloads = records(Path(outcome["log"]).read_text())
                if (
                    outcome["status"] != "complete"
                    or outcome.get("returncode") != 0
                    or not outcome["joined"]
                ):
                    raise RuntimeError("child failed or timed out")
                if "1 passed; 0 failed; 0 ignored;" not in Path(outcome["log"]).read_text():
                    raise RuntimeError("zero or incomplete test selection")
                if len(payloads) != 1 or not valid_record(payloads[0], case):
                    raise RuntimeError("missing, incomplete or invalid numerical payload")
                outcome["numerical"] = payloads[0]
                outcome["validated"] = True
            except (ValueError, RuntimeError, TypeError) as error:
                outcome["validated"] = False
                outcome["validation_error"] = str(error)
                atomic(report_path, report)
                raise
            atomic(report_path, report)
            print(
                json.dumps(
                    {
                        "phase": phase,
                        "label": label,
                        "seconds": outcome["seconds"],
                        "validated": True,
                        "numerical": outcome["numerical"],
                    }
                ),
                flush=True,
            )
        report["status"] = "complete"
        report["parity"] = len(report["cases"]) == len(cases) and all(
            case.get("validated") is True for case in report["cases"]
        )
    except BaseException as error:
        report["status"] = "failed"
        report["parity"] = False
        report["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        report["conditions_after"] = conditions()
        report["finished_utc"] = datetime.now(UTC).isoformat()
        report["all_case_children_joined"] = all(
            case.get("joined") is True for case in report["cases"]
        )
        atomic(report_path, report)
        print(
            json.dumps(
                {
                    "report": str(report_path),
                    "status": report["status"],
                    "parity": report["parity"],
                    "cases": len(report["cases"]),
                }
            ),
            flush=True,
        )


if __name__ == "__main__":

    def interrupt(signum, frame):
        raise KeyboardInterrupt(f"signal {signum}")

    signal.signal(signal.SIGTERM, interrupt)
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--phase", choices=["k03", "k04"])
    args = parser.parse_args()
    if args.self_test:
        self_test()
    if args.phase:
        campaign(args.phase)
    if not args.self_test and not args.phase:
        parser.error("choose --self-test or --phase")
