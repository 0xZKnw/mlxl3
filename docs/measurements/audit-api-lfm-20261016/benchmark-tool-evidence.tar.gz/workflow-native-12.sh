ruff format --check benchmarks/benchmark_idle_memory.py tests/test_idle_memory_benchmark.py docs/measurements/memory-saver/check-transitions.py
ruff check benchmarks/benchmark_idle_memory.py tests/test_idle_memory_benchmark.py docs/measurements/memory-saver/check-transitions.py
python -m pytest -q tests/test_idle_memory_benchmark.py
ruff format --check docs/measurements/adaptive-memory-20261009/bridge-boundaries-capture.py
ruff check docs/measurements/adaptive-memory-20261009/bridge-boundaries-capture.py
python -m py_compile docs/measurements/adaptive-memory-20261009/bridge-boundaries-capture.py
ruff format --check docs/measurements/tune-feedback-20261010/diagnose-tune.py
ruff check docs/measurements/tune-feedback-20261010/diagnose-tune.py
python docs/measurements/tune-feedback-20261010/diagnose-tune.py --self-test
