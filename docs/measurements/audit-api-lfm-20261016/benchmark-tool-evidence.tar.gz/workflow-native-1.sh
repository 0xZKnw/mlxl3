rustup toolchain install stable --profile minimal --component rustfmt --component clippy
rustup default stable
