python -m pip install mlx==0.32.2
mlxl3_mlx_root="$(python -c 'import importlib.util; print(next(iter(importlib.util.find_spec("mlx").submodule_search_locations)))')"
export MLXL3_MLX_ROOT="$mlxl3_mlx_root"
cargo clippy --locked --all-targets --features mlx,chat -- -D warnings
cargo build --locked --release --features mlx,chat
