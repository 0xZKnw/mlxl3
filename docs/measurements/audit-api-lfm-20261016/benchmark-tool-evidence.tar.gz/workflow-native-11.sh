ruff format --check benchmarks/eval_lfm25_quality.py tests/test_lfm25_quality.py
ruff check benchmarks/eval_lfm25_quality.py tests/test_lfm25_quality.py
python -m py_compile benchmarks/eval_lfm25_quality.py
python -m pytest -q tests/test_lfm25_quality.py
