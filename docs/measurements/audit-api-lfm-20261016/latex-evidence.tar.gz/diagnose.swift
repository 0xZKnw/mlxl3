import AppKit
import SwiftMath
let formulas = [
  #"\mathbb{E}[T_n] = \sum_{i=0}^{n-1}\mathbb{E}[T_{i+1}-T_i] = e\,n\sum_{i=0}^{n-1}\frac{1}{n-i} = e\,n\left(1+\frac12+\frac13+\dots+\frac1n\right)."#,
  #"\boxed{\mathbb{E}[T_n] \approx e\,n\,\ln n}."#,
  #"1+\frac12+\frac13+\ldots+\frac1n"#,
]
for formula in formulas {
  var error: NSError?
  let list = MTMathListBuilder.build(fromString: formula, error: &error)
  print("\(list != nil ? "parsed" : "failed"): \(error?.localizedDescription ?? "none")")
}
