import AppKit
import SwiftMath
let formulas = [#"\dots"#, #"\boxed{x}"#]
for formula in formulas {
    precondition(MTMathListBuilder.build(fromString: formula) != nil, "Missing standard LaTeX command: \(formula)")
}
print("standard reply commands parsed")
