import AppKit
import SwiftMath
let formulas = [
  #"\mathbb{E}[T_n] = \sum_{i=0}^{n-1}\mathbb{E}[T_{i+1}-T_i] = e\,n\sum_{i=0}^{n-1}\frac{1}{n-i} = e\,n\left(1+\frac12+\frac13+\dots+\frac1n\right)."#,
  #"\boxed{\mathbb{E}[T_n] \approx e\,n\,\ln n}."#,
  #"1+\frac12+\frac13+\ldots+\frac1n"#,
]
for (index, formula) in formulas.enumerated() {
  var error: NSError?
  let list = MTMathListBuilder.build(fromString: formula, error: &error)
  print("\(list != nil ? "parsed" : "failed"): \(error?.localizedDescription ?? "none")")
  let renderer = MTMathImage(latex: formula, fontSize: 24, textColor: .white)
  let (renderError, image) = renderer.asImage()
  precondition(renderError == nil && image != nil)
  let bitmap = NSBitmapImageRep(data: image!.tiffRepresentation!)!
  try! bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: "build/audit-api-lfm/latex/formula-\(index).png"))
}
