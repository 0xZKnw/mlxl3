#!/bin/zsh
set -euo pipefail
out="$PWD/build/audit-api-lfm/latex/remaining"
mkdir -p "$out"
product="$PWD/apps/MLXL3Studio/.build/out/Products/Debug"
args=(-swift-version 6 -parse-as-library -module-cache-path "$out/modules" -sdk /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk -I "$product")
sources=(apps/MLXL3Studio/Sources/MLXL3Studio/*.swift)
sources=("${(@)sources:#*/MLXL3StudioApp.swift}")
response_sources=("${(@)sources:#*/MarkdownResponseView.swift}")
awk '{print}' apps/MLXL3Studio/Sources/MLXL3Studio/MarkdownResponseView.swift tests/response-ui-check.swift > "$out/ResponseUICombined.swift"
swiftc "${args[@]}" -warnings-as-errors -O "${response_sources[@]}" "$product/SwiftMath.o" "$out/ResponseUICombined.swift" -o "$out/response-check"
"$out/response-check" "$PWD/tests/fake-desktop-engine.py"
swiftc "${args[@]}" -warnings-as-errors -O apps/MLXL3Studio/Sources/MLXL3Studio/CLICommand.swift tests/cli-command-check.swift -o "$out/cli-command-check"
"$out/cli-command-check" /Users/justin/Documents/mix-stq1_0/.venv/bin/python
swiftc "${args[@]}" -warnings-as-errors -O apps/MLXL3Studio/Sources/MLXL3Studio/ModelDownloadProgress.swift tests/download-progress-check.swift -o "$out/download-progress-check"
"$out/download-progress-check"
swiftc "${args[@]}" -warnings-as-errors -O apps/MLXL3Studio/Sources/MLXL3Studio/MTPTuning.swift tests/mtp-tuning-check.swift -o "$out/mtp-tuning-check"
"$out/mtp-tuning-check"
swiftc "${args[@]}" -warnings-as-errors -O apps/MLXL3Studio/Sources/MLXL3Studio/MCPConfiguration.swift apps/MLXL3Studio/Sources/MLXL3Studio/Localization.swift tests/mcp-configuration-check.swift -o "$out/mcp-configuration-check"
"$out/mcp-configuration-check"
print "Remaining Desktop checks passed; unchanged preceding checks are in desktop-check-attempt1.log"
