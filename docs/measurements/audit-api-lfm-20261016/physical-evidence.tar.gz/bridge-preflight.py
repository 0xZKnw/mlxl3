from pathlib import Path
import hashlib,json,os,sys,time
sys.path[:0]=[str(Path(__file__).resolve().parents[2]/'scripts'),str(Path(__file__).resolve().parents[2]/'benchmarks')]
from native_json_process import JsonProcess
from compare_native import event,generate
root=Path(__file__).parent;out=root/'physical/bridge-preflight';out.mkdir(exist_ok=False)
binary=(root/'candidate-lfm-01/mlxl3').resolve();model='/Users/justin/Documents/mix-stq1_0/models/LFM2.5-24B-A2B-EXL3-4bpw-v2'
env={k:v for k,v in os.environ.items() if not k.startswith('MLXL3_')};env.update(MLXL3_HOME=str((out/'home').resolve()),MLXL3_LFM_MOE_PREFILL='1',MLXL3_LFM_KV_CAPACITY='0',MLXL3_LFM_PREFILL_TRACE='1')
report={'status':'running','parity':False,'runs':{},'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'flags':{k:v for k,v in env.items() if k.startswith('MLXL3_')},'scope':'template counts and actual bridge microblock dispatch; no performance conclusion'}
def save():
 p=out/'report.tmp';p.write_text(json.dumps(report,indent=2));p.replace(out/'report.json')
save();started=time.monotonic();deadline=started+180
try:
 with (out/'stderr.log').open('w') as stderr:
  with JsonProcess([str(binary),'bridge',model,'--context-length','4096'],stderr=stderr,env=env) as process:
   startup_deadline=min(deadline,time.monotonic()+60)
   report['startup_events']=[]
   while True:
    ready=event(process,startup_deadline)
    report['startup_events'].append(ready);save()
    if ready['type']=='ready':break
   report['ready']=ready
   for name in ('fr-266','code-266','fr-600','code-600'):
    prompt=(root/'prompts'/f'{name}.txt').read_text();run=generate(process,prompt,4,name,45,campaign_deadline=deadline)
    assert type(run['stats']['prompt_tokens']) is int and run['stats']['prompt_tokens']==int(name.rsplit('-',1)[1]),(name,run['stats'])
    report['runs'][name]=run;save()
  assert process.process.returncode==0,('abnormal bridge shutdown',process.process.returncode)
 traces=[]
 for line in (out/'stderr.log').read_text().splitlines():
  try:value=json.loads(line)
  except json.JSONDecodeError:continue
  if value.get('type')=='lfm_prefill_dispatch':traces.append(value)
 assert traces and sum(t['tokens'] for t in traces)==1732
 assert sum(t['router_rows'] for t in traces)==1732*38
 assert all(t['max_block']<=8 for t in traces) and sum(t['grouped_moe_calls'] for t in traces)>0
 report.update(status='complete',parity=True,trace={'records':len(traces),'tokens':sum(t['tokens'] for t in traces),'grouped_graph_calls':sum(t['grouped_moe_calls'] for t in traces),'router_rows':sum(t['router_rows'] for t in traces)},seconds=time.monotonic()-started,exit_code=process.process.returncode)
except BaseException as error:
 report.update(status='failed',parity=False,error={'type':type(error).__name__,'message':str(error)},seconds=time.monotonic()-started);raise
finally:save()
