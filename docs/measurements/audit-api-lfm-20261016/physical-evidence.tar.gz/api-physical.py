"""Bounded physical API journey; run alone after numerical gates, not for timing."""
import hashlib
import http.client
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from native_json_process import JsonProcess

binary, moe_mode, kv_mode, output = sys.argv[1:]
output = Path(output)
output.mkdir(parents=True, exist_ok=False)
model = '/Users/justin/Documents/mix-stq1_0/models/LFM2.5-24B-A2B-EXL3-4bpw-v2'
key = 'mlxl3-physical-fixture'
started = time.monotonic()
deadline = started + 180
report = {'status': 'running', 'parity': False, 'checks': [], 'binary_sha256': hashlib.sha256(Path(binary).read_bytes()).hexdigest(), 'moe_mode': moe_mode, 'kv_mode': kv_mode, 'model': model, 'scope': 'actual HTTP/model finish reason, disconnect after dispatch while busy, recovery, process cleanup; no proof that no model delta or terminal cancellation occurred; not performance or full numeric proof'}
process = None
stderr_path = output / 'server.stderr'

def save():
    temporary = output / 'report.tmp'
    temporary.write_text(json.dumps(report, indent=2))
    temporary.replace(output / 'report.json')

def check(name, value):
    assert value, name
    report['checks'].append(name)
    save()

def request(method, path, body=None, operation_deadline=None):
    request_deadline = min(deadline, time.monotonic() + 30, operation_deadline if operation_deadline is not None else deadline)
    remaining = request_deadline - time.monotonic()
    assert remaining > 0, 'global deadline'
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=min(30, remaining))
    try:
        connection.request(method, path, None if body is None else json.dumps(body), headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
        response = connection.getresponse()
        data = response.read(1024 * 1024 + 1)
        assert len(data) <= 1024 * 1024, 'response bound'
        assert time.monotonic() <= request_deadline, 'late HTTP response'
        return response.status, data
    finally:
        connection.close()

def completion(prompt, stream=False):
    return {'model': model, 'messages': [{'role': 'user', 'content': prompt}], 'max_tokens': 1, 'temperature': 0, 'top_k': 1, 'repetition_penalty': 1, 'stream': stream, 'stream_options': {'include_usage': True}}

save()
try:
    env = {k: v for k, v in os.environ.items() if not k.startswith('MLXL3_')}
    env.update(MLXL3_HOME=str((output / 'home').resolve()), MLXL3_LFM_PREFILL_TRACE='1')
    if moe_mode != 'default': env['MLXL3_LFM_MOE_PREFILL'] = moe_mode
    if kv_mode != 'default': env['MLXL3_LFM_KV_CAPACITY'] = kv_mode
    with stderr_path.open('w') as stderr:
        process = JsonProcess([str(Path(binary).resolve()), 'serve', model, '--host', '127.0.0.1', '--port', '0', '--api-key', key, '--context-length', '4096'], stderr=stderr, env=env)
        ready = process.receive(min(deadline, time.monotonic() + 60))
        check('server ready with real model', ready.get('type') == 'ready' and type(ready.get('port')) is int and ready['port'] > 0)
        port = ready['port']
        rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid='], text=True).splitlines()
        children = [int(row.split()[0]) for row in rows if len(row.split()) == 2 and int(row.split()[1]) == process.process.pid]
        check('resident child owned by server', len(children) == 1)
        status, data = request('GET', '/ready')
        check('ready healthy and free', status == 200 and json.loads(data)['ready'] is True)
        status, data = request('GET', '/v1/capabilities')
        caps = json.loads(data)
        check('capabilities schema', status == 200 and caps.get('schema') == 1)
        status, data = request('POST', '/v1/chat/completions', completion('Écris le mot bonjour.'))
        cold = json.loads(data)
        check('nonstream max_tokens=1 is length', status == 200 and cold['choices'][0]['finish_reason'] == 'length' and type(cold['usage']['completion_tokens']) is int and cold['usage']['completion_tokens'] == 1 and type(cold['usage']['prompt_tokens']) is int and cold['usage']['prompt_tokens'] > 0)
        status, data = request('POST', '/v1/chat/completions', completion('Écris le mot bonjour.', True))
        check('stream status and bound', status == 200 and b'[DONE]' in data)
        events = [json.loads(line[5:]) for line in data.splitlines() if line.startswith(b'data:') and line[5:].strip() != b'[DONE]']
        reasons = [choice['finish_reason'] for event in events for choice in event.get('choices', []) if choice.get('finish_reason') is not None]
        check('stream max_tokens=1 is length', reasons == ['length'] and any(type(event.get('usage', {}).get('completion_tokens')) is int and event['usage']['completion_tokens'] == 1 for event in events if isinstance(event.get('usage'), dict)))
        # Drain the exact trace count of both completed one-token controls, so
        # an old stderr event cannot masquerade as the long request's dispatch.
        until = min(deadline, time.monotonic() + 5)
        while time.monotonic() < until:
            traced_tokens = 0
            for line in stderr_path.read_text().splitlines():
                position = line.find('{')
                if position < 0: continue
                try: value = json.loads(line[position:])
                except json.JSONDecodeError: continue
                if value.get('type') == 'lfm_prefill_dispatch':
                    assert type(value.get('tokens')) is int and value['tokens'] > 0
                    traced_tokens += value['tokens']
            expected_tokens = 2 * cold['usage']['prompt_tokens']
            assert traced_tokens <= expected_tokens, 'extra dispatch in controls'
            if traced_tokens == expected_tokens: break
            time.sleep(0.005)
        else: raise AssertionError('completed control traces did not drain')
        offset = stderr_path.stat().st_size
        long_prompt = (Path(__file__).parent / 'prompts/fr-600.txt').read_text() * 4
        pending = completion(long_prompt, True)
        pending['max_tokens'] = 48
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=30)
        try:
            connection.request('POST', '/v1/chat/completions', json.dumps(pending), headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
            response = connection.getresponse()
            first = response.readline(65537)
            check('stream starts with assistant role', response.status == 200 and first.startswith(b'data:') and json.loads(first[5:])['choices'][0]['delta'].get('role') == 'assistant')
            until = min(deadline, time.monotonic() + 30)
            while time.monotonic() < until:
                with stderr_path.open() as trace:
                    trace.seek(offset)
                    current = trace.read(1024 * 1024 + 1)
                assert len(current) <= 1024 * 1024, 'trace bound'
                if '"type":"lfm_prefill_dispatch"' in current: break
                time.sleep(0.005)
            else: raise AssertionError('no actual microblock dispatch before disconnect')
            status, data = request('GET', '/ready')
            check('actual prefill is busy before disconnect', status == 503 and json.loads(data)['busy'] is True)
            response.close()
        finally:
            connection.close()
        cancelled = time.monotonic()
        recovery_deadline = min(deadline, cancelled + 15)
        while time.monotonic() < recovery_deadline:
            status, data = request('GET', '/ready', operation_deadline=recovery_deadline)
            assert time.monotonic() <= recovery_deadline, 'late recovery response'
            if status == 200 and json.loads(data).get('ready') is True: break
            time.sleep(0.01)
        else: raise AssertionError('not ready within15s after disconnect')
        report['cancel_recovery_seconds'] = time.monotonic() - cancelled
        check('busy request disconnected and ready again within15s', status == 200)
        status, data = request('POST', '/v1/chat/completions', completion('Écris le mot bonjour.'))
        after = json.loads(data)
        check('next request equals cold control', status == 200 and type(after['usage']['completion_tokens']) is int and type(after['usage']['prompt_tokens']) is int and after['choices'] == cold['choices'] and after['usage'] == cold['usage'])
        process.process.send_signal(signal.SIGTERM)
        check('SIGTERM server exits cleanly', process.process.wait(timeout=15) == 0)
        remaining = {int(row.split()[0]) for row in subprocess.check_output(['ps', '-axo', 'pid='], text=True).splitlines() if row.strip()}
        check('resident child reaped', not (set(children) & remaining))
        process.close()
        report.update(status='complete', parity=True, seconds=time.monotonic() - started)
except BaseException as error:
    report.update(status='failed', parity=False, error={'type': type(error).__name__, 'message': str(error)}, seconds=time.monotonic() - started)
    raise
finally:
    if process is not None and process.process.poll() is None:
        process.process.send_signal(signal.SIGTERM)
        try: process.process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.process.kill()
            process.process.wait(timeout=5)
            report.update(status='failed', parity=False, cleanup='server required SIGKILL; outer supervisor must check process group')
    if process is not None: process.close()
    save()
