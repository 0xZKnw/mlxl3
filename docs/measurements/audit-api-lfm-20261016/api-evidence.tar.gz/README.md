# API evidence — 16 October 2026

This archive preserves the four API source files whose SHA-256 exactly matches
api/verification.json, every CPU log recorded by that manifest, the original
pre-fix adapter, and the parent F01 classification test/model-checking logs.
No model weights, private user inputs, credentials, live service data or binaries
are included. Fixtures use disposable fake bridges and non-production keys.

The API sources are a modified local working tree based on commit
2eae717fb0bccc34d6ab0c7e6ca2da8ce1fbb230, not a published release or clean commit.
The source manifest authenticates those four files; it does not authenticate the
entire source tree or a future executable. F01 parent logs describe the actual
CPU classification at that earlier stage. They do not freeze a complete
historical main.rs/contracts.rs source tree; no claim of such identity is made.

33 API fixtures passed. They are included in the later integrated Rust count
121 passed /3 ignored (74 library +14 contract integration +33 API), not33 extra.
The API proof checks65 obligations and3 covers on token usage; parent F01 checks
15 obligations and4 covers on two booleans. The Origin parser attempt timed out
30s and is not proved. The earlier string-inclusive F01 attempt was interrupted;
it remains unproved and its observed elapsed time was not a strict120s timeout.
Tests and bounded checks do not prove all concurrency, Hyper/Tokio, signals,
MLX/Metal, full generation or later K04 changes. Preserved failed preparation
and mutation logs remain failures, even where a later fixed run passed.

Read the versioned api.md and opti.md for protocols, limits and integration state.
The JSON index in this archive lists SHA-256 and size of every other entry.
