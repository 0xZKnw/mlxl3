"""Apply the preregistered paired-median and drift gates; incomplete runs fail closed."""
import json, math, statistics, sys
from pathlib import Path
root=Path(sys.argv[1]);report={'status':'running','qualified':False,'cases':{},'criteria':{'drift_limit_percent':3,'prefill_min_percent':3,'decode_min_percent':-3},'scope':'code266 and FR600 documents only; short27 secondary'}
def save():
 p=root/'analysis.tmp';p.write_text(json.dumps(report,indent=2,allow_nan=False));p.replace(root/'analysis.json')
def metrics(passes,prompt,key):
 vals={label:[p['prompts'][prompt]['runs'][0]['stats'][key] for p in passes if p['label']==label] for label in 'AB'}
 assert all(len(a)==3 and all(type(v) in (int,float) and v>0 and math.isfinite(v) for v in a) for a in vals.values())
 ratios=[]
 for i in (0,2,4):
  pair=passes[i:i+2];assert {p['label'] for p in pair}=={'A','B'}
  a,b=[next(p['prompts'][prompt]['runs'][0]['stats'][key] for p in pair if p['label']==label) for label in 'AB'];ratios.append(b/a)
 return {'values':vals,'drift_percent':{k:100*(v[-1]/v[0]-1) for k,v in vals.items()},'pair_ratios_B_over_A':ratios,'median_pair_change_percent':100*(statistics.median(ratios)-1)}
try:
 save();campaign=json.loads((root/'campaign.json').read_text())
 assert campaign['status']=='complete' and campaign['parity'] is True
 assert abs(campaign['clock_gap_seconds'])<=5 and max(campaign['seconds'],campaign['wall_seconds'])<=900
 for name,count in [('code-266',266),('fr-600',600)]:
  result=json.loads((root/name/'results.json').read_text());passes=result['passes']
  assert result['status']=='complete' and result['parity'] is True and len(passes)==6
  assert all(p['status']=='complete' and p['exit_code']==0 and p['ready']['context_limit']==4096 for p in passes)
  assert all(p['prompts']['document']['runs'][0]['stats']['prompt_tokens']==count for p in passes)
  values={prompt:{m:metrics(passes,prompt,m) for m in ('prefill_tps','decode_tps','ttft_seconds','elapsed_seconds')} for prompt in ('document','short')}
  document=values['document'];stable=all(abs(d)<=3 for m in ('prefill_tps','decode_tps') for d in document[m]['drift_percent'].values())
  qualifies=stable and document['prefill_tps']['median_pair_change_percent']>=3 and document['decode_tps']['median_pair_change_percent']>=-3
  report['cases'][name]={'qualified':qualifies,'stable':stable,'metrics':values}
 report.update(status='complete',qualified=all(v['qualified'] for v in report['cases'].values()))
except BaseException as error:
 report.update(status='failed',qualified=False,error={'type':type(error).__name__,'message':str(error)});raise
finally:save()
print(json.dumps({'status':report['status'],'qualified':report['qualified'],'cases':{k:{'qualified':v['qualified'],'stable':v['stable'],'prefill_change_percent':v['metrics']['document']['prefill_tps']['median_pair_change_percent'],'decode_change_percent':v['metrics']['document']['decode_tps']['median_pair_change_percent']} for k,v in report['cases'].items()}}))
