"""Campaign coordinator: existing tested CLI; one absolute budget and explicit failures."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path.cwd()
mode, order, suffix = sys.argv[1:]
assert mode == 'k03' and order in ('ABBAAB', 'BAABBA')
base = root / 'dist/MLXL3 Desktop.app/Contents/Resources/runtime/mlxl3'
candidate = root / 'dist/MLXL3 Desktop.app/Contents/Resources/runtime/mlxl3'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == 'f4da463b99962eb4132e78e37a8e9498b37ef77913e40e2e0eb59410d6bd2eb7'
assert hashlib.sha256(base.read_bytes()).hexdigest() == 'f4da463b99962eb4132e78e37a8e9498b37ef77913e40e2e0eb59410d6bd2eb7'
out = root / f'docs/measurements/audit-api-lfm-20261016/perf-{mode}-{order.lower()}{suffix}'
out.mkdir(exist_ok=False)
started = time.monotonic()
started_wall = time.time()
deadline = started + 900
report = dict(status='running', parity=None, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), budget_seconds=900, context_limit=4096, mode=mode, order=order, warmup_tokens=256, measured_tokens=128, scope='same binary forced serial/microblocks; document qualification code266 and FR600 only; short27 secondary observation', cases=[])
def save():
    report['seconds'] = time.monotonic() - started
    report['wall_seconds'] = time.time() - started_wall
    report['clock_gap_seconds'] = report['wall_seconds'] - report['seconds']
    tmp = out / 'campaign.json.tmp'
    tmp.write_text(json.dumps(report, indent=2) + '\n')
    tmp.replace(out / 'campaign.json')
def remaining_budget():
    active = time.monotonic() - started
    wall = time.time() - started_wall
    if abs(wall - active) > 5:
        raise RuntimeError('host suspension or clock discontinuity invalidates this campaign')
    remaining = min(900 - active, 900 - wall)
    if remaining <= 0:
        raise TimeoutError('global 900s active/wall campaign budget expired')
    return remaining
env = {k:v for k,v in os.environ.items() if not k.startswith('MLXL3_')}
env['MLXL3_HOME'] = str(root / 'build/audit-api-lfm/timing-home')
try:
    save()
    for name, count in [('code-266',266), ('fr-600',600)]:
        remaining = remaining_budget()
        if remaining <= 0:
            raise TimeoutError('global 900s campaign budget expired')
        args = [sys.executable, 'benchmarks/compare_native.py', '/Users/justin/Documents/mix-stq1_0/models/LFM2.5-24B-A2B-EXL3-4bpw-v2', '--baseline',str(base if mode=='k03' else candidate),'--candidate',str(candidate)]
        flags = [('MLXL3_LFM_MOE_PREFILL', '0' if mode=='k03' else '1', '1'), ('MLXL3_LFM_PREFILL_TRACE','0','0')]
        for key, a, b in flags:
            args += ['--baseline-env',f'{key}={a}','--candidate-env',f'{key}={b}']
        args += ['--output',str(out/name),'--prompt-file',str(root/f'build/audit-api-lfm/prompts/{name}.txt'),'--tokens','128','--warmup-tokens','256','--mtp-depth','0','--dflash-mode','0','--repeats','1','--order',order,'--settle-seconds','2','--load-timeout','120','--request-timeout','120','--campaign-timeout',str(remaining)]
        case = dict(name=name,status='running',command=args)
        report['cases'].append(case)
        save()
        with (out/f'{name}.log').open('w') as log:
            proc = subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            case['supervisor_pid'] = proc.pid
            save()
            try:
                while True:
                    remaining = remaining_budget()
                    try:
                        case['exit'] = proc.wait(timeout=min(0.5, remaining))
                        break
                    except subprocess.TimeoutExpired:
                        continue
                remaining_budget()
            except BaseException:
                try:
                    os.killpg(proc.pid,signal.SIGINT)
                except ProcessLookupError:
                    pass
                try:
                    proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGKILL)
                    proc.wait(timeout=5)
                raise
        try:
            os.killpg(proc.pid,0)
        except ProcessLookupError:
            case['process_group_empty'] = True
        else:
            os.killpg(proc.pid,signal.SIGKILL)
            raise RuntimeError('process group still alive after driver completion')
        assert case['exit']==0, f'{name}: driver exit {case["exit"]}'
        result = json.loads((out/name/'results.json').read_text())
        assert result['status']=='complete' and result['parity'] is True
        assert len(result['passes'])==6
        for p in result['passes']:
            assert p['ready']['context_limit']==4096
            assert p['exit_code']==0 and p['status']=='complete'
            for run in [p['prompts']['document']['warmup'],*p['prompts']['document']['runs']]:
                assert run['stats']['prompt_tokens']==count
        case.update(status='complete',parity=True,summary=result['summary'])
        save()
        print(json.dumps({'case':name,'seconds':report['seconds'],'summary':result['summary']}),flush=True)
    report.update(status='complete',parity=True)
except BaseException as error:
    report.update(status='failed',parity=None,error={'type':type(error).__name__,'message':str(error)})
    if report['cases'] and report['cases'][-1]['status']=='running':
        report['cases'][-1]['status']='failed'
    raise
finally:
    save()
