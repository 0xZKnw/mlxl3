import hashlib, json, math, os, signal, subprocess, time
from pathlib import Path
import numpy as np
R = Path.cwd()
OUT = R/'build/audit-api-lfm/physical/release-numeric'
BIN = R/'dist/MLXL3 Desktop.app/Contents/Resources/runtime/mlxl3'
OLD = R/'build/audit-api-lfm/baseline-0bebf744/mlxl3'
MODEL = Path('/Users/justin/Documents/mix-stq1_0/models/LFM2.5-24B-A2B-EXL3-4bpw-v2')
CONFIG = json.loads((MODEL/'config.json').read_text())
def finite(bits):
    a=np.asarray(bits, dtype=np.uint16)
    assert a.size and np.all((a & 0x7c00)!=0x7c00), 'empty or nonfinite F16'
def validate(row,tokens):
    logits=row['logits']; assert len(logits)==128000
    assert all(type(b) is int and 0<=b<=65535 for b in logits)
    finite(logits)
    expected={}
    for i,kind in enumerate(CONFIG['layer_types']):
        if kind=='full_attention':
            for key in ('keys','values'): expected[f'model.layers.{i}.{key}']=[1,8,tokens,64]
        else: expected[f'model.layers.{i}.conv_state']=[1,2,2048]
    assert len(row['states'])==len(expected)==50
    seen=set()
    for s in row['states']:
        name=s['name']; assert name not in seen and s['shape']==expected[name]; seen.add(name)
        raw=s['data']; assert len(raw)==2*math.prod(s['shape']) and all(type(b) is int and 0<=b<=255 for b in raw)
        finite(np.frombuffer(bytes(raw),dtype='<u2'))
    assert seen==set(expected)
for bad in ([0x7c00],[0xfc00],[0x7e01],[]):
    try: finite(bad)
    except AssertionError: pass
    else: raise AssertionError('finitude mutation escaped')
finite([0,0x8000,0x3c00,0x7bff])
assert hashlib.sha256(BIN.read_bytes()).hexdigest()=='f4da463b99962eb4132e78e37a8e9498b37ef77913e40e2e0eb59410d6bd2eb7'
OUT.mkdir(exist_ok=False)
report={'status':'running','parity':False,'runs':[],'binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest(),'scope':'signed shipped runtime; exact full F16 logits and all50states; numeric qualification, no speed claim'}
def save():
    p=OUT/'report.tmp'; p.write_text(json.dumps(report,indent=2)); p.replace(OUT/'report.json')
def run(name,binary,count,batch,flag):
    env={k:v for k,v in os.environ.items() if not k.startswith(('MLXL3_','MTL_'))}
    env.update(MLXL3_HOME=str(OUT/'home'), MTL_DEBUG_LAYER='1', MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1',MTL_SHADER_VALIDATION_ABORT_ON_FAULT='1')
    if flag is not None: env['MLXL3_LFM_MOE_PREFILL']=str(flag)
    env['MLXL3_LFM_PREFILL_TRACE']='1'
    args=[str(binary),'forward',str(MODEL),'--tokens',','.join(str(101+73*i) for i in range(count)),'--states']+(['--batch'] if batch else [])
    item={'name':name,'command':args,'flags':{k:v for k,v in env.items() if k.startswith(('MLXL3_','MTL_'))},'status':'running'};report['runs'].append(item);save();start=time.monotonic()
    with (OUT/f'{name}.jsonl').open('wb') as stdout, (OUT/f'{name}.stderr').open('wb') as stderr:
        p=subprocess.Popen(args,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try: p.wait(timeout=120)
        finally:
            if p.poll() is None:
                os.killpg(p.pid,signal.SIGKILL); p.wait(timeout=5)
            item.update(exit_code=p.returncode,joined=p.poll() is not None,seconds=time.monotonic()-start)
    assert p.returncode==0,(name,p.returncode)
    rows=[json.loads(line) for line in (OUT/f'{name}.jsonl').read_text().splitlines()]
    assert len(rows)==(1 if batch else count)
    for i,row in enumerate(rows): validate(row,count if batch else i+1)
    item.update(status='complete',positions=len(rows),dump_sha256=hashlib.sha256((OUT/f'{name}.jsonl').read_bytes()).hexdigest());save()
    return rows
try:
    save(); a=run('signed-default-m1-8',BIN,8,False,None)
    assert report['runs'][-1]['dump_sha256']=='9033cb5af618b2d928088a556f71cd58f301ad31296b2685f03f9725bc63263a'
    baseline=run('old-serial-batch65',OLD,65,True,0)
    for flag in (0,1):
        actual=run(f'signed-batch65-{flag}',BIN,65,True,flag)
        assert actual==baseline, f'numeric mismatch flag{flag}'
    trace=[json.loads(s) for s in (OUT/'signed-batch65-1.stderr').read_text().splitlines() if s.startswith('{')]
    trace=[r for r in trace if r.get('type')=='lfm_prefill_dispatch']
    assert trace==[dict(type='lfm_prefill_dispatch',tokens=65,blocks=9,max_block=8,router_rows=2470,grouped_moe_calls=304)],trace
    report.update(status='complete',parity=True,trace=trace)
except BaseException as error:
    report.update(status='failed',parity=False,error={'type':type(error).__name__,'message':str(error)});raise
finally: save()
print(json.dumps({k:v for k,v in report.items() if k!='runs'}))
