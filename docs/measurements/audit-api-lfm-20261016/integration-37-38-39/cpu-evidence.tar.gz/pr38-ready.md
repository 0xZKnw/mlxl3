This adds a deployable BF16-guided router recalibration experiment for LFM2.5 EXL3, with complete checkpoint reloads and strict quality gates. The H100 experiment is complete: **none of the three candidates improved fidelity enough to pass validation**, so V2 remains the published model. These guarded experimental tools and their negative results are being integrated; no candidate is promoted.

The fit uses actual paired BF16 router logits and quantized V2 inputs/logits, masked Top20 ridge in F64, and writes the existing 38 F16 gates. V2 trellises, biases, scales and 29,779 other tensors are preserved. Candidates use their own routes at inference. All three physical exports were reloaded and measured; no teacher decisions are required by the candidate.

| H100 validation, 12,276 labels / 6 domains | KL (BF16 teacher → model) | PPL |
|---|---:|---:|
| V2 | 0.108002630 | 10.999832 |
| Correction 0.25 | 0.107533788 | 11.020998 |
| Correction 0.5 | 0.114167554 | 11.086917 |
| Correction 1 | 0.135970209 | 10.958061 |

Correction 0.25 reduces mean KL only 0.434% and fails the code, multilingual and tiny domain guards. The larger corrections worsen mean KL. Thresholds were registered before the run and remain unchanged. Lower PPL on some labels does not establish greater BF16 fidelity. These scores use a new corpus and Transformers 5.16.1 BF16 causal decode reference; they must not be compared directly to earlier MLX-teacher scores.

The resume took 897.182s, with the completed BF16 reference reused after 53 artifact hashes were checked. Passive 128-token controls are bitexact, and the fixed 176-byte CUDA tune cache is unchanged. The initial failed CUDA cache-shape attempt and its completed BF16 reference are preserved. The fix aligns batch_shape with physical cache capacity without adding input/label tokens. All GPU tasks are stopped.

Validation:
- Final affected CPU suite: 322 passed, 0 skipped. Desktop context without optional Torch/scripts path: 824 passed, 30 skipped. Earlier full Torch suite: 1,258 passed, 1 skipped, with affected checks rerun after changes; suites overlap.
- Tests cover capture/plan integrity, physical export/hash checks, matched teacher/labels, selection boundaries, subprocess interruption/cleanup, failed and partial reports, real CLI imports and cache-page boundaries. The 128/1023 cache failures reproduce before the fix; negative mutations are detected.
- Ruff format/strict lint, Python compilation and real Modal SDK CLI pass. CrossHair locally confirms 12 scalar postconditions with 20s per condition. In CI 3da it confirms 11/12; domain_gate remains unconfirmed after 20s without a counterexample. This does not prove tensor, CUDA, MLX or I/O correctness.
- On executable commit 3da63cb55b7ead34b5ee3f57d0bd0fb775166108, conversion and Regression CI pass; Ubuntu/macOS and the macOS MLX bridge checks pass. Kani was still running at the archived snapshot. The earlier f46 Kani was cancelled for an unknown reason; its workflow limit is 60 minutes, with no 25-minute step timeout found. No Rust source changes are introduced by this experiment.

No candidate was selected, so final chat/CJK and historical/native candidate tests, compaction and publication were not run. No new 24B conversion was repeated: this experiment recalibrates V2 gates at the existing 4bpw recipe. No HF model, release, merge, installed engine or app was changed.

Full results: docs/lfm25-router38-results-2026-10-15.md. Frozen protocol, source SHAs, raw report/score copies, artifact manifest, CPU evidence and GPU/CI logs: docs/measurements/quant-lfm25-router38-20261015/. Large logits and small gate artifacts remain on the private Modal Volume; gate files also remain in local build for reproduction.

Final report commit: bacb69c3c4e3c46b6f1ccb8d1b02a15cdc8f0305. Its diff from executable commit 3da contains only documentation and evidence; the worktree is clean. New-head conversion and Regression workflows are running, Native Rust checks are pending; duplicate push runs were cancelled by workflow concurrency. No final-head global CI success is claimed.

## Integration, 16 October 2026

The user explicitly requested merging PRs 37, 38 and 39. The combined source passes 1,267 Python tests with Pony and CPU Torch present; 64 physical-Metal/Ling checks remain skipped. Format, strict Ruff and compilation pass. CrossHair confirms 29 scalar postconditions in its model; seven string-related conditions remain unconfirmed at 20 seconds each. The initial missing-dependency import failures are preserved separately. Native/Desktop/packaging source is byte-identical to the already qualified PR39 source f75cf254. Historical Kani failure at bacb69c3 is a runner shutdown during dflash_copy_len_17, without a reported counterexample; that harness is not claimed proved. No cloud job, new checkpoint or HF publication is performed by this integration.
