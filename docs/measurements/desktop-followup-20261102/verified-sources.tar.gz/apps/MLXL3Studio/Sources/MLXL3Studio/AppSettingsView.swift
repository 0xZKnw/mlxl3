import SwiftUI

struct AppSettingsView: View {
    @EnvironmentObject private var studio: StudioModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 13) {
                MonogramMark(size: 26)
                VStack(alignment: .leading, spacing: 2) {
                    Text(L("Réglages", "Settings"))
                        .font(.system(size: 24, weight: .regular, design: .serif))
                    Text("MLXL3 Desktop")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(StudioTheme.quiet)
                }
                Spacer()
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .bold))
                        .frame(width: 30, height: 30)
                }
                .buttonStyle(RoundGlassButtonStyle())
            }
            .padding(.horizontal, 26)
            .padding(.top, 25)
            .padding(.bottom, 20)

            Rectangle()
                .fill(StudioTheme.contrast.opacity(0.075))
                .frame(height: 1)

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Label(L("Apparence", "Appearance"), systemImage: "paintpalette")
                        .font(.system(size: 13, weight: .semibold))
                    Picker(L("Thème", "Theme"), selection: Binding(
                        get: { studio.theme }, set: { studio.setTheme($0) }
                    )) {
                        ForEach(AppTheme.allCases, id: \.self) { theme in
                            Text(theme.title).tag(theme)
                        }
                    }
                    .pickerStyle(.segmented)
                    .accessibilityLabel(L("Thème de l’interface", "Interface theme"))
                    Divider()
                    VStack(alignment: .leading, spacing: 10) {
                        Toggle(L("Charger le modèle au démarrage", "Load model on startup"), isOn: Binding(
                            get: { studio.loadModelOnStartup },
                            set: { studio.setLoadModelOnStartup($0) }
                        ))
                        Picker(L("Modèle de démarrage", "Startup model"), selection: Binding(
                            get: { studio.startupModelPath }, set: { studio.setStartupModelPath($0) }
                        )) {
                            Text(L("Dernier modèle sélectionné", "Last selected model")).tag("")
                            ForEach(studio.models) { model in
                                Text(model.name).tag(model.path)
                            }
                            if !studio.startupModelPath.isEmpty && !studio.models.contains(where: { $0.path == studio.startupModelPath }) {
                                Text(L("Modèle indisponible", "Model unavailable")).tag(studio.startupModelPath)
                            }
                        }
                        .disabled(!studio.loadModelOnStartup)
                        if !studio.startupModelPath.isEmpty && !studio.models.contains(where: { $0.path == studio.startupModelPath }) {
                            Text(L("Le modèle choisi n’est plus disponible. Choisis un autre modèle pour le prochain démarrage.", "The selected model is no longer available. Choose another model for the next launch."))
                                .font(.caption).foregroundStyle(StudioTheme.secondary)
                        }
                        Text(L("À l’ouverture de MLXL3, charge le modèle choisi ci-dessus. Sinon, sélectionne un modèle pour le charger. Le changement s’applique au prochain démarrage.", "When MLXL3 opens, loads the model chosen above. Otherwise, select a model to load it. Changes apply on the next launch."))
                            .font(.system(size: 11))
                            .foregroundStyle(StudioTheme.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Divider()
                    VStack(alignment: .leading, spacing: 10) {
                        Toggle(L("Notification de fin de génération", "Generation completion notification"), isOn: Binding(
                            get: { studio.completionNotificationsEnabled },
                            set: { studio.setCompletionNotificationsEnabled($0) }
                        ))
                        Text(L("Préviens-moi lorsque la réponse est terminée et que MLXL3 est en arrière-plan. Le contenu de la conversation n’apparaît pas dans la notification.", "Notify me when the response is complete and MLXL3 is in the background. Conversation content is not included in the notification."))
                            .font(.system(size: 11)).foregroundStyle(StudioTheme.secondary)
                        if let status = studio.notificationStatus {
                            Text(status).font(.caption).foregroundStyle(StudioTheme.secondary)
                        }
                    }
                    Divider()
                    Label(L("Langue de l’app", "App language"), systemImage: "globe")
                        .font(.system(size: 13, weight: .semibold))
                    Picker(L("Langue de l’app", "App language"), selection: Binding(
                        get: { studio.language }, set: { studio.setLanguage($0) }
                    )) {
                        ForEach(AppLanguage.allCases, id: \.self) { language in
                            Text(language.title).tag(language)
                        }
                    }
                    .pickerStyle(.segmented)
                    .accessibilityLabel(L("Langue de l’app", "App language"))
                    Divider()
                    VStack(alignment: .leading, spacing: 10) {
                        Label(L("Déchargement automatique du modèle", "Automatic model unloading"), systemImage: "moon.zzz")
                            .font(.system(size: 13, weight: .semibold))
                        Picker(L("Après une période d’inactivité", "After inactivity"), selection: Binding(
                            get: { studio.modelIdleUnloadDelay },
                            set: { studio.setModelIdleUnloadDelay($0) }
                        )) {
                            ForEach(ModelIdleUnloadDelay.allCases, id: \.self) { delay in
                                Text(delay.title).tag(delay)
                            }
                        }
                        .pickerStyle(.menu)
                        .accessibilityLabel(L("Délai de déchargement automatique", "Automatic unload delay"))
                        Text(L("Libère la mémoire du modèle lorsque tu ne l’utilises plus. Le délai commence après le chargement ou la fin de la dernière utilisation. Les générations et le tuning ne sont jamais interrompus. Tes conversations sont conservées ; sélectionne de nouveau le modèle pour le recharger.", "Frees the model’s memory when it is no longer in use. The delay starts after loading or the last use finishes. Generation and tuning are never interrupted. Your conversations are kept; select the model again to reload it."))
                            .font(.system(size: 11))
                            .foregroundStyle(StudioTheme.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Divider()
                    VStack(alignment: .leading, spacing: 10) {
                        Toggle(L("Économie de mémoire", "Memory saving"), isOn: Binding(
                            get: { studio.memorySaverEnabled },
                            set: { studio.setMemorySaverEnabled($0) }
                        ))
                        .disabled(studio.isGenerating || studio.isTuningMTP || (studio.engineState.isReady && !studio.memorySaverSupported))
                        if studio.engineState.isReady && !studio.memorySaverSupported {
                            Text(L("Mets à jour le moteur pour utiliser cette option.", "Update the engine to use this option."))
                                .font(.system(size: 11))
                                .foregroundStyle(StudioTheme.secondary)
                        }
                        Text(L("Après les prochaines réponses, libère aussi le cache de contexte et les petits buffers inutilisés. Le modèle et tes conversations restent chargés. Le prochain message recalculera son contexte et peut démarrer plus lentement.", "After future responses, also frees the context cache and small unused buffers. The model and your conversations stay loaded. The next message recomputes its context and may start more slowly."))
                            .font(.system(size: 11))
                            .foregroundStyle(StudioTheme.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Divider()
                    HuggingFaceAccountView(library: studio.modelLibrary)
                    HStack {
                        Button(L("Exporter les conversations", "Export conversations"), action: studio.exportConversations)
                        Button(L("Importer des conversations", "Import conversations"), action: studio.importConversations)
                    }
                    Divider()
                    VStack(alignment: .leading, spacing: 12) {
                        Label(L("Flux de données", "Data flow"), systemImage: "lock.shield")
                            .font(.system(size: 13, weight: .semibold))
                        dataFlowRow(
                            L("Inférence et kernels Metal", "Inference and Metal kernels"),
                            L("Toujours sur ce Mac", "Always on this Mac"),
                            "internaldrive"
                        )
                        dataFlowRow(
                            L("Téléchargements et mises à jour", "Downloads and updates"),
                            L("Réseau · Hugging Face et GitHub", "Network · Hugging Face and GitHub"),
                            "network"
                        )
                        dataFlowRow(
                            "MCP",
                            studio.mcpEnabled
                                ? L("Actif · des données peuvent quitter ce Mac", "On · data may leave this Mac")
                                : L("Désactivé", "Off"),
                            studio.mcpEnabled ? "arrow.up.right" : "minus.circle"
                        )
                        Text(L("Un serveur MCP local peut lui-même utiliser Internet. Active uniquement des outils de confiance.", "A local MCP server can itself use the Internet. Enable only tools you trust."))
                            .font(.system(size: 11)).foregroundStyle(StudioTheme.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(16)
                    .background(StudioTheme.contrast.opacity(0.035), in: RoundedRectangle(cornerRadius: 14))
                    .overlay {
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(StudioTheme.contrast.opacity(0.07), lineWidth: 0.7)
                    }
                    Divider()
                    UpdateSettingsCard(
                        updater: studio.updateManager,
                        canInstall: !studio.isGenerating,
                        install: studio.installUpdateAndRestart
                    )

                    VStack(alignment: .leading, spacing: 11) {
                        Label(L("Comment ça marche", "How it works"), systemImage: "shippingbox")
                            .font(.system(size: 13, weight: .semibold))
                        Text(L("Le moteur MLXL3 et l’interface sont livrés dans le même DMG. Une nouvelle release GitHub met donc les deux à jour ensemble, sans désynchroniser leurs versions.", "The MLXL3 engine and interface ship in the same DMG. A GitHub release updates both together, keeping their versions in sync."))
                            .font(.system(size: 12.5, weight: .regular))
                            .foregroundStyle(StudioTheme.secondary)
                            .lineSpacing(4)
                        HStack(spacing: 8) {
                            Label(L("Vérification au démarrage", "Check at startup"), systemImage: "checkmark.circle.fill")
                            Label(L("DMG vérifié en SHA-256", "SHA-256 verified DMG"), systemImage: "lock.shield.fill")
                        }
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(StudioTheme.quiet)
                    }
                    .padding(.vertical, 17)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    Link("Powered by MTPLX", destination: URL(string: "https://github.com/youssofal/MTPLX")!)
                        .font(.system(size: 10)).foregroundStyle(StudioTheme.quiet)
                }
                .padding(26)
            }
        }
        .id(studio.language)
        .frame(width: 650, height: 560)
        .background(StudioTheme.canvas)
        .preferredColorScheme(studio.theme.colorScheme)
    }

    private func dataFlowRow(_ title: String, _ detail: String, _ icon: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .frame(width: 17)
                .foregroundStyle(StudioTheme.quiet)
            Text(title)
                .font(.system(size: 11.5, weight: .medium))
            Spacer()
            Text(detail)
                .font(.system(size: 10.5, weight: .medium))
                .foregroundStyle(StudioTheme.quiet)
        }
    }
}

private struct HuggingFaceAccountView: View {
    @ObservedObject var library: ModelLibrary
    @State private var token = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Hugging Face", systemImage: "key")
            SecureField(L("Token HF pour les modèles privés/gated", "HF token for private/gated models"), text: $token)
                .textFieldStyle(.roundedBorder)
            HStack {
                Button(L("Connexion", "Sign in")) { library.authenticate(token: token); token = "" }.disabled(!token.hasPrefix("hf_") || token.count > 4000)
                Button(L("Déconnexion", "Sign out")) { library.authenticate(token: nil) }
            }
            Text(L("Token enregistré localement par Hugging Face. Accepte aussi la licence du modèle sur son site si nécessaire.", "Token stored locally by Hugging Face. Accept the model license on its website when required."))
                .font(.system(size: 11)).foregroundStyle(StudioTheme.secondary)
            if let message = library.authMessage { Text(message).font(.caption).textSelection(.enabled) }
        }
    }
}

private struct UpdateSettingsCard: View {
    @ObservedObject var updater: UpdateManager
    let canInstall: Bool
    let install: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                        .fill(StudioTheme.contrast.opacity(0.07))
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(StudioTheme.accent)
                }
                .frame(width: 40, height: 40)

                VStack(alignment: .leading, spacing: 4) {
                    Text(L("Mises à jour", "Updates"))
                        .font(.system(size: 15, weight: .bold))
                    Text(L("App \(updater.currentVersion) · Moteur \(updater.currentEngineVersion)", "App \(updater.currentVersion) · Engine \(updater.currentEngineVersion)"))
                        .font(.system(size: 10.5, weight: .medium))
                        .foregroundStyle(StudioTheme.quiet)
                }
                Spacer()
                updateAction
            }

            HStack(spacing: 10) {
                stateIcon
                VStack(alignment: .leading, spacing: 3) {
                    Text(statusTitle)
                        .font(.system(size: 12.5, weight: .semibold))
                    Text(statusDetail)
                        .font(.system(size: 11, weight: .regular))
                        .foregroundStyle(StudioTheme.quiet)
                        .lineLimit(3)
                }
                Spacer(minLength: 0)
            }
            .padding(13)
            .background(Color.black.opacity(0.20), in: RoundedRectangle(cornerRadius: 12))
            .overlay {
                RoundedRectangle(cornerRadius: 12)
                    .stroke(StudioTheme.contrast.opacity(0.07), lineWidth: 0.7)
            }

            HStack(spacing: 10) {
                Image(systemName: "cpu")
                VStack(alignment: .leading, spacing: 3) {
                    Text(L("Moteur indépendant", "Independent engine"))
                        .font(.system(size: 12, weight: .semibold))
                    Text(engineDetail)
                        .font(.system(size: 11))
                        .foregroundStyle(StudioTheme.quiet)
                }
                Spacer()
            }

            if let release = updater.latestRelease,
               updater.hasAppUpdate,
               !release.notes.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                VStack(alignment: .leading, spacing: 7) {
                    HStack {
                        Text(L("NOUVEAUTÉS · \(release.tag.uppercased())", "WHAT’S NEW · \(release.tag.uppercased())"))
                            .font(.system(size: 8.5, weight: .bold))
                            .tracking(1.1)
                            .foregroundStyle(StudioTheme.quiet)
                        Spacer()
                        Button(L("Voir la release", "View release")) { updater.openReleasePage() }
                            .buttonStyle(.plain)
                            .font(.system(size: 10.5, weight: .semibold))
                            .foregroundStyle(StudioTheme.accent)
                    }
                    Text(release.notes)
                        .font(.system(size: 11.5, weight: .regular))
                        .foregroundStyle(StudioTheme.secondary)
                        .lineSpacing(3)
                        .lineLimit(7)
                        .textSelection(.enabled)
                }
            }

            if updater.hasReadyUpdate && !canInstall {
                Text(L("Termine ou arrête la génération avant de redémarrer pour installer.", "Finish or stop generation before restarting to install."))
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(Color.orange.opacity(0.82))
            }
        }
        .padding(.vertical, 12)
    }

    @ViewBuilder
    private var updateAction: some View {
        if updater.hasReadyUpdate && !updater.isBusy {
            Button(action: install) {
                Label(updater.state.readyRelease != nil
                      ? L("Redémarrer et installer", "Restart and install")
                      : L("Installer le moteur", "Install engine"), systemImage: "arrow.clockwise")
                    .font(.system(size: 11, weight: .bold))
                    .padding(.horizontal, 13)
                    .frame(height: 34)
            }
            .buttonStyle(PrimaryGlassButtonStyle())
            .disabled(!canInstall)
        } else if updater.isBusy {
            ProgressView()
                .controlSize(.small)
                .frame(width: 34, height: 34)
        } else {
            Button(action: updater.checkForUpdates) {
                Text(L("Rechercher", "Search"))
                    .font(.system(size: 11, weight: .bold))
                    .padding(.horizontal, 15)
                    .frame(height: 34)
            }
            .buttonStyle(GlassPillButtonStyle())
        }
    }

    private var engineDetail: String {
        switch updater.engineState {
        case .idle: L("Le moteur se met à jour séparément de l’app.", "The engine updates separately from the app.")
        case .checking: L("Recherche d’un nouveau moteur…", "Checking for a new engine…")
        case .upToDate: L("Moteur à jour. L’app et tes modèles sont conservés.", "Engine up to date. Your app and models are preserved.")
        case let .downloading(release): L("Téléchargement du moteur \(release.version)…", "Downloading engine \(release.version)…")
        case let .ready(release, _): L("Moteur \(release.version) vérifié et prêt à installer.", "Engine \(release.version) verified and ready to install.")
        case .installing: L("Validation et activation du moteur…", "Validating and activating engine…")
        case let .failed(message): message
        }
    }

    @ViewBuilder
    private var stateIcon: some View {
        switch updater.state {
        case .checking, .downloading, .installing:
            ProgressView().controlSize(.small)
        case .ready:
            Image(systemName: "arrow.down.circle.fill")
                .foregroundStyle(StudioTheme.accent)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(Color.orange.opacity(0.9))
        case .upToDate:
            Image(systemName: "checkmark.seal.fill")
                .foregroundStyle(Color(red: 0.42, green: 1.0, blue: 0.69))
        case .idle:
            Image(systemName: "circle.dotted")
                .foregroundStyle(StudioTheme.quiet)
        }
    }

    private var statusTitle: String {
        switch updater.state {
        case .idle: L("Prêt à vérifier", "Ready to check")
        case .checking: L("Recherche sur GitHub…", "Checking GitHub…")
        case let .upToDate(date):
            L("MLXL3 est à jour · \(date.formatted(date: .omitted, time: .shortened))", "MLXL3 is up to date · \(date.formatted(date: .omitted, time: .shortened))")
        case let .downloading(release): L("Téléchargement de \(release.tag)…", "Downloading \(release.tag)…")
        case let .ready(release, _): L("\(release.tag) est prête", "\(release.tag) is ready")
        case let .installing(release): L("Préparation de \(release.tag)…", "Preparing \(release.tag)…")
        case .failed: L("Mise à jour impossible", "Update failed")
        }
    }

    private var statusDetail: String {
        switch updater.state {
        case .idle:
            L("Recherche les nouvelles versions du moteur et de l’interface.", "Check for new engine and interface versions.")
        case .checking:
            L("Lecture de la dernière release publique de 0xZKnw/mlxl3.", "Reading the latest public release of 0xZKnw/mlxl3.")
        case .upToDate:
            L("Le moteur et l’interface utilisent la dernière version publiée.", "The engine and interface are up to date.")
        case let .downloading(release):
            L("Le DMG de \(ByteCountFormatter.string(fromByteCount: release.asset.size, countStyle: .file)) est téléchargé en arrière-plan.", "The \(ByteCountFormatter.string(fromByteCount: release.asset.size, countStyle: .file)) DMG is downloading in the background.")
        case .ready:
            L("Le téléchargement et l’empreinte SHA-256 sont validés.", "Download and SHA-256 checksum verified.")
        case .installing:
            L("MLXL3 va se fermer, remplacer l’app puis se relancer automatiquement.", "MLXL3 will close, replace the app, then restart automatically.")
        case let .failed(message):
            message
        }
    }
}

struct UpdateStatusButton: View {
    @ObservedObject var updater: UpdateManager
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack(alignment: .topTrailing) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .frame(width: 30, height: 30)
                if updater.hasAvailableUpdate {
                    Circle()
                        .fill(StudioTheme.accent)
                        .frame(width: 7, height: 7)
                        .overlay(Circle().stroke(StudioTheme.sidebar, lineWidth: 1.5))
                        .offset(x: 1, y: -1)
                }
            }
        }
        .buttonStyle(RoundGlassButtonStyle())
        .help(updater.hasAvailableUpdate ? L("Mise à jour prête", "Update ready") : L("Réglages", "Settings"))
    }
}
